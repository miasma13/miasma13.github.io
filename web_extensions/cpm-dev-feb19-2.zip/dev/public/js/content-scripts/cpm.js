"use strict";
(() => {
  // node_modules/@duckduckgo/autoconsent/dist/autoconsent.esm.js
  var __typeError = (msg) => {
    throw TypeError(msg);
  };
  var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
  var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
  var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
  var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
  var _Tools = class _Tools2 {
    static setBase(base) {
      _Tools2.base = base;
    }
    static findElement(options, parent = null, multiple = false) {
      let possibleTargets = null;
      if (parent != null) {
        possibleTargets = Array.from(parent.querySelectorAll(options.selector));
      } else {
        if (_Tools2.base != null) {
          possibleTargets = Array.from(
            _Tools2.base.querySelectorAll(options.selector)
          );
        } else {
          possibleTargets = Array.from(
            document.querySelectorAll(options.selector)
          );
        }
      }
      if (options.textFilter != null) {
        possibleTargets = possibleTargets.filter((possibleTarget) => {
          const textContent = possibleTarget.textContent.toLowerCase();
          if (Array.isArray(options.textFilter)) {
            let foundText = false;
            for (const text of options.textFilter) {
              if (textContent.indexOf(text.toLowerCase()) !== -1) {
                foundText = true;
                break;
              }
            }
            return foundText;
          } else if (options.textFilter != null) {
            return textContent.indexOf(options.textFilter.toLowerCase()) !== -1;
          }
          return false;
        });
      }
      if (options.styleFilters != null) {
        possibleTargets = possibleTargets.filter((possibleTarget) => {
          const styles = window.getComputedStyle(possibleTarget);
          let keep = true;
          for (const styleFilter of options.styleFilters) {
            const option = styles[styleFilter.option];
            if (styleFilter.negated) {
              keep = keep && option !== styleFilter.value;
            } else {
              keep = keep && option === styleFilter.value;
            }
          }
          return keep;
        });
      }
      if (options.displayFilter != null) {
        possibleTargets = possibleTargets.filter((possibleTarget) => {
          if (options.displayFilter) {
            return possibleTarget.offsetHeight !== 0;
          } else {
            return possibleTarget.offsetHeight === 0;
          }
        });
      }
      if (options.iframeFilter != null) {
        possibleTargets = possibleTargets.filter(() => {
          if (options.iframeFilter) {
            return window.location !== window.parent.location;
          } else {
            return window.location === window.parent.location;
          }
        });
      }
      if (options.childFilter != null) {
        possibleTargets = possibleTargets.filter((possibleTarget) => {
          const oldBase = _Tools2.base;
          _Tools2.setBase(possibleTarget);
          const childResults = _Tools2.find(options.childFilter);
          _Tools2.setBase(oldBase);
          return childResults.target != null;
        });
      }
      if (multiple) {
        return possibleTargets;
      } else {
        if (possibleTargets.length > 1) {
          console.warn(
            "Multiple possible targets: ",
            possibleTargets,
            options,
            parent
          );
        }
        return possibleTargets[0];
      }
    }
    static find(options, multiple = false) {
      const results = [];
      if (options.parent != null) {
        const parent = _Tools2.findElement(options.parent, null, multiple);
        if (parent != null) {
          if (parent instanceof Array) {
            parent.forEach((p) => {
              const targets = _Tools2.findElement(options.target, p, multiple);
              if (targets instanceof Array) {
                targets.forEach((target) => {
                  results.push({
                    parent: p,
                    target
                  });
                });
              } else {
                results.push({
                  parent: p,
                  target: targets
                });
              }
            });
            return results;
          } else {
            const targets = _Tools2.findElement(options.target, parent, multiple);
            if (targets instanceof Array) {
              targets.forEach((target) => {
                results.push({
                  parent,
                  target
                });
              });
            } else {
              results.push({
                parent,
                target: targets
              });
            }
          }
        }
      } else {
        const targets = _Tools2.findElement(options.target, null, multiple);
        if (targets instanceof Array) {
          targets.forEach((target) => {
            results.push({
              parent: null,
              target
            });
          });
        } else {
          results.push({
            parent: null,
            target: targets
          });
        }
      }
      if (results.length === 0) {
        results.push({
          parent: null,
          target: null
        });
      }
      if (multiple) {
        return results;
      } else {
        if (results.length !== 1) {
          console.warn(
            "Multiple results found, even though multiple false",
            results
          );
        }
        return results[0];
      }
    }
  };
  _Tools.base = null;
  var Tools = _Tools;
  function matches(config) {
    const result = Tools.find(config);
    if (config.type === "css") {
      return !!result.target;
    } else if (config.type === "checkbox") {
      return !!result.target && result.target.checked;
    }
  }
  async function executeAction(config, param) {
    switch (config.type) {
      case "click":
        return clickAction(config);
      case "list":
        return listAction(config, param);
      case "consent":
        return consentAction(config, param);
      case "ifcss":
        return ifCssAction(config, param);
      case "waitcss":
        return waitCssAction(config);
      case "foreach":
        return forEachAction(config, param);
      case "hide":
        return hideAction(config);
      case "slide":
        return slideAction(config);
      case "close":
        return closeAction();
      case "wait":
        return waitAction(config);
      case "eval":
        return evalAction(config);
      default:
        throw new Error("Unknown action type: " + config.type);
    }
  }
  var STEP_TIMEOUT = 0;
  function waitTimeout(timeout) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve();
      }, timeout);
    });
  }
  async function clickAction(config) {
    const result = Tools.find(config);
    if (result.target != null) {
      result.target.click();
    }
    return waitTimeout(STEP_TIMEOUT);
  }
  async function listAction(config, param) {
    for (const action of config.actions) {
      await executeAction(action, param);
    }
  }
  async function consentAction(config, consentTypes) {
    for (const consentConfig of config.consents) {
      const shouldEnable = consentTypes.indexOf(consentConfig.type) !== -1;
      if (consentConfig.matcher && consentConfig.toggleAction) {
        const isEnabled = matches(consentConfig.matcher);
        if (isEnabled !== shouldEnable) {
          await executeAction(consentConfig.toggleAction);
        }
      } else {
        if (shouldEnable) {
          await executeAction(consentConfig.trueAction);
        } else {
          await executeAction(consentConfig.falseAction);
        }
      }
    }
  }
  async function ifCssAction(config, param) {
    const result = Tools.find(config);
    if (!result.target) {
      if (config.trueAction) {
        await executeAction(config.trueAction, param);
      }
    } else {
      if (config.falseAction) {
        await executeAction(config.falseAction, param);
      }
    }
  }
  async function waitCssAction(config) {
    await new Promise((resolve) => {
      let numRetries = config.retries || 10;
      const waitTime = config.waitTime || 250;
      const checkCss = () => {
        const result = Tools.find(config);
        if (config.negated && result.target || !config.negated && !result.target) {
          if (numRetries > 0) {
            numRetries -= 1;
            setTimeout(checkCss, waitTime);
          } else {
            resolve();
          }
        } else {
          resolve();
        }
      };
      checkCss();
    });
  }
  async function forEachAction(config, param) {
    const results = Tools.find(config, true);
    const oldBase = Tools.base;
    for (const result of results) {
      if (result.target) {
        Tools.setBase(result.target);
        await executeAction(config.action, param);
      }
    }
    Tools.setBase(oldBase);
  }
  async function hideAction(config) {
    const result = Tools.find(config);
    if (result.target) {
      result.target.classList.add("Autoconsent-Hidden");
    }
  }
  async function slideAction(config) {
    const result = Tools.find(config);
    const dragResult = Tools.find(config.dragTarget);
    if (result.target) {
      const targetBounds = result.target.getBoundingClientRect();
      const dragTargetBounds = dragResult.target.getBoundingClientRect();
      let yDiff = dragTargetBounds.top - targetBounds.top;
      let xDiff = dragTargetBounds.left - targetBounds.left;
      if (this.config.axis.toLowerCase() === "y") {
        xDiff = 0;
      }
      if (this.config.axis.toLowerCase() === "x") {
        yDiff = 0;
      }
      const screenX = window.screenX + targetBounds.left + targetBounds.width / 2;
      const screenY = window.screenY + targetBounds.top + targetBounds.height / 2;
      const clientX = targetBounds.left + targetBounds.width / 2;
      const clientY = targetBounds.top + targetBounds.height / 2;
      const mouseDown = document.createEvent("MouseEvents");
      mouseDown.initMouseEvent(
        "mousedown",
        true,
        true,
        window,
        0,
        screenX,
        screenY,
        clientX,
        clientY,
        false,
        false,
        false,
        false,
        0,
        result.target
      );
      const mouseMove = document.createEvent("MouseEvents");
      mouseMove.initMouseEvent(
        "mousemove",
        true,
        true,
        window,
        0,
        screenX + xDiff,
        screenY + yDiff,
        clientX + xDiff,
        clientY + yDiff,
        false,
        false,
        false,
        false,
        0,
        result.target
      );
      const mouseUp = document.createEvent("MouseEvents");
      mouseUp.initMouseEvent(
        "mouseup",
        true,
        true,
        window,
        0,
        screenX + xDiff,
        screenY + yDiff,
        clientX + xDiff,
        clientY + yDiff,
        false,
        false,
        false,
        false,
        0,
        result.target
      );
      result.target.dispatchEvent(mouseDown);
      await this.waitTimeout(10);
      result.target.dispatchEvent(mouseMove);
      await this.waitTimeout(10);
      result.target.dispatchEvent(mouseUp);
    }
  }
  async function waitAction(config) {
    await waitTimeout(config.waitTime);
  }
  async function closeAction() {
    window.close();
  }
  async function evalAction(config) {
    console.log("eval!", config.code);
    return new Promise((resolve) => {
      try {
        if (config.async) {
          window.eval(config.code);
          setTimeout(() => {
            resolve(window.eval("window.__consentCheckResult"));
          }, config.timeout || 250);
        } else {
          resolve(window.eval(config.code));
        }
      } catch (e) {
        console.warn("eval error", e, config.code);
        resolve(false);
      }
    });
  }
  function getRandomID() {
    if (crypto && typeof crypto.randomUUID !== "undefined") {
      return crypto.randomUUID();
    }
    return Math.random().toString();
  }
  var Deferred = class {
    constructor(id, timeout = 1e3) {
      this.id = id;
      this.promise = new Promise((resolve, reject) => {
        this.resolve = resolve;
        this.reject = reject;
      });
      this.timer = window.setTimeout(() => {
        this.reject(new Error("timeout"));
      }, timeout);
    }
  };
  var evalState = {
    pending: /* @__PURE__ */ new Map(),
    sendContentMessage: null
  };
  function requestEval(code, snippetId) {
    const id = getRandomID();
    evalState.sendContentMessage({
      type: "eval",
      id,
      code,
      snippetId
    });
    const deferred = new Deferred(id);
    evalState.pending.set(deferred.id, deferred);
    return deferred.promise;
  }
  function resolveEval(id, value) {
    const deferred = evalState.pending.get(id);
    if (deferred) {
      evalState.pending.delete(id);
      deferred.timer && window.clearTimeout(deferred.timer);
      deferred.resolve(value);
    } else {
      console.warn("no eval #", id);
    }
  }
  var snippets = {
    // code-based rules
    EVAL_0: () => console.log(1),
    EVAL_CONSENTMANAGER_1: () => window.__cmp && typeof __cmp("getCMPData") === "object",
    EVAL_CONSENTMANAGER_2: () => !__cmp("consentStatus").userChoiceExists,
    EVAL_CONSENTMANAGER_3: () => __cmp("setConsent", 0),
    EVAL_CONSENTMANAGER_4: () => __cmp("setConsent", 1),
    EVAL_CONSENTMANAGER_5: () => __cmp("consentStatus").userChoiceExists,
    EVAL_COOKIEBOT_1: () => !!window.Cookiebot,
    EVAL_COOKIEBOT_2: () => !window.Cookiebot.hasResponse && window.Cookiebot.dialog?.visible === true,
    EVAL_COOKIEBOT_3: () => window.Cookiebot.withdraw() || true,
    EVAL_COOKIEBOT_4: () => window.Cookiebot.hide() || true,
    EVAL_COOKIEBOT_5: () => window.Cookiebot.declined === true,
    EVAL_KLARO_1: () => {
      const config = globalThis.klaroConfig || globalThis.klaro?.getManager && globalThis.klaro.getManager().config;
      if (!config) {
        return true;
      }
      const optionalServices = (config.services || config.apps).filter((s) => !s.required).map((s) => s.name);
      if (klaro && klaro.getManager) {
        const manager = klaro.getManager();
        return optionalServices.every((name) => !manager.consents[name]);
      } else if (klaroConfig && klaroConfig.storageMethod === "cookie") {
        const cookieName = klaroConfig.cookieName || klaroConfig.storageName;
        const consents = JSON.parse(
          decodeURIComponent(
            document.cookie.split(";").find((c) => c.trim().startsWith(cookieName)).split("=")[1]
          )
        );
        return Object.keys(consents).filter((k) => optionalServices.includes(k)).every((k) => consents[k] === false);
      }
    },
    EVAL_KLARO_OPEN_POPUP: () => {
      klaro.show(void 0, true);
    },
    EVAL_KLARO_TRY_API_OPT_OUT: () => {
      if (window.klaro && typeof klaro.show === "function" && typeof klaro.getManager === "function") {
        try {
          klaro.getManager().changeAll(false);
          klaro.getManager().saveAndApplyConsents();
          return true;
        } catch (e) {
          console.warn(e);
          return false;
        }
      }
      return false;
    },
    EVAL_ONETRUST_1: () => window.OnetrustActiveGroups.split(",").filter((s) => s.length > 0).length <= 1,
    EVAL_TRUSTARC_TOP: () => window && window.truste && window.truste.eu.bindMap.prefCookie === "0",
    EVAL_TRUSTARC_FRAME_TEST: () => window && window.QueryString && window.QueryString.preferences === "0",
    EVAL_TRUSTARC_FRAME_GTM: () => window && window.QueryString && window.QueryString.gtm === "1",
    // declarative rules
    EVAL_ADOPT_TEST: () => !!localStorage.getItem("adoptConsentMode"),
    EVAL_ADULTFRIENDFINDER_TEST: () => !!localStorage.getItem("cookieConsent"),
    EVAL_BAHN_TEST: () => utag.gdpr.getSelectedCategories().length === 1,
    EVAL_BIGCOMMERCE_CONSENT_MANAGER_DETECT: () => !!(window.consentManager && window.consentManager.version),
    EVAL_BORLABS_0: () => !JSON.parse(
      decodeURIComponent(
        document.cookie.split(";").find((c) => c.indexOf("borlabs-cookie") !== -1).split("=", 2)[1]
      )
    ).consents.statistics,
    EVAL_CC_BANNER2_0: () => !!document.cookie.match(/sncc=[^;]+D%3Dtrue/),
    EVAL_COINBASE_0: () => JSON.parse(decodeURIComponent(document.cookie.match(/cm_(eu|default)_preferences=([0-9a-zA-Z\\{\\}\\[\\]%:]*);?/)[2])).consent.length <= 1,
    EVAL_COOKIE_LAW_INFO_0: () => {
      if (CLI.disableAllCookies) CLI.disableAllCookies();
      if (CLI.reject_close) CLI.reject_close();
      document.body.classList.remove("cli-barmodal-open");
      return true;
    },
    EVAL_COOKIE_LAW_INFO_DETECT: () => !!window.CLI,
    EVAL_COOKIE_MANAGER_POPUP_0: () => JSON.parse(
      document.cookie.split(";").find((c) => c.trim().startsWith("CookieLevel")).split("=")[1]
    ).social === false,
    EVAL_COOKIEALERT_0: () => document.querySelector("body").removeAttribute("style") || true,
    EVAL_COOKIEALERT_1: () => document.querySelector("body").removeAttribute("style") || true,
    EVAL_COOKIEALERT_2: () => window.CookieConsent.declined === true,
    EVAL_COOKIEFIRST_0: () => ((o) => o.performance === false && o.functional === false && o.advertising === false)(
      JSON.parse(
        decodeURIComponent(
          document.cookie.split(";").find((c) => c.indexOf("cookiefirst") !== -1).trim()
        ).split("=")[1]
      )
    ),
    EVAL_COOKIEFIRST_1: () => document.querySelectorAll("button[data-cookiefirst-accent-color=true][role=checkbox]:not([disabled])").forEach((i) => i.getAttribute("aria-checked") === "true" && i.click()) || true,
    EVAL_COOKIEINFORMATION_0: () => CookieInformation.declineAllCategories() || true,
    EVAL_COOKIEINFORMATION_1: () => CookieInformation.submitAllCategories() || true,
    EVAL_ETSY_0: () => document.querySelectorAll(".gdpr-overlay-body input").forEach((toggle) => {
      toggle.checked = false;
    }) || true,
    EVAL_ETSY_1: () => document.querySelector(".gdpr-overlay-view button[data-wt-overlay-close]").click() || true,
    EVAL_EZOIC_0: () => ezCMP.handleAcceptAllClick(),
    EVAL_FIDES_DETECT_POPUP: () => window.Fides?.initialized,
    EVAL_GDPR_LEGAL_COOKIE_DETECT_CMP: () => !!window.GDPR_LC,
    EVAL_GDPR_LEGAL_COOKIE_TEST: () => !!window.GDPR_LC?.userConsentSetting,
    EVAL_IUBENDA_0: () => document.querySelectorAll(".purposes-item input[type=checkbox]:not([disabled])").forEach((x) => {
      if (x.checked) x.click();
    }) || true,
    EVAL_IUBENDA_1: () => !!document.cookie.match(/_iub_cs-\d+=/),
    EVAL_MEDIAVINE_0: () => document.querySelectorAll('[data-name="mediavine-gdpr-cmp"] input[type=checkbox]').forEach((x) => x.checked && x.click()) || true,
    EVAL_MICROSOFT_0: () => Array.from(document.querySelectorAll("div > button")).filter((el) => el.innerText.match("Reject|Ablehnen"))[0].click() || true,
    EVAL_MICROSOFT_1: () => Array.from(document.querySelectorAll("div > button")).filter((el) => el.innerText.match("Accept|Annehmen"))[0].click() || true,
    EVAL_MICROSOFT_2: () => !!document.cookie.match("MSCC|GHCC"),
    EVAL_MOOVE_0: () => document.querySelectorAll("#moove_gdpr_cookie_modal input").forEach((i) => {
      if (!i.disabled) i.checked = i.name === "moove_gdpr_strict_cookies" || i.id === "moove_gdpr_strict_cookies";
    }) || true,
    EVAL_NHNIEUWS_TEST: () => !!localStorage.getItem("psh:cookies-seen"),
    EVAL_OSANO_DETECT: () => !!window.Osano?.cm?.dialogOpen,
    EVAL_PANDECTES_TEST: () => document.cookie.includes("_pandectes_gdpr=") && JSON.parse(
      atob(
        document.cookie.split(";").find((s) => s.trim().startsWith("_pandectes_gdpr")).split("=")[1]
      )
    ).status === "deny",
    EVAL_POVR_GOBACK: () => window.history.back() || true,
    EVAL_PUBTECH_0: () => document.cookie.includes("euconsent-v2") && (document.cookie.match(/.YAAAAAAAAAAA/) || document.cookie.match(/.aAAAAAAAAAAA/) || document.cookie.match(/.YAAACFgAAAAA/)),
    EVAL_REMARKABLE_TEST: () => !!localStorage.getItem("rmCookieConsent"),
    EVAL_SHOPIFY_TEST: () => document.cookie.includes("gdpr_cookie_consent=0") || document.cookie.includes("_tracking_consent=") && JSON.parse(
      decodeURIComponent(
        document.cookie.split(";").find((s) => s.trim().startsWith("_tracking_consent")).split("=")[1]
      )
    ).purposes.a === false,
    EVAL_SKYSCANNER_TEST: () => document.cookie.match(/gdpr=[^;]*adverts:::false/) && !document.cookie.match(/gdpr=[^;]*init:::true/),
    EVAL_SIRDATA_UNBLOCK_SCROLL: () => {
      document.documentElement.classList.forEach((cls) => {
        if (cls.startsWith("sd-cmp-")) document.documentElement.classList.remove(cls);
      });
      return true;
    },
    EVAL_STEAMPOWERED_0: () => JSON.parse(
      decodeURIComponent(
        document.cookie.split(";").find((s) => s.trim().startsWith("cookieSettings")).split("=")[1]
      )
    ).preference_state === 2,
    EVAL_TAKEALOT_0: () => document.body.classList.remove("freeze") || (document.body.style = "") || true,
    EVAL_TARTEAUCITRON_0: () => tarteaucitron.userInterface.respondAll(false) || true,
    EVAL_TARTEAUCITRON_1: () => tarteaucitron.userInterface.respondAll(true) || true,
    EVAL_TARTEAUCITRON_2: () => document.cookie.match(/tarteaucitron=[^;]*/)?.[0].includes("false"),
    EVAL_TEALIUM_0: () => typeof window.utag !== "undefined" && typeof utag.gdpr === "object",
    EVAL_TEALIUM_1: () => utag.gdpr.setConsentValue(false) || true,
    EVAL_TEALIUM_DONOTSELL: () => utag.gdpr.dns?.setDnsState(false) || true,
    EVAL_TEALIUM_2: () => utag.gdpr.setConsentValue(true) || true,
    EVAL_TEALIUM_3: () => utag.gdpr.getConsentState() !== 1,
    EVAL_TEALIUM_DONOTSELL_CHECK: () => utag.gdpr.dns?.getDnsState() !== 1,
    EVAL_TESTCMP_STEP: () => !!document.querySelector("#reject-all"),
    EVAL_TESTCMP_0: () => window.results.results[0] === "button_clicked",
    EVAL_TESTCMP_COSMETIC_0: () => window.results.results[0] === "banner_hidden",
    EVAL_THEFREEDICTIONARY_0: () => cmpUi.showPurposes() || cmpUi.rejectAll() || true,
    EVAL_THEFREEDICTIONARY_1: () => cmpUi.allowAll() || true,
    EVAL_USERCENTRICS_API_0: () => typeof UC_UI === "object",
    EVAL_USERCENTRICS_API_1: () => !!UC_UI.closeCMP(),
    EVAL_USERCENTRICS_API_2: () => !!UC_UI.denyAllConsents(),
    EVAL_USERCENTRICS_API_3: () => !!UC_UI.acceptAllConsents(),
    EVAL_USERCENTRICS_API_4: () => !!UC_UI.closeCMP(),
    EVAL_USERCENTRICS_API_5: () => UC_UI.areAllConsentsAccepted() === true,
    EVAL_USERCENTRICS_API_6: () => UC_UI.areAllConsentsAccepted() === false,
    EVAL_USERCENTRICS_BUTTON_0: () => JSON.parse(localStorage.getItem("usercentrics")).consents.every((c) => c.isEssential || !c.consentStatus),
    EVAL_WAITROSE_0: () => Array.from(document.querySelectorAll("label[id$=cookies-deny-label]")).forEach((e) => e.click()) || true
  };
  function getFunctionBody(snippetFunc) {
    const snippetStr = snippetFunc.toString();
    return `(${snippetStr})()`;
  }
  function getStyleElement(styleOverrideElementId = "autoconsent-css-rules") {
    const styleSelector = `style#${styleOverrideElementId}`;
    const existingElement = document.querySelector(styleSelector);
    if (existingElement && existingElement instanceof HTMLStyleElement) {
      return existingElement;
    } else {
      const parent = document.head || document.getElementsByTagName("head")[0] || document.documentElement;
      const css = document.createElement("style");
      css.id = styleOverrideElementId;
      parent.appendChild(css);
      return css;
    }
  }
  function getHidingStyle(method) {
    const hidingSnippet = method === "opacity" ? `opacity: 0` : `display: none`;
    return `${hidingSnippet} !important; z-index: -1 !important; pointer-events: none !important;`;
  }
  function hideElements(styleEl, selector, method = "display") {
    const rule = `${selector} { ${getHidingStyle(method)} } `;
    if (styleEl instanceof HTMLStyleElement) {
      styleEl.innerText += rule;
      return selector.length > 0;
    }
    return false;
  }
  async function waitFor(predicate, maxTimes, interval) {
    const result = await predicate();
    if (!result && maxTimes > 0) {
      return new Promise((resolve) => {
        setTimeout(async () => {
          resolve(waitFor(predicate, maxTimes - 1, interval));
        }, interval);
      });
    }
    return Promise.resolve(result);
  }
  function isElementVisible(elem) {
    if (!elem) {
      return false;
    }
    if (elem.offsetParent !== null) {
      return true;
    } else {
      const css = window.getComputedStyle(elem);
      if (css.position === "fixed" && css.display !== "none") {
        return true;
      }
    }
    return false;
  }
  function copyObject(data) {
    if (globalThis.structuredClone) {
      return structuredClone(data);
    }
    return JSON.parse(JSON.stringify(data));
  }
  function normalizeConfig(providedConfig) {
    const defaultConfig = {
      enabled: true,
      autoAction: "optOut",
      // if falsy, the extension will wait for an explicit user signal before opting in/out
      disabledCmps: [],
      enablePrehide: true,
      enableCosmeticRules: true,
      enableGeneratedRules: true,
      enableHeuristicDetection: false,
      enableHeuristicAction: false,
      detectRetries: 20,
      isMainWorld: false,
      prehideTimeout: 2e3,
      enableFilterList: false,
      visualTest: false,
      logs: {
        lifecycle: false,
        rulesteps: false,
        detectionsteps: false,
        evals: false,
        errors: true,
        messages: false,
        waits: false
      }
    };
    const updatedConfig = copyObject(defaultConfig);
    for (const key of Object.keys(defaultConfig)) {
      if (typeof providedConfig[key] !== "undefined") {
        updatedConfig[key] = providedConfig[key];
      }
    }
    return updatedConfig;
  }
  function scheduleWhenIdle(callback, timeout = 500) {
    if (globalThis.requestIdleCallback) {
      requestIdleCallback(callback, { timeout });
    } else {
      setTimeout(callback, 0);
    }
  }
  function highlightNode(node) {
    if (!node.style) return;
    if (node.__oldStyles !== void 0) {
      return;
    }
    if (node.hasAttribute("style")) {
      node.__oldStyles = node.style.cssText;
    }
    node.style.animation = "pulsate .5s infinite";
    node.style.outline = "solid red";
    let styleTag = document.querySelector("style#autoconsent-debug-styles");
    if (!styleTag) {
      styleTag = document.createElement("style");
      styleTag.id = "autoconsent-debug-styles";
    }
    styleTag.textContent = `
      @keyframes pulsate {
        0% {
          outline-width: 8px;
          outline-offset: -4px;
        }
        50% {
          outline-width: 4px;
          outline-offset: -2px;
        }
        100% {
          outline-width: 8px;
          outline-offset: -4px;
        }
      }
    `;
    document.head.appendChild(styleTag);
  }
  function unhighlightNode(node) {
    if (!node.style || !node.hasAttribute("style")) return;
    if (node.__oldStyles !== void 0) {
      node.style.cssText = node.__oldStyles;
      delete node.__oldStyles;
    } else {
      node.removeAttribute("style");
    }
  }
  function isTopFrame() {
    return window.top === window && (!globalThis.location.ancestorOrigins || globalThis.location.ancestorOrigins.length === 0);
  }
  var DETECT_PATTERNS = [
    /accept cookies/gi,
    /accept all/gi,
    /reject all/gi,
    /only necessary cookies/gi,
    // "only necessary" is probably too broad
    /(?:by continuing.{0,100}cookie)|(?:cookie.{0,100}by continuing)/gi,
    /(?:by continuing.{0,100}privacy)|(?:privacy.{0,100}by continuing)/gi,
    /by clicking.{0,100}(?:accept|agree|allow)/gi,
    /we (?:use|serve)(?: optional)? cookies/gi,
    /we are using cookies/gi,
    /use of cookies/gi,
    /(?:this|our) (?:web)?site.{0,100}cookies/gi,
    /cookies (?:and|or) .{0,100} technologies/gi,
    /such as cookies/gi,
    /read more about.{0,100}cookies/gi,
    /consent to.{0,100}cookies/gi,
    /we and our partners.{0,100}cookies/gi,
    /we.{0,100}store.{0,100}information.{0,100}such as.{0,100}cookies/gi,
    /store and\/or access information.{0,100}on a device/gi,
    /personalised ads and content, ad and content measurement/gi,
    // it might be tempting to add the patterns below, but they cause too many false positives. Don't do it :)
    // /cookies? settings/i,
    // /cookies? preferences/i,
    // FR
    /utilisons.{0,100}des.{0,100}cookies/gi,
    /nous.{0,100}utilisons.{0,100}des/gi,
    /des.{0,100}cookies.{0,100}pour/gi,
    /des.{0,100}informations.{0,100}sur/gi,
    /retirer.{0,100}votre.{0,100}consentement/gi,
    /accéder.{0,100}à.{0,100}des/gi,
    /à.{0,100}des.{0,100}informations/gi,
    /et.{0,100}nos.{0,100}partenaires/gi,
    /publicités.{0,100}et.{0,100}du.{0,100}contenu/gi,
    /utilise.{0,100}des.{0,100}cookies/gi,
    /utilisent.{0,100}des.{0,100}cookies/gi,
    /stocker.{0,100}et.{0,100}ou.{0,100}accéder/gi,
    /consentement.{0,100}à.{0,100}tout.{0,100}moment/gi,
    /votre.{0,100}consentement/gi,
    /accepter.{0,100}tout/gi,
    /utilisation.{0,100}des.{0,100}cookies/gi,
    /cookies.{0,100}ou.{0,100}technologies/gi,
    /acceptez.{0,100}l.{0,100}utilisation/gi,
    /continuer sans accepter/gi,
    /tout refuser/gi,
    /(?:refuser|rejeter) tous les cookies/gi,
    /je refuse/gi,
    /refuser et continuer/gi,
    /refuser les cookies/gi,
    /seulement nécessaires/gi,
    /je désactive les finalités non essentielles/gi,
    /cookies essentiels uniquement/gi,
    /nécessaires uniquement/gi,
    // DE
    /wir.{0,100}verwenden.{0,100}cookies/gi,
    /wir.{0,100}und.{0,100}unsere.{0,100}partner/gi,
    /zugriff.{0,100}auf.{0,100}informationen.{0,100}auf/gi,
    /inhalte.{0,100}messung.{0,100}von.{0,100}werbeleistung.{0,100}und/gi,
    /cookies.{0,100}und.{0,100}andere/gi,
    /verwendung.{0,100}von.{0,100}cookies/gi,
    /wir.{0,100}nutzen.{0,100}cookies/gi,
    /verwendet.{0,100}cookies/gi,
    /sie.{0,100}können.{0,100}ihre.{0,100}auswahl/gi,
    /und.{0,100}ähnliche.{0,100}technologien/gi,
    /cookies.{0,100}wir.{0,100}verwenden/gi,
    /alles?.{0,100}ablehnen/gi,
    /(?:nur|nicht).{0,100}(?:zusätzliche|essenzielle|funktionale|notwendige|erforderliche).{0,100}(?:cookies|akzeptieren|erlauben|ablehnen)/gi,
    /weiter.{0,100}(?:ohne|mit).{0,100}(?:einwilligung|zustimmung|cookies)/gi,
    /(?:cookies|einwilligung).{0,100}ablehnen/gi,
    /nur funktionale cookies akzeptieren/gi,
    /optionale ablehnen/gi,
    /zustimmung verweigern/gi,
    // NL
    /gebruik.{0,100}van.{0,100}cookies/gi,
    /(?:we|wij).{0,100}gebruiken.{0,100}cookies.{0,100}om/gi,
    /cookies.{0,100}en.{0,100}vergelijkbare/gi,
    /(?:alles|cookies).{0,100}(?:afwijzen|weigeren|verwerpen)/gi,
    /alleen.{0,100}noodzakelijke?\b/gi,
    /cookies weigeren/gi,
    /weiger.{0,100}(?:cookies|alles)/gi,
    /doorgaan zonder (?:te accepteren|akkoord te gaan)/gi,
    /alleen.{0,100}(?:optionele|functionele|functioneel|noodzakelijke|essentiële).{0,100}cookies/gi,
    /wijs alles af/gi
  ];
  var REJECT_PATTERNS_ENGLISH = [
    // e.g. "i reject cookies", "reject all", "reject all cookies", "reject cookies", "deny all", "deny all cookies", "refuse", "refuse all", "refuse cookies", "refuse all cookies", "deny", "reject all and close", "deny all and close", "reject non-essential cookies", "reject all non-essential cookies and continue", "reject optional cookies", "reject additional cookies", "reject targeting cookies", "reject marketing cookies", "reject analytics cookies", "reject tracking cookies", "reject advertising cookies", "reject all and close", "deny all and close"
    // note that "reject and subscribe" and "reject and pay" are excluded
    /^\s*(i)?\s*(reject|deny|refuse|decline|disable)\s*(all)?\s*(non-essential|optional|additional|targeting|analytics|marketing|unrequired|non-necessary|extra|tracking|advertising)?\s*(cookies)?\s*$/is,
    // e.g. "i do not accept", "i do not accept cookies", "do not accept", "do not accept cookies"
    /^\s*(i)?\s*do\s+not\s+accept\s*(cookies)?\s*$/is,
    // e.g. "continue without accepting", "continue without agreeing", "continue without agreeing →"
    /^\s*(continue|proceed|continue\s+browsing)\s+without\s+(accepting|agreeing|consent|cookies|tracking)(\s*→)?\s*$/is,
    // e.g. "strictly necessary cookies only", "essential cookies only", "required only", "use necessary cookies only", "essentials only"
    // note that "only" is required
    /^\s*(use|accept|allow|continue\s+with)?\s*(strictly)?\s*(necessary|essentials?|required)?\s*(cookies)?\s*only\s*$/is,
    // e.g. "allow essential cookies", "allow necessary", "allow essentials", "allow essentials only"
    // note that "essential" is required
    /^\s*(use|accept|allow|continue\s+with)?\s*(strictly)?\s*(necessary|essentials?|required)\s*(cookies)?\s*$/is,
    // e.g. "accept only essential cookies", "use only necessary cookies", "allow only essential", "only essentials", "continue with only essential cookies"
    // note that "only" is required
    /^\s*(use|accept|allow|continue\s+with)?\s*only\s*(strictly)?\s*(necessary|essentials?|required)?\s*(cookies)?\s*$/is,
    // e.g. "do not sell or share my personal information", "do not sell my personal information"
    // often used in CCPA
    /^\s*do\s+not\s+sell(\s+or\s+share)?\s*my\s*personal\s*information\s*$/is
    // These are impactful, but look error-prone
    // // e.g. "disagree"
    // /^\s*(i)?\s*disagree\s*(and\s+close)?\s*$/i,
    // // e.g. "i do not agree"
    // /^\s*(i\s+)?do\s+not\s+agree\s*$/i,
  ];
  var REJECT_PATTERNS_DUTCH = [
    "weigeren",
    "alles afwijzen",
    "alleen noodzakelijke cookies",
    "afwijzen",
    "alles weigeren",
    "cookies weigeren",
    "alleen noodzakelijk",
    "weiger",
    "weiger cookies",
    "doorgaan zonder te accepteren",
    "alleen functionele cookies",
    "alleen functioneel",
    "alleen noodzakelijke",
    "alleen essenti\xEBle cookies",
    "functioneel",
    "alle cookies verwerpen",
    "doorgaan zonder akkoord te gaan",
    "weiger alles",
    "nee, bedankt",
    "alle cookies weigeren",
    "weiger alle cookies",
    "alleen noodzakelijke cookies accepteren",
    "alleen strikt noodzakelijk",
    "ik weiger",
    "optionele cookies weigeren",
    "alle weigeren",
    "accepteer alleen noodzakelijke cookies",
    "alleen functionele cookies accepteren",
    "enkel noodzakelijke cookies",
    "niet accepteren",
    "weiger niet-essenti\xEBle cookies",
    "weiger niet-noodzakelijke cookies",
    "wijs alles af",
    "alle cookies afwijzen",
    "alleen vereiste cookies",
    "cookies afwijzen",
    "doorgaan zonder accepteren",
    "hier weigeren",
    "weiger alle",
    "aanvaard enkel essenti\xEBle cookies",
    "aanvullende cookies weigeren",
    "accepteren weigeren",
    "alle afwijzen",
    "alle niet functionele afwijzen",
    "alle optionele weigeren",
    "alleen noodzakelijke accepteren",
    "alleen strikt noodzakelijke cookies",
    "allen afwijzen",
    "clear weigeren",
    "enkel functioneel",
    "enkel noodzakelijke cookies aanvaarden",
    "functioneel altijd actief",
    "nee, accepteer alleen de noodzakelijke",
    "nee, geen cookies a.u.b.",
    "nee, weiger cookies",
    "nee, weigeren",
    "niet-noodzakelijke cookies weigeren",
    "optioneel afwijzen",
    "tracking cookies weigeren",
    "weigeren cookies",
    "weigeren?",
    "weigeren.",
    "strikt noodzakelijk",
    "weiger optionele cookies",
    "noodzakelijke cookies",
    "essenti\xEBle cookies",
    "ga verder zonder aanvaarden",
    "doorgaan zonder cookies",
    "accepteer noodzakelijke cookies",
    "noodzakelijke",
    "indien je enkel technisch noodzakelijke cookies wenst te accepteren, klik dan hier",
    "weiger",
    "alleen de noodzakelijke cookies",
    "alleen noodzakelijk",
    "alleen verplichte cookies",
    "ik wil alleen minimale cookies",
    "doorgaan zonder te accepteren",
    "geen cookies toestaan",
    "liever geen cookies",
    "nee, geen persoonlijke cookies",
    "nee, liever geen cookies",
    "ga door zonder te accepteren",
    "verder zonder accepteren",
    "essenti\xEBle accepteren",
    "functionele cookies",
    "strikt noodzakelijke cookies",
    "alleen basic cookies",
    "alleen basiscookies",
    "alleen standaard cookies",
    "alle cookies verwerpen",
    "noodzakelijk",
    "noodzakelijk cookies accepteren",
    "noodzakelijke cookies accepteren",
    "accepteer alleen noodzakelijk",
    "enkel noodzakelijke toestaan",
    "enkel strikt noodzakelijke cookies",
    "ik wijs ze liever af",
    "ik weiger cookies",
    "ik weiger optionele cookies",
    "weiger alle cookies",
    "weiger alle niet-noodzakelijke cookies",
    "weiger alle onnodige cookies",
    "weiger alle optionele",
    "weiger alles",
    "weiger targeting en third party cookies."
  ];
  var REJECT_PATTERNS_FRENCH = [
    "continuer sans accepter",
    "tout refuser",
    "refuser",
    "refuser tous les cookies",
    "je refuse",
    "refuser tout",
    "tout rejeter",
    "refuser et continuer",
    "rejeter",
    "refuser les cookies",
    "cookies n\xE9cessaires uniquement",
    "seulement n\xE9cessaires",
    "rejeter tout",
    "refuser les cookies optionnels",
    "je d\xE9sactive les finalit\xE9s non essentielles",
    "refuser les cookies non n\xE9cessaires",
    "rejeter tous les cookies",
    "cookies essentiels uniquement",
    "n\xE9cessaires uniquement",
    "refuser les cookies non essentiels",
    "tout refuser et fermer",
    "tout refuser sauf les cookies techniques",
    "continuer sans accepter x",
    "je refuse lutilisation de cookies",
    "non merci, seulement des cookies techniques",
    "non, tout refuser",
    "refuser tous les cookies non n\xE9cessaires",
    "rejeter les cookies",
    "uniquement les essentiels",
    "refuser tous",
    "accepter uniquement les n\xE9cessaires",
    "allow anonymous analytics",
    "autoriser les cookies essentiels uniquement",
    "autoriser uniquement les n\xE9cessaires",
    "cookies essentiels seulement",
    "cookies n\xE9cessaires seulement",
    "cookies techniques uniquement",
    "je pr\xE9f\xE8re les rejeter",
    "je refuse :(",
    "je refuse les cookies",
    "je refuse tous les cookies",
    "je refuse tout",
    "ne pas accepter",
    "non, accepter les n\xE9cessaires uniquement",
    "refuser (sauf cookies n\xE9cessaires)",
    "refuser ce cookie",
    "refuser les coockies",
    "refuser les cookies facultatifs",
    "refuser tout, sauf les cookies techniques",
    "refuser toutes",
    "refuser toutes les options",
    "rejeter la banni\xE8re",
    "rejeter les cookies non essentiels",
    "rejeter les cookies optionnels",
    "rejeter tous les non fonctionnels",
    "rejeter tout optionnel",
    "tout refuser, sauf les cookies techniques",
    "uniquement n\xE9cessaires",
    "x continuer sans accepter",
    "strictement n\xE9cessaires",
    "utiliser uniquement les cookies n\xE9cessaires",
    "cookies n\xE9cessaires",
    "accepter uniquement les cookies essentiels",
    "accepter les cookies n\xE9cessaires",
    "uniquement les cookies n\xE9cessaires",
    "autoriser uniquement les cookies essentiels",
    "autoriser uniquement les cookies n\xE9cessaires",
    "si vous ne souhaitez pas accepter les cookies \xE0 lexception des cookies techniquement n\xE9cessaires, veuillez cliquer ici",
    "cookies strictement n\xE9cessaires",
    "accepter les cookies strictement n\xE9cessaires",
    "autoriser les cookies essentiels",
    "non, merci, uniquement les cookies n\xE9cessaires",
    "indispensable uniquement",
    "uniquement autoriser les cookies essentiels",
    "utiliser que les cookies n\xE9cessaires",
    "uniquement les sdk n\xE9cessaires",
    "uniquement n\xE9cessaire",
    "utiliser uniquement les cookies fonctionnels",
    "refus",
    "refusez",
    "naccepter que les cookies indispensables",
    "naccepter que les cookies n\xE9cessaires",
    "naccepter que les cookies techniques",
    "n\xE9cessaires seulement"
  ];
  var REJECT_PATTERNS_GERMAN = [
    "ablehnen",
    "alle ablehnen",
    "nur notwendige cookies",
    "nur essenzielle cookies akzeptieren",
    "nur notwendige cookies verwenden",
    "alles ablehnen",
    "nur notwendige",
    "alle cookies ablehnen",
    "weiter ohne einwilligung",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons nur essenzielle cookies akzeptieren.",
    "cookies ablehnen",
    "optionale cookies ablehnen",
    "nur erforderliche cookies",
    "einwilligung ablehnen",
    "nur erforderliche",
    "nur notwendige cookies zulassen",
    "nur funktionale cookies akzeptieren",
    "nur notwendige cookies akzeptieren",
    "nur notwendige technologien",
    "verweigern",
    "webanalyse ablehnen",
    "weiter ohne zustimmung",
    "optionale ablehnen",
    "nur notwendige akzeptieren",
    "nur funktionale cookies",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons ablehnen.",
    "nur notwendige cookies erlauben",
    "zustimmung verweigern",
    "nein, danke",
    "nur erforderliche cookies akzeptieren",
    "zus\xE4tzliche cookies ablehnen",
    "ablehnen und nur essenzielle cookies akzeptieren",
    "nicht erforderliche ablehnen",
    "nicht essenzielle cookies daten ablehnen",
    "nur technisch notwendige cookies",
    "nur technisch notwendige cookies akzeptieren",
    "ablehnen speichern",
    "alle funktionen ablehnen",
    "alle optionalen cookies ablehnen",
    "alles verweigern",
    "mit erforderlichen einstellungen fortfahren",
    "nicht notwendige ablehnen",
    "notwendige cookies akzeptieren",
    "nur erforderliche technologien",
    "nur essenzielle cookies",
    "nur essenzielle cookies erlauben",
    "technisch nicht notwendige cookies ablehnen",
    "tippen sie zum ablehnen bitte hier",
    "ablehnen deny",
    "fortfahren ohne zu akzeptieren",
    "nur erforderliche akzeptieren",
    "nur notwendige erlauben",
    "ablehnen ...nur technisch notwendige cookies verwendet werden",
    "ablehnen (au\xDFer notwendige cookies)",
    "ablehnen und fortfahren",
    "ablehnen und schlie\xDFen",
    "ablehnen: nur grundfunktionen",
    "akzeptieren nur notwendige cookies",
    "alle ablehnen (au\xDFer notwendige cookies)",
    "alle nicht essenziellen cookies ablehnen",
    "alle nicht notwendigen cookies ablehnen",
    "alle optionale ablehnen",
    "alle optionalen ablehnen",
    "alle verweigern",
    "analyse cookies ablehnen",
    "cookie einstellungenablehnen",
    "erforderliche cookies akzeptieren",
    "erforderliche cookies zulassen",
    "externe inhalte ablehnen",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons ablehnen und nur essenzielle cookies akzeptieren.",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons nicht-essenzielle cookies verweigern.",
    "mit diesem button wird der dialog geschlossen. seine funktionalit\xE4t ist identisch mit der des buttons nur essenzielle akzeptieren.",
    "mit erforderlichen cookies fortfahren",
    "mit notwendigen fortfahren",
    "nein, bitte nicht",
    "nein, ich stimme nicht zu",
    "nicht funktionale cookies ablehnen",
    "nicht notwendige cookies ablehnen",
    "nicht-essenzielle cookies ablehnen",
    "nicht-essenzielle cookies verweigern",
    "notwendige cookies zulassen",
    "nur erforderliche cookies erlauben",
    "nur erforderliche cookies setzen",
    "nur erforderliche cookies verwenden",
    "nur essenzielle akzeptieren",
    "nur notwendige cookies annehmen",
    "nur notwendige cookies speichern",
    "nur notwendige cookies verwenden.",
    "nur notwendige funktionscookies akzeptieren",
    "nur notwendigen cookies zustimmen",
    "nur notwendiges akzeptieren",
    "nur wesentliche cookies annehmen",
    "opt. cookies ablehnen",
    "optionale dienste ablehnen",
    "optionale tools ablehnen",
    "sie alle cookies ablehnen",
    "technisch notwendige annehmen",
    "nur essentielle cookies",
    "nur essentielle",
    "nur funktionale akzeptieren",
    "nur technisch notwendige akzeptieren",
    "nur technisch notwendige daten und cookies ...",
    "nur technisch notwendige zulassen",
    "nur wesentliche",
    "ohne einverst\xE4ndnis fortfahren",
    "ohne einwilligung",
    "ohne zustimmung fortfahren",
    "ohne zustimmung weiter",
    "weiter mit essentiellen cookies",
    "weiter ohne annahme",
    "weiter ohne statistische analyse-cookies",
    "weiter ohne statistische cookies",
    "wesentliche cookies",
    "fortfahren ohne zustimmung"
  ];
  var REJECT_PATTERNS_ITALIAN = [
    "rifiuta",
    "rifiuta cookies",
    "rifiuta i cookie",
    "rifiuta i cookies",
    "rifiuta tutti i cookie",
    "rifiuta tutti i cookies",
    "rifiuta cookie non necessari",
    "rifiuta i cookie non tecnici",
    "rifiuta non necessari",
    "rifiuta tutto",
    "rifiuta tutti",
    "rifiuta e chiudi",
    "chiudi rifiuta tutti i cookie",
    "chiudi e rifiuta tutti i cookie",
    "chiudi e rifiuta tutto",
    "nega",
    "nega tutti",
    "negare",
    "non accetto",
    "accetta solo i necessari",
    "usa solo i cookie necessari",
    "accetta solo necessari",
    "solo necessari",
    "continua senza accettare x",
    "continua senza accettare",
    "rifiutare",
    "rifiutare i cookie",
    "rifiutare tutti i cookie",
    "rifiutare tutti",
    "rifiutare e continuare",
    "installa solo i cookie strettamente necessari",
    "solo cookies tecnici",
    "accetta necessari",
    "solo cookie tecnici",
    "solo cookie necessari",
    "strettamente necessari",
    "tecnici",
    "accetta solo cookie di navigazione",
    "chiudi e prosegui solo con i cookies tecnici necessari",
    "consenti solo i cookie tecnici",
    "solo cookie essenziali",
    "blocca i cookie non essenziali",
    "accetta i cookie necessari",
    "accetta solo cookie tecnici",
    "accetta solo i cookie essenziali",
    "accetta solo i cookie necessari",
    "accetta solo i necessary",
    "accetta i cookie essenziali",
    "accetta cookie tecnici",
    "necessari",
    "usa solo i cookie tecnici",
    "usa solo i necessari",
    "rifiuto",
    "essenziali",
    "accetta cookie essenziali",
    "accetta cookie necessari",
    "accetta solo cookie essenziali",
    "accetta solo cookie necessari",
    "rifiuta cookie non necessari",
    "rifiuta cookie non essenziali",
    "rifiuta i cookie non necessari",
    "rifiuta i cookie non essenziali",
    "rifiuta tutti i cookie e chiudi",
    "rifiuta tutto e chiudi",
    "rifiuta tutti i cookie chiudi",
    "continuare senza accettare",
    "rifiutare cookies",
    "rifiutare i cookies",
    "rifiutare non necessari",
    "rifiutare tutto",
    "rifiutare e chiudere",
    "solo essenziali",
    "solo tecnici",
    "negare tutti"
  ];
  var REJECT_PATTERNS_BRAZILIAN_PORTUGUESE = [
    // (deny)
    /^\s*(rejeitar|recusar|desativar|bloquear|negar|não\s*aceito|não \s*aceitar)\s*$/is,
    // (proceed) (without accepting)
    /^\s*(continuar|prosseguir|seguir)\s*(sem\s*aceitar)\s*$/is,
    // (deny) (everything) (optional)
    /^\s*(rejeitar|recusar|desativar|bloquear|negar|não\s*aceito|não \s*aceitar)\s*(tudo|o)?\s*(opcional|(não[-\s](essencial|funcional|obrigatório|necessário)))?\s*$/is,
    // (deny) (all) (the) (optional) (cookies)
    /^\s*(rejeitar|recusar|desativar|bloquear|negar|não\s*aceito|não \s*aceitar)\s*(todos)?\s*(os)?\s*(cookies)?\s*(opcionais|(não[-\s](essenciais|funcionais|obrigatórios|necessários)))?\s*$/is,
    // (accept) (only) (the) (essential)
    /^\s*(aceitar|utilizar)?\s*(apenas|somente|só)?\s*(o)?\s*(essencial|funcional|obrigatório|necessário)\s*$/is,
    // (accept) (only) (the) (essential) (cookies)
    /^\s*(aceitar|utilizar)?\s*(apenas|somente|só)?\s*(os)?\s*(cookies)?\s*(essenciais|funcionais|obrigatórios|necessários)\s*$/is
  ];
  var REJECT_PATTERNS_SPANISH = [
    "rechazar",
    "rechazar todo",
    "rechazar todas",
    "denegar",
    "rechazar cookies",
    "rechazarlas todas",
    "no acepto",
    "rechazar todas las cookies",
    "rechazar y cerrar",
    "denegar todas",
    "solo necesarias",
    "rechazar cookies opcionales",
    "rechazar opcionales",
    "cookies estrictamente necesarias",
    "aceptar s\xF3lo necesarias",
    "denegar todo",
    "clear rechazar cookies",
    "configurar rechazar cookies",
    "denegar cookies",
    "rechazar y continuar",
    "rechazar las cookies",
    "clear rechazar",
    "denegar todas las cookies",
    "rechazar cookies no esenciales",
    "rechazarlas",
    "no, no acepto",
    "permitir s\xF3lo necesarias",
    "rechazar cookies adicionales",
    "rechazar cookies anal\xEDticas",
    "rechazar no necesarias",
    "rechazar opcional",
    "rechazar todo lo opcional",
    "solo cookies estrictamente necesarias",
    "solo esenciales",
    "x rechazar todas las cookies",
    "solo usar cookies necesarias",
    "solo cookies necesarias",
    "declinar",
    "aceptar solo las cookies esenciales",
    "necesarias",
    "aceptar cookies opcionales",
    "aceptar solo lo necesario",
    "solo funcionales",
    "declinar y cerrar",
    "d\xE9clin",
    "declina",
    "declinar consentimiento",
    "declinar todas",
    "solo las cookies necesarias",
    "nom\xE9s sutilitzen cookies quan \xE9s necessari",
    "no, s\xF3lo las estrictamente necesarias",
    "solo las necesarias",
    "acceptar nom\xE9s les necess\xE0ries",
    "acepta solo las necesarias",
    "aceptar solo lo esencial",
    "aceptar las obligatorias",
    "permitir solo cookies t\xE9cnicas",
    "cookies t\xE9cnicas",
    "permitir solo cookies t\xE9cnicas",
    "usar solo cookies t\xE9cnicas",
    "aceptar solo las esenciales"
  ];
  var REJECT_PATTERNS_SWEDISH = [
    "avvisa",
    "endast n\xF6dv\xE4ndiga",
    "avvisa alla",
    "endast n\xF6dv\xE4ndiga cookies",
    "neka",
    "neka alla",
    "avvisa allt",
    "avvisa alla cookies",
    "till\xE5t bara n\xF6dv\xE4ndiga cookies",
    "bara n\xF6dv\xE4ndiga",
    "bara n\xF6dv\xE4ndiga cookies",
    "till\xE5t bara n\xF6dv\xE4ndiga kakor",
    "endast n\xF6dv\xE4ndiga kakor",
    "till\xE5t endast n\xF6dv\xE4ndiga",
    "forts\xE4tt utan att acceptera",
    "godk\xE4nn endast n\xF6dv\xE4ndiga",
    "acceptera endast n\xF6dv\xE4ndiga",
    "avvisa cookies",
    "till\xE5t endast n\xF6dv\xE4ndiga kakor",
    "acceptera endast n\xF6dv\xE4ndiga cookies",
    "neka kakor",
    "bara n\xF6dv\xE4ndiga kakor",
    "neka alla cookies",
    "anv\xE4nd endast n\xF6dv\xE4ndiga",
    "avvisa alla utom n\xF6dv\xE4ndiga",
    "hantera eller avvisa",
    "neka alla utom n\xF6dv\xE4ndiga kakor",
    "neka och st\xE4ng",
    "till\xE5t bara n\xF6dv\xE4ndiga tj\xE4nster",
    "avvisa alla utom n\xF6dv\xE4ndiga kakor",
    "avvisa alla valfria",
    "godk\xE4nn bara n\xF6dv\xE4ndiga cookies",
    "acceptera endast n\xF6dv\xE4ndiga kakor",
    "anv\xE4nd endast n\xF6dv\xE4ndiga cookies",
    "avvisa alla kakor",
    "avvisa alla valm\xF6jligheter",
    "avvisa ej n\xF6dv\xE4ndiga",
    "avvisa icke-n\xF6dv\xE4ndiga",
    "f\xF6rneka",
    "godk\xE4nn bara n\xF6dv\xE4ndiga",
    "godk\xE4nn bara n\xF6dv\xE4ndiga kakor",
    "godk\xE4nn endast n\xF6dv\xE4ndiga cookies",
    "godk\xE4nn endast n\xF6dv\xE4ndiga kakor",
    "godta endast n\xF6dv\xE4ndiga",
    "jag godk\xE4nner bara n\xF6dv\xE4ndiga kakor",
    "nej, avvisa alla",
    "nej, bara n\xF6dv\xE4ndiga",
    "nej, bara n\xF6dv\xE4ndiga cookies",
    "neka alla utom n\xF6dv\xE4ndiga",
    "neka alla.",
    "neka cookies",
    "neka samtliga",
    "ok, endast n\xF6dv\xE4ndiga",
    "spara endast n\xF6dv\xE4ndiga",
    "st\xE4ng och avvisa",
    "till\xE5t bara n\xF6dv\xE4ndiga",
    "godk\xE4nn n\xF6dv\xE4ndiga kakor",
    "godk\xE4nn n\xF6dv\xE4ndiga",
    "acceptera n\xF6dv\xE4ndiga",
    "strikt n\xF6dv\xE4ndigt",
    "till\xE5t n\xF6dv\xE4ndiga",
    "n\xF6dv\xE4ndiga",
    "enbart n\xF6dv\xE4ndiga",
    "jag godk\xE4nner n\xF6dv\xE4ndiga kakor",
    "acceptera n\xF6dv\xE4ndiga kakor",
    "godk\xE4nn enbart n\xF6dv\xE4ndiga kakor",
    "godk\xE4nn n\xF6dv\xE4ndiga cookies",
    "om du inte vill acceptera andra cookies \xE4n de som \xE4r tekniskt n\xF6dv\xE4ndiga klickar du h\xE4r",
    "acceptera enbart n\xF6dv\xE4ndiga",
    "n\xF6dv\xE4ndiga cookies",
    "jag godk\xE4nner enbart att ni anv\xE4nder n\xF6dv\xE4ndiga cookies",
    "+ strikt n\xF6dv\xE4ndiga cookies",
    "anv\xE4nd enbart n\xF6dv\xE4ndiga cookies",
    "enbart n\xF6dv\xE4ndiga cookies",
    "godk\xE4nn n\xF6dv\xE4ndiga kakor st\xE4ng",
    "ok till n\xF6dv\xE4ndiga",
    "strikt n\xF6dv\xE4ndiga",
    "forts\xE4tt utan att godk\xE4nna",
    "avb\xF6j alla cookies",
    "jag accepterar endast grundl\xE4ggande kakor",
    "nej, jag avb\xF6jer",
    "till\xE5t inte cookies"
  ];
  var REJECT_PATTERNS = [
    ...REJECT_PATTERNS_ENGLISH,
    ...REJECT_PATTERNS_DUTCH,
    ...REJECT_PATTERNS_FRENCH,
    ...REJECT_PATTERNS_GERMAN,
    ...REJECT_PATTERNS_ITALIAN,
    ...REJECT_PATTERNS_BRAZILIAN_PORTUGUESE,
    ...REJECT_PATTERNS_SPANISH,
    ...REJECT_PATTERNS_SWEDISH
  ];
  var NEVER_MATCH_PATTERNS = [
    /pay|subscribe/is,
    /abonneer/is,
    /abonnier/is,
    /abonner/is,
    /abbonati/is,
    /iscriviti/is,
    /abbonare/is,
    /iscrivere/is,
    /sostienici/is,
    /suscribir/is
  ];
  var BUTTON_LIKE_ELEMENT_SELECTOR = 'button, input[type="button"], input[type="submit"], a, [role="button"], [class*="button"]';
  var TEXT_LIMIT = 1e5;
  function checkHeuristicPatterns(allText, detectPatterns = DETECT_PATTERNS) {
    allText = allText.slice(0, TEXT_LIMIT);
    const patterns = [];
    const snippets2 = [];
    for (const p of detectPatterns) {
      const matches2 = allText?.match(p);
      if (matches2) {
        patterns.push(p.toString());
        snippets2.push(...matches2.map((m) => m.substring(0, 200)));
      }
    }
    return { patterns, snippets: snippets2 };
  }
  function getActionablePopups() {
    const popups = getPotentialPopups();
    const result = popups.reduce((acc, popup) => {
      const popupText = popup.text?.trim();
      if (popupText) {
        const { patterns } = checkHeuristicPatterns(popupText);
        if (patterns.length > 0) {
          const { rejectButtons, otherButtons } = classifyButtons(popup.buttons);
          if (rejectButtons.length > 0) {
            acc.push({
              ...popup,
              rejectButtons,
              otherButtons
            });
          }
        }
      }
      return acc;
    }, []);
    return result;
  }
  function classifyButtons(buttons) {
    const rejectButtons = [];
    const otherButtons = [];
    for (const button of buttons) {
      if (isRejectButton(button.text)) {
        rejectButtons.push(button);
      } else {
        otherButtons.push(button);
      }
    }
    return {
      rejectButtons,
      otherButtons
    };
  }
  function isRejectButton(buttonText, rejectPatterns = REJECT_PATTERNS, neverMatchPatterns = NEVER_MATCH_PATTERNS) {
    if (!buttonText) {
      return false;
    }
    const cleanedButtonText = cleanButtonText(buttonText);
    return !neverMatchPatterns.some((p) => p.test(cleanedButtonText)) && rejectPatterns.some((p) => p instanceof RegExp && p.test(cleanedButtonText) || p === cleanedButtonText);
  }
  function cleanButtonText(buttonText) {
    let result = buttonText.toLowerCase();
    result = result.replace(/[“”"'/#&[\]→✕×⟩❯><✗×‘’›«»]+/g, "");
    result = result.replace(
      /[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F1E0}-\u{1F1FF}\u2600-\u26FF\u2700-\u27BF\u{1F900}-\u{1F9FF}\u{1FA70}-\u{1FAFF}]/gu,
      ""
    );
    result = result.replace(/\n+/g, " ");
    result = result.replace(/\s+/g, " ");
    result = result.trim();
    return result;
  }
  function getPotentialPopups() {
    const isFramed = !isTopFrame();
    if (isFramed && window.parent && window.parent !== window.top) {
      return [];
    }
    return collectPotentialPopups(isFramed);
  }
  function collectPotentialPopups(isFramed) {
    let elements = [];
    if (!isFramed) {
      elements = getPopupLikeElements();
    } else {
      const doc = document.body || document.documentElement;
      if (doc && isElementVisible(doc) && doc.innerText) {
        elements.push(doc);
      }
    }
    const potentialPopups = [];
    for (const el of elements) {
      if (el.innerText) {
        potentialPopups.push({
          text: el.innerText,
          element: el,
          buttons: getButtonData(el)
        });
      }
    }
    return potentialPopups;
  }
  function getPopupLikeElements() {
    const walker = document.createTreeWalker(
      document.documentElement,
      NodeFilter.SHOW_ELEMENT,
      // visit only element nodes
      {
        acceptNode(node) {
          if (node.tagName === "BODY") {
            return NodeFilter.FILTER_SKIP;
          }
          const cssPosition = window.getComputedStyle(node).position;
          if ((cssPosition === "fixed" || cssPosition === "sticky") && isElementVisible(node)) {
            return NodeFilter.FILTER_ACCEPT;
          }
          return NodeFilter.FILTER_SKIP;
        }
      }
    );
    const found = [];
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      found.push(node);
    }
    return excludeContainers(found);
  }
  function getButtonData(el) {
    const actionableButtons = excludeContainers(getButtonLikeElements(el)).filter(
      (b) => isElementVisible(b) && !isDisabled(b) && (b.innerText.trim() || // <input> values do not appear in innerText
      b instanceof HTMLInputElement && ["submit", "button"].includes(b.type) && b.value?.trim())
    );
    return actionableButtons.map((b) => ({
      text: (b.innerText || b.textContent || "").trim() || b.value?.trim() || "",
      element: b
    }));
  }
  function getButtonLikeElements(el) {
    return Array.from(el.querySelectorAll(BUTTON_LIKE_ELEMENT_SELECTOR));
  }
  function isDisabled(el) {
    return "disabled" in el && Boolean(el.disabled) || el.hasAttribute("disabled");
  }
  function excludeContainers(elements) {
    const results = [];
    if (elements.length > 0) {
      for (let i = elements.length - 1; i >= 0; i--) {
        let container = false;
        for (let j = 0; j < elements.length; j++) {
          if (i !== j && elements[i].contains(elements[j])) {
            container = true;
            break;
          }
        }
        if (!container) {
          results.push(elements[i]);
        }
      }
    }
    return results;
  }
  var defaultRunContext = {
    main: true,
    frame: false,
    urlPattern: ""
  };
  var AutoConsentCMPBase = class {
    constructor(autoconsentInstance) {
      this.name = "BASERULE";
      this.runContext = defaultRunContext;
      this.autoconsent = autoconsentInstance;
    }
    get hasSelfTest() {
      throw new Error("Not Implemented");
    }
    get isIntermediate() {
      throw new Error("Not Implemented");
    }
    get isCosmetic() {
      throw new Error("Not Implemented");
    }
    mainWorldEval(snippetId) {
      const snippet = snippets[snippetId];
      if (!snippet) {
        this.autoconsent.config.logs.errors && console.warn("Snippet not found", snippetId);
        return Promise.resolve(false);
      }
      const logsConfig = this.autoconsent.config.logs;
      if (this.autoconsent.config.isMainWorld) {
        logsConfig.evals && console.log("inline eval:", snippetId, snippet);
        let result = false;
        try {
          result = !!snippet.call(globalThis);
        } catch (e) {
          logsConfig.evals && console.error("error evaluating rule", snippetId, e);
        }
        return Promise.resolve(result);
      }
      const snippetSrc = getFunctionBody(snippet);
      logsConfig.evals && console.log("async eval:", snippetId, snippetSrc);
      return requestEval(snippetSrc, snippetId).catch((e) => {
        logsConfig.evals && console.error("error evaluating rule", snippetId, e);
        return false;
      });
    }
    checkRunContext() {
      if (!this.checkFrameContext(isTopFrame())) {
        return false;
      }
      if (this.runContext.urlPattern && !this.hasMatchingUrlPattern()) {
        return false;
      }
      return true;
    }
    checkFrameContext(isTop) {
      const runCtx = {
        ...defaultRunContext,
        ...this.runContext
      };
      if (isTop && !runCtx.main) {
        return false;
      }
      if (!isTop && !runCtx.frame) {
        return false;
      }
      return true;
    }
    hasMatchingUrlPattern() {
      return Boolean(this.runContext?.urlPattern && window.location.href.match(this.runContext.urlPattern));
    }
    detectCmp() {
      throw new Error("Not Implemented");
    }
    async detectPopup() {
      return false;
    }
    optOut() {
      throw new Error("Not Implemented");
    }
    optIn() {
      throw new Error("Not Implemented");
    }
    openCmp() {
      throw new Error("Not Implemented");
    }
    async test() {
      return Promise.resolve(true);
    }
    async highlightElements(elements, all = false, delayTimeout = 2e3) {
      if (elements.length === 0) {
        return;
      }
      if (!all) {
        elements = [elements[0]];
      }
      this.autoconsent.sendContentMessage({
        type: "visualDelay",
        timeout: delayTimeout
      });
      for (const el of elements) {
        this.autoconsent.config.logs.rulesteps && console.log("highlighting", el);
        highlightNode(el);
      }
      await this.wait(delayTimeout);
      for (const el of elements) {
        unhighlightNode(el);
      }
    }
    // Implementing DomActionsProvider below:
    async clickElement(element) {
      if (this.autoconsent.config.visualTest) {
        await this.highlightElements([element]);
      }
      this.autoconsent.updateState({ clicks: this.autoconsent.state.clicks + 1 });
      return this.autoconsent.domActions.clickElement(element);
    }
    async click(selector, all = false) {
      if (this.autoconsent.config.visualTest) {
        await this.highlightElements(this.elementSelector(selector), all);
      }
      this.autoconsent.updateState({ clicks: this.autoconsent.state.clicks + 1 });
      return this.autoconsent.domActions.click(selector, all);
    }
    elementExists(selector) {
      return this.autoconsent.domActions.elementExists(selector);
    }
    elementVisible(selector, check) {
      return this.autoconsent.domActions.elementVisible(selector, check);
    }
    waitForElement(selector, timeout) {
      return this.autoconsent.domActions.waitForElement(selector, timeout);
    }
    waitForVisible(selector, timeout, check) {
      return this.autoconsent.domActions.waitForVisible(selector, timeout, check);
    }
    async waitForThenClick(selector, timeout, all) {
      if (this.autoconsent.config.visualTest) {
        await this.highlightElements(this.elementSelector(selector), all);
      }
      this.autoconsent.updateState({ clicks: this.autoconsent.state.clicks + 1 });
      return this.autoconsent.domActions.waitForThenClick(selector, timeout, all);
    }
    wait(ms) {
      return this.autoconsent.domActions.wait(ms);
    }
    hide(selector, method) {
      return this.autoconsent.domActions.hide(selector, method);
    }
    cookieContains(substring) {
      return this.autoconsent.domActions.cookieContains(substring);
    }
    prehide(selector) {
      return this.autoconsent.domActions.prehide(selector);
    }
    undoPrehide() {
      return this.autoconsent.domActions.undoPrehide();
    }
    querySingleReplySelector(selector, parent) {
      return this.autoconsent.domActions.querySingleReplySelector(selector, parent);
    }
    querySelectorChain(selectors) {
      return this.autoconsent.domActions.querySelectorChain(selectors);
    }
    elementSelector(selector) {
      return this.autoconsent.domActions.elementSelector(selector);
    }
    waitForMutation(selector) {
      return this.autoconsent.domActions.waitForMutation(selector);
    }
  };
  var AutoConsentCMP = class extends AutoConsentCMPBase {
    constructor(rule, autoconsentInstance) {
      super(autoconsentInstance);
      this.rule = rule;
      this.name = rule.name;
      this.runContext = rule.runContext || defaultRunContext;
    }
    get hasSelfTest() {
      return !!this.rule.test && this.rule.test.length > 0;
    }
    get isIntermediate() {
      return !!this.rule.intermediate;
    }
    get isCosmetic() {
      return !!this.rule.cosmetic;
    }
    get prehideSelectors() {
      return this.rule.prehideSelectors || [];
    }
    async detectCmp() {
      if (this.rule.detectCmp) {
        return this._runRulesSequentially(this.rule.detectCmp, this.autoconsent.config.logs.detectionsteps);
      }
      return false;
    }
    async detectPopup() {
      if (this.rule.detectPopup) {
        return this._runRulesSequentially(this.rule.detectPopup, this.autoconsent.config.logs.detectionsteps);
      }
      return false;
    }
    async optOut() {
      const logsConfig = this.autoconsent.config.logs;
      if (this.rule.optOut) {
        logsConfig.lifecycle && console.log("Initiated optOut()", this.rule.optOut);
        return this._runRulesSequentially(this.rule.optOut, this.autoconsent.config.logs.rulesteps);
      }
      return false;
    }
    async optIn() {
      const logsConfig = this.autoconsent.config.logs;
      if (this.rule.optIn) {
        logsConfig.lifecycle && console.log("Initiated optIn()", this.rule.optIn);
        return this._runRulesSequentially(this.rule.optIn, this.autoconsent.config.logs.rulesteps);
      }
      return false;
    }
    async openCmp() {
      if (this.rule.openCmp) {
        return this._runRulesSequentially(this.rule.openCmp, this.autoconsent.config.logs.rulesteps);
      }
      return false;
    }
    async test() {
      if (this.hasSelfTest && this.rule.test) {
        return this._runRulesSequentially(this.rule.test, this.autoconsent.config.logs.rulesteps);
      }
      return super.test();
    }
    async evaluateRuleStep(rule) {
      const results = [];
      const logsConfig = this.autoconsent.config.logs;
      if (rule.exists) {
        results.push(this.elementExists(rule.exists));
      }
      if (rule.visible) {
        results.push(this.elementVisible(rule.visible, rule.check));
      }
      if (rule.eval) {
        const res = this.mainWorldEval(rule.eval);
        results.push(res);
      }
      if (rule.waitFor) {
        results.push(this.waitForElement(rule.waitFor, rule.timeout));
      }
      if (rule.waitForVisible) {
        results.push(this.waitForVisible(rule.waitForVisible, rule.timeout, rule.check));
      }
      if (rule.click) {
        results.push(this.click(rule.click, rule.all));
      }
      if (rule.waitForThenClick) {
        results.push(this.waitForThenClick(rule.waitForThenClick, rule.timeout, rule.all));
      }
      if (rule.wait) {
        results.push(this.wait(rule.wait));
      }
      if (rule.hide) {
        results.push(this.hide(rule.hide, rule.method));
      }
      if (rule.cookieContains) {
        results.push(this.cookieContains(rule.cookieContains));
      }
      if (rule.if) {
        if (!rule.if.exists && !rule.if.visible) {
          console.error("invalid conditional rule", rule.if);
          return false;
        }
        if (!rule.then) {
          console.error('invalid conditional rule, missing "then" step', rule.if);
          return false;
        }
        const condition = await this.evaluateRuleStep(rule.if);
        logsConfig.rulesteps && console.log("Condition is", condition);
        if (condition) {
          results.push(this._runRulesSequentially(rule.then, logsConfig.rulesteps));
        } else if (rule.else) {
          results.push(this._runRulesSequentially(rule.else, logsConfig.rulesteps));
        } else {
          results.push(true);
        }
      }
      if (rule.any) {
        let resultOfAny = false;
        for (const step of rule.any) {
          if (await this.evaluateRuleStep(step)) {
            resultOfAny = true;
            break;
          }
        }
        results.push(resultOfAny);
      }
      if (results.length === 0) {
        logsConfig.errors && console.warn("Unrecognized rule", rule);
        return false;
      }
      const all = await Promise.all(results);
      const result = all.reduce((a, b) => a && b, true);
      if (rule.negated) {
        return !result;
      }
      return result;
    }
    async _runRulesParallel(rules) {
      const results = rules.map((rule) => this.evaluateRuleStep(rule));
      const detections = await Promise.all(results);
      return detections.every((r) => !!r);
    }
    async _runRulesSequentially(rules, logSteps = true) {
      for (const rule of rules) {
        logSteps && console.log("Running rule...", rule);
        const result = await this.evaluateRuleStep(rule);
        logSteps && console.log("...rule result", result);
        if (!result && !rule.optional) {
          return false;
        }
      }
      return true;
    }
  };
  var AutoConsentHeuristicCMP = class extends AutoConsentCMPBase {
    constructor(autoconsentInstance) {
      super(autoconsentInstance);
      this.popups = [];
      this.name = "HEURISTIC";
      this.runContext = {
        main: true,
        frame: false
        // do not run in iframes for security reasons
      };
    }
    get hasSelfTest() {
      return true;
    }
    get isIntermediate() {
      return false;
    }
    get isCosmetic() {
      return false;
    }
    detectCmp() {
      this.popups = getActionablePopups();
      if (this.popups.length > 0) {
        return Promise.resolve(true);
      }
      return Promise.resolve(false);
    }
    async detectPopup() {
      if (this.popups.length > 0) {
        if (this.popups.length > 1 || this.popups[0].rejectButtons && this.popups[0].rejectButtons.length > 1) {
          this.autoconsent.config.logs.errors && console.warn("Heuristic found multiple reject buttons");
        }
        return true;
      }
      return false;
    }
    optOut() {
      const button = this.popups[0]?.rejectButtons?.[0];
      if (button) {
        return this.clickElement(button.element);
      }
      return Promise.resolve(false);
    }
    optIn() {
      throw new Error("Not Implemented");
    }
    openCmp() {
      throw new Error("Not Implemented");
    }
    async test() {
      const button = this.popups[0].rejectButtons?.[0];
      if (button) {
        await this.wait(500);
        return !isElementVisible(button.element);
      }
      return false;
    }
  };
  var ConsentOMaticCMP = class {
    constructor(name, config) {
      this.name = name;
      this.config = config;
      this.methods = /* @__PURE__ */ new Map();
      this.runContext = defaultRunContext;
      this.isCosmetic = false;
      config.methods.forEach((methodConfig) => {
        if (methodConfig.action) {
          this.methods.set(methodConfig.name, methodConfig.action);
        }
      });
      this.hasSelfTest = false;
    }
    get isIntermediate() {
      return false;
    }
    checkRunContext() {
      return true;
    }
    checkFrameContext(isTop) {
      return true;
    }
    hasMatchingUrlPattern() {
      return false;
    }
    async detectCmp() {
      const matchResults = this.config.detectors.map((detectorConfig) => matches(detectorConfig.presentMatcher));
      return matchResults.some((r) => !!r);
    }
    async detectPopup() {
      const matchResults = this.config.detectors.map((detectorConfig) => matches(detectorConfig.showingMatcher));
      return matchResults.some((r) => !!r);
    }
    async executeAction(method, param) {
      if (this.methods.has(method)) {
        return executeAction(this.methods.get(method), param);
      }
      return true;
    }
    async optOut() {
      await this.executeAction("HIDE_CMP");
      await this.executeAction("OPEN_OPTIONS");
      await this.executeAction("HIDE_CMP");
      await this.executeAction("DO_CONSENT", []);
      await this.executeAction("SAVE_CONSENT");
      return true;
    }
    async optIn() {
      await this.executeAction("HIDE_CMP");
      await this.executeAction("OPEN_OPTIONS");
      await this.executeAction("HIDE_CMP");
      await this.executeAction("DO_CONSENT", ["D", "A", "B", "E", "F", "X"]);
      await this.executeAction("SAVE_CONSENT");
      return true;
    }
    async openCmp() {
      await this.executeAction("HIDE_CMP");
      await this.executeAction("OPEN_OPTIONS");
      return true;
    }
    async test() {
      return true;
    }
  };
  var SUPPORTED_RULE_STEP_VERSION = 1;
  var cookieSettingsButton = "#truste-show-consent";
  var shortcutOptOut = "#truste-consent-required";
  var shortcutOptIn = "#truste-consent-button";
  var popupContent = "#truste-consent-content";
  var bannerOverlay = "#trustarc-banner-overlay";
  var bannerContainer = "#truste-consent-track";
  var TrustArcTop = class extends AutoConsentCMPBase {
    constructor(autoconsentInstance) {
      super(autoconsentInstance);
      this.name = "TrustArc-top";
      this.prehideSelectors = [".trustarc-banner-container", `.truste_popframe,.truste_overlay,.truste_box_overlay,${bannerContainer}`];
      this.runContext = {
        main: true,
        frame: false
      };
      this._shortcutButton = null;
      this._optInDone = false;
    }
    get hasSelfTest() {
      return true;
    }
    get isIntermediate() {
      if (this._optInDone) {
        return false;
      }
      return !this._shortcutButton;
    }
    get isCosmetic() {
      return false;
    }
    async detectCmp() {
      const result = this.elementExists(`${cookieSettingsButton},${bannerContainer}`);
      if (result) {
        this._shortcutButton = document.querySelector(shortcutOptOut);
      }
      return result;
    }
    async detectPopup() {
      return this.elementVisible(`${popupContent},${bannerOverlay},${bannerContainer}`, "any");
    }
    async optOut() {
      if (this._shortcutButton) {
        this._shortcutButton.click();
        return true;
      }
      hideElements(getStyleElement(), `.truste_popframe, .truste_overlay, .truste_box_overlay, ${bannerContainer}`);
      await this.click(cookieSettingsButton);
      setTimeout(() => {
        getStyleElement().remove();
      }, 1e4);
      return true;
    }
    async optIn() {
      this._optInDone = true;
      return await this.click(shortcutOptIn);
    }
    async openCmp() {
      return true;
    }
    async test() {
      await this.wait(500);
      return await this.mainWorldEval("EVAL_TRUSTARC_TOP");
    }
  };
  var TrustArcFrame = class extends AutoConsentCMPBase {
    constructor() {
      super(...arguments);
      this.name = "TrustArc-frame";
      this.runContext = {
        main: false,
        frame: true,
        urlPattern: "^https://consent-pref\\.trustarc\\.com/\\?"
      };
    }
    get hasSelfTest() {
      return true;
    }
    get isIntermediate() {
      return false;
    }
    get isCosmetic() {
      return false;
    }
    async detectCmp() {
      return true;
    }
    async detectPopup() {
      return this.elementVisible("#defaultpreferencemanager", "any") && this.elementVisible(".mainContent", "any");
    }
    async navigateToSettings() {
      await waitFor(
        async () => {
          return this.elementExists(".shp") || this.elementVisible(".advance", "any") || this.elementExists(".switch span:first-child");
        },
        10,
        500
      );
      if (this.elementExists(".shp")) {
        await this.click(".shp");
      }
      await this.waitForElement(".prefPanel", 5e3);
      if (this.elementVisible(".advance", "any")) {
        await this.click(".advance");
      }
      return await waitFor(() => this.elementVisible(".switch span:first-child", "any"), 5, 1e3);
    }
    async optOut() {
      if (await this.mainWorldEval("EVAL_TRUSTARC_FRAME_TEST")) {
        return true;
      }
      let timeout = 3e3;
      if (await this.mainWorldEval("EVAL_TRUSTARC_FRAME_GTM")) {
        timeout = 1500;
      }
      await waitFor(() => document.readyState === "complete", 20, 100);
      await this.waitForElement(".mainContent[aria-hidden=false]", timeout);
      if (await this.click(".rejectAll")) {
        return true;
      }
      if (this.elementExists(".prefPanel")) {
        await this.waitForElement('.prefPanel[style="visibility: visible;"]', timeout);
      }
      if (await this.click("#catDetails0")) {
        await this.click(".submit");
        this.waitForThenClick("#gwt-debug-close_id", timeout);
        return true;
      }
      if (await this.click(".required")) {
        this.waitForThenClick("#gwt-debug-close_id", timeout);
        return true;
      }
      await this.navigateToSettings();
      await this.click(".switch span:nth-child(1):not(.active)", true);
      await this.click(".submit");
      this.waitForThenClick("#gwt-debug-close_id", timeout * 10);
      return true;
    }
    async optIn() {
      if (await this.click(".call")) {
        return true;
      }
      await this.navigateToSettings();
      await this.click(".switch span:nth-child(2)", true);
      await this.click(".submit");
      this.waitForElement("#gwt-debug-close_id", 3e5).then(() => {
        this.click("#gwt-debug-close_id");
      });
      return true;
    }
    async test() {
      await this.wait(500);
      return await this.mainWorldEval("EVAL_TRUSTARC_FRAME_TEST");
    }
  };
  var Cookiebot = class extends AutoConsentCMPBase {
    constructor() {
      super(...arguments);
      this.name = "Cybotcookiebot";
      this.prehideSelectors = [
        "#CybotCookiebotDialog,#CybotCookiebotDialogBodyUnderlay,#dtcookie-container,#cookiebanner,#cb-cookieoverlay,.modal--cookie-banner,#cookiebanner_outer,#CookieBanner"
      ];
    }
    get hasSelfTest() {
      return true;
    }
    get isIntermediate() {
      return false;
    }
    get isCosmetic() {
      return false;
    }
    async detectCmp() {
      return await this.mainWorldEval("EVAL_COOKIEBOT_1");
    }
    async detectPopup() {
      return this.mainWorldEval("EVAL_COOKIEBOT_2");
    }
    async optOut() {
      await this.wait(500);
      let res = await this.mainWorldEval("EVAL_COOKIEBOT_3");
      await this.wait(1e3);
      res = res && await this.mainWorldEval("EVAL_COOKIEBOT_4");
      return res;
    }
    async optIn() {
      if (this.elementExists("#dtcookie-container")) {
        return await this.click(".h-dtcookie-accept");
      }
      await this.click(".CybotCookiebotDialogBodyLevelButton:not(:checked):enabled", true);
      await this.click("#CybotCookiebotDialogBodyLevelButtonAccept");
      await this.click("#CybotCookiebotDialogBodyButtonAccept");
      return true;
    }
    async test() {
      await this.wait(500);
      return await this.mainWorldEval("EVAL_COOKIEBOT_5");
    }
  };
  var SourcePoint = class extends AutoConsentCMPBase {
    constructor() {
      super(...arguments);
      this.name = "Sourcepoint-frame";
      this.prehideSelectors = ["div[id^='sp_message_container_'],.message-overlay", "#sp_privacy_manager_container"];
      this.ccpaNotice = false;
      this.ccpaPopup = false;
      this.runContext = {
        main: true,
        frame: true
      };
    }
    get hasSelfTest() {
      return false;
    }
    get isIntermediate() {
      return false;
    }
    get isCosmetic() {
      return false;
    }
    async detectCmp() {
      const url = new URL(location.href);
      if (url.searchParams.has("message_id") && url.hostname === "ccpa-notice.sp-prod.net") {
        this.ccpaNotice = true;
        return true;
      }
      if (url.hostname === "ccpa-pm.sp-prod.net") {
        this.ccpaPopup = true;
        return true;
      }
      return (url.pathname === "/index.html" || url.pathname === "/privacy-manager/index.html" || url.pathname === "/ccpa_pm/index.html" || url.pathname === "/us_pm/index.html") && (url.searchParams.has("message_id") || url.searchParams.has("requestUUID") || url.searchParams.has("consentUUID"));
    }
    async detectPopup() {
      if (this.ccpaNotice) {
        return true;
      }
      if (this.ccpaPopup) {
        return await this.waitForElement(".priv-save-btn", 2e3);
      }
      await this.waitForElement(
        ".sp_choice_type_11,.sp_choice_type_12,.sp_choice_type_13,.sp_choice_type_ACCEPT_ALL,.sp_choice_type_SAVE_AND_EXIT",
        2e3
      );
      return !this.elementExists(".sp_choice_type_9");
    }
    async optIn() {
      await this.waitForElement(".sp_choice_type_11,.sp_choice_type_ACCEPT_ALL", 2e3);
      if (await this.click(".sp_choice_type_11")) {
        return true;
      }
      if (await this.click(".sp_choice_type_ACCEPT_ALL")) {
        return true;
      }
      return false;
    }
    isManagerOpen() {
      return location.pathname === "/privacy-manager/index.html" || location.pathname === "/ccpa_pm/index.html";
    }
    async optOut() {
      await this.wait(500);
      const logsConfig = this.autoconsent.config.logs;
      if (this.ccpaPopup) {
        const toggles = document.querySelectorAll(
          ".priv-purpose-container .sp-switch-arrow-block a.neutral.on .right"
        );
        for (const t of toggles) {
          t.click();
        }
        const switches = document.querySelectorAll(
          ".priv-purpose-container .sp-switch-arrow-block a.switch-bg.on"
        );
        for (const t of switches) {
          t.click();
        }
        return await this.click(".priv-save-btn");
      }
      if (this.elementVisible(".sp_choice_type_SE", "any")) {
        await this.click(
          [
            "xpath///div[contains(., 'Do not share my personal information') and contains(@class, 'switch-container')]",
            ".pm-switch[aria-checked=false] .slider"
          ],
          false
        );
        return await this.click(".sp_choice_type_SE");
      }
      if (!this.isManagerOpen()) {
        const actionable = await this.waitForVisible('.sp_choice_type_12,.sp_choice_type_13,[data-choice="1739968508799"]');
        if (!actionable) {
          return false;
        }
        if (!this.elementExists('.sp_choice_type_12,[data-choice="1739968508799"]')) {
          return await this.click(".sp_choice_type_13");
        }
        await this.click('.sp_choice_type_12,[data-choice="1739968508799"]');
        await waitFor(() => this.isManagerOpen(), 200, 100);
      }
      await this.waitForElement(".type-modal", 2e4);
      if (this.elementExists("[role=tablist]")) {
        await this.waitForElement("[role=tablist] [role=tab]", 1e4);
      }
      this.waitForThenClick(".ccpa-stack .pm-switch[aria-checked=true] .slider", 500, true);
      try {
        const rejectSelector1 = ".sp_choice_type_REJECT_ALL";
        const rejectSelector2 = ".reject-toggle";
        const path = await Promise.race([
          this.waitForElement(rejectSelector1, 2e3).then((success) => success ? 0 : -1),
          this.waitForElement(rejectSelector2, 2e3).then((success) => success ? 1 : -1),
          this.waitForElement(".pm-features", 2e3).then((success) => success ? 2 : -1)
        ]);
        if (path === 0) {
          await this.waitForVisible(rejectSelector1);
          return await this.click(rejectSelector1);
        } else if (path === 1) {
          await this.click(rejectSelector2);
        } else if (path === 2) {
          await this.waitForElement(".pm-features", 1e4);
          await this.click(".checked > span", true);
          await this.click(".chevron");
        }
      } catch (e) {
        logsConfig.errors && console.warn(e);
      }
      return await this.click(".sp_choice_type_SAVE_AND_EXIT");
    }
  };
  var ConsentManager = class extends AutoConsentCMPBase {
    constructor() {
      super(...arguments);
      this.name = "consentmanager.net";
      this.prehideSelectors = ["#cmpbox,#cmpbox2"];
      this.apiAvailable = false;
    }
    get hasSelfTest() {
      return this.apiAvailable;
    }
    get isIntermediate() {
      return false;
    }
    get isCosmetic() {
      return false;
    }
    async detectCmp() {
      this.apiAvailable = await this.mainWorldEval("EVAL_CONSENTMANAGER_1");
      if (!this.apiAvailable) {
        return this.elementExists("#cmpbox");
      } else {
        return true;
      }
    }
    async detectPopup() {
      if (this.apiAvailable) {
        await this.wait(500);
        return await this.mainWorldEval("EVAL_CONSENTMANAGER_2");
      }
      return this.elementVisible("#cmpbox .cmpmore", "any");
    }
    async optOut() {
      await this.wait(500);
      if (this.apiAvailable) {
        return await this.mainWorldEval("EVAL_CONSENTMANAGER_3");
      }
      if (await this.click(".cmpboxbtnno")) {
        return true;
      }
      if (this.elementExists(".cmpwelcomeprpsbtn")) {
        await this.click(".cmpwelcomeprpsbtn > a[aria-checked=true]", true);
        await this.click(".cmpboxbtnsave");
        return true;
      }
      await this.click(".cmpboxbtncustom");
      await this.waitForElement(".cmptblbox", 2e3);
      await this.click(".cmptdchoice > a[aria-checked=true]", true);
      await this.click(".cmpboxbtnyescustomchoices");
      this.hide("#cmpwrapper,#cmpbox", "display");
      return true;
    }
    async optIn() {
      if (this.apiAvailable) {
        return await this.mainWorldEval("EVAL_CONSENTMANAGER_4");
      }
      return await this.click(".cmpboxbtnyes");
    }
    async test() {
      if (this.apiAvailable) {
        return await this.mainWorldEval("EVAL_CONSENTMANAGER_5");
      }
      return false;
    }
  };
  var Evidon = class extends AutoConsentCMPBase {
    constructor() {
      super(...arguments);
      this.name = "Evidon";
    }
    get hasSelfTest() {
      return false;
    }
    get isIntermediate() {
      return false;
    }
    get isCosmetic() {
      return false;
    }
    async detectCmp() {
      return this.elementExists("#_evidon_banner");
    }
    async detectPopup() {
      return this.elementVisible("#_evidon_banner", "any");
    }
    async optOut() {
      if (await this.click("#_evidon-decline-button")) {
        return true;
      }
      hideElements(getStyleElement(), "#evidon-prefdiag-overlay,#evidon-prefdiag-background,#_evidon-background");
      await this.waitForThenClick("#_evidon-option-button");
      await this.waitForElement("#evidon-prefdiag-overlay", 5e3);
      await this.wait(500);
      await this.waitForThenClick("#evidon-prefdiag-decline");
      return true;
    }
    async optIn() {
      return await this.click("#_evidon-accept-button");
    }
  };
  var Onetrust = class extends AutoConsentCMPBase {
    constructor() {
      super(...arguments);
      this.name = "Onetrust";
      this.prehideSelectors = ["#onetrust-banner-sdk,#onetrust-consent-sdk,.onetrust-pc-dark-filter,.js-consent-banner"];
    }
    get hasSelfTest() {
      return true;
    }
    get isIntermediate() {
      return false;
    }
    get isCosmetic() {
      return false;
    }
    async detectCmp() {
      return this.elementExists("#onetrust-banner-sdk,#onetrust-pc-sdk");
    }
    async detectPopup() {
      return this.elementVisible("#onetrust-banner-sdk,#onetrust-pc-sdk", "any");
    }
    async optOut() {
      if (this.elementVisible("#onetrust-reject-all-handler,.ot-pc-refuse-all-handler,.js-reject-cookies", "any")) {
        return await this.click("#onetrust-reject-all-handler,.ot-pc-refuse-all-handler,.js-reject-cookies");
      }
      if (this.elementExists("#onetrust-pc-btn-handler")) {
        await this.click("#onetrust-pc-btn-handler");
      } else {
        await this.click(".ot-sdk-show-settings,button.js-cookie-settings");
      }
      await this.waitForElement("#onetrust-consent-sdk", 2e3);
      await this.wait(1e3);
      await this.click("#onetrust-consent-sdk input.category-switch-handler:checked,.js-editor-toggle-state:checked", true);
      await this.wait(1e3);
      await this.waitForElement(".save-preference-btn-handler,.js-consent-save", 2e3);
      await this.click(".save-preference-btn-handler,.js-consent-save");
      await this.waitForVisible("#onetrust-banner-sdk", 5e3, "none");
      return true;
    }
    async optIn() {
      return await this.click("#onetrust-accept-btn-handler,#accept-recommended-btn-handler,.js-accept-cookies");
    }
    async test() {
      return await waitFor(() => this.mainWorldEval("EVAL_ONETRUST_1"), 10, 500);
    }
  };
  var Klaro = class extends AutoConsentCMPBase {
    constructor() {
      super(...arguments);
      this.name = "Klaro";
      this.prehideSelectors = [".klaro"];
      this.settingsOpen = false;
    }
    get hasSelfTest() {
      return true;
    }
    get isIntermediate() {
      return false;
    }
    get isCosmetic() {
      return false;
    }
    async detectCmp() {
      if (this.elementExists(".klaro > .cookie-modal")) {
        this.settingsOpen = true;
        return true;
      }
      return this.elementExists(".klaro > .cookie-notice");
    }
    async detectPopup() {
      return this.elementVisible(".klaro > .cookie-notice,.klaro > .cookie-modal", "any");
    }
    async optOut() {
      const apiOptOutSuccess = await this.mainWorldEval("EVAL_KLARO_TRY_API_OPT_OUT");
      if (apiOptOutSuccess) {
        return true;
      }
      if (await this.click(".klaro .cn-decline")) {
        return true;
      }
      await this.mainWorldEval("EVAL_KLARO_OPEN_POPUP");
      if (await this.click(".klaro .cn-decline")) {
        return true;
      }
      await this.click(
        ".cm-purpose:not(.cm-toggle-all) > input:not(.half-checked,.required,.only-required),.cm-purpose:not(.cm-toggle-all) > div > input:not(.half-checked,.required,.only-required)",
        true
      );
      return await this.click(".cm-btn-accept,.cm-button");
    }
    async optIn() {
      if (await this.click(".klaro .cm-btn-accept-all")) {
        return true;
      }
      if (this.settingsOpen) {
        await this.click(".cm-purpose:not(.cm-toggle-all) > input.half-checked", true);
        return await this.click(".cm-btn-accept");
      }
      return await this.click(".klaro .cookie-notice .cm-btn-success");
    }
    async test() {
      return await this.mainWorldEval("EVAL_KLARO_1");
    }
  };
  var Uniconsent = class extends AutoConsentCMPBase {
    constructor() {
      super(...arguments);
      this.name = "Uniconsent";
    }
    get prehideSelectors() {
      return [".unic", ".modal:has(.unic)"];
    }
    get hasSelfTest() {
      return true;
    }
    get isIntermediate() {
      return false;
    }
    get isCosmetic() {
      return false;
    }
    async detectCmp() {
      return this.elementExists(".unic .unic-box,.unic .unic-bar,.unic .unic-modal");
    }
    async detectPopup() {
      return this.elementVisible(".unic .unic-box,.unic .unic-bar,.unic .unic-modal", "any");
    }
    async optOut() {
      await this.waitForElement(".unic button", 1e3);
      document.querySelectorAll(".unic button").forEach((button) => {
        const text = button.textContent;
        if (text.includes("Manage Options") || text.includes("Optionen verwalten")) {
          button.click();
        }
      });
      if (await this.waitForElement(".unic input[type=checkbox]", 1e3)) {
        await this.waitForElement(".unic button", 1e3);
        document.querySelectorAll(".unic input[type=checkbox]").forEach((c) => {
          if (c.checked) {
            c.click();
          }
        });
        for (const b of document.querySelectorAll(".unic button")) {
          const text = b.textContent;
          for (const pattern of ["Confirm Choices", "Save Choices", "Auswahl speichern"]) {
            if (text.includes(pattern)) {
              b.click();
              await this.wait(500);
              return true;
            }
          }
        }
      }
      return false;
    }
    async optIn() {
      return this.waitForThenClick(".unic #unic-agree");
    }
    async test() {
      await this.wait(1e3);
      const res = this.elementExists(".unic .unic-box,.unic .unic-bar");
      return !res;
    }
  };
  var Conversant = class extends AutoConsentCMPBase {
    constructor() {
      super(...arguments);
      this.prehideSelectors = [".cmp-root"];
      this.name = "Conversant";
    }
    get hasSelfTest() {
      return true;
    }
    get isIntermediate() {
      return false;
    }
    get isCosmetic() {
      return false;
    }
    async detectCmp() {
      return this.elementExists(".cmp-root .cmp-receptacle");
    }
    async detectPopup() {
      return this.elementVisible(".cmp-root .cmp-receptacle", "any");
    }
    async optOut() {
      if (!await this.waitForThenClick(".cmp-main-button:not(.cmp-main-button--primary)")) {
        return false;
      }
      if (!await this.waitForElement(".cmp-view-tab-tabs")) {
        return false;
      }
      await this.waitForThenClick(".cmp-view-tab-tabs > :first-child");
      await this.waitForThenClick(".cmp-view-tab-tabs > .cmp-view-tab--active:first-child");
      for (const item of Array.from(document.querySelectorAll(".cmp-accordion-item"))) {
        item.querySelector(".cmp-accordion-item-title").click();
        await waitFor(() => !!item.querySelector(".cmp-accordion-item-content.cmp-active"), 10, 50);
        const content = item.querySelector(".cmp-accordion-item-content.cmp-active");
        content.querySelectorAll(".cmp-toggle-actions .cmp-toggle-deny:not(.cmp-toggle-deny--active)").forEach((e) => e.click());
        content.querySelectorAll(".cmp-toggle-actions .cmp-toggle-checkbox:not(.cmp-toggle-checkbox--active)").forEach((e) => e.click());
      }
      await this.click(".cmp-main-button:not(.cmp-main-button--primary)");
      return true;
    }
    async optIn() {
      return this.waitForThenClick(".cmp-main-button.cmp-main-button--primary");
    }
    async test() {
      return document.cookie.includes("cmp-data=0");
    }
  };
  var Tiktok = class extends AutoConsentCMPBase {
    constructor() {
      super(...arguments);
      this.name = "tiktok.com";
      this.runContext = {
        urlPattern: "tiktok"
      };
    }
    get hasSelfTest() {
      return true;
    }
    get isIntermediate() {
      return false;
    }
    get isCosmetic() {
      return false;
    }
    getShadowRoot() {
      const container = document.querySelector("tiktok-cookie-banner");
      if (!container) {
        return null;
      }
      return container.shadowRoot;
    }
    async detectCmp() {
      return this.elementExists("tiktok-cookie-banner");
    }
    async detectPopup() {
      const banner = this.getShadowRoot()?.querySelector(".tiktok-cookie-banner");
      return isElementVisible(banner);
    }
    async optOut() {
      const logsConfig = this.autoconsent.config.logs;
      const declineButton = this.getShadowRoot()?.querySelector(".button-wrapper button:first-child");
      if (declineButton) {
        logsConfig.rulesteps && console.log("[clicking]", declineButton);
        declineButton.click();
        return true;
      } else {
        logsConfig.errors && console.log("no decline button found");
        return false;
      }
    }
    async optIn() {
      const logsConfig = this.autoconsent.config.logs;
      const acceptButton = this.getShadowRoot()?.querySelector(".button-wrapper button:last-child");
      if (acceptButton) {
        logsConfig.rulesteps && console.log("[clicking]", acceptButton);
        acceptButton.click();
        return true;
      } else {
        logsConfig.errors && console.log("no accept button found");
        return false;
      }
    }
    async test() {
      const match = document.cookie.match(/cookie-consent=([^;]+)/);
      if (!match) {
        return false;
      }
      const value = JSON.parse(decodeURIComponent(match[1]));
      return Object.values(value).every((x) => typeof x !== "boolean" || x === false);
    }
  };
  var Tumblr = class extends AutoConsentCMPBase {
    constructor() {
      super(...arguments);
      this.name = "tumblr-com";
      this.runContext = {
        urlPattern: "^https://(www\\.)?tumblr\\.com/"
      };
    }
    get hasSelfTest() {
      return false;
    }
    get isIntermediate() {
      return false;
    }
    get isCosmetic() {
      return false;
    }
    get prehideSelectors() {
      return ["#cmp-app-container"];
    }
    async detectCmp() {
      return this.elementExists("#cmp-app-container");
    }
    async detectPopup() {
      return this.elementVisible("#cmp-app-container", "any");
    }
    async optOut() {
      let iframe = document.querySelector("#cmp-app-container iframe");
      let settingsButton = iframe.contentDocument?.querySelector(".cmp-components-button.is-secondary");
      if (!settingsButton) {
        return false;
      }
      settingsButton.click();
      await waitFor(
        () => {
          const iframe2 = document.querySelector("#cmp-app-container iframe");
          return !!iframe2.contentDocument?.querySelector(".cmp__dialog input");
        },
        5,
        500
      );
      iframe = document.querySelector("#cmp-app-container iframe");
      settingsButton = iframe.contentDocument?.querySelector(".cmp-components-button.is-secondary");
      if (!settingsButton) {
        return false;
      }
      settingsButton.click();
      return true;
    }
    async optIn() {
      const iframe = document.querySelector("#cmp-app-container iframe");
      const acceptButton = iframe.contentDocument.querySelector(".cmp-components-button.is-primary");
      if (acceptButton) {
        acceptButton.click();
        return true;
      }
      return false;
    }
  };
  var Admiral = class extends AutoConsentCMPBase {
    constructor() {
      super(...arguments);
      this.name = "Admiral";
    }
    get hasSelfTest() {
      return false;
    }
    get isIntermediate() {
      return false;
    }
    get isCosmetic() {
      return false;
    }
    async detectCmp() {
      return this.elementExists("div > div[class*=Card] > div[class*=Frame] > div[class*=Pills] > button[class*=Pills__StyledPill]");
    }
    async detectPopup() {
      return this.elementVisible(
        "div > div[class*=Card] > div[class*=Frame] > div[class*=Pills] > button[class*=Pills__StyledPill]",
        "any"
      );
    }
    async optOut() {
      const rejectAllSelector = "xpath///button[contains(., 'Afvis alle') or contains(., 'Reject all') or contains(., 'Odbaci sve') or contains(., 'Rechazar todo') or contains(., 'Atmesti visus') or contains(., 'Odm\xEDtnout v\u0161e') or contains(., '\u0391\u03C0\u03CC\u03C1\u03C1\u03B9\u03C8\u03B7 \u03CC\u03BB\u03C9\u03BD') or contains(., 'Rejeitar tudo') or contains(., 'T\xFCm\xFCn\xFC reddet') or contains(., '\u041E\u0442\u043A\u043B\u043E\u043D\u0438\u0442\u044C \u0432\u0441\u0435') or contains(., 'Noraid\u012Bt visu') or contains(., 'Avvisa alla') or contains(., 'Odrzu\u0107 wszystkie') or contains(., 'Alles afwijzen') or contains(., '\u041E\u0442\u0445\u0432\u044A\u0440\u043B\u044F\u043D\u0435 \u043D\u0430 \u0432\u0441\u0438\u0447\u043A\u0438') or contains(., 'Rifiuta tutto') or contains(., 'Zavrni vse') or contains(., 'Az \xF6sszes elutas\xEDt\xE1sa') or contains(., 'Respinge\u021Bi tot') or contains(., 'Alles ablehnen') or contains(., 'Tout rejeter') or contains(., 'Odmietnu\u0165 v\u0161etko') or contains(., 'L\xFCkka k\xF5ik tagasi') or contains(., 'Hylk\xE4\xE4 kaikki')]";
      if (await this.waitForElement(rejectAllSelector, 500)) {
        return await this.click(rejectAllSelector);
      }
      const purposesButtonSelector = "xpath///button[contains(., 'Zwecke') or contains(., '\u03A3\u03BA\u03BF\u03C0\u03BF\u03AF') or contains(., 'Purposes') or contains(., '\u0426\u0435\u043B\u0438') or contains(., 'Eesm\xE4rgid') or contains(., 'Tikslai') or contains(., 'Svrhe') or contains(., 'Cele') or contains(., '\xDA\u010Dely') or contains(., 'Finalidades') or contains(., 'M\u0113r\u0137i') or contains(., 'Scopuri') or contains(., 'Fines') or contains(., '\xC4ndam\xE5l') or contains(., 'Finalit\xE9s') or contains(., 'Doeleinden') or contains(., 'Tarkoitukset') or contains(., 'Scopi') or contains(., 'Ama\xE7lar') or contains(., 'Nameni') or contains(., 'C\xE9lok') or contains(., 'Form\xE5l')]";
      const saveAndExitSelector = "xpath///button[contains(., 'Spara & avsluta') or contains(., 'Save & exit') or contains(., 'Ulo\u017Eit a ukon\u010Dit') or contains(., 'Enregistrer et quitter') or contains(., 'Speichern & Verlassen') or contains(., 'Tallenna ja poistu') or contains(., 'I\u0161saugoti ir i\u0161eiti') or contains(., 'Opslaan & afsluiten') or contains(., 'Guardar y salir') or contains(., 'Shrani in zapri') or contains(., 'Ulo\u017Ei\u0165 a ukon\u010Di\u0165') or contains(., 'Kaydet ve \xE7\u0131k\u0131\u015F yap') or contains(., '\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0438 \u0432\u044B\u0439\u0442\u0438') or contains(., 'Salvesta ja v\xE4lju') or contains(., 'Salva ed esci') or contains(., 'Gem & afslut') or contains(., '\u0391\u03C0\u03BF\u03B8\u03AE\u03BA\u03B5\u03C5\u03C3\u03B7 \u03BA\u03B1\u03B9 \u03AD\u03BE\u03BF\u03B4\u03BF\u03C2') or contains(., 'Saglab\u0101t un iziet') or contains(., 'Ment\xE9s \xE9s kil\xE9p\xE9s') or contains(., 'Guardar e sair') or contains(., 'Zapisz & zako\u0144cz') or contains(., 'Salvare \u0219i ie\u0219ire') or contains(., 'Spremi i iza\u0111i') or contains(., '\u0417\u0430\u043F\u0430\u0437\u0432\u0430\u043D\u0435 \u0438 \u0438\u0437\u0445\u043E\u0434')]";
      if (await this.waitForThenClick(purposesButtonSelector) && await this.waitForVisible(saveAndExitSelector)) {
        const popupBody = this.elementSelector(saveAndExitSelector)[0].parentElement?.parentElement;
        const checkboxes = popupBody?.querySelectorAll("input[type=checkbox]:checked");
        checkboxes?.forEach((checkbox) => checkbox.click());
        return await this.click(saveAndExitSelector);
      }
      return false;
    }
    async optIn() {
      return await this.click(
        "xpath///button[contains(., 'Sprejmi vse') or contains(., 'Prihvati sve') or contains(., 'Godk\xE4nn alla') or contains(., 'Prija\u0165 v\u0161etko') or contains(., '\u041F\u0440\u0438\u043D\u044F\u0442\u044C \u0432\u0441\u0435') or contains(., 'Aceptar todo') or contains(., '\u0391\u03C0\u03BF\u03B4\u03BF\u03C7\u03AE \u03CC\u03BB\u03C9\u03BD') or contains(., 'Zaakceptuj wszystkie') or contains(., 'Accetta tutto') or contains(., 'Priimti visus') or contains(., 'Pie\u0146emt visu') or contains(., 'T\xFCm\xFCn\xFC kabul et') or contains(., 'Az \xF6sszes elfogad\xE1sa') or contains(., 'Accept all') or contains(., '\u041F\u0440\u0438\u0435\u043C\u0430\u043D\u0435 \u043D\u0430 \u0432\u0441\u0438\u0447\u043A\u0438') or contains(., 'Accepter alle') or contains(., 'Hyv\xE4ksy kaikki') or contains(., 'Tout accepter') or contains(., 'Alles accepteren') or contains(., 'Aktsepteeri k\xF5ik') or contains(., 'P\u0159ijmout v\u0161e') or contains(., 'Alles akzeptieren') or contains(., 'Aceitar tudo') or contains(., 'Accepta\u021Bi tot')]"
      );
    }
  };
  var dynamicCMPs = [
    TrustArcTop,
    TrustArcFrame,
    Cookiebot,
    SourcePoint,
    ConsentManager,
    Evidon,
    Onetrust,
    Klaro,
    Uniconsent,
    Conversant,
    Tiktok,
    Tumblr,
    Admiral
  ];
  var DomActions = class {
    constructor(autoconsentInstance) {
      this.autoconsentInstance = autoconsentInstance;
    }
    async clickElement(element) {
      if (!element || !(element instanceof HTMLElement)) {
        return false;
      }
      this.autoconsentInstance.config.logs.rulesteps && console.log("[clickElement]", element);
      element.click();
      return true;
    }
    async click(selector, all = false) {
      const elements = this.elementSelector(selector);
      this.autoconsentInstance.config.logs.rulesteps && console.log("[click]", selector, all, elements);
      if (elements.length > 0) {
        if (all) {
          elements.forEach((e) => e.click());
        } else {
          elements[0].click();
        }
      }
      return elements.length > 0;
    }
    elementExists(selector) {
      const exists = this.elementSelector(selector).length > 0;
      return exists;
    }
    elementVisible(selector, check = "all") {
      const elem = this.elementSelector(selector);
      const results = new Array(elem.length);
      elem.forEach((e, i) => {
        results[i] = isElementVisible(e);
      });
      if (check === "none") {
        return results.every((r) => !r);
      } else if (results.length === 0) {
        return false;
      } else if (check === "any") {
        return results.some((r) => r);
      }
      return results.every((r) => r);
    }
    waitForElement(selector, timeout = 1e4) {
      const interval = 200;
      const times = Math.ceil(timeout / interval);
      this.autoconsentInstance.config.logs.rulesteps && console.log("[waitForElement]", selector);
      return waitFor(() => this.elementSelector(selector).length > 0, times, interval);
    }
    waitForVisible(selector, timeout = 1e4, check = "any") {
      const interval = 200;
      const times = Math.ceil(timeout / interval);
      this.autoconsentInstance.config.logs.rulesteps && console.log("[waitForVisible]", selector);
      return waitFor(() => this.elementVisible(selector, check), times, interval);
    }
    async waitForThenClick(selector, timeout = 1e4, all = false) {
      await this.waitForElement(selector, timeout);
      return await this.click(selector, all);
    }
    wait(ms) {
      this.autoconsentInstance.config.logs.rulesteps && this.autoconsentInstance.config.logs.waits && console.log("[wait]", ms);
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(true);
        }, ms);
      });
    }
    cookieContains(substring) {
      return document.cookie.includes(substring);
    }
    hide(selector, method) {
      this.autoconsentInstance.config.logs.rulesteps && console.log("[hide]", selector);
      const styleEl = getStyleElement();
      return hideElements(styleEl, selector, method);
    }
    prehide(selector) {
      const styleEl = getStyleElement("autoconsent-prehide");
      this.autoconsentInstance.config.logs.lifecycle && console.log("[prehide]", styleEl, location.href);
      return hideElements(styleEl, selector, "opacity");
    }
    undoPrehide() {
      const existingElement = getStyleElement("autoconsent-prehide");
      this.autoconsentInstance.config.logs.lifecycle && console.log("[undoprehide]", existingElement, location.href);
      existingElement.remove();
    }
    async createOrUpdateStyleSheet(cssText, styleSheet) {
      if (!styleSheet) {
        styleSheet = new CSSStyleSheet();
      }
      styleSheet = await styleSheet.replace(cssText);
      return styleSheet;
    }
    removeStyleSheet(styleSheet) {
      if (styleSheet) {
        styleSheet.replace("");
        return true;
      }
      return false;
    }
    querySingleReplySelector(selector, parent = document) {
      if (selector.startsWith("aria/")) {
        return [];
      }
      if (selector.startsWith("xpath/")) {
        const xpath = selector.slice(6);
        const result = document.evaluate(xpath, parent, null, XPathResult.ANY_TYPE, null);
        let node = null;
        const elements = [];
        while (node = result.iterateNext()) {
          elements.push(node);
        }
        return elements;
      }
      if (selector.startsWith("text/")) {
        return [];
      }
      if (selector.startsWith("pierce/")) {
        return [];
      }
      if (parent.shadowRoot) {
        return Array.from(parent.shadowRoot.querySelectorAll(selector));
      }
      if (parent.contentDocument?.querySelectorAll) {
        return Array.from(parent.contentDocument.querySelectorAll(selector));
      }
      return Array.from(parent.querySelectorAll(selector));
    }
    querySelectorChain(selectors) {
      let parent = document;
      let matches2 = [];
      for (const selector of selectors) {
        matches2 = this.querySingleReplySelector(selector, parent);
        if (matches2.length === 0) {
          return [];
        }
        parent = matches2[0];
      }
      return matches2;
    }
    elementSelector(selector) {
      if (typeof selector === "string") {
        return this.querySingleReplySelector(selector);
      }
      return this.querySelectorChain(selector);
    }
    waitForMutation(selector, timeout = 6e4) {
      const node = this.elementSelector(selector);
      if (node.length === 0) {
        throw new Error(`${selector} did not match any elements`);
      }
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          reject(new Error("Timed out waiting for mutation"));
          observer.disconnect();
        }, timeout);
        const observer = new MutationObserver(() => {
          clearTimeout(timer);
          observer.disconnect();
          resolve(true);
        });
        observer.observe(node[0], {
          subtree: true,
          childList: true,
          attributes: true
        });
      });
    }
  };
  var compactedRuleSteps = [
    ["exists", "e"],
    ["visible", "v"],
    ["waitForThenClick", "c"],
    ["click", "k"],
    ["waitFor", "w"],
    ["waitForVisible", "wv"],
    ["hide", "h"],
    ["cookieContains", "cc"]
  ];
  function decodeNullableBoolean(value) {
    if (value === 1) {
      return true;
    }
    if (value === 0) {
      return false;
    }
    return void 0;
  }
  function decodeRules(encoded) {
    if (encoded.v > 1) {
      throw new Error("Unsupported rule format.");
    }
    return encoded.r.filter((r) => r[0] <= SUPPORTED_RULE_STEP_VERSION).map((rule) => new CompactedCMPRule(rule, encoded.s));
  }
  var CompactedCMPRule = class {
    constructor(rule, strings) {
      this.intermediate = false;
      this.optIn = [];
      this.r = rule;
      this.s = strings;
      if (this.r[10] && this.r[10].intermediate) {
        this.intermediate = this.r[10].intermediate;
      }
    }
    _decodeRuleStep(step) {
      const clonedStep = { ...step };
      const decodeRuleStep = this._decodeRuleStep.bind(this);
      for (const [longKey, shortKey] of compactedRuleSteps) {
        if (clonedStep[shortKey] !== void 0) {
          clonedStep[longKey] = this.s[clonedStep[shortKey]];
          delete clonedStep[shortKey];
        }
      }
      if (step.if) {
        clonedStep.if = decodeRuleStep(step.if);
        clonedStep.then = step.then && step.then.map(decodeRuleStep);
        if (step.else) {
          clonedStep.else = step.else.map(decodeRuleStep);
        }
      }
      if (step.any) {
        clonedStep.any = step.any.map(decodeRuleStep);
      }
      return { ...clonedStep };
    }
    get name() {
      return this.r[1];
    }
    get cosmetic() {
      return decodeNullableBoolean(this.r[2]);
    }
    get runContext() {
      const runContext = {};
      const urlPattern = this.r[3];
      const mainFrame = this.r[4];
      const runInMainFrame = decodeNullableBoolean(Math.floor(mainFrame / 10) % 10);
      const runInSubFrame = decodeNullableBoolean(mainFrame % 10);
      if (runInMainFrame !== void 0) {
        runContext.main = runInMainFrame;
      }
      if (runInSubFrame !== void 0) {
        runContext.frame = runInSubFrame;
      }
      if (urlPattern !== "") {
        runContext.urlPattern = urlPattern;
      }
      return runContext;
    }
    get prehideSelectors() {
      return this.r[5].map((i) => this.s[i].toString());
    }
    get detectCmp() {
      return this.r[6].map(this._decodeRuleStep.bind(this));
    }
    get detectPopup() {
      return this.r[7].map(this._decodeRuleStep.bind(this));
    }
    get optOut() {
      return this.r[8].map(this._decodeRuleStep.bind(this));
    }
    get test() {
      return this.r[9].map(this._decodeRuleStep.bind(this));
    }
  };
  function filterCMPs(rules, config) {
    return rules.filter((cmp) => {
      return (!config.disabledCmps || !config.disabledCmps.includes(cmp.name)) && // CMP is not disabled
      (config.enableCosmeticRules || !cmp.isCosmetic) && // CMP is not cosmetic or cosmetic rules are enabled
      (config.enableGeneratedRules || !cmp.name.startsWith("auto_"));
    });
  }
  var _config;
  var AutoConsent = class {
    constructor(sendContentMessage, config = null, declarativeRules = null) {
      this.id = getRandomID();
      this.rules = [];
      __privateAdd(this, _config);
      this.state = {
        cosmeticFiltersOn: false,
        filterListReported: false,
        lifecycle: "loading",
        prehideOn: false,
        findCmpAttempts: 0,
        detectedCmps: [],
        detectedPopups: [],
        heuristicPatterns: [],
        heuristicSnippets: [],
        selfTest: null,
        clicks: 0,
        startTime: 0,
        endTime: 0
      };
      evalState.sendContentMessage = sendContentMessage;
      this.sendContentMessage = sendContentMessage;
      this.rules = [];
      this.updateState({ lifecycle: "loading" });
      this.addDynamicRules();
      if (config) {
        this.initialize(config, declarativeRules);
      } else {
        if (declarativeRules) {
          this.parseDeclarativeRules(declarativeRules);
        }
        const initMsg = {
          type: "init",
          url: window.location.href
        };
        sendContentMessage(initMsg);
        this.updateState({ lifecycle: "waitingForInitResponse" });
      }
      this.domActions = new DomActions(this);
    }
    get config() {
      if (!__privateGet(this, _config)) {
        throw new Error("AutoConsent is not initialized yet");
      }
      return __privateGet(this, _config);
    }
    initialize(config, declarativeRules) {
      const normalizedConfig = normalizeConfig(config);
      normalizedConfig.logs.lifecycle && console.log("autoconsent init", window.location.href);
      __privateSet(this, _config, normalizedConfig);
      if (!normalizedConfig.enabled) {
        normalizedConfig.logs.lifecycle && console.log("autoconsent is disabled");
        return;
      }
      if (declarativeRules) {
        this.parseDeclarativeRules(declarativeRules);
      }
      if (config.enableFilterList) {
        this.initializeFilterList();
      }
      this.rules = filterCMPs(this.rules, normalizedConfig);
      if (this.shouldPrehide) {
        if (document.documentElement) {
          this.prehideElements();
        } else {
          const delayedPrehide = () => {
            window.removeEventListener("DOMContentLoaded", delayedPrehide);
            this.prehideElements();
          };
          window.addEventListener("DOMContentLoaded", delayedPrehide);
        }
      }
      if (document.readyState === "loading") {
        const onReady = () => {
          window.removeEventListener("DOMContentLoaded", onReady);
          this.start();
        };
        window.addEventListener("DOMContentLoaded", onReady);
      } else {
        this.start();
      }
      this.updateState({ lifecycle: "initialized" });
    }
    initializeFilterList() {
    }
    get shouldPrehide() {
      return this.config.enablePrehide && !this.config.visualTest;
    }
    saveFocus() {
      this.focusedElement = document.activeElement;
      if (this.focusedElement) {
        this.config.logs.lifecycle && console.log("saving focus", this.focusedElement, location.href);
      }
    }
    restoreFocus() {
      if (this.focusedElement) {
        this.config.logs.lifecycle && console.log("restoring focus", this.focusedElement, location.href);
        try {
          this.focusedElement.focus({ preventScroll: true });
        } catch (e) {
          this.config.logs.errors && console.warn("error restoring focus", e);
        }
        this.focusedElement = void 0;
      }
    }
    addDynamicRules() {
      dynamicCMPs.forEach((Cmp) => {
        this.rules.push(new Cmp(this));
      });
    }
    parseDeclarativeRules(declarativeRules) {
      if (declarativeRules.consentomatic) {
        for (const [name, rule] of Object.entries(declarativeRules.consentomatic)) {
          this.addConsentomaticCMP(name, rule);
        }
      }
      if (declarativeRules.autoconsent) {
        declarativeRules.autoconsent.forEach((ruleset) => {
          this.addDeclarativeCMP(ruleset);
        });
      }
      if (declarativeRules.compact) {
        try {
          const rules = decodeRules(declarativeRules.compact);
          rules.forEach(this.addDeclarativeCMP.bind(this));
        } catch (e) {
          this.config.logs.errors && console.error(e);
        }
      }
    }
    addDeclarativeCMP(ruleset) {
      if ((ruleset.minimumRuleStepVersion || 1) <= SUPPORTED_RULE_STEP_VERSION) {
        this.rules.push(new AutoConsentCMP(ruleset, this));
      }
    }
    addConsentomaticCMP(name, config) {
      this.rules.push(new ConsentOMaticCMP(`com_${name}`, config));
    }
    // start the detection process, possibly with a delay
    start() {
      scheduleWhenIdle(() => this._start());
    }
    async _start() {
      const logsConfig = this.config.logs;
      logsConfig.lifecycle && console.log(`Detecting CMPs on ${window.location.href}`);
      this.updateState({ lifecycle: "started" });
      const foundCmps = await this.findCmp(this.config.detectRetries);
      this.updateState({ detectedCmps: foundCmps.map((c) => c.name) });
      if (foundCmps.length === 0) {
        logsConfig.lifecycle && console.log("no CMP found", location.href);
        if (this.shouldPrehide) {
          this.undoPrehide();
        }
        return this.filterListFallback();
      }
      this.updateState({ lifecycle: "cmpDetected" });
      const staticCmps = [];
      const cosmeticCmps = [];
      for (const cmp of foundCmps) {
        if (cmp.isCosmetic) {
          cosmeticCmps.push(cmp);
        } else {
          staticCmps.push(cmp);
        }
      }
      let result = false;
      let foundPopups = await this.detectPopups(staticCmps, async (cmp) => {
        result = await this.handlePopup(cmp);
      });
      if (foundPopups.length === 0) {
        foundPopups = await this.detectPopups(cosmeticCmps, async (cmp) => {
          result = await this.handlePopup(cmp);
        });
      }
      if (foundPopups.length === 0) {
        logsConfig.lifecycle && console.log("no popup found");
        if (this.shouldPrehide) {
          this.undoPrehide();
        }
        return false;
      }
      if (foundPopups.length > 1) {
        const errorDetails = {
          msg: `Found multiple CMPs, check the detection rules.`,
          cmps: foundPopups.map((cmp) => cmp.name)
        };
        logsConfig.errors && console.warn(errorDetails.msg, errorDetails.cmps);
        this.sendContentMessage({
          type: "autoconsentError",
          details: errorDetails
        });
      }
      return result;
    }
    async findCmp(retries) {
      const logsConfig = this.config.logs;
      this.updateState({ findCmpAttempts: this.state.findCmpAttempts + 1 });
      const foundCMPs = [];
      const isTop = isTopFrame();
      const siteSpecificRules = [];
      const genericRules = [];
      this.rules.forEach((cmp) => {
        if (cmp.checkFrameContext(isTop)) {
          const isSiteSpecific = !!cmp.runContext.urlPattern;
          if (cmp.hasMatchingUrlPattern()) {
            siteSpecificRules.push(cmp);
          } else if (!isSiteSpecific) {
            genericRules.push(cmp);
          }
        }
      });
      const heuristicRules = isTop && this.config.enableHeuristicAction ? [new AutoConsentHeuristicCMP(this)] : [];
      const rulesPriorityStages = [
        ["site-specific", siteSpecificRules],
        ["generic", genericRules],
        ["heuristic", heuristicRules]
      ];
      const runDetectCmp = async (cmp) => {
        try {
          const result = await cmp.detectCmp();
          if (result) {
            logsConfig.lifecycle && console.log(`Found CMP: ${cmp.name} ${window.location.href}`);
            this.sendContentMessage({
              type: "cmpDetected",
              url: location.href,
              cmp: cmp.name
            });
            foundCMPs.push(cmp);
          }
        } catch (e) {
          logsConfig.errors && console.warn(`error detecting ${cmp.name}`, e);
        }
      };
      const mutationObserver = this.domActions.waitForMutation("html");
      mutationObserver.catch(() => {
      });
      for (const [stageName, ruleGroup] of rulesPriorityStages) {
        logsConfig.lifecycle && ruleGroup.length > 0 && console.log(
          `Trying ${stageName} rules`,
          ruleGroup.map((r) => r.name)
        );
        await Promise.all(ruleGroup.map(runDetectCmp));
        if (foundCMPs.length > 0) {
          break;
        }
      }
      this.detectHeuristics();
      if (foundCMPs.length === 0 && retries > 0) {
        try {
          await Promise.all([this.domActions.wait(500), mutationObserver]);
        } catch (e) {
          return [];
        }
        return this.findCmp(retries - 1);
      }
      return foundCMPs;
    }
    detectHeuristics() {
      if (this.config.enableHeuristicDetection) {
        const { patterns, snippets: snippets2 } = checkHeuristicPatterns(document.documentElement?.innerText || "");
        if (patterns.length > 0 && (patterns.length !== this.state.heuristicPatterns.length || this.state.heuristicPatterns.some((p, i) => p !== patterns[i]))) {
          this.config.logs.lifecycle && console.log("Heuristic patterns found", patterns, snippets2);
          this.updateState({ heuristicPatterns: patterns, heuristicSnippets: snippets2 });
        }
      }
    }
    /**
     * Detect if a CMP has a popup open. Fullfils with the CMP if a popup is open, otherwise rejects.
     */
    async detectPopup(cmp) {
      const isOpen = await this.waitForPopup(cmp).catch((error) => {
        this.config.logs.errors && console.warn(`error waiting for a popup for ${cmp.name}`, error);
        return false;
      });
      if (isOpen) {
        this.updateState({ detectedPopups: this.state.detectedPopups.concat([cmp.name]) });
        this.sendContentMessage({
          type: "popupFound",
          cmp: cmp.name,
          url: location.href
        });
        return cmp;
      }
      throw new Error("Popup is not shown");
    }
    /**
     * Detect if any of the CMPs has a popup open. Returns a list of CMPs with open popups.
     */
    async detectPopups(cmps, onFirstPopupAppears) {
      const tasks = cmps.map((cmp) => this.detectPopup(cmp));
      await Promise.any(tasks).then((cmp) => {
        this.detectHeuristics();
        onFirstPopupAppears(cmp);
      }).catch(() => {
      });
      const results = await Promise.allSettled(tasks);
      const popups = [];
      for (const result of results) {
        if (result.status === "fulfilled") {
          popups.push(result.value);
        }
      }
      return popups;
    }
    async handlePopup(cmp) {
      this.updateState({ lifecycle: "openPopupDetected", startTime: Date.now() });
      if (this.shouldPrehide && !this.state.prehideOn) {
        this.prehideElements();
      }
      if (this.state.cosmeticFiltersOn) {
        this.undoCosmetics();
      }
      this.foundCmp = cmp;
      if (this.config.autoAction === "optOut") {
        return await this.doOptOut();
      } else if (this.config.autoAction === "optIn") {
        return await this.doOptIn();
      } else {
        this.config.logs.lifecycle && console.log("waiting for opt-out signal...", location.href);
        return true;
      }
    }
    async doOptOut() {
      const logsConfig = this.config.logs;
      this.updateState({ lifecycle: "runningOptOut" });
      this.saveFocus();
      let optOutResult;
      if (!this.foundCmp) {
        logsConfig.errors && console.log("no CMP to opt out");
        optOutResult = false;
      } else {
        logsConfig.lifecycle && console.log(`CMP ${this.foundCmp.name}: opt out on ${window.location.href}`);
        optOutResult = await this.foundCmp.optOut();
        logsConfig.lifecycle && console.log(`${this.foundCmp.name}: opt out result ${optOutResult}`);
      }
      if (this.shouldPrehide) {
        this.undoPrehide();
      }
      this.sendContentMessage({
        type: "optOutResult",
        cmp: this.foundCmp ? this.foundCmp.name : "none",
        result: optOutResult,
        scheduleSelfTest: Boolean(this.foundCmp && this.foundCmp.hasSelfTest),
        url: location.href
      });
      if (optOutResult && this.foundCmp && !this.foundCmp.isIntermediate) {
        this.state.endTime = Date.now();
        logsConfig.lifecycle && console.log(
          `${this.foundCmp.name}: done in ${this.state.endTime - this.state.startTime}ms with ${this.state.clicks} clicks`
        );
        this.sendContentMessage({
          type: "autoconsentDone",
          cmp: this.foundCmp?.name,
          isCosmetic: this.foundCmp?.isCosmetic,
          url: location.href,
          duration: this.state.endTime - this.state.startTime,
          totalClicks: this.state.clicks
        });
        this.updateState({ lifecycle: "done" });
      } else {
        this.updateState({ lifecycle: optOutResult ? "optOutSucceeded" : "optOutFailed" });
      }
      this.restoreFocus();
      return optOutResult;
    }
    async doOptIn() {
      const logsConfig = this.config.logs;
      this.updateState({ lifecycle: "runningOptIn" });
      this.saveFocus();
      let optInResult;
      if (!this.foundCmp) {
        logsConfig.errors && console.log("no CMP to opt in");
        optInResult = false;
      } else {
        logsConfig.lifecycle && console.log(`CMP ${this.foundCmp.name}: opt in on ${window.location.href}`);
        optInResult = await this.foundCmp.optIn();
        logsConfig.lifecycle && console.log(`${this.foundCmp.name}: opt in result ${optInResult}`);
      }
      if (this.shouldPrehide) {
        this.undoPrehide();
      }
      this.sendContentMessage({
        type: "optInResult",
        cmp: this.foundCmp ? this.foundCmp.name : "none",
        result: optInResult,
        scheduleSelfTest: false,
        // self-tests are only for opt-out at the moment
        url: location.href
      });
      if (optInResult && this.foundCmp && !this.foundCmp.isIntermediate) {
        this.state.endTime = Date.now();
        logsConfig.lifecycle && console.log(
          `${this.foundCmp.name}: done in ${this.state.endTime - this.state.startTime}ms with ${this.state.clicks} clicks`
        );
        this.sendContentMessage({
          type: "autoconsentDone",
          cmp: this.foundCmp.name,
          isCosmetic: this.foundCmp.isCosmetic,
          url: location.href,
          duration: this.state.endTime - this.state.startTime,
          totalClicks: this.state.clicks
        });
        this.updateState({ lifecycle: "done" });
      } else {
        this.updateState({ lifecycle: optInResult ? "optInSucceeded" : "optInFailed" });
      }
      this.restoreFocus();
      return optInResult;
    }
    async doSelfTest() {
      const logsConfig = this.config.logs;
      let selfTestResult;
      if (!this.foundCmp) {
        logsConfig.errors && console.log("no CMP to self test");
        selfTestResult = false;
      } else {
        logsConfig.lifecycle && console.log(`CMP ${this.foundCmp.name}: self-test on ${window.location.href}`);
        selfTestResult = await this.foundCmp.test();
      }
      this.sendContentMessage({
        type: "selfTestResult",
        cmp: this.foundCmp ? this.foundCmp.name : "none",
        result: selfTestResult,
        url: location.href
      });
      this.updateState({ selfTest: selfTestResult });
      return selfTestResult;
    }
    // TODO: use MutationObserver like in findCmp()
    async waitForPopup(cmp, retries = 10, interval = 500) {
      const logsConfig = this.config.logs;
      logsConfig.lifecycle && console.log("checking if popup is open...", cmp.name);
      const isOpen = await cmp.detectPopup().catch((e) => {
        logsConfig.errors && console.warn(`error detecting popup for ${cmp.name}`, e);
        return false;
      });
      if (!isOpen && retries > 0) {
        await this.domActions.wait(interval);
        return this.waitForPopup(cmp, retries - 1, interval);
      }
      logsConfig.lifecycle && console.log(cmp.name, `popup is ${isOpen ? "open" : "not open"}`);
      return isOpen;
    }
    prehideElements() {
      const logsConfig = this.config.logs;
      const globalHidden = [
        "#didomi-popup,.didomi-popup-container,.didomi-popup-notice,.didomi-consent-popup-preferences,#didomi-notice,.didomi-popup-backdrop,.didomi-screen-medium"
      ];
      const selectors = this.rules.filter((rule) => rule.prehideSelectors && rule.checkRunContext()).reduce((selectorList, rule) => [...selectorList || [], ...rule.prehideSelectors || []], globalHidden);
      this.updateState({ prehideOn: true });
      setTimeout(() => {
        if (this.shouldPrehide && this.state.prehideOn && !["runningOptOut", "runningOptIn"].includes(this.state.lifecycle)) {
          logsConfig.lifecycle && console.log("Process is taking too long, unhiding elements");
          this.undoPrehide();
        }
      }, this.config.prehideTimeout || 2e3);
      return this.domActions.prehide(selectors.join(","));
    }
    undoPrehide() {
      this.updateState({ prehideOn: false });
      this.domActions.undoPrehide();
    }
    undoCosmetics() {
    }
    reportFilterlist() {
      this.sendContentMessage({
        type: "cmpDetected",
        url: location.href,
        cmp: "filterList"
      });
      this.sendContentMessage({
        type: "popupFound",
        cmp: "filterList",
        url: location.href
      });
      this.updateState({ filterListReported: true });
    }
    filterListFallback() {
      this.updateState({ lifecycle: "nothingDetected" });
      return false;
    }
    updateState(change) {
      Object.assign(this.state, change);
      this.sendContentMessage({
        type: "report",
        instanceId: this.id,
        url: window.location.href,
        mainFrame: isTopFrame(),
        state: this.state
      });
    }
    async receiveMessageCallback(message) {
      const logsConfig = __privateGet(this, _config)?.logs;
      if (logsConfig?.messages) {
        console.log("received from background", message, window.location.href);
      }
      switch (message.type) {
        case "initResp":
          this.initialize(message.config, message.rules);
          break;
        case "optIn":
          await this.doOptIn();
          break;
        case "optOut":
          await this.doOptOut();
          break;
        case "selfTest":
          await this.doSelfTest();
          break;
        case "evalResp":
          resolveEval(message.id, message.result);
          break;
      }
    }
  };
  _config = /* @__PURE__ */ new WeakMap();

  // shared/js/cpm.js
  var consent = new AutoConsent(async (msg) => {
    await chrome.runtime.sendMessage({
      messageType: "autoconsent",
      autoconsentPayload: msg
    });
  });
  chrome.runtime.onMessage.addListener((message) => {
    return Promise.resolve(consent.receiveMessageCallback(message));
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibm9kZV9tb2R1bGVzL0BkdWNrZHVja2dvL2F1dG9jb25zZW50L2Rpc3QvYXV0b2NvbnNlbnQuZXNtLmpzIiwgInNoYXJlZC9qcy9jcG0uanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbInZhciBfX3R5cGVFcnJvciA9IChtc2cpID0+IHtcbiAgdGhyb3cgVHlwZUVycm9yKG1zZyk7XG59O1xudmFyIF9fYWNjZXNzQ2hlY2sgPSAob2JqLCBtZW1iZXIsIG1zZykgPT4gbWVtYmVyLmhhcyhvYmopIHx8IF9fdHlwZUVycm9yKFwiQ2Fubm90IFwiICsgbXNnKTtcbnZhciBfX3ByaXZhdGVHZXQgPSAob2JqLCBtZW1iZXIsIGdldHRlcikgPT4gKF9fYWNjZXNzQ2hlY2sob2JqLCBtZW1iZXIsIFwicmVhZCBmcm9tIHByaXZhdGUgZmllbGRcIiksIGdldHRlciA/IGdldHRlci5jYWxsKG9iaikgOiBtZW1iZXIuZ2V0KG9iaikpO1xudmFyIF9fcHJpdmF0ZUFkZCA9IChvYmosIG1lbWJlciwgdmFsdWUpID0+IG1lbWJlci5oYXMob2JqKSA/IF9fdHlwZUVycm9yKFwiQ2Fubm90IGFkZCB0aGUgc2FtZSBwcml2YXRlIG1lbWJlciBtb3JlIHRoYW4gb25jZVwiKSA6IG1lbWJlciBpbnN0YW5jZW9mIFdlYWtTZXQgPyBtZW1iZXIuYWRkKG9iaikgOiBtZW1iZXIuc2V0KG9iaiwgdmFsdWUpO1xudmFyIF9fcHJpdmF0ZVNldCA9IChvYmosIG1lbWJlciwgdmFsdWUsIHNldHRlcikgPT4gKF9fYWNjZXNzQ2hlY2sob2JqLCBtZW1iZXIsIFwid3JpdGUgdG8gcHJpdmF0ZSBmaWVsZFwiKSwgc2V0dGVyID8gc2V0dGVyLmNhbGwob2JqLCB2YWx1ZSkgOiBtZW1iZXIuc2V0KG9iaiwgdmFsdWUpLCB2YWx1ZSk7XG5cbi8vIGxpYi9jb25zZW50b21hdGljL3Rvb2xzLnRzXG52YXIgX1Rvb2xzID0gY2xhc3MgX1Rvb2xzIHtcbiAgc3RhdGljIHNldEJhc2UoYmFzZSkge1xuICAgIF9Ub29scy5iYXNlID0gYmFzZTtcbiAgfVxuICBzdGF0aWMgZmluZEVsZW1lbnQob3B0aW9ucywgcGFyZW50ID0gbnVsbCwgbXVsdGlwbGUgPSBmYWxzZSkge1xuICAgIGxldCBwb3NzaWJsZVRhcmdldHMgPSBudWxsO1xuICAgIGlmIChwYXJlbnQgIT0gbnVsbCkge1xuICAgICAgcG9zc2libGVUYXJnZXRzID0gQXJyYXkuZnJvbShwYXJlbnQucXVlcnlTZWxlY3RvckFsbChvcHRpb25zLnNlbGVjdG9yKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChfVG9vbHMuYmFzZSAhPSBudWxsKSB7XG4gICAgICAgIHBvc3NpYmxlVGFyZ2V0cyA9IEFycmF5LmZyb20oXG4gICAgICAgICAgX1Rvb2xzLmJhc2UucXVlcnlTZWxlY3RvckFsbChvcHRpb25zLnNlbGVjdG9yKVxuICAgICAgICApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcG9zc2libGVUYXJnZXRzID0gQXJyYXkuZnJvbShcbiAgICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKG9wdGlvbnMuc2VsZWN0b3IpXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChvcHRpb25zLnRleHRGaWx0ZXIgIT0gbnVsbCkge1xuICAgICAgcG9zc2libGVUYXJnZXRzID0gcG9zc2libGVUYXJnZXRzLmZpbHRlcigocG9zc2libGVUYXJnZXQpID0+IHtcbiAgICAgICAgY29uc3QgdGV4dENvbnRlbnQgPSBwb3NzaWJsZVRhcmdldC50ZXh0Q29udGVudC50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShvcHRpb25zLnRleHRGaWx0ZXIpKSB7XG4gICAgICAgICAgbGV0IGZvdW5kVGV4dCA9IGZhbHNlO1xuICAgICAgICAgIGZvciAoY29uc3QgdGV4dCBvZiBvcHRpb25zLnRleHRGaWx0ZXIpIHtcbiAgICAgICAgICAgIGlmICh0ZXh0Q29udGVudC5pbmRleE9mKHRleHQudG9Mb3dlckNhc2UoKSkgIT09IC0xKSB7XG4gICAgICAgICAgICAgIGZvdW5kVGV4dCA9IHRydWU7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gZm91bmRUZXh0O1xuICAgICAgICB9IGVsc2UgaWYgKG9wdGlvbnMudGV4dEZpbHRlciAhPSBudWxsKSB7XG4gICAgICAgICAgcmV0dXJuIHRleHRDb250ZW50LmluZGV4T2Yob3B0aW9ucy50ZXh0RmlsdGVyLnRvTG93ZXJDYXNlKCkpICE9PSAtMTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKG9wdGlvbnMuc3R5bGVGaWx0ZXJzICE9IG51bGwpIHtcbiAgICAgIHBvc3NpYmxlVGFyZ2V0cyA9IHBvc3NpYmxlVGFyZ2V0cy5maWx0ZXIoKHBvc3NpYmxlVGFyZ2V0KSA9PiB7XG4gICAgICAgIGNvbnN0IHN0eWxlcyA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKHBvc3NpYmxlVGFyZ2V0KTtcbiAgICAgICAgbGV0IGtlZXAgPSB0cnVlO1xuICAgICAgICBmb3IgKGNvbnN0IHN0eWxlRmlsdGVyIG9mIG9wdGlvbnMuc3R5bGVGaWx0ZXJzKSB7XG4gICAgICAgICAgY29uc3Qgb3B0aW9uID0gc3R5bGVzW3N0eWxlRmlsdGVyLm9wdGlvbl07XG4gICAgICAgICAgaWYgKHN0eWxlRmlsdGVyLm5lZ2F0ZWQpIHtcbiAgICAgICAgICAgIGtlZXAgPSBrZWVwICYmIG9wdGlvbiAhPT0gc3R5bGVGaWx0ZXIudmFsdWU7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGtlZXAgPSBrZWVwICYmIG9wdGlvbiA9PT0gc3R5bGVGaWx0ZXIudmFsdWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBrZWVwO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChvcHRpb25zLmRpc3BsYXlGaWx0ZXIgIT0gbnVsbCkge1xuICAgICAgcG9zc2libGVUYXJnZXRzID0gcG9zc2libGVUYXJnZXRzLmZpbHRlcigocG9zc2libGVUYXJnZXQpID0+IHtcbiAgICAgICAgaWYgKG9wdGlvbnMuZGlzcGxheUZpbHRlcikge1xuICAgICAgICAgIHJldHVybiBwb3NzaWJsZVRhcmdldC5vZmZzZXRIZWlnaHQgIT09IDA7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIHBvc3NpYmxlVGFyZ2V0Lm9mZnNldEhlaWdodCA9PT0gMDtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChvcHRpb25zLmlmcmFtZUZpbHRlciAhPSBudWxsKSB7XG4gICAgICBwb3NzaWJsZVRhcmdldHMgPSBwb3NzaWJsZVRhcmdldHMuZmlsdGVyKCgpID0+IHtcbiAgICAgICAgaWYgKG9wdGlvbnMuaWZyYW1lRmlsdGVyKSB7XG4gICAgICAgICAgcmV0dXJuIHdpbmRvdy5sb2NhdGlvbiAhPT0gd2luZG93LnBhcmVudC5sb2NhdGlvbjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gd2luZG93LmxvY2F0aW9uID09PSB3aW5kb3cucGFyZW50LmxvY2F0aW9uO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKG9wdGlvbnMuY2hpbGRGaWx0ZXIgIT0gbnVsbCkge1xuICAgICAgcG9zc2libGVUYXJnZXRzID0gcG9zc2libGVUYXJnZXRzLmZpbHRlcigocG9zc2libGVUYXJnZXQpID0+IHtcbiAgICAgICAgY29uc3Qgb2xkQmFzZSA9IF9Ub29scy5iYXNlO1xuICAgICAgICBfVG9vbHMuc2V0QmFzZShwb3NzaWJsZVRhcmdldCk7XG4gICAgICAgIGNvbnN0IGNoaWxkUmVzdWx0cyA9IF9Ub29scy5maW5kKG9wdGlvbnMuY2hpbGRGaWx0ZXIpO1xuICAgICAgICBfVG9vbHMuc2V0QmFzZShvbGRCYXNlKTtcbiAgICAgICAgcmV0dXJuIGNoaWxkUmVzdWx0cy50YXJnZXQgIT0gbnVsbDtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAobXVsdGlwbGUpIHtcbiAgICAgIHJldHVybiBwb3NzaWJsZVRhcmdldHM7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChwb3NzaWJsZVRhcmdldHMubGVuZ3RoID4gMSkge1xuICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgXCJNdWx0aXBsZSBwb3NzaWJsZSB0YXJnZXRzOiBcIixcbiAgICAgICAgICBwb3NzaWJsZVRhcmdldHMsXG4gICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgICBwYXJlbnRcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBwb3NzaWJsZVRhcmdldHNbMF07XG4gICAgfVxuICB9XG4gIHN0YXRpYyBmaW5kKG9wdGlvbnMsIG11bHRpcGxlID0gZmFsc2UpIHtcbiAgICBjb25zdCByZXN1bHRzID0gW107XG4gICAgaWYgKG9wdGlvbnMucGFyZW50ICE9IG51bGwpIHtcbiAgICAgIGNvbnN0IHBhcmVudCA9IF9Ub29scy5maW5kRWxlbWVudChvcHRpb25zLnBhcmVudCwgbnVsbCwgbXVsdGlwbGUpO1xuICAgICAgaWYgKHBhcmVudCAhPSBudWxsKSB7XG4gICAgICAgIGlmIChwYXJlbnQgaW5zdGFuY2VvZiBBcnJheSkge1xuICAgICAgICAgIHBhcmVudC5mb3JFYWNoKChwKSA9PiB7XG4gICAgICAgICAgICBjb25zdCB0YXJnZXRzID0gX1Rvb2xzLmZpbmRFbGVtZW50KG9wdGlvbnMudGFyZ2V0LCBwLCBtdWx0aXBsZSk7XG4gICAgICAgICAgICBpZiAodGFyZ2V0cyBpbnN0YW5jZW9mIEFycmF5KSB7XG4gICAgICAgICAgICAgIHRhcmdldHMuZm9yRWFjaCgodGFyZ2V0KSA9PiB7XG4gICAgICAgICAgICAgICAgcmVzdWx0cy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgIHBhcmVudDogcCxcbiAgICAgICAgICAgICAgICAgIHRhcmdldFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHJlc3VsdHMucHVzaCh7XG4gICAgICAgICAgICAgICAgcGFyZW50OiBwLFxuICAgICAgICAgICAgICAgIHRhcmdldDogdGFyZ2V0c1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4gcmVzdWx0cztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zdCB0YXJnZXRzID0gX1Rvb2xzLmZpbmRFbGVtZW50KG9wdGlvbnMudGFyZ2V0LCBwYXJlbnQsIG11bHRpcGxlKTtcbiAgICAgICAgICBpZiAodGFyZ2V0cyBpbnN0YW5jZW9mIEFycmF5KSB7XG4gICAgICAgICAgICB0YXJnZXRzLmZvckVhY2goKHRhcmdldCkgPT4ge1xuICAgICAgICAgICAgICByZXN1bHRzLnB1c2goe1xuICAgICAgICAgICAgICAgIHBhcmVudCxcbiAgICAgICAgICAgICAgICB0YXJnZXRcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVzdWx0cy5wdXNoKHtcbiAgICAgICAgICAgICAgcGFyZW50LFxuICAgICAgICAgICAgICB0YXJnZXQ6IHRhcmdldHNcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCB0YXJnZXRzID0gX1Rvb2xzLmZpbmRFbGVtZW50KG9wdGlvbnMudGFyZ2V0LCBudWxsLCBtdWx0aXBsZSk7XG4gICAgICBpZiAodGFyZ2V0cyBpbnN0YW5jZW9mIEFycmF5KSB7XG4gICAgICAgIHRhcmdldHMuZm9yRWFjaCgodGFyZ2V0KSA9PiB7XG4gICAgICAgICAgcmVzdWx0cy5wdXNoKHtcbiAgICAgICAgICAgIHBhcmVudDogbnVsbCxcbiAgICAgICAgICAgIHRhcmdldFxuICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc3VsdHMucHVzaCh7XG4gICAgICAgICAgcGFyZW50OiBudWxsLFxuICAgICAgICAgIHRhcmdldDogdGFyZ2V0c1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHJlc3VsdHMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXN1bHRzLnB1c2goe1xuICAgICAgICBwYXJlbnQ6IG51bGwsXG4gICAgICAgIHRhcmdldDogbnVsbFxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChtdWx0aXBsZSkge1xuICAgICAgcmV0dXJuIHJlc3VsdHM7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChyZXN1bHRzLmxlbmd0aCAhPT0gMSkge1xuICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgXCJNdWx0aXBsZSByZXN1bHRzIGZvdW5kLCBldmVuIHRob3VnaCBtdWx0aXBsZSBmYWxzZVwiLFxuICAgICAgICAgIHJlc3VsdHNcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXN1bHRzWzBdO1xuICAgIH1cbiAgfVxufTtcbl9Ub29scy5iYXNlID0gbnVsbDtcbnZhciBUb29scyA9IF9Ub29scztcblxuLy8gbGliL2NvbnNlbnRvbWF0aWMvaW5kZXgudHNcbmZ1bmN0aW9uIG1hdGNoZXMoY29uZmlnKSB7XG4gIGNvbnN0IHJlc3VsdCA9IFRvb2xzLmZpbmQoY29uZmlnKTtcbiAgaWYgKGNvbmZpZy50eXBlID09PSBcImNzc1wiKSB7XG4gICAgcmV0dXJuICEhcmVzdWx0LnRhcmdldDtcbiAgfSBlbHNlIGlmIChjb25maWcudHlwZSA9PT0gXCJjaGVja2JveFwiKSB7XG4gICAgcmV0dXJuICEhcmVzdWx0LnRhcmdldCAmJiByZXN1bHQudGFyZ2V0LmNoZWNrZWQ7XG4gIH1cbn1cbmFzeW5jIGZ1bmN0aW9uIGV4ZWN1dGVBY3Rpb24oY29uZmlnLCBwYXJhbSkge1xuICBzd2l0Y2ggKGNvbmZpZy50eXBlKSB7XG4gICAgY2FzZSBcImNsaWNrXCI6XG4gICAgICByZXR1cm4gY2xpY2tBY3Rpb24oY29uZmlnKTtcbiAgICBjYXNlIFwibGlzdFwiOlxuICAgICAgcmV0dXJuIGxpc3RBY3Rpb24oY29uZmlnLCBwYXJhbSk7XG4gICAgY2FzZSBcImNvbnNlbnRcIjpcbiAgICAgIHJldHVybiBjb25zZW50QWN0aW9uKGNvbmZpZywgcGFyYW0pO1xuICAgIGNhc2UgXCJpZmNzc1wiOlxuICAgICAgcmV0dXJuIGlmQ3NzQWN0aW9uKGNvbmZpZywgcGFyYW0pO1xuICAgIGNhc2UgXCJ3YWl0Y3NzXCI6XG4gICAgICByZXR1cm4gd2FpdENzc0FjdGlvbihjb25maWcpO1xuICAgIGNhc2UgXCJmb3JlYWNoXCI6XG4gICAgICByZXR1cm4gZm9yRWFjaEFjdGlvbihjb25maWcsIHBhcmFtKTtcbiAgICBjYXNlIFwiaGlkZVwiOlxuICAgICAgcmV0dXJuIGhpZGVBY3Rpb24oY29uZmlnKTtcbiAgICBjYXNlIFwic2xpZGVcIjpcbiAgICAgIHJldHVybiBzbGlkZUFjdGlvbihjb25maWcpO1xuICAgIGNhc2UgXCJjbG9zZVwiOlxuICAgICAgcmV0dXJuIGNsb3NlQWN0aW9uKCk7XG4gICAgY2FzZSBcIndhaXRcIjpcbiAgICAgIHJldHVybiB3YWl0QWN0aW9uKGNvbmZpZyk7XG4gICAgY2FzZSBcImV2YWxcIjpcbiAgICAgIHJldHVybiBldmFsQWN0aW9uKGNvbmZpZyk7XG4gICAgZGVmYXVsdDpcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlVua25vd24gYWN0aW9uIHR5cGU6IFwiICsgY29uZmlnLnR5cGUpO1xuICB9XG59XG52YXIgU1RFUF9USU1FT1VUID0gMDtcbmZ1bmN0aW9uIHdhaXRUaW1lb3V0KHRpbWVvdXQpIHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICByZXNvbHZlKCk7XG4gICAgfSwgdGltZW91dCk7XG4gIH0pO1xufVxuYXN5bmMgZnVuY3Rpb24gY2xpY2tBY3Rpb24oY29uZmlnKSB7XG4gIGNvbnN0IHJlc3VsdCA9IFRvb2xzLmZpbmQoY29uZmlnKTtcbiAgaWYgKHJlc3VsdC50YXJnZXQgIT0gbnVsbCkge1xuICAgIHJlc3VsdC50YXJnZXQuY2xpY2soKTtcbiAgfVxuICByZXR1cm4gd2FpdFRpbWVvdXQoU1RFUF9USU1FT1VUKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIGxpc3RBY3Rpb24oY29uZmlnLCBwYXJhbSkge1xuICBmb3IgKGNvbnN0IGFjdGlvbiBvZiBjb25maWcuYWN0aW9ucykge1xuICAgIGF3YWl0IGV4ZWN1dGVBY3Rpb24oYWN0aW9uLCBwYXJhbSk7XG4gIH1cbn1cbmFzeW5jIGZ1bmN0aW9uIGNvbnNlbnRBY3Rpb24oY29uZmlnLCBjb25zZW50VHlwZXMpIHtcbiAgZm9yIChjb25zdCBjb25zZW50Q29uZmlnIG9mIGNvbmZpZy5jb25zZW50cykge1xuICAgIGNvbnN0IHNob3VsZEVuYWJsZSA9IGNvbnNlbnRUeXBlcy5pbmRleE9mKGNvbnNlbnRDb25maWcudHlwZSkgIT09IC0xO1xuICAgIGlmIChjb25zZW50Q29uZmlnLm1hdGNoZXIgJiYgY29uc2VudENvbmZpZy50b2dnbGVBY3Rpb24pIHtcbiAgICAgIGNvbnN0IGlzRW5hYmxlZCA9IG1hdGNoZXMoY29uc2VudENvbmZpZy5tYXRjaGVyKTtcbiAgICAgIGlmIChpc0VuYWJsZWQgIT09IHNob3VsZEVuYWJsZSkge1xuICAgICAgICBhd2FpdCBleGVjdXRlQWN0aW9uKGNvbnNlbnRDb25maWcudG9nZ2xlQWN0aW9uKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKHNob3VsZEVuYWJsZSkge1xuICAgICAgICBhd2FpdCBleGVjdXRlQWN0aW9uKGNvbnNlbnRDb25maWcudHJ1ZUFjdGlvbik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhd2FpdCBleGVjdXRlQWN0aW9uKGNvbnNlbnRDb25maWcuZmFsc2VBY3Rpb24pO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuYXN5bmMgZnVuY3Rpb24gaWZDc3NBY3Rpb24oY29uZmlnLCBwYXJhbSkge1xuICBjb25zdCByZXN1bHQgPSBUb29scy5maW5kKGNvbmZpZyk7XG4gIGlmICghcmVzdWx0LnRhcmdldCkge1xuICAgIGlmIChjb25maWcudHJ1ZUFjdGlvbikge1xuICAgICAgYXdhaXQgZXhlY3V0ZUFjdGlvbihjb25maWcudHJ1ZUFjdGlvbiwgcGFyYW0pO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBpZiAoY29uZmlnLmZhbHNlQWN0aW9uKSB7XG4gICAgICBhd2FpdCBleGVjdXRlQWN0aW9uKGNvbmZpZy5mYWxzZUFjdGlvbiwgcGFyYW0pO1xuICAgIH1cbiAgfVxufVxuYXN5bmMgZnVuY3Rpb24gd2FpdENzc0FjdGlvbihjb25maWcpIHtcbiAgYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICBsZXQgbnVtUmV0cmllcyA9IGNvbmZpZy5yZXRyaWVzIHx8IDEwO1xuICAgIGNvbnN0IHdhaXRUaW1lID0gY29uZmlnLndhaXRUaW1lIHx8IDI1MDtcbiAgICBjb25zdCBjaGVja0NzcyA9ICgpID0+IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IFRvb2xzLmZpbmQoY29uZmlnKTtcbiAgICAgIGlmIChjb25maWcubmVnYXRlZCAmJiByZXN1bHQudGFyZ2V0IHx8ICFjb25maWcubmVnYXRlZCAmJiAhcmVzdWx0LnRhcmdldCkge1xuICAgICAgICBpZiAobnVtUmV0cmllcyA+IDApIHtcbiAgICAgICAgICBudW1SZXRyaWVzIC09IDE7XG4gICAgICAgICAgc2V0VGltZW91dChjaGVja0Nzcywgd2FpdFRpbWUpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgfVxuICAgIH07XG4gICAgY2hlY2tDc3MoKTtcbiAgfSk7XG59XG5hc3luYyBmdW5jdGlvbiBmb3JFYWNoQWN0aW9uKGNvbmZpZywgcGFyYW0pIHtcbiAgY29uc3QgcmVzdWx0cyA9IFRvb2xzLmZpbmQoY29uZmlnLCB0cnVlKTtcbiAgY29uc3Qgb2xkQmFzZSA9IFRvb2xzLmJhc2U7XG4gIGZvciAoY29uc3QgcmVzdWx0IG9mIHJlc3VsdHMpIHtcbiAgICBpZiAocmVzdWx0LnRhcmdldCkge1xuICAgICAgVG9vbHMuc2V0QmFzZShyZXN1bHQudGFyZ2V0KTtcbiAgICAgIGF3YWl0IGV4ZWN1dGVBY3Rpb24oY29uZmlnLmFjdGlvbiwgcGFyYW0pO1xuICAgIH1cbiAgfVxuICBUb29scy5zZXRCYXNlKG9sZEJhc2UpO1xufVxuYXN5bmMgZnVuY3Rpb24gaGlkZUFjdGlvbihjb25maWcpIHtcbiAgY29uc3QgcmVzdWx0ID0gVG9vbHMuZmluZChjb25maWcpO1xuICBpZiAocmVzdWx0LnRhcmdldCkge1xuICAgIHJlc3VsdC50YXJnZXQuY2xhc3NMaXN0LmFkZChcIkF1dG9jb25zZW50LUhpZGRlblwiKTtcbiAgfVxufVxuYXN5bmMgZnVuY3Rpb24gc2xpZGVBY3Rpb24oY29uZmlnKSB7XG4gIGNvbnN0IHJlc3VsdCA9IFRvb2xzLmZpbmQoY29uZmlnKTtcbiAgY29uc3QgZHJhZ1Jlc3VsdCA9IFRvb2xzLmZpbmQoY29uZmlnLmRyYWdUYXJnZXQpO1xuICBpZiAocmVzdWx0LnRhcmdldCkge1xuICAgIGNvbnN0IHRhcmdldEJvdW5kcyA9IHJlc3VsdC50YXJnZXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgY29uc3QgZHJhZ1RhcmdldEJvdW5kcyA9IGRyYWdSZXN1bHQudGFyZ2V0LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGxldCB5RGlmZiA9IGRyYWdUYXJnZXRCb3VuZHMudG9wIC0gdGFyZ2V0Qm91bmRzLnRvcDtcbiAgICBsZXQgeERpZmYgPSBkcmFnVGFyZ2V0Qm91bmRzLmxlZnQgLSB0YXJnZXRCb3VuZHMubGVmdDtcbiAgICBpZiAodGhpcy5jb25maWcuYXhpcy50b0xvd2VyQ2FzZSgpID09PSBcInlcIikge1xuICAgICAgeERpZmYgPSAwO1xuICAgIH1cbiAgICBpZiAodGhpcy5jb25maWcuYXhpcy50b0xvd2VyQ2FzZSgpID09PSBcInhcIikge1xuICAgICAgeURpZmYgPSAwO1xuICAgIH1cbiAgICBjb25zdCBzY3JlZW5YID0gd2luZG93LnNjcmVlblggKyB0YXJnZXRCb3VuZHMubGVmdCArIHRhcmdldEJvdW5kcy53aWR0aCAvIDI7XG4gICAgY29uc3Qgc2NyZWVuWSA9IHdpbmRvdy5zY3JlZW5ZICsgdGFyZ2V0Qm91bmRzLnRvcCArIHRhcmdldEJvdW5kcy5oZWlnaHQgLyAyO1xuICAgIGNvbnN0IGNsaWVudFggPSB0YXJnZXRCb3VuZHMubGVmdCArIHRhcmdldEJvdW5kcy53aWR0aCAvIDI7XG4gICAgY29uc3QgY2xpZW50WSA9IHRhcmdldEJvdW5kcy50b3AgKyB0YXJnZXRCb3VuZHMuaGVpZ2h0IC8gMjtcbiAgICBjb25zdCBtb3VzZURvd24gPSBkb2N1bWVudC5jcmVhdGVFdmVudChcIk1vdXNlRXZlbnRzXCIpO1xuICAgIG1vdXNlRG93bi5pbml0TW91c2VFdmVudChcbiAgICAgIFwibW91c2Vkb3duXCIsXG4gICAgICB0cnVlLFxuICAgICAgdHJ1ZSxcbiAgICAgIHdpbmRvdyxcbiAgICAgIDAsXG4gICAgICBzY3JlZW5YLFxuICAgICAgc2NyZWVuWSxcbiAgICAgIGNsaWVudFgsXG4gICAgICBjbGllbnRZLFxuICAgICAgZmFsc2UsXG4gICAgICBmYWxzZSxcbiAgICAgIGZhbHNlLFxuICAgICAgZmFsc2UsXG4gICAgICAwLFxuICAgICAgcmVzdWx0LnRhcmdldFxuICAgICk7XG4gICAgY29uc3QgbW91c2VNb3ZlID0gZG9jdW1lbnQuY3JlYXRlRXZlbnQoXCJNb3VzZUV2ZW50c1wiKTtcbiAgICBtb3VzZU1vdmUuaW5pdE1vdXNlRXZlbnQoXG4gICAgICBcIm1vdXNlbW92ZVwiLFxuICAgICAgdHJ1ZSxcbiAgICAgIHRydWUsXG4gICAgICB3aW5kb3csXG4gICAgICAwLFxuICAgICAgc2NyZWVuWCArIHhEaWZmLFxuICAgICAgc2NyZWVuWSArIHlEaWZmLFxuICAgICAgY2xpZW50WCArIHhEaWZmLFxuICAgICAgY2xpZW50WSArIHlEaWZmLFxuICAgICAgZmFsc2UsXG4gICAgICBmYWxzZSxcbiAgICAgIGZhbHNlLFxuICAgICAgZmFsc2UsXG4gICAgICAwLFxuICAgICAgcmVzdWx0LnRhcmdldFxuICAgICk7XG4gICAgY29uc3QgbW91c2VVcCA9IGRvY3VtZW50LmNyZWF0ZUV2ZW50KFwiTW91c2VFdmVudHNcIik7XG4gICAgbW91c2VVcC5pbml0TW91c2VFdmVudChcbiAgICAgIFwibW91c2V1cFwiLFxuICAgICAgdHJ1ZSxcbiAgICAgIHRydWUsXG4gICAgICB3aW5kb3csXG4gICAgICAwLFxuICAgICAgc2NyZWVuWCArIHhEaWZmLFxuICAgICAgc2NyZWVuWSArIHlEaWZmLFxuICAgICAgY2xpZW50WCArIHhEaWZmLFxuICAgICAgY2xpZW50WSArIHlEaWZmLFxuICAgICAgZmFsc2UsXG4gICAgICBmYWxzZSxcbiAgICAgIGZhbHNlLFxuICAgICAgZmFsc2UsXG4gICAgICAwLFxuICAgICAgcmVzdWx0LnRhcmdldFxuICAgICk7XG4gICAgcmVzdWx0LnRhcmdldC5kaXNwYXRjaEV2ZW50KG1vdXNlRG93bik7XG4gICAgYXdhaXQgdGhpcy53YWl0VGltZW91dCgxMCk7XG4gICAgcmVzdWx0LnRhcmdldC5kaXNwYXRjaEV2ZW50KG1vdXNlTW92ZSk7XG4gICAgYXdhaXQgdGhpcy53YWl0VGltZW91dCgxMCk7XG4gICAgcmVzdWx0LnRhcmdldC5kaXNwYXRjaEV2ZW50KG1vdXNlVXApO1xuICB9XG59XG5hc3luYyBmdW5jdGlvbiB3YWl0QWN0aW9uKGNvbmZpZykge1xuICBhd2FpdCB3YWl0VGltZW91dChjb25maWcud2FpdFRpbWUpO1xufVxuYXN5bmMgZnVuY3Rpb24gY2xvc2VBY3Rpb24oKSB7XG4gIHdpbmRvdy5jbG9zZSgpO1xufVxuYXN5bmMgZnVuY3Rpb24gZXZhbEFjdGlvbihjb25maWcpIHtcbiAgY29uc29sZS5sb2coXCJldmFsIVwiLCBjb25maWcuY29kZSk7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBpZiAoY29uZmlnLmFzeW5jKSB7XG4gICAgICAgIHdpbmRvdy5ldmFsKGNvbmZpZy5jb2RlKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgcmVzb2x2ZSh3aW5kb3cuZXZhbChcIndpbmRvdy5fX2NvbnNlbnRDaGVja1Jlc3VsdFwiKSk7XG4gICAgICAgIH0sIGNvbmZpZy50aW1lb3V0IHx8IDI1MCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXNvbHZlKHdpbmRvdy5ldmFsKGNvbmZpZy5jb2RlKSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS53YXJuKFwiZXZhbCBlcnJvclwiLCBlLCBjb25maWcuY29kZSk7XG4gICAgICByZXNvbHZlKGZhbHNlKTtcbiAgICB9XG4gIH0pO1xufVxuXG4vLyBsaWIvcmFuZG9tLnRzXG5mdW5jdGlvbiBnZXRSYW5kb21JRCgpIHtcbiAgaWYgKGNyeXB0byAmJiB0eXBlb2YgY3J5cHRvLnJhbmRvbVVVSUQgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICByZXR1cm4gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbiAgfVxuICByZXR1cm4gTWF0aC5yYW5kb20oKS50b1N0cmluZygpO1xufVxuXG4vLyBsaWIvZXZhbC1oYW5kbGVyLnRzXG52YXIgRGVmZXJyZWQgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKGlkLCB0aW1lb3V0ID0gMWUzKSB7XG4gICAgdGhpcy5pZCA9IGlkO1xuICAgIHRoaXMucHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHRoaXMucmVzb2x2ZSA9IHJlc29sdmU7XG4gICAgICB0aGlzLnJlamVjdCA9IHJlamVjdDtcbiAgICB9KTtcbiAgICB0aGlzLnRpbWVyID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGhpcy5yZWplY3QobmV3IEVycm9yKFwidGltZW91dFwiKSk7XG4gICAgfSwgdGltZW91dCk7XG4gIH1cbn07XG52YXIgZXZhbFN0YXRlID0ge1xuICBwZW5kaW5nOiAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpLFxuICBzZW5kQ29udGVudE1lc3NhZ2U6IG51bGxcbn07XG5mdW5jdGlvbiByZXF1ZXN0RXZhbChjb2RlLCBzbmlwcGV0SWQpIHtcbiAgY29uc3QgaWQgPSBnZXRSYW5kb21JRCgpO1xuICBldmFsU3RhdGUuc2VuZENvbnRlbnRNZXNzYWdlKHtcbiAgICB0eXBlOiBcImV2YWxcIixcbiAgICBpZCxcbiAgICBjb2RlLFxuICAgIHNuaXBwZXRJZFxuICB9KTtcbiAgY29uc3QgZGVmZXJyZWQgPSBuZXcgRGVmZXJyZWQoaWQpO1xuICBldmFsU3RhdGUucGVuZGluZy5zZXQoZGVmZXJyZWQuaWQsIGRlZmVycmVkKTtcbiAgcmV0dXJuIGRlZmVycmVkLnByb21pc2U7XG59XG5mdW5jdGlvbiByZXNvbHZlRXZhbChpZCwgdmFsdWUpIHtcbiAgY29uc3QgZGVmZXJyZWQgPSBldmFsU3RhdGUucGVuZGluZy5nZXQoaWQpO1xuICBpZiAoZGVmZXJyZWQpIHtcbiAgICBldmFsU3RhdGUucGVuZGluZy5kZWxldGUoaWQpO1xuICAgIGRlZmVycmVkLnRpbWVyICYmIHdpbmRvdy5jbGVhclRpbWVvdXQoZGVmZXJyZWQudGltZXIpO1xuICAgIGRlZmVycmVkLnJlc29sdmUodmFsdWUpO1xuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUud2FybihcIm5vIGV2YWwgI1wiLCBpZCk7XG4gIH1cbn1cblxuLy8gbGliL2V2YWwtc25pcHBldHMudHNcbnZhciBzbmlwcGV0cyA9IHtcbiAgLy8gY29kZS1iYXNlZCBydWxlc1xuICBFVkFMXzA6ICgpID0+IGNvbnNvbGUubG9nKDEpLFxuICBFVkFMX0NPTlNFTlRNQU5BR0VSXzE6ICgpID0+IHdpbmRvdy5fX2NtcCAmJiB0eXBlb2YgX19jbXAoXCJnZXRDTVBEYXRhXCIpID09PSBcIm9iamVjdFwiLFxuICBFVkFMX0NPTlNFTlRNQU5BR0VSXzI6ICgpID0+ICFfX2NtcChcImNvbnNlbnRTdGF0dXNcIikudXNlckNob2ljZUV4aXN0cyxcbiAgRVZBTF9DT05TRU5UTUFOQUdFUl8zOiAoKSA9PiBfX2NtcChcInNldENvbnNlbnRcIiwgMCksXG4gIEVWQUxfQ09OU0VOVE1BTkFHRVJfNDogKCkgPT4gX19jbXAoXCJzZXRDb25zZW50XCIsIDEpLFxuICBFVkFMX0NPTlNFTlRNQU5BR0VSXzU6ICgpID0+IF9fY21wKFwiY29uc2VudFN0YXR1c1wiKS51c2VyQ2hvaWNlRXhpc3RzLFxuICBFVkFMX0NPT0tJRUJPVF8xOiAoKSA9PiAhIXdpbmRvdy5Db29raWVib3QsXG4gIEVWQUxfQ09PS0lFQk9UXzI6ICgpID0+ICF3aW5kb3cuQ29va2llYm90Lmhhc1Jlc3BvbnNlICYmIHdpbmRvdy5Db29raWVib3QuZGlhbG9nPy52aXNpYmxlID09PSB0cnVlLFxuICBFVkFMX0NPT0tJRUJPVF8zOiAoKSA9PiB3aW5kb3cuQ29va2llYm90LndpdGhkcmF3KCkgfHwgdHJ1ZSxcbiAgRVZBTF9DT09LSUVCT1RfNDogKCkgPT4gd2luZG93LkNvb2tpZWJvdC5oaWRlKCkgfHwgdHJ1ZSxcbiAgRVZBTF9DT09LSUVCT1RfNTogKCkgPT4gd2luZG93LkNvb2tpZWJvdC5kZWNsaW5lZCA9PT0gdHJ1ZSxcbiAgRVZBTF9LTEFST18xOiAoKSA9PiB7XG4gICAgY29uc3QgY29uZmlnID0gZ2xvYmFsVGhpcy5rbGFyb0NvbmZpZyB8fCBnbG9iYWxUaGlzLmtsYXJvPy5nZXRNYW5hZ2VyICYmIGdsb2JhbFRoaXMua2xhcm8uZ2V0TWFuYWdlcigpLmNvbmZpZztcbiAgICBpZiAoIWNvbmZpZykge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGNvbnN0IG9wdGlvbmFsU2VydmljZXMgPSAoY29uZmlnLnNlcnZpY2VzIHx8IGNvbmZpZy5hcHBzKS5maWx0ZXIoKHMpID0+ICFzLnJlcXVpcmVkKS5tYXAoKHMpID0+IHMubmFtZSk7XG4gICAgaWYgKGtsYXJvICYmIGtsYXJvLmdldE1hbmFnZXIpIHtcbiAgICAgIGNvbnN0IG1hbmFnZXIgPSBrbGFyby5nZXRNYW5hZ2VyKCk7XG4gICAgICByZXR1cm4gb3B0aW9uYWxTZXJ2aWNlcy5ldmVyeSgobmFtZSkgPT4gIW1hbmFnZXIuY29uc2VudHNbbmFtZV0pO1xuICAgIH0gZWxzZSBpZiAoa2xhcm9Db25maWcgJiYga2xhcm9Db25maWcuc3RvcmFnZU1ldGhvZCA9PT0gXCJjb29raWVcIikge1xuICAgICAgY29uc3QgY29va2llTmFtZSA9IGtsYXJvQ29uZmlnLmNvb2tpZU5hbWUgfHwga2xhcm9Db25maWcuc3RvcmFnZU5hbWU7XG4gICAgICBjb25zdCBjb25zZW50cyA9IEpTT04ucGFyc2UoXG4gICAgICAgIGRlY29kZVVSSUNvbXBvbmVudChcbiAgICAgICAgICBkb2N1bWVudC5jb29raWUuc3BsaXQoXCI7XCIpLmZpbmQoKGMpID0+IGMudHJpbSgpLnN0YXJ0c1dpdGgoY29va2llTmFtZSkpLnNwbGl0KFwiPVwiKVsxXVxuICAgICAgICApXG4gICAgICApO1xuICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKGNvbnNlbnRzKS5maWx0ZXIoKGspID0+IG9wdGlvbmFsU2VydmljZXMuaW5jbHVkZXMoaykpLmV2ZXJ5KChrKSA9PiBjb25zZW50c1trXSA9PT0gZmFsc2UpO1xuICAgIH1cbiAgfSxcbiAgRVZBTF9LTEFST19PUEVOX1BPUFVQOiAoKSA9PiB7XG4gICAga2xhcm8uc2hvdyh2b2lkIDAsIHRydWUpO1xuICB9LFxuICBFVkFMX0tMQVJPX1RSWV9BUElfT1BUX09VVDogKCkgPT4ge1xuICAgIGlmICh3aW5kb3cua2xhcm8gJiYgdHlwZW9mIGtsYXJvLnNob3cgPT09IFwiZnVuY3Rpb25cIiAmJiB0eXBlb2Yga2xhcm8uZ2V0TWFuYWdlciA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICB0cnkge1xuICAgICAgICBrbGFyby5nZXRNYW5hZ2VyKCkuY2hhbmdlQWxsKGZhbHNlKTtcbiAgICAgICAga2xhcm8uZ2V0TWFuYWdlcigpLnNhdmVBbmRBcHBseUNvbnNlbnRzKCk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLndhcm4oZSk7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9LFxuICBFVkFMX09ORVRSVVNUXzE6ICgpID0+IHdpbmRvdy5PbmV0cnVzdEFjdGl2ZUdyb3Vwcy5zcGxpdChcIixcIikuZmlsdGVyKChzKSA9PiBzLmxlbmd0aCA+IDApLmxlbmd0aCA8PSAxLFxuICBFVkFMX1RSVVNUQVJDX1RPUDogKCkgPT4gd2luZG93ICYmIHdpbmRvdy50cnVzdGUgJiYgd2luZG93LnRydXN0ZS5ldS5iaW5kTWFwLnByZWZDb29raWUgPT09IFwiMFwiLFxuICBFVkFMX1RSVVNUQVJDX0ZSQU1FX1RFU1Q6ICgpID0+IHdpbmRvdyAmJiB3aW5kb3cuUXVlcnlTdHJpbmcgJiYgd2luZG93LlF1ZXJ5U3RyaW5nLnByZWZlcmVuY2VzID09PSBcIjBcIixcbiAgRVZBTF9UUlVTVEFSQ19GUkFNRV9HVE06ICgpID0+IHdpbmRvdyAmJiB3aW5kb3cuUXVlcnlTdHJpbmcgJiYgd2luZG93LlF1ZXJ5U3RyaW5nLmd0bSA9PT0gXCIxXCIsXG4gIC8vIGRlY2xhcmF0aXZlIHJ1bGVzXG4gIEVWQUxfQURPUFRfVEVTVDogKCkgPT4gISFsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImFkb3B0Q29uc2VudE1vZGVcIiksXG4gIEVWQUxfQURVTFRGUklFTkRGSU5ERVJfVEVTVDogKCkgPT4gISFsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvb2tpZUNvbnNlbnRcIiksXG4gIEVWQUxfQkFITl9URVNUOiAoKSA9PiB1dGFnLmdkcHIuZ2V0U2VsZWN0ZWRDYXRlZ29yaWVzKCkubGVuZ3RoID09PSAxLFxuICBFVkFMX0JJR0NPTU1FUkNFX0NPTlNFTlRfTUFOQUdFUl9ERVRFQ1Q6ICgpID0+ICEhKHdpbmRvdy5jb25zZW50TWFuYWdlciAmJiB3aW5kb3cuY29uc2VudE1hbmFnZXIudmVyc2lvbiksXG4gIEVWQUxfQk9STEFCU18wOiAoKSA9PiAhSlNPTi5wYXJzZShcbiAgICBkZWNvZGVVUklDb21wb25lbnQoXG4gICAgICBkb2N1bWVudC5jb29raWUuc3BsaXQoXCI7XCIpLmZpbmQoKGMpID0+IGMuaW5kZXhPZihcImJvcmxhYnMtY29va2llXCIpICE9PSAtMSkuc3BsaXQoXCI9XCIsIDIpWzFdXG4gICAgKVxuICApLmNvbnNlbnRzLnN0YXRpc3RpY3MsXG4gIEVWQUxfQ0NfQkFOTkVSMl8wOiAoKSA9PiAhIWRvY3VtZW50LmNvb2tpZS5tYXRjaCgvc25jYz1bXjtdK0QlM0R0cnVlLyksXG4gIEVWQUxfQ09JTkJBU0VfMDogKCkgPT4gSlNPTi5wYXJzZShkZWNvZGVVUklDb21wb25lbnQoZG9jdW1lbnQuY29va2llLm1hdGNoKC9jbV8oZXV8ZGVmYXVsdClfcHJlZmVyZW5jZXM9KFswLTlhLXpBLVpcXFxce1xcXFx9XFxcXFtcXFxcXSU6XSopOz8vKVsyXSkpLmNvbnNlbnQubGVuZ3RoIDw9IDEsXG4gIEVWQUxfQ09PS0lFX0xBV19JTkZPXzA6ICgpID0+IHtcbiAgICBpZiAoQ0xJLmRpc2FibGVBbGxDb29raWVzKSBDTEkuZGlzYWJsZUFsbENvb2tpZXMoKTtcbiAgICBpZiAoQ0xJLnJlamVjdF9jbG9zZSkgQ0xJLnJlamVjdF9jbG9zZSgpO1xuICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnJlbW92ZShcImNsaS1iYXJtb2RhbC1vcGVuXCIpO1xuICAgIHJldHVybiB0cnVlO1xuICB9LFxuICBFVkFMX0NPT0tJRV9MQVdfSU5GT19ERVRFQ1Q6ICgpID0+ICEhd2luZG93LkNMSSxcbiAgRVZBTF9DT09LSUVfTUFOQUdFUl9QT1BVUF8wOiAoKSA9PiBKU09OLnBhcnNlKFxuICAgIGRvY3VtZW50LmNvb2tpZS5zcGxpdChcIjtcIikuZmluZCgoYykgPT4gYy50cmltKCkuc3RhcnRzV2l0aChcIkNvb2tpZUxldmVsXCIpKS5zcGxpdChcIj1cIilbMV1cbiAgKS5zb2NpYWwgPT09IGZhbHNlLFxuICBFVkFMX0NPT0tJRUFMRVJUXzA6ICgpID0+IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJib2R5XCIpLnJlbW92ZUF0dHJpYnV0ZShcInN0eWxlXCIpIHx8IHRydWUsXG4gIEVWQUxfQ09PS0lFQUxFUlRfMTogKCkgPT4gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcImJvZHlcIikucmVtb3ZlQXR0cmlidXRlKFwic3R5bGVcIikgfHwgdHJ1ZSxcbiAgRVZBTF9DT09LSUVBTEVSVF8yOiAoKSA9PiB3aW5kb3cuQ29va2llQ29uc2VudC5kZWNsaW5lZCA9PT0gdHJ1ZSxcbiAgRVZBTF9DT09LSUVGSVJTVF8wOiAoKSA9PiAoKG8pID0+IG8ucGVyZm9ybWFuY2UgPT09IGZhbHNlICYmIG8uZnVuY3Rpb25hbCA9PT0gZmFsc2UgJiYgby5hZHZlcnRpc2luZyA9PT0gZmFsc2UpKFxuICAgIEpTT04ucGFyc2UoXG4gICAgICBkZWNvZGVVUklDb21wb25lbnQoXG4gICAgICAgIGRvY3VtZW50LmNvb2tpZS5zcGxpdChcIjtcIikuZmluZCgoYykgPT4gYy5pbmRleE9mKFwiY29va2llZmlyc3RcIikgIT09IC0xKS50cmltKClcbiAgICAgICkuc3BsaXQoXCI9XCIpWzFdXG4gICAgKVxuICApLFxuICBFVkFMX0NPT0tJRUZJUlNUXzE6ICgpID0+IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJidXR0b25bZGF0YS1jb29raWVmaXJzdC1hY2NlbnQtY29sb3I9dHJ1ZV1bcm9sZT1jaGVja2JveF06bm90KFtkaXNhYmxlZF0pXCIpLmZvckVhY2goKGkpID0+IGkuZ2V0QXR0cmlidXRlKFwiYXJpYS1jaGVja2VkXCIpID09PSBcInRydWVcIiAmJiBpLmNsaWNrKCkpIHx8IHRydWUsXG4gIEVWQUxfQ09PS0lFSU5GT1JNQVRJT05fMDogKCkgPT4gQ29va2llSW5mb3JtYXRpb24uZGVjbGluZUFsbENhdGVnb3JpZXMoKSB8fCB0cnVlLFxuICBFVkFMX0NPT0tJRUlORk9STUFUSU9OXzE6ICgpID0+IENvb2tpZUluZm9ybWF0aW9uLnN1Ym1pdEFsbENhdGVnb3JpZXMoKSB8fCB0cnVlLFxuICBFVkFMX0VUU1lfMDogKCkgPT4gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi5nZHByLW92ZXJsYXktYm9keSBpbnB1dFwiKS5mb3JFYWNoKCh0b2dnbGUpID0+IHtcbiAgICB0b2dnbGUuY2hlY2tlZCA9IGZhbHNlO1xuICB9KSB8fCB0cnVlLFxuICBFVkFMX0VUU1lfMTogKCkgPT4gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5nZHByLW92ZXJsYXktdmlldyBidXR0b25bZGF0YS13dC1vdmVybGF5LWNsb3NlXVwiKS5jbGljaygpIHx8IHRydWUsXG4gIEVWQUxfRVpPSUNfMDogKCkgPT4gZXpDTVAuaGFuZGxlQWNjZXB0QWxsQ2xpY2soKSxcbiAgRVZBTF9GSURFU19ERVRFQ1RfUE9QVVA6ICgpID0+IHdpbmRvdy5GaWRlcz8uaW5pdGlhbGl6ZWQsXG4gIEVWQUxfR0RQUl9MRUdBTF9DT09LSUVfREVURUNUX0NNUDogKCkgPT4gISF3aW5kb3cuR0RQUl9MQyxcbiAgRVZBTF9HRFBSX0xFR0FMX0NPT0tJRV9URVNUOiAoKSA9PiAhIXdpbmRvdy5HRFBSX0xDPy51c2VyQ29uc2VudFNldHRpbmcsXG4gIEVWQUxfSVVCRU5EQV8wOiAoKSA9PiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLnB1cnBvc2VzLWl0ZW0gaW5wdXRbdHlwZT1jaGVja2JveF06bm90KFtkaXNhYmxlZF0pXCIpLmZvckVhY2goKHgpID0+IHtcbiAgICBpZiAoeC5jaGVja2VkKSB4LmNsaWNrKCk7XG4gIH0pIHx8IHRydWUsXG4gIEVWQUxfSVVCRU5EQV8xOiAoKSA9PiAhIWRvY3VtZW50LmNvb2tpZS5tYXRjaCgvX2l1Yl9jcy1cXGQrPS8pLFxuICBFVkFMX01FRElBVklORV8wOiAoKSA9PiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdbZGF0YS1uYW1lPVwibWVkaWF2aW5lLWdkcHItY21wXCJdIGlucHV0W3R5cGU9Y2hlY2tib3hdJykuZm9yRWFjaCgoeCkgPT4geC5jaGVja2VkICYmIHguY2xpY2soKSkgfHwgdHJ1ZSxcbiAgRVZBTF9NSUNST1NPRlRfMDogKCkgPT4gQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiZGl2ID4gYnV0dG9uXCIpKS5maWx0ZXIoKGVsKSA9PiBlbC5pbm5lclRleHQubWF0Y2goXCJSZWplY3R8QWJsZWhuZW5cIikpWzBdLmNsaWNrKCkgfHwgdHJ1ZSxcbiAgRVZBTF9NSUNST1NPRlRfMTogKCkgPT4gQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiZGl2ID4gYnV0dG9uXCIpKS5maWx0ZXIoKGVsKSA9PiBlbC5pbm5lclRleHQubWF0Y2goXCJBY2NlcHR8QW5uZWhtZW5cIikpWzBdLmNsaWNrKCkgfHwgdHJ1ZSxcbiAgRVZBTF9NSUNST1NPRlRfMjogKCkgPT4gISFkb2N1bWVudC5jb29raWUubWF0Y2goXCJNU0NDfEdIQ0NcIiksXG4gIEVWQUxfTU9PVkVfMDogKCkgPT4gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIiNtb292ZV9nZHByX2Nvb2tpZV9tb2RhbCBpbnB1dFwiKS5mb3JFYWNoKChpKSA9PiB7XG4gICAgaWYgKCFpLmRpc2FibGVkKSBpLmNoZWNrZWQgPSBpLm5hbWUgPT09IFwibW9vdmVfZ2Rwcl9zdHJpY3RfY29va2llc1wiIHx8IGkuaWQgPT09IFwibW9vdmVfZ2Rwcl9zdHJpY3RfY29va2llc1wiO1xuICB9KSB8fCB0cnVlLFxuICBFVkFMX05ITklFVVdTX1RFU1Q6ICgpID0+ICEhbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJwc2g6Y29va2llcy1zZWVuXCIpLFxuICBFVkFMX09TQU5PX0RFVEVDVDogKCkgPT4gISF3aW5kb3cuT3Nhbm8/LmNtPy5kaWFsb2dPcGVuLFxuICBFVkFMX1BBTkRFQ1RFU19URVNUOiAoKSA9PiBkb2N1bWVudC5jb29raWUuaW5jbHVkZXMoXCJfcGFuZGVjdGVzX2dkcHI9XCIpICYmIEpTT04ucGFyc2UoXG4gICAgYXRvYihcbiAgICAgIGRvY3VtZW50LmNvb2tpZS5zcGxpdChcIjtcIikuZmluZCgocykgPT4gcy50cmltKCkuc3RhcnRzV2l0aChcIl9wYW5kZWN0ZXNfZ2RwclwiKSkuc3BsaXQoXCI9XCIpWzFdXG4gICAgKVxuICApLnN0YXR1cyA9PT0gXCJkZW55XCIsXG4gIEVWQUxfUE9WUl9HT0JBQ0s6ICgpID0+IHdpbmRvdy5oaXN0b3J5LmJhY2soKSB8fCB0cnVlLFxuICBFVkFMX1BVQlRFQ0hfMDogKCkgPT4gZG9jdW1lbnQuY29va2llLmluY2x1ZGVzKFwiZXVjb25zZW50LXYyXCIpICYmIChkb2N1bWVudC5jb29raWUubWF0Y2goLy5ZQUFBQUFBQUFBQUEvKSB8fCBkb2N1bWVudC5jb29raWUubWF0Y2goLy5hQUFBQUFBQUFBQUEvKSB8fCBkb2N1bWVudC5jb29raWUubWF0Y2goLy5ZQUFBQ0ZnQUFBQUEvKSksXG4gIEVWQUxfUkVNQVJLQUJMRV9URVNUOiAoKSA9PiAhIWxvY2FsU3RvcmFnZS5nZXRJdGVtKFwicm1Db29raWVDb25zZW50XCIpLFxuICBFVkFMX1NIT1BJRllfVEVTVDogKCkgPT4gZG9jdW1lbnQuY29va2llLmluY2x1ZGVzKFwiZ2Rwcl9jb29raWVfY29uc2VudD0wXCIpIHx8IGRvY3VtZW50LmNvb2tpZS5pbmNsdWRlcyhcIl90cmFja2luZ19jb25zZW50PVwiKSAmJiBKU09OLnBhcnNlKFxuICAgIGRlY29kZVVSSUNvbXBvbmVudChcbiAgICAgIGRvY3VtZW50LmNvb2tpZS5zcGxpdChcIjtcIikuZmluZCgocykgPT4gcy50cmltKCkuc3RhcnRzV2l0aChcIl90cmFja2luZ19jb25zZW50XCIpKS5zcGxpdChcIj1cIilbMV1cbiAgICApXG4gICkucHVycG9zZXMuYSA9PT0gZmFsc2UsXG4gIEVWQUxfU0tZU0NBTk5FUl9URVNUOiAoKSA9PiBkb2N1bWVudC5jb29raWUubWF0Y2goL2dkcHI9W147XSphZHZlcnRzOjo6ZmFsc2UvKSAmJiAhZG9jdW1lbnQuY29va2llLm1hdGNoKC9nZHByPVteO10qaW5pdDo6OnRydWUvKSxcbiAgRVZBTF9TSVJEQVRBX1VOQkxPQ0tfU0NST0xMOiAoKSA9PiB7XG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsYXNzTGlzdC5mb3JFYWNoKChjbHMpID0+IHtcbiAgICAgIGlmIChjbHMuc3RhcnRzV2l0aChcInNkLWNtcC1cIikpIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKGNscyk7XG4gICAgfSk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0sXG4gIEVWQUxfU1RFQU1QT1dFUkVEXzA6ICgpID0+IEpTT04ucGFyc2UoXG4gICAgZGVjb2RlVVJJQ29tcG9uZW50KFxuICAgICAgZG9jdW1lbnQuY29va2llLnNwbGl0KFwiO1wiKS5maW5kKChzKSA9PiBzLnRyaW0oKS5zdGFydHNXaXRoKFwiY29va2llU2V0dGluZ3NcIikpLnNwbGl0KFwiPVwiKVsxXVxuICAgIClcbiAgKS5wcmVmZXJlbmNlX3N0YXRlID09PSAyLFxuICBFVkFMX1RBS0VBTE9UXzA6ICgpID0+IGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnJlbW92ZShcImZyZWV6ZVwiKSB8fCAoZG9jdW1lbnQuYm9keS5zdHlsZSA9IFwiXCIpIHx8IHRydWUsXG4gIEVWQUxfVEFSVEVBVUNJVFJPTl8wOiAoKSA9PiB0YXJ0ZWF1Y2l0cm9uLnVzZXJJbnRlcmZhY2UucmVzcG9uZEFsbChmYWxzZSkgfHwgdHJ1ZSxcbiAgRVZBTF9UQVJURUFVQ0lUUk9OXzE6ICgpID0+IHRhcnRlYXVjaXRyb24udXNlckludGVyZmFjZS5yZXNwb25kQWxsKHRydWUpIHx8IHRydWUsXG4gIEVWQUxfVEFSVEVBVUNJVFJPTl8yOiAoKSA9PiBkb2N1bWVudC5jb29raWUubWF0Y2goL3RhcnRlYXVjaXRyb249W147XSovKT8uWzBdLmluY2x1ZGVzKFwiZmFsc2VcIiksXG4gIEVWQUxfVEVBTElVTV8wOiAoKSA9PiB0eXBlb2Ygd2luZG93LnV0YWcgIT09IFwidW5kZWZpbmVkXCIgJiYgdHlwZW9mIHV0YWcuZ2RwciA9PT0gXCJvYmplY3RcIixcbiAgRVZBTF9URUFMSVVNXzE6ICgpID0+IHV0YWcuZ2Rwci5zZXRDb25zZW50VmFsdWUoZmFsc2UpIHx8IHRydWUsXG4gIEVWQUxfVEVBTElVTV9ET05PVFNFTEw6ICgpID0+IHV0YWcuZ2Rwci5kbnM/LnNldERuc1N0YXRlKGZhbHNlKSB8fCB0cnVlLFxuICBFVkFMX1RFQUxJVU1fMjogKCkgPT4gdXRhZy5nZHByLnNldENvbnNlbnRWYWx1ZSh0cnVlKSB8fCB0cnVlLFxuICBFVkFMX1RFQUxJVU1fMzogKCkgPT4gdXRhZy5nZHByLmdldENvbnNlbnRTdGF0ZSgpICE9PSAxLFxuICBFVkFMX1RFQUxJVU1fRE9OT1RTRUxMX0NIRUNLOiAoKSA9PiB1dGFnLmdkcHIuZG5zPy5nZXREbnNTdGF0ZSgpICE9PSAxLFxuICBFVkFMX1RFU1RDTVBfU1RFUDogKCkgPT4gISFkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3JlamVjdC1hbGxcIiksXG4gIEVWQUxfVEVTVENNUF8wOiAoKSA9PiB3aW5kb3cucmVzdWx0cy5yZXN1bHRzWzBdID09PSBcImJ1dHRvbl9jbGlja2VkXCIsXG4gIEVWQUxfVEVTVENNUF9DT1NNRVRJQ18wOiAoKSA9PiB3aW5kb3cucmVzdWx0cy5yZXN1bHRzWzBdID09PSBcImJhbm5lcl9oaWRkZW5cIixcbiAgRVZBTF9USEVGUkVFRElDVElPTkFSWV8wOiAoKSA9PiBjbXBVaS5zaG93UHVycG9zZXMoKSB8fCBjbXBVaS5yZWplY3RBbGwoKSB8fCB0cnVlLFxuICBFVkFMX1RIRUZSRUVESUNUSU9OQVJZXzE6ICgpID0+IGNtcFVpLmFsbG93QWxsKCkgfHwgdHJ1ZSxcbiAgRVZBTF9VU0VSQ0VOVFJJQ1NfQVBJXzA6ICgpID0+IHR5cGVvZiBVQ19VSSA9PT0gXCJvYmplY3RcIixcbiAgRVZBTF9VU0VSQ0VOVFJJQ1NfQVBJXzE6ICgpID0+ICEhVUNfVUkuY2xvc2VDTVAoKSxcbiAgRVZBTF9VU0VSQ0VOVFJJQ1NfQVBJXzI6ICgpID0+ICEhVUNfVUkuZGVueUFsbENvbnNlbnRzKCksXG4gIEVWQUxfVVNFUkNFTlRSSUNTX0FQSV8zOiAoKSA9PiAhIVVDX1VJLmFjY2VwdEFsbENvbnNlbnRzKCksXG4gIEVWQUxfVVNFUkNFTlRSSUNTX0FQSV80OiAoKSA9PiAhIVVDX1VJLmNsb3NlQ01QKCksXG4gIEVWQUxfVVNFUkNFTlRSSUNTX0FQSV81OiAoKSA9PiBVQ19VSS5hcmVBbGxDb25zZW50c0FjY2VwdGVkKCkgPT09IHRydWUsXG4gIEVWQUxfVVNFUkNFTlRSSUNTX0FQSV82OiAoKSA9PiBVQ19VSS5hcmVBbGxDb25zZW50c0FjY2VwdGVkKCkgPT09IGZhbHNlLFxuICBFVkFMX1VTRVJDRU5UUklDU19CVVRUT05fMDogKCkgPT4gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJjZW50cmljc1wiKSkuY29uc2VudHMuZXZlcnkoKGMpID0+IGMuaXNFc3NlbnRpYWwgfHwgIWMuY29uc2VudFN0YXR1cyksXG4gIEVWQUxfV0FJVFJPU0VfMDogKCkgPT4gQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwibGFiZWxbaWQkPWNvb2tpZXMtZGVueS1sYWJlbF1cIikpLmZvckVhY2goKGUpID0+IGUuY2xpY2soKSkgfHwgdHJ1ZVxufTtcbmZ1bmN0aW9uIGdldEZ1bmN0aW9uQm9keShzbmlwcGV0RnVuYykge1xuICBjb25zdCBzbmlwcGV0U3RyID0gc25pcHBldEZ1bmMudG9TdHJpbmcoKTtcbiAgcmV0dXJuIGAoJHtzbmlwcGV0U3RyfSkoKWA7XG59XG5cbi8vIGxpYi91dGlscy50c1xuZnVuY3Rpb24gZ2V0U3R5bGVFbGVtZW50KHN0eWxlT3ZlcnJpZGVFbGVtZW50SWQgPSBcImF1dG9jb25zZW50LWNzcy1ydWxlc1wiKSB7XG4gIGNvbnN0IHN0eWxlU2VsZWN0b3IgPSBgc3R5bGUjJHtzdHlsZU92ZXJyaWRlRWxlbWVudElkfWA7XG4gIGNvbnN0IGV4aXN0aW5nRWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3Ioc3R5bGVTZWxlY3Rvcik7XG4gIGlmIChleGlzdGluZ0VsZW1lbnQgJiYgZXhpc3RpbmdFbGVtZW50IGluc3RhbmNlb2YgSFRNTFN0eWxlRWxlbWVudCkge1xuICAgIHJldHVybiBleGlzdGluZ0VsZW1lbnQ7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgcGFyZW50ID0gZG9jdW1lbnQuaGVhZCB8fCBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImhlYWRcIilbMF0gfHwgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50O1xuICAgIGNvbnN0IGNzcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzdHlsZVwiKTtcbiAgICBjc3MuaWQgPSBzdHlsZU92ZXJyaWRlRWxlbWVudElkO1xuICAgIHBhcmVudC5hcHBlbmRDaGlsZChjc3MpO1xuICAgIHJldHVybiBjc3M7XG4gIH1cbn1cbmZ1bmN0aW9uIGdldEhpZGluZ1N0eWxlKG1ldGhvZCkge1xuICBjb25zdCBoaWRpbmdTbmlwcGV0ID0gbWV0aG9kID09PSBcIm9wYWNpdHlcIiA/IGBvcGFjaXR5OiAwYCA6IGBkaXNwbGF5OiBub25lYDtcbiAgcmV0dXJuIGAke2hpZGluZ1NuaXBwZXR9ICFpbXBvcnRhbnQ7IHotaW5kZXg6IC0xICFpbXBvcnRhbnQ7IHBvaW50ZXItZXZlbnRzOiBub25lICFpbXBvcnRhbnQ7YDtcbn1cbmZ1bmN0aW9uIGhpZGVFbGVtZW50cyhzdHlsZUVsLCBzZWxlY3RvciwgbWV0aG9kID0gXCJkaXNwbGF5XCIpIHtcbiAgY29uc3QgcnVsZSA9IGAke3NlbGVjdG9yfSB7ICR7Z2V0SGlkaW5nU3R5bGUobWV0aG9kKX0gfSBgO1xuICBpZiAoc3R5bGVFbCBpbnN0YW5jZW9mIEhUTUxTdHlsZUVsZW1lbnQpIHtcbiAgICBzdHlsZUVsLmlubmVyVGV4dCArPSBydWxlO1xuICAgIHJldHVybiBzZWxlY3Rvci5sZW5ndGggPiAwO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHdhaXRGb3IocHJlZGljYXRlLCBtYXhUaW1lcywgaW50ZXJ2YWwpIHtcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcHJlZGljYXRlKCk7XG4gIGlmICghcmVzdWx0ICYmIG1heFRpbWVzID4gMCkge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgc2V0VGltZW91dChhc3luYyAoKSA9PiB7XG4gICAgICAgIHJlc29sdmUod2FpdEZvcihwcmVkaWNhdGUsIG1heFRpbWVzIC0gMSwgaW50ZXJ2YWwpKTtcbiAgICAgIH0sIGludGVydmFsKTtcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHJlc3VsdCk7XG59XG5mdW5jdGlvbiBpc0VsZW1lbnRWaXNpYmxlKGVsZW0pIHtcbiAgaWYgKCFlbGVtKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChlbGVtLm9mZnNldFBhcmVudCAhPT0gbnVsbCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IGNzcyA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsZW0pO1xuICAgIGlmIChjc3MucG9zaXRpb24gPT09IFwiZml4ZWRcIiAmJiBjc3MuZGlzcGxheSAhPT0gXCJub25lXCIpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5mdW5jdGlvbiBjb3B5T2JqZWN0KGRhdGEpIHtcbiAgaWYgKGdsb2JhbFRoaXMuc3RydWN0dXJlZENsb25lKSB7XG4gICAgcmV0dXJuIHN0cnVjdHVyZWRDbG9uZShkYXRhKTtcbiAgfVxuICByZXR1cm4gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShkYXRhKSk7XG59XG5mdW5jdGlvbiBub3JtYWxpemVDb25maWcocHJvdmlkZWRDb25maWcpIHtcbiAgY29uc3QgZGVmYXVsdENvbmZpZyA9IHtcbiAgICBlbmFibGVkOiB0cnVlLFxuICAgIGF1dG9BY3Rpb246IFwib3B0T3V0XCIsXG4gICAgLy8gaWYgZmFsc3ksIHRoZSBleHRlbnNpb24gd2lsbCB3YWl0IGZvciBhbiBleHBsaWNpdCB1c2VyIHNpZ25hbCBiZWZvcmUgb3B0aW5nIGluL291dFxuICAgIGRpc2FibGVkQ21wczogW10sXG4gICAgZW5hYmxlUHJlaGlkZTogdHJ1ZSxcbiAgICBlbmFibGVDb3NtZXRpY1J1bGVzOiB0cnVlLFxuICAgIGVuYWJsZUdlbmVyYXRlZFJ1bGVzOiB0cnVlLFxuICAgIGVuYWJsZUhldXJpc3RpY0RldGVjdGlvbjogZmFsc2UsXG4gICAgZW5hYmxlSGV1cmlzdGljQWN0aW9uOiBmYWxzZSxcbiAgICBkZXRlY3RSZXRyaWVzOiAyMCxcbiAgICBpc01haW5Xb3JsZDogZmFsc2UsXG4gICAgcHJlaGlkZVRpbWVvdXQ6IDJlMyxcbiAgICBlbmFibGVGaWx0ZXJMaXN0OiBmYWxzZSxcbiAgICB2aXN1YWxUZXN0OiBmYWxzZSxcbiAgICBsb2dzOiB7XG4gICAgICBsaWZlY3ljbGU6IGZhbHNlLFxuICAgICAgcnVsZXN0ZXBzOiBmYWxzZSxcbiAgICAgIGRldGVjdGlvbnN0ZXBzOiBmYWxzZSxcbiAgICAgIGV2YWxzOiBmYWxzZSxcbiAgICAgIGVycm9yczogdHJ1ZSxcbiAgICAgIG1lc3NhZ2VzOiBmYWxzZSxcbiAgICAgIHdhaXRzOiBmYWxzZVxuICAgIH1cbiAgfTtcbiAgY29uc3QgdXBkYXRlZENvbmZpZyA9IGNvcHlPYmplY3QoZGVmYXVsdENvbmZpZyk7XG4gIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGRlZmF1bHRDb25maWcpKSB7XG4gICAgaWYgKHR5cGVvZiBwcm92aWRlZENvbmZpZ1trZXldICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICB1cGRhdGVkQ29uZmlnW2tleV0gPSBwcm92aWRlZENvbmZpZ1trZXldO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdXBkYXRlZENvbmZpZztcbn1cbmZ1bmN0aW9uIHNjaGVkdWxlV2hlbklkbGUoY2FsbGJhY2ssIHRpbWVvdXQgPSA1MDApIHtcbiAgaWYgKGdsb2JhbFRoaXMucmVxdWVzdElkbGVDYWxsYmFjaykge1xuICAgIHJlcXVlc3RJZGxlQ2FsbGJhY2soY2FsbGJhY2ssIHsgdGltZW91dCB9KTtcbiAgfSBlbHNlIHtcbiAgICBzZXRUaW1lb3V0KGNhbGxiYWNrLCAwKTtcbiAgfVxufVxuZnVuY3Rpb24gaGlnaGxpZ2h0Tm9kZShub2RlKSB7XG4gIGlmICghbm9kZS5zdHlsZSkgcmV0dXJuO1xuICBpZiAobm9kZS5fX29sZFN0eWxlcyAhPT0gdm9pZCAwKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChub2RlLmhhc0F0dHJpYnV0ZShcInN0eWxlXCIpKSB7XG4gICAgbm9kZS5fX29sZFN0eWxlcyA9IG5vZGUuc3R5bGUuY3NzVGV4dDtcbiAgfVxuICBub2RlLnN0eWxlLmFuaW1hdGlvbiA9IFwicHVsc2F0ZSAuNXMgaW5maW5pdGVcIjtcbiAgbm9kZS5zdHlsZS5vdXRsaW5lID0gXCJzb2xpZCByZWRcIjtcbiAgbGV0IHN0eWxlVGFnID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcInN0eWxlI2F1dG9jb25zZW50LWRlYnVnLXN0eWxlc1wiKTtcbiAgaWYgKCFzdHlsZVRhZykge1xuICAgIHN0eWxlVGFnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInN0eWxlXCIpO1xuICAgIHN0eWxlVGFnLmlkID0gXCJhdXRvY29uc2VudC1kZWJ1Zy1zdHlsZXNcIjtcbiAgfVxuICBzdHlsZVRhZy50ZXh0Q29udGVudCA9IGBcbiAgICAgIEBrZXlmcmFtZXMgcHVsc2F0ZSB7XG4gICAgICAgIDAlIHtcbiAgICAgICAgICBvdXRsaW5lLXdpZHRoOiA4cHg7XG4gICAgICAgICAgb3V0bGluZS1vZmZzZXQ6IC00cHg7XG4gICAgICAgIH1cbiAgICAgICAgNTAlIHtcbiAgICAgICAgICBvdXRsaW5lLXdpZHRoOiA0cHg7XG4gICAgICAgICAgb3V0bGluZS1vZmZzZXQ6IC0ycHg7XG4gICAgICAgIH1cbiAgICAgICAgMTAwJSB7XG4gICAgICAgICAgb3V0bGluZS13aWR0aDogOHB4O1xuICAgICAgICAgIG91dGxpbmUtb2Zmc2V0OiAtNHB4O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgYDtcbiAgZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChzdHlsZVRhZyk7XG59XG5mdW5jdGlvbiB1bmhpZ2hsaWdodE5vZGUobm9kZSkge1xuICBpZiAoIW5vZGUuc3R5bGUgfHwgIW5vZGUuaGFzQXR0cmlidXRlKFwic3R5bGVcIikpIHJldHVybjtcbiAgaWYgKG5vZGUuX19vbGRTdHlsZXMgIT09IHZvaWQgMCkge1xuICAgIG5vZGUuc3R5bGUuY3NzVGV4dCA9IG5vZGUuX19vbGRTdHlsZXM7XG4gICAgZGVsZXRlIG5vZGUuX19vbGRTdHlsZXM7XG4gIH0gZWxzZSB7XG4gICAgbm9kZS5yZW1vdmVBdHRyaWJ1dGUoXCJzdHlsZVwiKTtcbiAgfVxufVxuZnVuY3Rpb24gaXNUb3BGcmFtZSgpIHtcbiAgcmV0dXJuIHdpbmRvdy50b3AgPT09IHdpbmRvdyAmJiAoIWdsb2JhbFRoaXMubG9jYXRpb24uYW5jZXN0b3JPcmlnaW5zIHx8IGdsb2JhbFRoaXMubG9jYXRpb24uYW5jZXN0b3JPcmlnaW5zLmxlbmd0aCA9PT0gMCk7XG59XG5cbi8vIGxpYi9oZXVyaXN0aWMtcGF0dGVybnMudHNcbnZhciBERVRFQ1RfUEFUVEVSTlMgPSBbXG4gIC9hY2NlcHQgY29va2llcy9naSxcbiAgL2FjY2VwdCBhbGwvZ2ksXG4gIC9yZWplY3QgYWxsL2dpLFxuICAvb25seSBuZWNlc3NhcnkgY29va2llcy9naSxcbiAgLy8gXCJvbmx5IG5lY2Vzc2FyeVwiIGlzIHByb2JhYmx5IHRvbyBicm9hZFxuICAvKD86YnkgY29udGludWluZy57MCwxMDB9Y29va2llKXwoPzpjb29raWUuezAsMTAwfWJ5IGNvbnRpbnVpbmcpL2dpLFxuICAvKD86YnkgY29udGludWluZy57MCwxMDB9cHJpdmFjeSl8KD86cHJpdmFjeS57MCwxMDB9YnkgY29udGludWluZykvZ2ksXG4gIC9ieSBjbGlja2luZy57MCwxMDB9KD86YWNjZXB0fGFncmVlfGFsbG93KS9naSxcbiAgL3dlICg/OnVzZXxzZXJ2ZSkoPzogb3B0aW9uYWwpPyBjb29raWVzL2dpLFxuICAvd2UgYXJlIHVzaW5nIGNvb2tpZXMvZ2ksXG4gIC91c2Ugb2YgY29va2llcy9naSxcbiAgLyg/OnRoaXN8b3VyKSAoPzp3ZWIpP3NpdGUuezAsMTAwfWNvb2tpZXMvZ2ksXG4gIC9jb29raWVzICg/OmFuZHxvcikgLnswLDEwMH0gdGVjaG5vbG9naWVzL2dpLFxuICAvc3VjaCBhcyBjb29raWVzL2dpLFxuICAvcmVhZCBtb3JlIGFib3V0LnswLDEwMH1jb29raWVzL2dpLFxuICAvY29uc2VudCB0by57MCwxMDB9Y29va2llcy9naSxcbiAgL3dlIGFuZCBvdXIgcGFydG5lcnMuezAsMTAwfWNvb2tpZXMvZ2ksXG4gIC93ZS57MCwxMDB9c3RvcmUuezAsMTAwfWluZm9ybWF0aW9uLnswLDEwMH1zdWNoIGFzLnswLDEwMH1jb29raWVzL2dpLFxuICAvc3RvcmUgYW5kXFwvb3IgYWNjZXNzIGluZm9ybWF0aW9uLnswLDEwMH1vbiBhIGRldmljZS9naSxcbiAgL3BlcnNvbmFsaXNlZCBhZHMgYW5kIGNvbnRlbnQsIGFkIGFuZCBjb250ZW50IG1lYXN1cmVtZW50L2dpLFxuICAvLyBpdCBtaWdodCBiZSB0ZW1wdGluZyB0byBhZGQgdGhlIHBhdHRlcm5zIGJlbG93LCBidXQgdGhleSBjYXVzZSB0b28gbWFueSBmYWxzZSBwb3NpdGl2ZXMuIERvbid0IGRvIGl0IDopXG4gIC8vIC9jb29raWVzPyBzZXR0aW5ncy9pLFxuICAvLyAvY29va2llcz8gcHJlZmVyZW5jZXMvaSxcbiAgLy8gRlJcbiAgL3V0aWxpc29ucy57MCwxMDB9ZGVzLnswLDEwMH1jb29raWVzL2dpLFxuICAvbm91cy57MCwxMDB9dXRpbGlzb25zLnswLDEwMH1kZXMvZ2ksXG4gIC9kZXMuezAsMTAwfWNvb2tpZXMuezAsMTAwfXBvdXIvZ2ksXG4gIC9kZXMuezAsMTAwfWluZm9ybWF0aW9ucy57MCwxMDB9c3VyL2dpLFxuICAvcmV0aXJlci57MCwxMDB9dm90cmUuezAsMTAwfWNvbnNlbnRlbWVudC9naSxcbiAgL2FjY1x1MDBFOWRlci57MCwxMDB9XHUwMEUwLnswLDEwMH1kZXMvZ2ksXG4gIC9cdTAwRTAuezAsMTAwfWRlcy57MCwxMDB9aW5mb3JtYXRpb25zL2dpLFxuICAvZXQuezAsMTAwfW5vcy57MCwxMDB9cGFydGVuYWlyZXMvZ2ksXG4gIC9wdWJsaWNpdFx1MDBFOXMuezAsMTAwfWV0LnswLDEwMH1kdS57MCwxMDB9Y29udGVudS9naSxcbiAgL3V0aWxpc2UuezAsMTAwfWRlcy57MCwxMDB9Y29va2llcy9naSxcbiAgL3V0aWxpc2VudC57MCwxMDB9ZGVzLnswLDEwMH1jb29raWVzL2dpLFxuICAvc3RvY2tlci57MCwxMDB9ZXQuezAsMTAwfW91LnswLDEwMH1hY2NcdTAwRTlkZXIvZ2ksXG4gIC9jb25zZW50ZW1lbnQuezAsMTAwfVx1MDBFMC57MCwxMDB9dG91dC57MCwxMDB9bW9tZW50L2dpLFxuICAvdm90cmUuezAsMTAwfWNvbnNlbnRlbWVudC9naSxcbiAgL2FjY2VwdGVyLnswLDEwMH10b3V0L2dpLFxuICAvdXRpbGlzYXRpb24uezAsMTAwfWRlcy57MCwxMDB9Y29va2llcy9naSxcbiAgL2Nvb2tpZXMuezAsMTAwfW91LnswLDEwMH10ZWNobm9sb2dpZXMvZ2ksXG4gIC9hY2NlcHRlei57MCwxMDB9bC57MCwxMDB9dXRpbGlzYXRpb24vZ2ksXG4gIC9jb250aW51ZXIgc2FucyBhY2NlcHRlci9naSxcbiAgL3RvdXQgcmVmdXNlci9naSxcbiAgLyg/OnJlZnVzZXJ8cmVqZXRlcikgdG91cyBsZXMgY29va2llcy9naSxcbiAgL2plIHJlZnVzZS9naSxcbiAgL3JlZnVzZXIgZXQgY29udGludWVyL2dpLFxuICAvcmVmdXNlciBsZXMgY29va2llcy9naSxcbiAgL3NldWxlbWVudCBuXHUwMEU5Y2Vzc2FpcmVzL2dpLFxuICAvamUgZFx1MDBFOXNhY3RpdmUgbGVzIGZpbmFsaXRcdTAwRTlzIG5vbiBlc3NlbnRpZWxsZXMvZ2ksXG4gIC9jb29raWVzIGVzc2VudGllbHMgdW5pcXVlbWVudC9naSxcbiAgL25cdTAwRTljZXNzYWlyZXMgdW5pcXVlbWVudC9naSxcbiAgLy8gREVcbiAgL3dpci57MCwxMDB9dmVyd2VuZGVuLnswLDEwMH1jb29raWVzL2dpLFxuICAvd2lyLnswLDEwMH11bmQuezAsMTAwfXVuc2VyZS57MCwxMDB9cGFydG5lci9naSxcbiAgL3p1Z3JpZmYuezAsMTAwfWF1Zi57MCwxMDB9aW5mb3JtYXRpb25lbi57MCwxMDB9YXVmL2dpLFxuICAvaW5oYWx0ZS57MCwxMDB9bWVzc3VuZy57MCwxMDB9dm9uLnswLDEwMH13ZXJiZWxlaXN0dW5nLnswLDEwMH11bmQvZ2ksXG4gIC9jb29raWVzLnswLDEwMH11bmQuezAsMTAwfWFuZGVyZS9naSxcbiAgL3ZlcndlbmR1bmcuezAsMTAwfXZvbi57MCwxMDB9Y29va2llcy9naSxcbiAgL3dpci57MCwxMDB9bnV0emVuLnswLDEwMH1jb29raWVzL2dpLFxuICAvdmVyd2VuZGV0LnswLDEwMH1jb29raWVzL2dpLFxuICAvc2llLnswLDEwMH1rXHUwMEY2bm5lbi57MCwxMDB9aWhyZS57MCwxMDB9YXVzd2FobC9naSxcbiAgL3VuZC57MCwxMDB9XHUwMEU0aG5saWNoZS57MCwxMDB9dGVjaG5vbG9naWVuL2dpLFxuICAvY29va2llcy57MCwxMDB9d2lyLnswLDEwMH12ZXJ3ZW5kZW4vZ2ksXG4gIC9hbGxlcz8uezAsMTAwfWFibGVobmVuL2dpLFxuICAvKD86bnVyfG5pY2h0KS57MCwxMDB9KD86enVzXHUwMEU0dHpsaWNoZXxlc3NlbnppZWxsZXxmdW5rdGlvbmFsZXxub3R3ZW5kaWdlfGVyZm9yZGVybGljaGUpLnswLDEwMH0oPzpjb29raWVzfGFremVwdGllcmVufGVybGF1YmVufGFibGVobmVuKS9naSxcbiAgL3dlaXRlci57MCwxMDB9KD86b2huZXxtaXQpLnswLDEwMH0oPzplaW53aWxsaWd1bmd8enVzdGltbXVuZ3xjb29raWVzKS9naSxcbiAgLyg/OmNvb2tpZXN8ZWlud2lsbGlndW5nKS57MCwxMDB9YWJsZWhuZW4vZ2ksXG4gIC9udXIgZnVua3Rpb25hbGUgY29va2llcyBha3plcHRpZXJlbi9naSxcbiAgL29wdGlvbmFsZSBhYmxlaG5lbi9naSxcbiAgL3p1c3RpbW11bmcgdmVyd2VpZ2Vybi9naSxcbiAgLy8gTkxcbiAgL2dlYnJ1aWsuezAsMTAwfXZhbi57MCwxMDB9Y29va2llcy9naSxcbiAgLyg/OndlfHdpaikuezAsMTAwfWdlYnJ1aWtlbi57MCwxMDB9Y29va2llcy57MCwxMDB9b20vZ2ksXG4gIC9jb29raWVzLnswLDEwMH1lbi57MCwxMDB9dmVyZ2VsaWprYmFyZS9naSxcbiAgLyg/OmFsbGVzfGNvb2tpZXMpLnswLDEwMH0oPzphZndpanplbnx3ZWlnZXJlbnx2ZXJ3ZXJwZW4pL2dpLFxuICAvYWxsZWVuLnswLDEwMH1ub29kemFrZWxpamtlP1xcYi9naSxcbiAgL2Nvb2tpZXMgd2VpZ2VyZW4vZ2ksXG4gIC93ZWlnZXIuezAsMTAwfSg/OmNvb2tpZXN8YWxsZXMpL2dpLFxuICAvZG9vcmdhYW4gem9uZGVyICg/OnRlIGFjY2VwdGVyZW58YWtrb29yZCB0ZSBnYWFuKS9naSxcbiAgL2FsbGVlbi57MCwxMDB9KD86b3B0aW9uZWxlfGZ1bmN0aW9uZWxlfGZ1bmN0aW9uZWVsfG5vb2R6YWtlbGlqa2V8ZXNzZW50aVx1MDBFQmxlKS57MCwxMDB9Y29va2llcy9naSxcbiAgL3dpanMgYWxsZXMgYWYvZ2lcbl07XG52YXIgUkVKRUNUX1BBVFRFUk5TX0VOR0xJU0ggPSBbXG4gIC8vIGUuZy4gXCJpIHJlamVjdCBjb29raWVzXCIsIFwicmVqZWN0IGFsbFwiLCBcInJlamVjdCBhbGwgY29va2llc1wiLCBcInJlamVjdCBjb29raWVzXCIsIFwiZGVueSBhbGxcIiwgXCJkZW55IGFsbCBjb29raWVzXCIsIFwicmVmdXNlXCIsIFwicmVmdXNlIGFsbFwiLCBcInJlZnVzZSBjb29raWVzXCIsIFwicmVmdXNlIGFsbCBjb29raWVzXCIsIFwiZGVueVwiLCBcInJlamVjdCBhbGwgYW5kIGNsb3NlXCIsIFwiZGVueSBhbGwgYW5kIGNsb3NlXCIsIFwicmVqZWN0IG5vbi1lc3NlbnRpYWwgY29va2llc1wiLCBcInJlamVjdCBhbGwgbm9uLWVzc2VudGlhbCBjb29raWVzIGFuZCBjb250aW51ZVwiLCBcInJlamVjdCBvcHRpb25hbCBjb29raWVzXCIsIFwicmVqZWN0IGFkZGl0aW9uYWwgY29va2llc1wiLCBcInJlamVjdCB0YXJnZXRpbmcgY29va2llc1wiLCBcInJlamVjdCBtYXJrZXRpbmcgY29va2llc1wiLCBcInJlamVjdCBhbmFseXRpY3MgY29va2llc1wiLCBcInJlamVjdCB0cmFja2luZyBjb29raWVzXCIsIFwicmVqZWN0IGFkdmVydGlzaW5nIGNvb2tpZXNcIiwgXCJyZWplY3QgYWxsIGFuZCBjbG9zZVwiLCBcImRlbnkgYWxsIGFuZCBjbG9zZVwiXG4gIC8vIG5vdGUgdGhhdCBcInJlamVjdCBhbmQgc3Vic2NyaWJlXCIgYW5kIFwicmVqZWN0IGFuZCBwYXlcIiBhcmUgZXhjbHVkZWRcbiAgL15cXHMqKGkpP1xccyoocmVqZWN0fGRlbnl8cmVmdXNlfGRlY2xpbmV8ZGlzYWJsZSlcXHMqKGFsbCk/XFxzKihub24tZXNzZW50aWFsfG9wdGlvbmFsfGFkZGl0aW9uYWx8dGFyZ2V0aW5nfGFuYWx5dGljc3xtYXJrZXRpbmd8dW5yZXF1aXJlZHxub24tbmVjZXNzYXJ5fGV4dHJhfHRyYWNraW5nfGFkdmVydGlzaW5nKT9cXHMqKGNvb2tpZXMpP1xccyokL2lzLFxuICAvLyBlLmcuIFwiaSBkbyBub3QgYWNjZXB0XCIsIFwiaSBkbyBub3QgYWNjZXB0IGNvb2tpZXNcIiwgXCJkbyBub3QgYWNjZXB0XCIsIFwiZG8gbm90IGFjY2VwdCBjb29raWVzXCJcbiAgL15cXHMqKGkpP1xccypkb1xccytub3RcXHMrYWNjZXB0XFxzKihjb29raWVzKT9cXHMqJC9pcyxcbiAgLy8gZS5nLiBcImNvbnRpbnVlIHdpdGhvdXQgYWNjZXB0aW5nXCIsIFwiY29udGludWUgd2l0aG91dCBhZ3JlZWluZ1wiLCBcImNvbnRpbnVlIHdpdGhvdXQgYWdyZWVpbmcgXHUyMTkyXCJcbiAgL15cXHMqKGNvbnRpbnVlfHByb2NlZWR8Y29udGludWVcXHMrYnJvd3NpbmcpXFxzK3dpdGhvdXRcXHMrKGFjY2VwdGluZ3xhZ3JlZWluZ3xjb25zZW50fGNvb2tpZXN8dHJhY2tpbmcpKFxccypcdTIxOTIpP1xccyokL2lzLFxuICAvLyBlLmcuIFwic3RyaWN0bHkgbmVjZXNzYXJ5IGNvb2tpZXMgb25seVwiLCBcImVzc2VudGlhbCBjb29raWVzIG9ubHlcIiwgXCJyZXF1aXJlZCBvbmx5XCIsIFwidXNlIG5lY2Vzc2FyeSBjb29raWVzIG9ubHlcIiwgXCJlc3NlbnRpYWxzIG9ubHlcIlxuICAvLyBub3RlIHRoYXQgXCJvbmx5XCIgaXMgcmVxdWlyZWRcbiAgL15cXHMqKHVzZXxhY2NlcHR8YWxsb3d8Y29udGludWVcXHMrd2l0aCk/XFxzKihzdHJpY3RseSk/XFxzKihuZWNlc3Nhcnl8ZXNzZW50aWFscz98cmVxdWlyZWQpP1xccyooY29va2llcyk/XFxzKm9ubHlcXHMqJC9pcyxcbiAgLy8gZS5nLiBcImFsbG93IGVzc2VudGlhbCBjb29raWVzXCIsIFwiYWxsb3cgbmVjZXNzYXJ5XCIsIFwiYWxsb3cgZXNzZW50aWFsc1wiLCBcImFsbG93IGVzc2VudGlhbHMgb25seVwiXG4gIC8vIG5vdGUgdGhhdCBcImVzc2VudGlhbFwiIGlzIHJlcXVpcmVkXG4gIC9eXFxzKih1c2V8YWNjZXB0fGFsbG93fGNvbnRpbnVlXFxzK3dpdGgpP1xccyooc3RyaWN0bHkpP1xccyoobmVjZXNzYXJ5fGVzc2VudGlhbHM/fHJlcXVpcmVkKVxccyooY29va2llcyk/XFxzKiQvaXMsXG4gIC8vIGUuZy4gXCJhY2NlcHQgb25seSBlc3NlbnRpYWwgY29va2llc1wiLCBcInVzZSBvbmx5IG5lY2Vzc2FyeSBjb29raWVzXCIsIFwiYWxsb3cgb25seSBlc3NlbnRpYWxcIiwgXCJvbmx5IGVzc2VudGlhbHNcIiwgXCJjb250aW51ZSB3aXRoIG9ubHkgZXNzZW50aWFsIGNvb2tpZXNcIlxuICAvLyBub3RlIHRoYXQgXCJvbmx5XCIgaXMgcmVxdWlyZWRcbiAgL15cXHMqKHVzZXxhY2NlcHR8YWxsb3d8Y29udGludWVcXHMrd2l0aCk/XFxzKm9ubHlcXHMqKHN0cmljdGx5KT9cXHMqKG5lY2Vzc2FyeXxlc3NlbnRpYWxzP3xyZXF1aXJlZCk/XFxzKihjb29raWVzKT9cXHMqJC9pcyxcbiAgLy8gZS5nLiBcImRvIG5vdCBzZWxsIG9yIHNoYXJlIG15IHBlcnNvbmFsIGluZm9ybWF0aW9uXCIsIFwiZG8gbm90IHNlbGwgbXkgcGVyc29uYWwgaW5mb3JtYXRpb25cIlxuICAvLyBvZnRlbiB1c2VkIGluIENDUEFcbiAgL15cXHMqZG9cXHMrbm90XFxzK3NlbGwoXFxzK29yXFxzK3NoYXJlKT9cXHMqbXlcXHMqcGVyc29uYWxcXHMqaW5mb3JtYXRpb25cXHMqJC9pc1xuICAvLyBUaGVzZSBhcmUgaW1wYWN0ZnVsLCBidXQgbG9vayBlcnJvci1wcm9uZVxuICAvLyAvLyBlLmcuIFwiZGlzYWdyZWVcIlxuICAvLyAvXlxccyooaSk/XFxzKmRpc2FncmVlXFxzKihhbmRcXHMrY2xvc2UpP1xccyokL2ksXG4gIC8vIC8vIGUuZy4gXCJpIGRvIG5vdCBhZ3JlZVwiXG4gIC8vIC9eXFxzKihpXFxzKyk/ZG9cXHMrbm90XFxzK2FncmVlXFxzKiQvaSxcbl07XG52YXIgUkVKRUNUX1BBVFRFUk5TX0RVVENIID0gW1xuICBcIndlaWdlcmVuXCIsXG4gIFwiYWxsZXMgYWZ3aWp6ZW5cIixcbiAgXCJhbGxlZW4gbm9vZHpha2VsaWprZSBjb29raWVzXCIsXG4gIFwiYWZ3aWp6ZW5cIixcbiAgXCJhbGxlcyB3ZWlnZXJlblwiLFxuICBcImNvb2tpZXMgd2VpZ2VyZW5cIixcbiAgXCJhbGxlZW4gbm9vZHpha2VsaWprXCIsXG4gIFwid2VpZ2VyXCIsXG4gIFwid2VpZ2VyIGNvb2tpZXNcIixcbiAgXCJkb29yZ2FhbiB6b25kZXIgdGUgYWNjZXB0ZXJlblwiLFxuICBcImFsbGVlbiBmdW5jdGlvbmVsZSBjb29raWVzXCIsXG4gIFwiYWxsZWVuIGZ1bmN0aW9uZWVsXCIsXG4gIFwiYWxsZWVuIG5vb2R6YWtlbGlqa2VcIixcbiAgXCJhbGxlZW4gZXNzZW50aVxceEVCbGUgY29va2llc1wiLFxuICBcImZ1bmN0aW9uZWVsXCIsXG4gIFwiYWxsZSBjb29raWVzIHZlcndlcnBlblwiLFxuICBcImRvb3JnYWFuIHpvbmRlciBha2tvb3JkIHRlIGdhYW5cIixcbiAgXCJ3ZWlnZXIgYWxsZXNcIixcbiAgXCJuZWUsIGJlZGFua3RcIixcbiAgXCJhbGxlIGNvb2tpZXMgd2VpZ2VyZW5cIixcbiAgXCJ3ZWlnZXIgYWxsZSBjb29raWVzXCIsXG4gIFwiYWxsZWVuIG5vb2R6YWtlbGlqa2UgY29va2llcyBhY2NlcHRlcmVuXCIsXG4gIFwiYWxsZWVuIHN0cmlrdCBub29kemFrZWxpamtcIixcbiAgXCJpayB3ZWlnZXJcIixcbiAgXCJvcHRpb25lbGUgY29va2llcyB3ZWlnZXJlblwiLFxuICBcImFsbGUgd2VpZ2VyZW5cIixcbiAgXCJhY2NlcHRlZXIgYWxsZWVuIG5vb2R6YWtlbGlqa2UgY29va2llc1wiLFxuICBcImFsbGVlbiBmdW5jdGlvbmVsZSBjb29raWVzIGFjY2VwdGVyZW5cIixcbiAgXCJlbmtlbCBub29kemFrZWxpamtlIGNvb2tpZXNcIixcbiAgXCJuaWV0IGFjY2VwdGVyZW5cIixcbiAgXCJ3ZWlnZXIgbmlldC1lc3NlbnRpXFx4RUJsZSBjb29raWVzXCIsXG4gIFwid2VpZ2VyIG5pZXQtbm9vZHpha2VsaWprZSBjb29raWVzXCIsXG4gIFwid2lqcyBhbGxlcyBhZlwiLFxuICBcImFsbGUgY29va2llcyBhZndpanplblwiLFxuICBcImFsbGVlbiB2ZXJlaXN0ZSBjb29raWVzXCIsXG4gIFwiY29va2llcyBhZndpanplblwiLFxuICBcImRvb3JnYWFuIHpvbmRlciBhY2NlcHRlcmVuXCIsXG4gIFwiaGllciB3ZWlnZXJlblwiLFxuICBcIndlaWdlciBhbGxlXCIsXG4gIFwiYWFudmFhcmQgZW5rZWwgZXNzZW50aVxceEVCbGUgY29va2llc1wiLFxuICBcImFhbnZ1bGxlbmRlIGNvb2tpZXMgd2VpZ2VyZW5cIixcbiAgXCJhY2NlcHRlcmVuIHdlaWdlcmVuXCIsXG4gIFwiYWxsZSBhZndpanplblwiLFxuICBcImFsbGUgbmlldCBmdW5jdGlvbmVsZSBhZndpanplblwiLFxuICBcImFsbGUgb3B0aW9uZWxlIHdlaWdlcmVuXCIsXG4gIFwiYWxsZWVuIG5vb2R6YWtlbGlqa2UgYWNjZXB0ZXJlblwiLFxuICBcImFsbGVlbiBzdHJpa3Qgbm9vZHpha2VsaWprZSBjb29raWVzXCIsXG4gIFwiYWxsZW4gYWZ3aWp6ZW5cIixcbiAgXCJjbGVhciB3ZWlnZXJlblwiLFxuICBcImVua2VsIGZ1bmN0aW9uZWVsXCIsXG4gIFwiZW5rZWwgbm9vZHpha2VsaWprZSBjb29raWVzIGFhbnZhYXJkZW5cIixcbiAgXCJmdW5jdGlvbmVlbCBhbHRpamQgYWN0aWVmXCIsXG4gIFwibmVlLCBhY2NlcHRlZXIgYWxsZWVuIGRlIG5vb2R6YWtlbGlqa2VcIixcbiAgXCJuZWUsIGdlZW4gY29va2llcyBhLnUuYi5cIixcbiAgXCJuZWUsIHdlaWdlciBjb29raWVzXCIsXG4gIFwibmVlLCB3ZWlnZXJlblwiLFxuICBcIm5pZXQtbm9vZHpha2VsaWprZSBjb29raWVzIHdlaWdlcmVuXCIsXG4gIFwib3B0aW9uZWVsIGFmd2lqemVuXCIsXG4gIFwidHJhY2tpbmcgY29va2llcyB3ZWlnZXJlblwiLFxuICBcIndlaWdlcmVuIGNvb2tpZXNcIixcbiAgXCJ3ZWlnZXJlbj9cIixcbiAgXCJ3ZWlnZXJlbi5cIixcbiAgXCJzdHJpa3Qgbm9vZHpha2VsaWprXCIsXG4gIFwid2VpZ2VyIG9wdGlvbmVsZSBjb29raWVzXCIsXG4gIFwibm9vZHpha2VsaWprZSBjb29raWVzXCIsXG4gIFwiZXNzZW50aVxceEVCbGUgY29va2llc1wiLFxuICBcImdhIHZlcmRlciB6b25kZXIgYWFudmFhcmRlblwiLFxuICBcImRvb3JnYWFuIHpvbmRlciBjb29raWVzXCIsXG4gIFwiYWNjZXB0ZWVyIG5vb2R6YWtlbGlqa2UgY29va2llc1wiLFxuICBcIm5vb2R6YWtlbGlqa2VcIixcbiAgXCJpbmRpZW4gamUgZW5rZWwgdGVjaG5pc2NoIG5vb2R6YWtlbGlqa2UgY29va2llcyB3ZW5zdCB0ZSBhY2NlcHRlcmVuLCBrbGlrIGRhbiBoaWVyXCIsXG4gIFwid2VpZ2VyXCIsXG4gIFwiYWxsZWVuIGRlIG5vb2R6YWtlbGlqa2UgY29va2llc1wiLFxuICBcImFsbGVlbiBub29kemFrZWxpamtcIixcbiAgXCJhbGxlZW4gdmVycGxpY2h0ZSBjb29raWVzXCIsXG4gIFwiaWsgd2lsIGFsbGVlbiBtaW5pbWFsZSBjb29raWVzXCIsXG4gIFwiZG9vcmdhYW4gem9uZGVyIHRlIGFjY2VwdGVyZW5cIixcbiAgXCJnZWVuIGNvb2tpZXMgdG9lc3RhYW5cIixcbiAgXCJsaWV2ZXIgZ2VlbiBjb29raWVzXCIsXG4gIFwibmVlLCBnZWVuIHBlcnNvb25saWprZSBjb29raWVzXCIsXG4gIFwibmVlLCBsaWV2ZXIgZ2VlbiBjb29raWVzXCIsXG4gIFwiZ2EgZG9vciB6b25kZXIgdGUgYWNjZXB0ZXJlblwiLFxuICBcInZlcmRlciB6b25kZXIgYWNjZXB0ZXJlblwiLFxuICBcImVzc2VudGlcXHhFQmxlIGFjY2VwdGVyZW5cIixcbiAgXCJmdW5jdGlvbmVsZSBjb29raWVzXCIsXG4gIFwic3RyaWt0IG5vb2R6YWtlbGlqa2UgY29va2llc1wiLFxuICBcImFsbGVlbiBiYXNpYyBjb29raWVzXCIsXG4gIFwiYWxsZWVuIGJhc2lzY29va2llc1wiLFxuICBcImFsbGVlbiBzdGFuZGFhcmQgY29va2llc1wiLFxuICBcImFsbGUgY29va2llcyB2ZXJ3ZXJwZW5cIixcbiAgXCJub29kemFrZWxpamtcIixcbiAgXCJub29kemFrZWxpamsgY29va2llcyBhY2NlcHRlcmVuXCIsXG4gIFwibm9vZHpha2VsaWprZSBjb29raWVzIGFjY2VwdGVyZW5cIixcbiAgXCJhY2NlcHRlZXIgYWxsZWVuIG5vb2R6YWtlbGlqa1wiLFxuICBcImVua2VsIG5vb2R6YWtlbGlqa2UgdG9lc3RhYW5cIixcbiAgXCJlbmtlbCBzdHJpa3Qgbm9vZHpha2VsaWprZSBjb29raWVzXCIsXG4gIFwiaWsgd2lqcyB6ZSBsaWV2ZXIgYWZcIixcbiAgXCJpayB3ZWlnZXIgY29va2llc1wiLFxuICBcImlrIHdlaWdlciBvcHRpb25lbGUgY29va2llc1wiLFxuICBcIndlaWdlciBhbGxlIGNvb2tpZXNcIixcbiAgXCJ3ZWlnZXIgYWxsZSBuaWV0LW5vb2R6YWtlbGlqa2UgY29va2llc1wiLFxuICBcIndlaWdlciBhbGxlIG9ubm9kaWdlIGNvb2tpZXNcIixcbiAgXCJ3ZWlnZXIgYWxsZSBvcHRpb25lbGVcIixcbiAgXCJ3ZWlnZXIgYWxsZXNcIixcbiAgXCJ3ZWlnZXIgdGFyZ2V0aW5nIGVuIHRoaXJkIHBhcnR5IGNvb2tpZXMuXCJcbl07XG52YXIgUkVKRUNUX1BBVFRFUk5TX0ZSRU5DSCA9IFtcbiAgXCJjb250aW51ZXIgc2FucyBhY2NlcHRlclwiLFxuICBcInRvdXQgcmVmdXNlclwiLFxuICBcInJlZnVzZXJcIixcbiAgXCJyZWZ1c2VyIHRvdXMgbGVzIGNvb2tpZXNcIixcbiAgXCJqZSByZWZ1c2VcIixcbiAgXCJyZWZ1c2VyIHRvdXRcIixcbiAgXCJ0b3V0IHJlamV0ZXJcIixcbiAgXCJyZWZ1c2VyIGV0IGNvbnRpbnVlclwiLFxuICBcInJlamV0ZXJcIixcbiAgXCJyZWZ1c2VyIGxlcyBjb29raWVzXCIsXG4gIFwiY29va2llcyBuXFx4RTljZXNzYWlyZXMgdW5pcXVlbWVudFwiLFxuICBcInNldWxlbWVudCBuXFx4RTljZXNzYWlyZXNcIixcbiAgXCJyZWpldGVyIHRvdXRcIixcbiAgXCJyZWZ1c2VyIGxlcyBjb29raWVzIG9wdGlvbm5lbHNcIixcbiAgXCJqZSBkXFx4RTlzYWN0aXZlIGxlcyBmaW5hbGl0XFx4RTlzIG5vbiBlc3NlbnRpZWxsZXNcIixcbiAgXCJyZWZ1c2VyIGxlcyBjb29raWVzIG5vbiBuXFx4RTljZXNzYWlyZXNcIixcbiAgXCJyZWpldGVyIHRvdXMgbGVzIGNvb2tpZXNcIixcbiAgXCJjb29raWVzIGVzc2VudGllbHMgdW5pcXVlbWVudFwiLFxuICBcIm5cXHhFOWNlc3NhaXJlcyB1bmlxdWVtZW50XCIsXG4gIFwicmVmdXNlciBsZXMgY29va2llcyBub24gZXNzZW50aWVsc1wiLFxuICBcInRvdXQgcmVmdXNlciBldCBmZXJtZXJcIixcbiAgXCJ0b3V0IHJlZnVzZXIgc2F1ZiBsZXMgY29va2llcyB0ZWNobmlxdWVzXCIsXG4gIFwiY29udGludWVyIHNhbnMgYWNjZXB0ZXIgeFwiLFxuICBcImplIHJlZnVzZSBsdXRpbGlzYXRpb24gZGUgY29va2llc1wiLFxuICBcIm5vbiBtZXJjaSwgc2V1bGVtZW50IGRlcyBjb29raWVzIHRlY2huaXF1ZXNcIixcbiAgXCJub24sIHRvdXQgcmVmdXNlclwiLFxuICBcInJlZnVzZXIgdG91cyBsZXMgY29va2llcyBub24gblxceEU5Y2Vzc2FpcmVzXCIsXG4gIFwicmVqZXRlciBsZXMgY29va2llc1wiLFxuICBcInVuaXF1ZW1lbnQgbGVzIGVzc2VudGllbHNcIixcbiAgXCJyZWZ1c2VyIHRvdXNcIixcbiAgXCJhY2NlcHRlciB1bmlxdWVtZW50IGxlcyBuXFx4RTljZXNzYWlyZXNcIixcbiAgXCJhbGxvdyBhbm9ueW1vdXMgYW5hbHl0aWNzXCIsXG4gIFwiYXV0b3Jpc2VyIGxlcyBjb29raWVzIGVzc2VudGllbHMgdW5pcXVlbWVudFwiLFxuICBcImF1dG9yaXNlciB1bmlxdWVtZW50IGxlcyBuXFx4RTljZXNzYWlyZXNcIixcbiAgXCJjb29raWVzIGVzc2VudGllbHMgc2V1bGVtZW50XCIsXG4gIFwiY29va2llcyBuXFx4RTljZXNzYWlyZXMgc2V1bGVtZW50XCIsXG4gIFwiY29va2llcyB0ZWNobmlxdWVzIHVuaXF1ZW1lbnRcIixcbiAgXCJqZSBwclxceEU5ZlxceEU4cmUgbGVzIHJlamV0ZXJcIixcbiAgXCJqZSByZWZ1c2UgOihcIixcbiAgXCJqZSByZWZ1c2UgbGVzIGNvb2tpZXNcIixcbiAgXCJqZSByZWZ1c2UgdG91cyBsZXMgY29va2llc1wiLFxuICBcImplIHJlZnVzZSB0b3V0XCIsXG4gIFwibmUgcGFzIGFjY2VwdGVyXCIsXG4gIFwibm9uLCBhY2NlcHRlciBsZXMgblxceEU5Y2Vzc2FpcmVzIHVuaXF1ZW1lbnRcIixcbiAgXCJyZWZ1c2VyIChzYXVmIGNvb2tpZXMgblxceEU5Y2Vzc2FpcmVzKVwiLFxuICBcInJlZnVzZXIgY2UgY29va2llXCIsXG4gIFwicmVmdXNlciBsZXMgY29vY2tpZXNcIixcbiAgXCJyZWZ1c2VyIGxlcyBjb29raWVzIGZhY3VsdGF0aWZzXCIsXG4gIFwicmVmdXNlciB0b3V0LCBzYXVmIGxlcyBjb29raWVzIHRlY2huaXF1ZXNcIixcbiAgXCJyZWZ1c2VyIHRvdXRlc1wiLFxuICBcInJlZnVzZXIgdG91dGVzIGxlcyBvcHRpb25zXCIsXG4gIFwicmVqZXRlciBsYSBiYW5uaVxceEU4cmVcIixcbiAgXCJyZWpldGVyIGxlcyBjb29raWVzIG5vbiBlc3NlbnRpZWxzXCIsXG4gIFwicmVqZXRlciBsZXMgY29va2llcyBvcHRpb25uZWxzXCIsXG4gIFwicmVqZXRlciB0b3VzIGxlcyBub24gZm9uY3Rpb25uZWxzXCIsXG4gIFwicmVqZXRlciB0b3V0IG9wdGlvbm5lbFwiLFxuICBcInRvdXQgcmVmdXNlciwgc2F1ZiBsZXMgY29va2llcyB0ZWNobmlxdWVzXCIsXG4gIFwidW5pcXVlbWVudCBuXFx4RTljZXNzYWlyZXNcIixcbiAgXCJ4IGNvbnRpbnVlciBzYW5zIGFjY2VwdGVyXCIsXG4gIFwic3RyaWN0ZW1lbnQgblxceEU5Y2Vzc2FpcmVzXCIsXG4gIFwidXRpbGlzZXIgdW5pcXVlbWVudCBsZXMgY29va2llcyBuXFx4RTljZXNzYWlyZXNcIixcbiAgXCJjb29raWVzIG5cXHhFOWNlc3NhaXJlc1wiLFxuICBcImFjY2VwdGVyIHVuaXF1ZW1lbnQgbGVzIGNvb2tpZXMgZXNzZW50aWVsc1wiLFxuICBcImFjY2VwdGVyIGxlcyBjb29raWVzIG5cXHhFOWNlc3NhaXJlc1wiLFxuICBcInVuaXF1ZW1lbnQgbGVzIGNvb2tpZXMgblxceEU5Y2Vzc2FpcmVzXCIsXG4gIFwiYXV0b3Jpc2VyIHVuaXF1ZW1lbnQgbGVzIGNvb2tpZXMgZXNzZW50aWVsc1wiLFxuICBcImF1dG9yaXNlciB1bmlxdWVtZW50IGxlcyBjb29raWVzIG5cXHhFOWNlc3NhaXJlc1wiLFxuICBcInNpIHZvdXMgbmUgc291aGFpdGV6IHBhcyBhY2NlcHRlciBsZXMgY29va2llcyBcXHhFMCBsZXhjZXB0aW9uIGRlcyBjb29raWVzIHRlY2huaXF1ZW1lbnQgblxceEU5Y2Vzc2FpcmVzLCB2ZXVpbGxleiBjbGlxdWVyIGljaVwiLFxuICBcImNvb2tpZXMgc3RyaWN0ZW1lbnQgblxceEU5Y2Vzc2FpcmVzXCIsXG4gIFwiYWNjZXB0ZXIgbGVzIGNvb2tpZXMgc3RyaWN0ZW1lbnQgblxceEU5Y2Vzc2FpcmVzXCIsXG4gIFwiYXV0b3Jpc2VyIGxlcyBjb29raWVzIGVzc2VudGllbHNcIixcbiAgXCJub24sIG1lcmNpLCB1bmlxdWVtZW50IGxlcyBjb29raWVzIG5cXHhFOWNlc3NhaXJlc1wiLFxuICBcImluZGlzcGVuc2FibGUgdW5pcXVlbWVudFwiLFxuICBcInVuaXF1ZW1lbnQgYXV0b3Jpc2VyIGxlcyBjb29raWVzIGVzc2VudGllbHNcIixcbiAgXCJ1dGlsaXNlciBxdWUgbGVzIGNvb2tpZXMgblxceEU5Y2Vzc2FpcmVzXCIsXG4gIFwidW5pcXVlbWVudCBsZXMgc2RrIG5cXHhFOWNlc3NhaXJlc1wiLFxuICBcInVuaXF1ZW1lbnQgblxceEU5Y2Vzc2FpcmVcIixcbiAgXCJ1dGlsaXNlciB1bmlxdWVtZW50IGxlcyBjb29raWVzIGZvbmN0aW9ubmVsc1wiLFxuICBcInJlZnVzXCIsXG4gIFwicmVmdXNlelwiLFxuICBcIm5hY2NlcHRlciBxdWUgbGVzIGNvb2tpZXMgaW5kaXNwZW5zYWJsZXNcIixcbiAgXCJuYWNjZXB0ZXIgcXVlIGxlcyBjb29raWVzIG5cXHhFOWNlc3NhaXJlc1wiLFxuICBcIm5hY2NlcHRlciBxdWUgbGVzIGNvb2tpZXMgdGVjaG5pcXVlc1wiLFxuICBcIm5cXHhFOWNlc3NhaXJlcyBzZXVsZW1lbnRcIlxuXTtcbnZhciBSRUpFQ1RfUEFUVEVSTlNfR0VSTUFOID0gW1xuICBcImFibGVobmVuXCIsXG4gIFwiYWxsZSBhYmxlaG5lblwiLFxuICBcIm51ciBub3R3ZW5kaWdlIGNvb2tpZXNcIixcbiAgXCJudXIgZXNzZW56aWVsbGUgY29va2llcyBha3plcHRpZXJlblwiLFxuICBcIm51ciBub3R3ZW5kaWdlIGNvb2tpZXMgdmVyd2VuZGVuXCIsXG4gIFwiYWxsZXMgYWJsZWhuZW5cIixcbiAgXCJudXIgbm90d2VuZGlnZVwiLFxuICBcImFsbGUgY29va2llcyBhYmxlaG5lblwiLFxuICBcIndlaXRlciBvaG5lIGVpbndpbGxpZ3VuZ1wiLFxuICBcIm1pdCBkaWVzZW0gYnV0dG9uIHdpcmQgZGVyIGRpYWxvZyBnZXNjaGxvc3Nlbi4gc2VpbmUgZnVua3Rpb25hbGl0XFx4RTR0IGlzdCBpZGVudGlzY2ggbWl0IGRlciBkZXMgYnV0dG9ucyBudXIgZXNzZW56aWVsbGUgY29va2llcyBha3plcHRpZXJlbi5cIixcbiAgXCJjb29raWVzIGFibGVobmVuXCIsXG4gIFwib3B0aW9uYWxlIGNvb2tpZXMgYWJsZWhuZW5cIixcbiAgXCJudXIgZXJmb3JkZXJsaWNoZSBjb29raWVzXCIsXG4gIFwiZWlud2lsbGlndW5nIGFibGVobmVuXCIsXG4gIFwibnVyIGVyZm9yZGVybGljaGVcIixcbiAgXCJudXIgbm90d2VuZGlnZSBjb29raWVzIHp1bGFzc2VuXCIsXG4gIFwibnVyIGZ1bmt0aW9uYWxlIGNvb2tpZXMgYWt6ZXB0aWVyZW5cIixcbiAgXCJudXIgbm90d2VuZGlnZSBjb29raWVzIGFremVwdGllcmVuXCIsXG4gIFwibnVyIG5vdHdlbmRpZ2UgdGVjaG5vbG9naWVuXCIsXG4gIFwidmVyd2VpZ2VyblwiLFxuICBcIndlYmFuYWx5c2UgYWJsZWhuZW5cIixcbiAgXCJ3ZWl0ZXIgb2huZSB6dXN0aW1tdW5nXCIsXG4gIFwib3B0aW9uYWxlIGFibGVobmVuXCIsXG4gIFwibnVyIG5vdHdlbmRpZ2UgYWt6ZXB0aWVyZW5cIixcbiAgXCJudXIgZnVua3Rpb25hbGUgY29va2llc1wiLFxuICBcIm1pdCBkaWVzZW0gYnV0dG9uIHdpcmQgZGVyIGRpYWxvZyBnZXNjaGxvc3Nlbi4gc2VpbmUgZnVua3Rpb25hbGl0XFx4RTR0IGlzdCBpZGVudGlzY2ggbWl0IGRlciBkZXMgYnV0dG9ucyBhYmxlaG5lbi5cIixcbiAgXCJudXIgbm90d2VuZGlnZSBjb29raWVzIGVybGF1YmVuXCIsXG4gIFwienVzdGltbXVuZyB2ZXJ3ZWlnZXJuXCIsXG4gIFwibmVpbiwgZGFua2VcIixcbiAgXCJudXIgZXJmb3JkZXJsaWNoZSBjb29raWVzIGFremVwdGllcmVuXCIsXG4gIFwienVzXFx4RTR0emxpY2hlIGNvb2tpZXMgYWJsZWhuZW5cIixcbiAgXCJhYmxlaG5lbiB1bmQgbnVyIGVzc2VuemllbGxlIGNvb2tpZXMgYWt6ZXB0aWVyZW5cIixcbiAgXCJuaWNodCBlcmZvcmRlcmxpY2hlIGFibGVobmVuXCIsXG4gIFwibmljaHQgZXNzZW56aWVsbGUgY29va2llcyBkYXRlbiBhYmxlaG5lblwiLFxuICBcIm51ciB0ZWNobmlzY2ggbm90d2VuZGlnZSBjb29raWVzXCIsXG4gIFwibnVyIHRlY2huaXNjaCBub3R3ZW5kaWdlIGNvb2tpZXMgYWt6ZXB0aWVyZW5cIixcbiAgXCJhYmxlaG5lbiBzcGVpY2hlcm5cIixcbiAgXCJhbGxlIGZ1bmt0aW9uZW4gYWJsZWhuZW5cIixcbiAgXCJhbGxlIG9wdGlvbmFsZW4gY29va2llcyBhYmxlaG5lblwiLFxuICBcImFsbGVzIHZlcndlaWdlcm5cIixcbiAgXCJtaXQgZXJmb3JkZXJsaWNoZW4gZWluc3RlbGx1bmdlbiBmb3J0ZmFocmVuXCIsXG4gIFwibmljaHQgbm90d2VuZGlnZSBhYmxlaG5lblwiLFxuICBcIm5vdHdlbmRpZ2UgY29va2llcyBha3plcHRpZXJlblwiLFxuICBcIm51ciBlcmZvcmRlcmxpY2hlIHRlY2hub2xvZ2llblwiLFxuICBcIm51ciBlc3NlbnppZWxsZSBjb29raWVzXCIsXG4gIFwibnVyIGVzc2VuemllbGxlIGNvb2tpZXMgZXJsYXViZW5cIixcbiAgXCJ0ZWNobmlzY2ggbmljaHQgbm90d2VuZGlnZSBjb29raWVzIGFibGVobmVuXCIsXG4gIFwidGlwcGVuIHNpZSB6dW0gYWJsZWhuZW4gYml0dGUgaGllclwiLFxuICBcImFibGVobmVuIGRlbnlcIixcbiAgXCJmb3J0ZmFocmVuIG9obmUgenUgYWt6ZXB0aWVyZW5cIixcbiAgXCJudXIgZXJmb3JkZXJsaWNoZSBha3plcHRpZXJlblwiLFxuICBcIm51ciBub3R3ZW5kaWdlIGVybGF1YmVuXCIsXG4gIFwiYWJsZWhuZW4gLi4ubnVyIHRlY2huaXNjaCBub3R3ZW5kaWdlIGNvb2tpZXMgdmVyd2VuZGV0IHdlcmRlblwiLFxuICBcImFibGVobmVuIChhdVxceERGZXIgbm90d2VuZGlnZSBjb29raWVzKVwiLFxuICBcImFibGVobmVuIHVuZCBmb3J0ZmFocmVuXCIsXG4gIFwiYWJsZWhuZW4gdW5kIHNjaGxpZVxceERGZW5cIixcbiAgXCJhYmxlaG5lbjogbnVyIGdydW5kZnVua3Rpb25lblwiLFxuICBcImFremVwdGllcmVuIG51ciBub3R3ZW5kaWdlIGNvb2tpZXNcIixcbiAgXCJhbGxlIGFibGVobmVuIChhdVxceERGZXIgbm90d2VuZGlnZSBjb29raWVzKVwiLFxuICBcImFsbGUgbmljaHQgZXNzZW56aWVsbGVuIGNvb2tpZXMgYWJsZWhuZW5cIixcbiAgXCJhbGxlIG5pY2h0IG5vdHdlbmRpZ2VuIGNvb2tpZXMgYWJsZWhuZW5cIixcbiAgXCJhbGxlIG9wdGlvbmFsZSBhYmxlaG5lblwiLFxuICBcImFsbGUgb3B0aW9uYWxlbiBhYmxlaG5lblwiLFxuICBcImFsbGUgdmVyd2VpZ2VyblwiLFxuICBcImFuYWx5c2UgY29va2llcyBhYmxlaG5lblwiLFxuICBcImNvb2tpZSBlaW5zdGVsbHVuZ2VuYWJsZWhuZW5cIixcbiAgXCJlcmZvcmRlcmxpY2hlIGNvb2tpZXMgYWt6ZXB0aWVyZW5cIixcbiAgXCJlcmZvcmRlcmxpY2hlIGNvb2tpZXMgenVsYXNzZW5cIixcbiAgXCJleHRlcm5lIGluaGFsdGUgYWJsZWhuZW5cIixcbiAgXCJtaXQgZGllc2VtIGJ1dHRvbiB3aXJkIGRlciBkaWFsb2cgZ2VzY2hsb3NzZW4uIHNlaW5lIGZ1bmt0aW9uYWxpdFxceEU0dCBpc3QgaWRlbnRpc2NoIG1pdCBkZXIgZGVzIGJ1dHRvbnMgYWJsZWhuZW4gdW5kIG51ciBlc3NlbnppZWxsZSBjb29raWVzIGFremVwdGllcmVuLlwiLFxuICBcIm1pdCBkaWVzZW0gYnV0dG9uIHdpcmQgZGVyIGRpYWxvZyBnZXNjaGxvc3Nlbi4gc2VpbmUgZnVua3Rpb25hbGl0XFx4RTR0IGlzdCBpZGVudGlzY2ggbWl0IGRlciBkZXMgYnV0dG9ucyBuaWNodC1lc3NlbnppZWxsZSBjb29raWVzIHZlcndlaWdlcm4uXCIsXG4gIFwibWl0IGRpZXNlbSBidXR0b24gd2lyZCBkZXIgZGlhbG9nIGdlc2NobG9zc2VuLiBzZWluZSBmdW5rdGlvbmFsaXRcXHhFNHQgaXN0IGlkZW50aXNjaCBtaXQgZGVyIGRlcyBidXR0b25zIG51ciBlc3NlbnppZWxsZSBha3plcHRpZXJlbi5cIixcbiAgXCJtaXQgZXJmb3JkZXJsaWNoZW4gY29va2llcyBmb3J0ZmFocmVuXCIsXG4gIFwibWl0IG5vdHdlbmRpZ2VuIGZvcnRmYWhyZW5cIixcbiAgXCJuZWluLCBiaXR0ZSBuaWNodFwiLFxuICBcIm5laW4sIGljaCBzdGltbWUgbmljaHQgenVcIixcbiAgXCJuaWNodCBmdW5rdGlvbmFsZSBjb29raWVzIGFibGVobmVuXCIsXG4gIFwibmljaHQgbm90d2VuZGlnZSBjb29raWVzIGFibGVobmVuXCIsXG4gIFwibmljaHQtZXNzZW56aWVsbGUgY29va2llcyBhYmxlaG5lblwiLFxuICBcIm5pY2h0LWVzc2VuemllbGxlIGNvb2tpZXMgdmVyd2VpZ2VyblwiLFxuICBcIm5vdHdlbmRpZ2UgY29va2llcyB6dWxhc3NlblwiLFxuICBcIm51ciBlcmZvcmRlcmxpY2hlIGNvb2tpZXMgZXJsYXViZW5cIixcbiAgXCJudXIgZXJmb3JkZXJsaWNoZSBjb29raWVzIHNldHplblwiLFxuICBcIm51ciBlcmZvcmRlcmxpY2hlIGNvb2tpZXMgdmVyd2VuZGVuXCIsXG4gIFwibnVyIGVzc2VuemllbGxlIGFremVwdGllcmVuXCIsXG4gIFwibnVyIG5vdHdlbmRpZ2UgY29va2llcyBhbm5laG1lblwiLFxuICBcIm51ciBub3R3ZW5kaWdlIGNvb2tpZXMgc3BlaWNoZXJuXCIsXG4gIFwibnVyIG5vdHdlbmRpZ2UgY29va2llcyB2ZXJ3ZW5kZW4uXCIsXG4gIFwibnVyIG5vdHdlbmRpZ2UgZnVua3Rpb25zY29va2llcyBha3plcHRpZXJlblwiLFxuICBcIm51ciBub3R3ZW5kaWdlbiBjb29raWVzIHp1c3RpbW1lblwiLFxuICBcIm51ciBub3R3ZW5kaWdlcyBha3plcHRpZXJlblwiLFxuICBcIm51ciB3ZXNlbnRsaWNoZSBjb29raWVzIGFubmVobWVuXCIsXG4gIFwib3B0LiBjb29raWVzIGFibGVobmVuXCIsXG4gIFwib3B0aW9uYWxlIGRpZW5zdGUgYWJsZWhuZW5cIixcbiAgXCJvcHRpb25hbGUgdG9vbHMgYWJsZWhuZW5cIixcbiAgXCJzaWUgYWxsZSBjb29raWVzIGFibGVobmVuXCIsXG4gIFwidGVjaG5pc2NoIG5vdHdlbmRpZ2UgYW5uZWhtZW5cIixcbiAgXCJudXIgZXNzZW50aWVsbGUgY29va2llc1wiLFxuICBcIm51ciBlc3NlbnRpZWxsZVwiLFxuICBcIm51ciBmdW5rdGlvbmFsZSBha3plcHRpZXJlblwiLFxuICBcIm51ciB0ZWNobmlzY2ggbm90d2VuZGlnZSBha3plcHRpZXJlblwiLFxuICBcIm51ciB0ZWNobmlzY2ggbm90d2VuZGlnZSBkYXRlbiB1bmQgY29va2llcyAuLi5cIixcbiAgXCJudXIgdGVjaG5pc2NoIG5vdHdlbmRpZ2UgenVsYXNzZW5cIixcbiAgXCJudXIgd2VzZW50bGljaGVcIixcbiAgXCJvaG5lIGVpbnZlcnN0XFx4RTRuZG5pcyBmb3J0ZmFocmVuXCIsXG4gIFwib2huZSBlaW53aWxsaWd1bmdcIixcbiAgXCJvaG5lIHp1c3RpbW11bmcgZm9ydGZhaHJlblwiLFxuICBcIm9obmUgenVzdGltbXVuZyB3ZWl0ZXJcIixcbiAgXCJ3ZWl0ZXIgbWl0IGVzc2VudGllbGxlbiBjb29raWVzXCIsXG4gIFwid2VpdGVyIG9obmUgYW5uYWhtZVwiLFxuICBcIndlaXRlciBvaG5lIHN0YXRpc3Rpc2NoZSBhbmFseXNlLWNvb2tpZXNcIixcbiAgXCJ3ZWl0ZXIgb2huZSBzdGF0aXN0aXNjaGUgY29va2llc1wiLFxuICBcIndlc2VudGxpY2hlIGNvb2tpZXNcIixcbiAgXCJmb3J0ZmFocmVuIG9obmUgenVzdGltbXVuZ1wiXG5dO1xudmFyIFJFSkVDVF9QQVRURVJOU19JVEFMSUFOID0gW1xuICBcInJpZml1dGFcIixcbiAgXCJyaWZpdXRhIGNvb2tpZXNcIixcbiAgXCJyaWZpdXRhIGkgY29va2llXCIsXG4gIFwicmlmaXV0YSBpIGNvb2tpZXNcIixcbiAgXCJyaWZpdXRhIHR1dHRpIGkgY29va2llXCIsXG4gIFwicmlmaXV0YSB0dXR0aSBpIGNvb2tpZXNcIixcbiAgXCJyaWZpdXRhIGNvb2tpZSBub24gbmVjZXNzYXJpXCIsXG4gIFwicmlmaXV0YSBpIGNvb2tpZSBub24gdGVjbmljaVwiLFxuICBcInJpZml1dGEgbm9uIG5lY2Vzc2FyaVwiLFxuICBcInJpZml1dGEgdHV0dG9cIixcbiAgXCJyaWZpdXRhIHR1dHRpXCIsXG4gIFwicmlmaXV0YSBlIGNoaXVkaVwiLFxuICBcImNoaXVkaSByaWZpdXRhIHR1dHRpIGkgY29va2llXCIsXG4gIFwiY2hpdWRpIGUgcmlmaXV0YSB0dXR0aSBpIGNvb2tpZVwiLFxuICBcImNoaXVkaSBlIHJpZml1dGEgdHV0dG9cIixcbiAgXCJuZWdhXCIsXG4gIFwibmVnYSB0dXR0aVwiLFxuICBcIm5lZ2FyZVwiLFxuICBcIm5vbiBhY2NldHRvXCIsXG4gIFwiYWNjZXR0YSBzb2xvIGkgbmVjZXNzYXJpXCIsXG4gIFwidXNhIHNvbG8gaSBjb29raWUgbmVjZXNzYXJpXCIsXG4gIFwiYWNjZXR0YSBzb2xvIG5lY2Vzc2FyaVwiLFxuICBcInNvbG8gbmVjZXNzYXJpXCIsXG4gIFwiY29udGludWEgc2VuemEgYWNjZXR0YXJlIHhcIixcbiAgXCJjb250aW51YSBzZW56YSBhY2NldHRhcmVcIixcbiAgXCJyaWZpdXRhcmVcIixcbiAgXCJyaWZpdXRhcmUgaSBjb29raWVcIixcbiAgXCJyaWZpdXRhcmUgdHV0dGkgaSBjb29raWVcIixcbiAgXCJyaWZpdXRhcmUgdHV0dGlcIixcbiAgXCJyaWZpdXRhcmUgZSBjb250aW51YXJlXCIsXG4gIFwiaW5zdGFsbGEgc29sbyBpIGNvb2tpZSBzdHJldHRhbWVudGUgbmVjZXNzYXJpXCIsXG4gIFwic29sbyBjb29raWVzIHRlY25pY2lcIixcbiAgXCJhY2NldHRhIG5lY2Vzc2FyaVwiLFxuICBcInNvbG8gY29va2llIHRlY25pY2lcIixcbiAgXCJzb2xvIGNvb2tpZSBuZWNlc3NhcmlcIixcbiAgXCJzdHJldHRhbWVudGUgbmVjZXNzYXJpXCIsXG4gIFwidGVjbmljaVwiLFxuICBcImFjY2V0dGEgc29sbyBjb29raWUgZGkgbmF2aWdhemlvbmVcIixcbiAgXCJjaGl1ZGkgZSBwcm9zZWd1aSBzb2xvIGNvbiBpIGNvb2tpZXMgdGVjbmljaSBuZWNlc3NhcmlcIixcbiAgXCJjb25zZW50aSBzb2xvIGkgY29va2llIHRlY25pY2lcIixcbiAgXCJzb2xvIGNvb2tpZSBlc3NlbnppYWxpXCIsXG4gIFwiYmxvY2NhIGkgY29va2llIG5vbiBlc3NlbnppYWxpXCIsXG4gIFwiYWNjZXR0YSBpIGNvb2tpZSBuZWNlc3NhcmlcIixcbiAgXCJhY2NldHRhIHNvbG8gY29va2llIHRlY25pY2lcIixcbiAgXCJhY2NldHRhIHNvbG8gaSBjb29raWUgZXNzZW56aWFsaVwiLFxuICBcImFjY2V0dGEgc29sbyBpIGNvb2tpZSBuZWNlc3NhcmlcIixcbiAgXCJhY2NldHRhIHNvbG8gaSBuZWNlc3NhcnlcIixcbiAgXCJhY2NldHRhIGkgY29va2llIGVzc2VuemlhbGlcIixcbiAgXCJhY2NldHRhIGNvb2tpZSB0ZWNuaWNpXCIsXG4gIFwibmVjZXNzYXJpXCIsXG4gIFwidXNhIHNvbG8gaSBjb29raWUgdGVjbmljaVwiLFxuICBcInVzYSBzb2xvIGkgbmVjZXNzYXJpXCIsXG4gIFwicmlmaXV0b1wiLFxuICBcImVzc2VuemlhbGlcIixcbiAgXCJhY2NldHRhIGNvb2tpZSBlc3NlbnppYWxpXCIsXG4gIFwiYWNjZXR0YSBjb29raWUgbmVjZXNzYXJpXCIsXG4gIFwiYWNjZXR0YSBzb2xvIGNvb2tpZSBlc3NlbnppYWxpXCIsXG4gIFwiYWNjZXR0YSBzb2xvIGNvb2tpZSBuZWNlc3NhcmlcIixcbiAgXCJyaWZpdXRhIGNvb2tpZSBub24gbmVjZXNzYXJpXCIsXG4gIFwicmlmaXV0YSBjb29raWUgbm9uIGVzc2VuemlhbGlcIixcbiAgXCJyaWZpdXRhIGkgY29va2llIG5vbiBuZWNlc3NhcmlcIixcbiAgXCJyaWZpdXRhIGkgY29va2llIG5vbiBlc3NlbnppYWxpXCIsXG4gIFwicmlmaXV0YSB0dXR0aSBpIGNvb2tpZSBlIGNoaXVkaVwiLFxuICBcInJpZml1dGEgdHV0dG8gZSBjaGl1ZGlcIixcbiAgXCJyaWZpdXRhIHR1dHRpIGkgY29va2llIGNoaXVkaVwiLFxuICBcImNvbnRpbnVhcmUgc2VuemEgYWNjZXR0YXJlXCIsXG4gIFwicmlmaXV0YXJlIGNvb2tpZXNcIixcbiAgXCJyaWZpdXRhcmUgaSBjb29raWVzXCIsXG4gIFwicmlmaXV0YXJlIG5vbiBuZWNlc3NhcmlcIixcbiAgXCJyaWZpdXRhcmUgdHV0dG9cIixcbiAgXCJyaWZpdXRhcmUgZSBjaGl1ZGVyZVwiLFxuICBcInNvbG8gZXNzZW56aWFsaVwiLFxuICBcInNvbG8gdGVjbmljaVwiLFxuICBcIm5lZ2FyZSB0dXR0aVwiXG5dO1xudmFyIFJFSkVDVF9QQVRURVJOU19CUkFaSUxJQU5fUE9SVFVHVUVTRSA9IFtcbiAgLy8gKGRlbnkpXG4gIC9eXFxzKihyZWplaXRhcnxyZWN1c2FyfGRlc2F0aXZhcnxibG9xdWVhcnxuZWdhcnxuXHUwMEUzb1xccyphY2VpdG98blx1MDBFM28gXFxzKmFjZWl0YXIpXFxzKiQvaXMsXG4gIC8vIChwcm9jZWVkKSAod2l0aG91dCBhY2NlcHRpbmcpXG4gIC9eXFxzKihjb250aW51YXJ8cHJvc3NlZ3VpcnxzZWd1aXIpXFxzKihzZW1cXHMqYWNlaXRhcilcXHMqJC9pcyxcbiAgLy8gKGRlbnkpIChldmVyeXRoaW5nKSAob3B0aW9uYWwpXG4gIC9eXFxzKihyZWplaXRhcnxyZWN1c2FyfGRlc2F0aXZhcnxibG9xdWVhcnxuZWdhcnxuXHUwMEUzb1xccyphY2VpdG98blx1MDBFM28gXFxzKmFjZWl0YXIpXFxzKih0dWRvfG8pP1xccyoob3BjaW9uYWx8KG5cdTAwRTNvWy1cXHNdKGVzc2VuY2lhbHxmdW5jaW9uYWx8b2JyaWdhdFx1MDBGM3Jpb3xuZWNlc3NcdTAwRTFyaW8pKSk/XFxzKiQvaXMsXG4gIC8vIChkZW55KSAoYWxsKSAodGhlKSAob3B0aW9uYWwpIChjb29raWVzKVxuICAvXlxccyoocmVqZWl0YXJ8cmVjdXNhcnxkZXNhdGl2YXJ8YmxvcXVlYXJ8bmVnYXJ8blx1MDBFM29cXHMqYWNlaXRvfG5cdTAwRTNvIFxccyphY2VpdGFyKVxccyoodG9kb3MpP1xccyoob3MpP1xccyooY29va2llcyk/XFxzKihvcGNpb25haXN8KG5cdTAwRTNvWy1cXHNdKGVzc2VuY2lhaXN8ZnVuY2lvbmFpc3xvYnJpZ2F0XHUwMEYzcmlvc3xuZWNlc3NcdTAwRTFyaW9zKSkpP1xccyokL2lzLFxuICAvLyAoYWNjZXB0KSAob25seSkgKHRoZSkgKGVzc2VudGlhbClcbiAgL15cXHMqKGFjZWl0YXJ8dXRpbGl6YXIpP1xccyooYXBlbmFzfHNvbWVudGV8c1x1MDBGMyk/XFxzKihvKT9cXHMqKGVzc2VuY2lhbHxmdW5jaW9uYWx8b2JyaWdhdFx1MDBGM3Jpb3xuZWNlc3NcdTAwRTFyaW8pXFxzKiQvaXMsXG4gIC8vIChhY2NlcHQpIChvbmx5KSAodGhlKSAoZXNzZW50aWFsKSAoY29va2llcylcbiAgL15cXHMqKGFjZWl0YXJ8dXRpbGl6YXIpP1xccyooYXBlbmFzfHNvbWVudGV8c1x1MDBGMyk/XFxzKihvcyk/XFxzKihjb29raWVzKT9cXHMqKGVzc2VuY2lhaXN8ZnVuY2lvbmFpc3xvYnJpZ2F0XHUwMEYzcmlvc3xuZWNlc3NcdTAwRTFyaW9zKVxccyokL2lzXG5dO1xudmFyIFJFSkVDVF9QQVRURVJOU19TUEFOSVNIID0gW1xuICBcInJlY2hhemFyXCIsXG4gIFwicmVjaGF6YXIgdG9kb1wiLFxuICBcInJlY2hhemFyIHRvZGFzXCIsXG4gIFwiZGVuZWdhclwiLFxuICBcInJlY2hhemFyIGNvb2tpZXNcIixcbiAgXCJyZWNoYXphcmxhcyB0b2Rhc1wiLFxuICBcIm5vIGFjZXB0b1wiLFxuICBcInJlY2hhemFyIHRvZGFzIGxhcyBjb29raWVzXCIsXG4gIFwicmVjaGF6YXIgeSBjZXJyYXJcIixcbiAgXCJkZW5lZ2FyIHRvZGFzXCIsXG4gIFwic29sbyBuZWNlc2FyaWFzXCIsXG4gIFwicmVjaGF6YXIgY29va2llcyBvcGNpb25hbGVzXCIsXG4gIFwicmVjaGF6YXIgb3BjaW9uYWxlc1wiLFxuICBcImNvb2tpZXMgZXN0cmljdGFtZW50ZSBuZWNlc2FyaWFzXCIsXG4gIFwiYWNlcHRhciBzXFx4RjNsbyBuZWNlc2FyaWFzXCIsXG4gIFwiZGVuZWdhciB0b2RvXCIsXG4gIFwiY2xlYXIgcmVjaGF6YXIgY29va2llc1wiLFxuICBcImNvbmZpZ3VyYXIgcmVjaGF6YXIgY29va2llc1wiLFxuICBcImRlbmVnYXIgY29va2llc1wiLFxuICBcInJlY2hhemFyIHkgY29udGludWFyXCIsXG4gIFwicmVjaGF6YXIgbGFzIGNvb2tpZXNcIixcbiAgXCJjbGVhciByZWNoYXphclwiLFxuICBcImRlbmVnYXIgdG9kYXMgbGFzIGNvb2tpZXNcIixcbiAgXCJyZWNoYXphciBjb29raWVzIG5vIGVzZW5jaWFsZXNcIixcbiAgXCJyZWNoYXphcmxhc1wiLFxuICBcIm5vLCBubyBhY2VwdG9cIixcbiAgXCJwZXJtaXRpciBzXFx4RjNsbyBuZWNlc2FyaWFzXCIsXG4gIFwicmVjaGF6YXIgY29va2llcyBhZGljaW9uYWxlc1wiLFxuICBcInJlY2hhemFyIGNvb2tpZXMgYW5hbFxceEVEdGljYXNcIixcbiAgXCJyZWNoYXphciBubyBuZWNlc2FyaWFzXCIsXG4gIFwicmVjaGF6YXIgb3BjaW9uYWxcIixcbiAgXCJyZWNoYXphciB0b2RvIGxvIG9wY2lvbmFsXCIsXG4gIFwic29sbyBjb29raWVzIGVzdHJpY3RhbWVudGUgbmVjZXNhcmlhc1wiLFxuICBcInNvbG8gZXNlbmNpYWxlc1wiLFxuICBcInggcmVjaGF6YXIgdG9kYXMgbGFzIGNvb2tpZXNcIixcbiAgXCJzb2xvIHVzYXIgY29va2llcyBuZWNlc2FyaWFzXCIsXG4gIFwic29sbyBjb29raWVzIG5lY2VzYXJpYXNcIixcbiAgXCJkZWNsaW5hclwiLFxuICBcImFjZXB0YXIgc29sbyBsYXMgY29va2llcyBlc2VuY2lhbGVzXCIsXG4gIFwibmVjZXNhcmlhc1wiLFxuICBcImFjZXB0YXIgY29va2llcyBvcGNpb25hbGVzXCIsXG4gIFwiYWNlcHRhciBzb2xvIGxvIG5lY2VzYXJpb1wiLFxuICBcInNvbG8gZnVuY2lvbmFsZXNcIixcbiAgXCJkZWNsaW5hciB5IGNlcnJhclwiLFxuICBcImRcXHhFOWNsaW5cIixcbiAgXCJkZWNsaW5hXCIsXG4gIFwiZGVjbGluYXIgY29uc2VudGltaWVudG9cIixcbiAgXCJkZWNsaW5hciB0b2Rhc1wiLFxuICBcInNvbG8gbGFzIGNvb2tpZXMgbmVjZXNhcmlhc1wiLFxuICBcIm5vbVxceEU5cyBzdXRpbGl0emVuIGNvb2tpZXMgcXVhbiBcXHhFOXMgbmVjZXNzYXJpXCIsXG4gIFwibm8sIHNcXHhGM2xvIGxhcyBlc3RyaWN0YW1lbnRlIG5lY2VzYXJpYXNcIixcbiAgXCJzb2xvIGxhcyBuZWNlc2FyaWFzXCIsXG4gIFwiYWNjZXB0YXIgbm9tXFx4RTlzIGxlcyBuZWNlc3NcXHhFMHJpZXNcIixcbiAgXCJhY2VwdGEgc29sbyBsYXMgbmVjZXNhcmlhc1wiLFxuICBcImFjZXB0YXIgc29sbyBsbyBlc2VuY2lhbFwiLFxuICBcImFjZXB0YXIgbGFzIG9ibGlnYXRvcmlhc1wiLFxuICBcInBlcm1pdGlyIHNvbG8gY29va2llcyB0XFx4RTljbmljYXNcIixcbiAgXCJjb29raWVzIHRcXHhFOWNuaWNhc1wiLFxuICBcInBlcm1pdGlyIHNvbG8gY29va2llcyB0XFx4RTljbmljYXNcIixcbiAgXCJ1c2FyIHNvbG8gY29va2llcyB0XFx4RTljbmljYXNcIixcbiAgXCJhY2VwdGFyIHNvbG8gbGFzIGVzZW5jaWFsZXNcIlxuXTtcbnZhciBSRUpFQ1RfUEFUVEVSTlNfU1dFRElTSCA9IFtcbiAgXCJhdnZpc2FcIixcbiAgXCJlbmRhc3QgblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwiYXZ2aXNhIGFsbGFcIixcbiAgXCJlbmRhc3QgblxceEY2ZHZcXHhFNG5kaWdhIGNvb2tpZXNcIixcbiAgXCJuZWthXCIsXG4gIFwibmVrYSBhbGxhXCIsXG4gIFwiYXZ2aXNhIGFsbHRcIixcbiAgXCJhdnZpc2EgYWxsYSBjb29raWVzXCIsXG4gIFwidGlsbFxceEU1dCBiYXJhIG5cXHhGNmR2XFx4RTRuZGlnYSBjb29raWVzXCIsXG4gIFwiYmFyYSBuXFx4RjZkdlxceEU0bmRpZ2FcIixcbiAgXCJiYXJhIG5cXHhGNmR2XFx4RTRuZGlnYSBjb29raWVzXCIsXG4gIFwidGlsbFxceEU1dCBiYXJhIG5cXHhGNmR2XFx4RTRuZGlnYSBrYWtvclwiLFxuICBcImVuZGFzdCBuXFx4RjZkdlxceEU0bmRpZ2Ega2Frb3JcIixcbiAgXCJ0aWxsXFx4RTV0IGVuZGFzdCBuXFx4RjZkdlxceEU0bmRpZ2FcIixcbiAgXCJmb3J0c1xceEU0dHQgdXRhbiBhdHQgYWNjZXB0ZXJhXCIsXG4gIFwiZ29ka1xceEU0bm4gZW5kYXN0IG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcImFjY2VwdGVyYSBlbmRhc3QgblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwiYXZ2aXNhIGNvb2tpZXNcIixcbiAgXCJ0aWxsXFx4RTV0IGVuZGFzdCBuXFx4RjZkdlxceEU0bmRpZ2Ega2Frb3JcIixcbiAgXCJhY2NlcHRlcmEgZW5kYXN0IG5cXHhGNmR2XFx4RTRuZGlnYSBjb29raWVzXCIsXG4gIFwibmVrYSBrYWtvclwiLFxuICBcImJhcmEgblxceEY2ZHZcXHhFNG5kaWdhIGtha29yXCIsXG4gIFwibmVrYSBhbGxhIGNvb2tpZXNcIixcbiAgXCJhbnZcXHhFNG5kIGVuZGFzdCBuXFx4RjZkdlxceEU0bmRpZ2FcIixcbiAgXCJhdnZpc2EgYWxsYSB1dG9tIG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcImhhbnRlcmEgZWxsZXIgYXZ2aXNhXCIsXG4gIFwibmVrYSBhbGxhIHV0b20gblxceEY2ZHZcXHhFNG5kaWdhIGtha29yXCIsXG4gIFwibmVrYSBvY2ggc3RcXHhFNG5nXCIsXG4gIFwidGlsbFxceEU1dCBiYXJhIG5cXHhGNmR2XFx4RTRuZGlnYSB0alxceEU0bnN0ZXJcIixcbiAgXCJhdnZpc2EgYWxsYSB1dG9tIG5cXHhGNmR2XFx4RTRuZGlnYSBrYWtvclwiLFxuICBcImF2dmlzYSBhbGxhIHZhbGZyaWFcIixcbiAgXCJnb2RrXFx4RTRubiBiYXJhIG5cXHhGNmR2XFx4RTRuZGlnYSBjb29raWVzXCIsXG4gIFwiYWNjZXB0ZXJhIGVuZGFzdCBuXFx4RjZkdlxceEU0bmRpZ2Ega2Frb3JcIixcbiAgXCJhbnZcXHhFNG5kIGVuZGFzdCBuXFx4RjZkdlxceEU0bmRpZ2EgY29va2llc1wiLFxuICBcImF2dmlzYSBhbGxhIGtha29yXCIsXG4gIFwiYXZ2aXNhIGFsbGEgdmFsbVxceEY2amxpZ2hldGVyXCIsXG4gIFwiYXZ2aXNhIGVqIG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcImF2dmlzYSBpY2tlLW5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcImZcXHhGNnJuZWthXCIsXG4gIFwiZ29ka1xceEU0bm4gYmFyYSBuXFx4RjZkdlxceEU0bmRpZ2FcIixcbiAgXCJnb2RrXFx4RTRubiBiYXJhIG5cXHhGNmR2XFx4RTRuZGlnYSBrYWtvclwiLFxuICBcImdvZGtcXHhFNG5uIGVuZGFzdCBuXFx4RjZkdlxceEU0bmRpZ2EgY29va2llc1wiLFxuICBcImdvZGtcXHhFNG5uIGVuZGFzdCBuXFx4RjZkdlxceEU0bmRpZ2Ega2Frb3JcIixcbiAgXCJnb2R0YSBlbmRhc3QgblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwiamFnIGdvZGtcXHhFNG5uZXIgYmFyYSBuXFx4RjZkdlxceEU0bmRpZ2Ega2Frb3JcIixcbiAgXCJuZWosIGF2dmlzYSBhbGxhXCIsXG4gIFwibmVqLCBiYXJhIG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcIm5laiwgYmFyYSBuXFx4RjZkdlxceEU0bmRpZ2EgY29va2llc1wiLFxuICBcIm5la2EgYWxsYSB1dG9tIG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcIm5la2EgYWxsYS5cIixcbiAgXCJuZWthIGNvb2tpZXNcIixcbiAgXCJuZWthIHNhbXRsaWdhXCIsXG4gIFwib2ssIGVuZGFzdCBuXFx4RjZkdlxceEU0bmRpZ2FcIixcbiAgXCJzcGFyYSBlbmRhc3QgblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwic3RcXHhFNG5nIG9jaCBhdnZpc2FcIixcbiAgXCJ0aWxsXFx4RTV0IGJhcmEgblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwiZ29ka1xceEU0bm4gblxceEY2ZHZcXHhFNG5kaWdhIGtha29yXCIsXG4gIFwiZ29ka1xceEU0bm4gblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwiYWNjZXB0ZXJhIG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcInN0cmlrdCBuXFx4RjZkdlxceEU0bmRpZ3RcIixcbiAgXCJ0aWxsXFx4RTV0IG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcIm5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcImVuYmFydCBuXFx4RjZkdlxceEU0bmRpZ2FcIixcbiAgXCJqYWcgZ29ka1xceEU0bm5lciBuXFx4RjZkdlxceEU0bmRpZ2Ega2Frb3JcIixcbiAgXCJhY2NlcHRlcmEgblxceEY2ZHZcXHhFNG5kaWdhIGtha29yXCIsXG4gIFwiZ29ka1xceEU0bm4gZW5iYXJ0IG5cXHhGNmR2XFx4RTRuZGlnYSBrYWtvclwiLFxuICBcImdvZGtcXHhFNG5uIG5cXHhGNmR2XFx4RTRuZGlnYSBjb29raWVzXCIsXG4gIFwib20gZHUgaW50ZSB2aWxsIGFjY2VwdGVyYSBhbmRyYSBjb29raWVzIFxceEU0biBkZSBzb20gXFx4RTRyIHRla25pc2t0IG5cXHhGNmR2XFx4RTRuZGlnYSBrbGlja2FyIGR1IGhcXHhFNHJcIixcbiAgXCJhY2NlcHRlcmEgZW5iYXJ0IG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcIm5cXHhGNmR2XFx4RTRuZGlnYSBjb29raWVzXCIsXG4gIFwiamFnIGdvZGtcXHhFNG5uZXIgZW5iYXJ0IGF0dCBuaSBhbnZcXHhFNG5kZXIgblxceEY2ZHZcXHhFNG5kaWdhIGNvb2tpZXNcIixcbiAgXCIrIHN0cmlrdCBuXFx4RjZkdlxceEU0bmRpZ2EgY29va2llc1wiLFxuICBcImFudlxceEU0bmQgZW5iYXJ0IG5cXHhGNmR2XFx4RTRuZGlnYSBjb29raWVzXCIsXG4gIFwiZW5iYXJ0IG5cXHhGNmR2XFx4RTRuZGlnYSBjb29raWVzXCIsXG4gIFwiZ29ka1xceEU0bm4gblxceEY2ZHZcXHhFNG5kaWdhIGtha29yIHN0XFx4RTRuZ1wiLFxuICBcIm9rIHRpbGwgblxceEY2ZHZcXHhFNG5kaWdhXCIsXG4gIFwic3RyaWt0IG5cXHhGNmR2XFx4RTRuZGlnYVwiLFxuICBcImZvcnRzXFx4RTR0dCB1dGFuIGF0dCBnb2RrXFx4RTRubmFcIixcbiAgXCJhdmJcXHhGNmogYWxsYSBjb29raWVzXCIsXG4gIFwiamFnIGFjY2VwdGVyYXIgZW5kYXN0IGdydW5kbFxceEU0Z2dhbmRlIGtha29yXCIsXG4gIFwibmVqLCBqYWcgYXZiXFx4RjZqZXJcIixcbiAgXCJ0aWxsXFx4RTV0IGludGUgY29va2llc1wiXG5dO1xudmFyIFJFSkVDVF9QQVRURVJOUyA9IFtcbiAgLi4uUkVKRUNUX1BBVFRFUk5TX0VOR0xJU0gsXG4gIC4uLlJFSkVDVF9QQVRURVJOU19EVVRDSCxcbiAgLi4uUkVKRUNUX1BBVFRFUk5TX0ZSRU5DSCxcbiAgLi4uUkVKRUNUX1BBVFRFUk5TX0dFUk1BTixcbiAgLi4uUkVKRUNUX1BBVFRFUk5TX0lUQUxJQU4sXG4gIC4uLlJFSkVDVF9QQVRURVJOU19CUkFaSUxJQU5fUE9SVFVHVUVTRSxcbiAgLi4uUkVKRUNUX1BBVFRFUk5TX1NQQU5JU0gsXG4gIC4uLlJFSkVDVF9QQVRURVJOU19TV0VESVNIXG5dO1xudmFyIE5FVkVSX01BVENIX1BBVFRFUk5TID0gW1xuICAvcGF5fHN1YnNjcmliZS9pcyxcbiAgL2Fib25uZWVyL2lzLFxuICAvYWJvbm5pZXIvaXMsXG4gIC9hYm9ubmVyL2lzLFxuICAvYWJib25hdGkvaXMsXG4gIC9pc2NyaXZpdGkvaXMsXG4gIC9hYmJvbmFyZS9pcyxcbiAgL2lzY3JpdmVyZS9pcyxcbiAgL3Nvc3RpZW5pY2kvaXMsXG4gIC9zdXNjcmliaXIvaXNcbl07XG5cbi8vIGxpYi9oZXVyaXN0aWNzLnRzXG52YXIgQlVUVE9OX0xJS0VfRUxFTUVOVF9TRUxFQ1RPUiA9ICdidXR0b24sIGlucHV0W3R5cGU9XCJidXR0b25cIl0sIGlucHV0W3R5cGU9XCJzdWJtaXRcIl0sIGEsIFtyb2xlPVwiYnV0dG9uXCJdLCBbY2xhc3MqPVwiYnV0dG9uXCJdJztcbnZhciBURVhUX0xJTUlUID0gMWU1O1xuZnVuY3Rpb24gY2hlY2tIZXVyaXN0aWNQYXR0ZXJucyhhbGxUZXh0LCBkZXRlY3RQYXR0ZXJucyA9IERFVEVDVF9QQVRURVJOUykge1xuICBhbGxUZXh0ID0gYWxsVGV4dC5zbGljZSgwLCBURVhUX0xJTUlUKTtcbiAgY29uc3QgcGF0dGVybnMgPSBbXTtcbiAgY29uc3Qgc25pcHBldHMyID0gW107XG4gIGZvciAoY29uc3QgcCBvZiBkZXRlY3RQYXR0ZXJucykge1xuICAgIGNvbnN0IG1hdGNoZXMyID0gYWxsVGV4dD8ubWF0Y2gocCk7XG4gICAgaWYgKG1hdGNoZXMyKSB7XG4gICAgICBwYXR0ZXJucy5wdXNoKHAudG9TdHJpbmcoKSk7XG4gICAgICBzbmlwcGV0czIucHVzaCguLi5tYXRjaGVzMi5tYXAoKG0pID0+IG0uc3Vic3RyaW5nKDAsIDIwMCkpKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHsgcGF0dGVybnMsIHNuaXBwZXRzOiBzbmlwcGV0czIgfTtcbn1cbmZ1bmN0aW9uIGdldEFjdGlvbmFibGVQb3B1cHMoKSB7XG4gIGNvbnN0IHBvcHVwcyA9IGdldFBvdGVudGlhbFBvcHVwcygpO1xuICBjb25zdCByZXN1bHQgPSBwb3B1cHMucmVkdWNlKChhY2MsIHBvcHVwKSA9PiB7XG4gICAgY29uc3QgcG9wdXBUZXh0ID0gcG9wdXAudGV4dD8udHJpbSgpO1xuICAgIGlmIChwb3B1cFRleHQpIHtcbiAgICAgIGNvbnN0IHsgcGF0dGVybnMgfSA9IGNoZWNrSGV1cmlzdGljUGF0dGVybnMocG9wdXBUZXh0KTtcbiAgICAgIGlmIChwYXR0ZXJucy5sZW5ndGggPiAwKSB7XG4gICAgICAgIGNvbnN0IHsgcmVqZWN0QnV0dG9ucywgb3RoZXJCdXR0b25zIH0gPSBjbGFzc2lmeUJ1dHRvbnMocG9wdXAuYnV0dG9ucyk7XG4gICAgICAgIGlmIChyZWplY3RCdXR0b25zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICBhY2MucHVzaCh7XG4gICAgICAgICAgICAuLi5wb3B1cCxcbiAgICAgICAgICAgIHJlamVjdEJ1dHRvbnMsXG4gICAgICAgICAgICBvdGhlckJ1dHRvbnNcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gYWNjO1xuICB9LCBbXSk7XG4gIHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBjbGFzc2lmeUJ1dHRvbnMoYnV0dG9ucykge1xuICBjb25zdCByZWplY3RCdXR0b25zID0gW107XG4gIGNvbnN0IG90aGVyQnV0dG9ucyA9IFtdO1xuICBmb3IgKGNvbnN0IGJ1dHRvbiBvZiBidXR0b25zKSB7XG4gICAgaWYgKGlzUmVqZWN0QnV0dG9uKGJ1dHRvbi50ZXh0KSkge1xuICAgICAgcmVqZWN0QnV0dG9ucy5wdXNoKGJ1dHRvbik7XG4gICAgfSBlbHNlIHtcbiAgICAgIG90aGVyQnV0dG9ucy5wdXNoKGJ1dHRvbik7XG4gICAgfVxuICB9XG4gIHJldHVybiB7XG4gICAgcmVqZWN0QnV0dG9ucyxcbiAgICBvdGhlckJ1dHRvbnNcbiAgfTtcbn1cbmZ1bmN0aW9uIGlzUmVqZWN0QnV0dG9uKGJ1dHRvblRleHQsIHJlamVjdFBhdHRlcm5zID0gUkVKRUNUX1BBVFRFUk5TLCBuZXZlck1hdGNoUGF0dGVybnMgPSBORVZFUl9NQVRDSF9QQVRURVJOUykge1xuICBpZiAoIWJ1dHRvblRleHQpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgY29uc3QgY2xlYW5lZEJ1dHRvblRleHQgPSBjbGVhbkJ1dHRvblRleHQoYnV0dG9uVGV4dCk7XG4gIHJldHVybiAhbmV2ZXJNYXRjaFBhdHRlcm5zLnNvbWUoKHApID0+IHAudGVzdChjbGVhbmVkQnV0dG9uVGV4dCkpICYmIHJlamVjdFBhdHRlcm5zLnNvbWUoKHApID0+IHAgaW5zdGFuY2VvZiBSZWdFeHAgJiYgcC50ZXN0KGNsZWFuZWRCdXR0b25UZXh0KSB8fCBwID09PSBjbGVhbmVkQnV0dG9uVGV4dCk7XG59XG5mdW5jdGlvbiBjbGVhbkJ1dHRvblRleHQoYnV0dG9uVGV4dCkge1xuICBsZXQgcmVzdWx0ID0gYnV0dG9uVGV4dC50b0xvd2VyQ2FzZSgpO1xuICByZXN1bHQgPSByZXN1bHQucmVwbGFjZSgvW1x1MjAxQ1x1MjAxRFwiJy8jJltcXF1cdTIxOTJcdTI3MTVcdTAwRDdcdTI3RTlcdTI3NkY+PFx1MjcxN1x1MDBEN1x1MjAxOFx1MjAxOVx1MjAzQVx1MDBBQlx1MDBCQl0rL2csIFwiXCIpO1xuICByZXN1bHQgPSByZXN1bHQucmVwbGFjZShcbiAgICAvW1xcdXsxRjYwMH0tXFx1ezFGNjRGfVxcdXsxRjMwMH0tXFx1ezFGNUZGfVxcdXsxRjY4MH0tXFx1ezFGNkZGfVxcdXsxRjFFMH0tXFx1ezFGMUZGfVxcdTI2MDAtXFx1MjZGRlxcdTI3MDAtXFx1MjdCRlxcdXsxRjkwMH0tXFx1ezFGOUZGfVxcdXsxRkE3MH0tXFx1ezFGQUZGfV0vZ3UsXG4gICAgXCJcIlxuICApO1xuICByZXN1bHQgPSByZXN1bHQucmVwbGFjZSgvXFxuKy9nLCBcIiBcIik7XG4gIHJlc3VsdCA9IHJlc3VsdC5yZXBsYWNlKC9cXHMrL2csIFwiIFwiKTtcbiAgcmVzdWx0ID0gcmVzdWx0LnRyaW0oKTtcbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGdldFBvdGVudGlhbFBvcHVwcygpIHtcbiAgY29uc3QgaXNGcmFtZWQgPSAhaXNUb3BGcmFtZSgpO1xuICBpZiAoaXNGcmFtZWQgJiYgd2luZG93LnBhcmVudCAmJiB3aW5kb3cucGFyZW50ICE9PSB3aW5kb3cudG9wKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIHJldHVybiBjb2xsZWN0UG90ZW50aWFsUG9wdXBzKGlzRnJhbWVkKTtcbn1cbmZ1bmN0aW9uIGNvbGxlY3RQb3RlbnRpYWxQb3B1cHMoaXNGcmFtZWQpIHtcbiAgbGV0IGVsZW1lbnRzID0gW107XG4gIGlmICghaXNGcmFtZWQpIHtcbiAgICBlbGVtZW50cyA9IGdldFBvcHVwTGlrZUVsZW1lbnRzKCk7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgZG9jID0gZG9jdW1lbnQuYm9keSB8fCBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQ7XG4gICAgaWYgKGRvYyAmJiBpc0VsZW1lbnRWaXNpYmxlKGRvYykgJiYgZG9jLmlubmVyVGV4dCkge1xuICAgICAgZWxlbWVudHMucHVzaChkb2MpO1xuICAgIH1cbiAgfVxuICBjb25zdCBwb3RlbnRpYWxQb3B1cHMgPSBbXTtcbiAgZm9yIChjb25zdCBlbCBvZiBlbGVtZW50cykge1xuICAgIGlmIChlbC5pbm5lclRleHQpIHtcbiAgICAgIHBvdGVudGlhbFBvcHVwcy5wdXNoKHtcbiAgICAgICAgdGV4dDogZWwuaW5uZXJUZXh0LFxuICAgICAgICBlbGVtZW50OiBlbCxcbiAgICAgICAgYnV0dG9uczogZ2V0QnV0dG9uRGF0YShlbClcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcG90ZW50aWFsUG9wdXBzO1xufVxuZnVuY3Rpb24gZ2V0UG9wdXBMaWtlRWxlbWVudHMoKSB7XG4gIGNvbnN0IHdhbGtlciA9IGRvY3VtZW50LmNyZWF0ZVRyZWVXYWxrZXIoXG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LFxuICAgIE5vZGVGaWx0ZXIuU0hPV19FTEVNRU5ULFxuICAgIC8vIHZpc2l0IG9ubHkgZWxlbWVudCBub2Rlc1xuICAgIHtcbiAgICAgIGFjY2VwdE5vZGUobm9kZSkge1xuICAgICAgICBpZiAobm9kZS50YWdOYW1lID09PSBcIkJPRFlcIikge1xuICAgICAgICAgIHJldHVybiBOb2RlRmlsdGVyLkZJTFRFUl9TS0lQO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGNzc1Bvc2l0aW9uID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUobm9kZSkucG9zaXRpb247XG4gICAgICAgIGlmICgoY3NzUG9zaXRpb24gPT09IFwiZml4ZWRcIiB8fCBjc3NQb3NpdGlvbiA9PT0gXCJzdGlja3lcIikgJiYgaXNFbGVtZW50VmlzaWJsZShub2RlKSkge1xuICAgICAgICAgIHJldHVybiBOb2RlRmlsdGVyLkZJTFRFUl9BQ0NFUFQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIE5vZGVGaWx0ZXIuRklMVEVSX1NLSVA7XG4gICAgICB9XG4gICAgfVxuICApO1xuICBjb25zdCBmb3VuZCA9IFtdO1xuICBmb3IgKGxldCBub2RlID0gd2Fsa2VyLm5leHROb2RlKCk7IG5vZGU7IG5vZGUgPSB3YWxrZXIubmV4dE5vZGUoKSkge1xuICAgIGZvdW5kLnB1c2gobm9kZSk7XG4gIH1cbiAgcmV0dXJuIGV4Y2x1ZGVDb250YWluZXJzKGZvdW5kKTtcbn1cbmZ1bmN0aW9uIGdldEJ1dHRvbkRhdGEoZWwpIHtcbiAgY29uc3QgYWN0aW9uYWJsZUJ1dHRvbnMgPSBleGNsdWRlQ29udGFpbmVycyhnZXRCdXR0b25MaWtlRWxlbWVudHMoZWwpKS5maWx0ZXIoXG4gICAgKGIpID0+IGlzRWxlbWVudFZpc2libGUoYikgJiYgIWlzRGlzYWJsZWQoYikgJiYgKGIuaW5uZXJUZXh0LnRyaW0oKSB8fCAvLyA8aW5wdXQ+IHZhbHVlcyBkbyBub3QgYXBwZWFyIGluIGlubmVyVGV4dFxuICAgIGIgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIFtcInN1Ym1pdFwiLCBcImJ1dHRvblwiXS5pbmNsdWRlcyhiLnR5cGUpICYmIGIudmFsdWU/LnRyaW0oKSlcbiAgKTtcbiAgcmV0dXJuIGFjdGlvbmFibGVCdXR0b25zLm1hcCgoYikgPT4gKHtcbiAgICB0ZXh0OiAoYi5pbm5lclRleHQgfHwgYi50ZXh0Q29udGVudCB8fCBcIlwiKS50cmltKCkgfHwgYi52YWx1ZT8udHJpbSgpIHx8IFwiXCIsXG4gICAgZWxlbWVudDogYlxuICB9KSk7XG59XG5mdW5jdGlvbiBnZXRCdXR0b25MaWtlRWxlbWVudHMoZWwpIHtcbiAgcmV0dXJuIEFycmF5LmZyb20oZWwucXVlcnlTZWxlY3RvckFsbChCVVRUT05fTElLRV9FTEVNRU5UX1NFTEVDVE9SKSk7XG59XG5mdW5jdGlvbiBpc0Rpc2FibGVkKGVsKSB7XG4gIHJldHVybiBcImRpc2FibGVkXCIgaW4gZWwgJiYgQm9vbGVhbihlbC5kaXNhYmxlZCkgfHwgZWwuaGFzQXR0cmlidXRlKFwiZGlzYWJsZWRcIik7XG59XG5mdW5jdGlvbiBleGNsdWRlQ29udGFpbmVycyhlbGVtZW50cykge1xuICBjb25zdCByZXN1bHRzID0gW107XG4gIGlmIChlbGVtZW50cy5sZW5ndGggPiAwKSB7XG4gICAgZm9yIChsZXQgaSA9IGVsZW1lbnRzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICBsZXQgY29udGFpbmVyID0gZmFsc2U7XG4gICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGVsZW1lbnRzLmxlbmd0aDsgaisrKSB7XG4gICAgICAgIGlmIChpICE9PSBqICYmIGVsZW1lbnRzW2ldLmNvbnRhaW5zKGVsZW1lbnRzW2pdKSkge1xuICAgICAgICAgIGNvbnRhaW5lciA9IHRydWU7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmICghY29udGFpbmVyKSB7XG4gICAgICAgIHJlc3VsdHMucHVzaChlbGVtZW50c1tpXSk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiByZXN1bHRzO1xufVxuXG4vLyBsaWIvY21wcy9iYXNlLnRzXG52YXIgZGVmYXVsdFJ1bkNvbnRleHQgPSB7XG4gIG1haW46IHRydWUsXG4gIGZyYW1lOiBmYWxzZSxcbiAgdXJsUGF0dGVybjogXCJcIlxufTtcbnZhciBBdXRvQ29uc2VudENNUEJhc2UgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKGF1dG9jb25zZW50SW5zdGFuY2UpIHtcbiAgICB0aGlzLm5hbWUgPSBcIkJBU0VSVUxFXCI7XG4gICAgdGhpcy5ydW5Db250ZXh0ID0gZGVmYXVsdFJ1bkNvbnRleHQ7XG4gICAgdGhpcy5hdXRvY29uc2VudCA9IGF1dG9jb25zZW50SW5zdGFuY2U7XG4gIH1cbiAgZ2V0IGhhc1NlbGZUZXN0KCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIk5vdCBJbXBsZW1lbnRlZFwiKTtcbiAgfVxuICBnZXQgaXNJbnRlcm1lZGlhdGUoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTm90IEltcGxlbWVudGVkXCIpO1xuICB9XG4gIGdldCBpc0Nvc21ldGljKCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIk5vdCBJbXBsZW1lbnRlZFwiKTtcbiAgfVxuICBtYWluV29ybGRFdmFsKHNuaXBwZXRJZCkge1xuICAgIGNvbnN0IHNuaXBwZXQgPSBzbmlwcGV0c1tzbmlwcGV0SWRdO1xuICAgIGlmICghc25pcHBldCkge1xuICAgICAgdGhpcy5hdXRvY29uc2VudC5jb25maWcubG9ncy5lcnJvcnMgJiYgY29uc29sZS53YXJuKFwiU25pcHBldCBub3QgZm91bmRcIiwgc25pcHBldElkKTtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoZmFsc2UpO1xuICAgIH1cbiAgICBjb25zdCBsb2dzQ29uZmlnID0gdGhpcy5hdXRvY29uc2VudC5jb25maWcubG9ncztcbiAgICBpZiAodGhpcy5hdXRvY29uc2VudC5jb25maWcuaXNNYWluV29ybGQpIHtcbiAgICAgIGxvZ3NDb25maWcuZXZhbHMgJiYgY29uc29sZS5sb2coXCJpbmxpbmUgZXZhbDpcIiwgc25pcHBldElkLCBzbmlwcGV0KTtcbiAgICAgIGxldCByZXN1bHQgPSBmYWxzZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJlc3VsdCA9ICEhc25pcHBldC5jYWxsKGdsb2JhbFRoaXMpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBsb2dzQ29uZmlnLmV2YWxzICYmIGNvbnNvbGUuZXJyb3IoXCJlcnJvciBldmFsdWF0aW5nIHJ1bGVcIiwgc25pcHBldElkLCBlKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUocmVzdWx0KTtcbiAgICB9XG4gICAgY29uc3Qgc25pcHBldFNyYyA9IGdldEZ1bmN0aW9uQm9keShzbmlwcGV0KTtcbiAgICBsb2dzQ29uZmlnLmV2YWxzICYmIGNvbnNvbGUubG9nKFwiYXN5bmMgZXZhbDpcIiwgc25pcHBldElkLCBzbmlwcGV0U3JjKTtcbiAgICByZXR1cm4gcmVxdWVzdEV2YWwoc25pcHBldFNyYywgc25pcHBldElkKS5jYXRjaCgoZSkgPT4ge1xuICAgICAgbG9nc0NvbmZpZy5ldmFscyAmJiBjb25zb2xlLmVycm9yKFwiZXJyb3IgZXZhbHVhdGluZyBydWxlXCIsIHNuaXBwZXRJZCwgZSk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfSk7XG4gIH1cbiAgY2hlY2tSdW5Db250ZXh0KCkge1xuICAgIGlmICghdGhpcy5jaGVja0ZyYW1lQ29udGV4dChpc1RvcEZyYW1lKCkpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmICh0aGlzLnJ1bkNvbnRleHQudXJsUGF0dGVybiAmJiAhdGhpcy5oYXNNYXRjaGluZ1VybFBhdHRlcm4oKSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBjaGVja0ZyYW1lQ29udGV4dChpc1RvcCkge1xuICAgIGNvbnN0IHJ1bkN0eCA9IHtcbiAgICAgIC4uLmRlZmF1bHRSdW5Db250ZXh0LFxuICAgICAgLi4udGhpcy5ydW5Db250ZXh0XG4gICAgfTtcbiAgICBpZiAoaXNUb3AgJiYgIXJ1bkN0eC5tYWluKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmICghaXNUb3AgJiYgIXJ1bkN0eC5mcmFtZSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBoYXNNYXRjaGluZ1VybFBhdHRlcm4oKSB7XG4gICAgcmV0dXJuIEJvb2xlYW4odGhpcy5ydW5Db250ZXh0Py51cmxQYXR0ZXJuICYmIHdpbmRvdy5sb2NhdGlvbi5ocmVmLm1hdGNoKHRoaXMucnVuQ29udGV4dC51cmxQYXR0ZXJuKSk7XG4gIH1cbiAgZGV0ZWN0Q21wKCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIk5vdCBJbXBsZW1lbnRlZFwiKTtcbiAgfVxuICBhc3luYyBkZXRlY3RQb3B1cCgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgb3B0T3V0KCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIk5vdCBJbXBsZW1lbnRlZFwiKTtcbiAgfVxuICBvcHRJbigpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJOb3QgSW1wbGVtZW50ZWRcIik7XG4gIH1cbiAgb3BlbkNtcCgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJOb3QgSW1wbGVtZW50ZWRcIik7XG4gIH1cbiAgYXN5bmMgdGVzdCgpIHtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHRydWUpO1xuICB9XG4gIGFzeW5jIGhpZ2hsaWdodEVsZW1lbnRzKGVsZW1lbnRzLCBhbGwgPSBmYWxzZSwgZGVsYXlUaW1lb3V0ID0gMmUzKSB7XG4gICAgaWYgKGVsZW1lbnRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoIWFsbCkge1xuICAgICAgZWxlbWVudHMgPSBbZWxlbWVudHNbMF1dO1xuICAgIH1cbiAgICB0aGlzLmF1dG9jb25zZW50LnNlbmRDb250ZW50TWVzc2FnZSh7XG4gICAgICB0eXBlOiBcInZpc3VhbERlbGF5XCIsXG4gICAgICB0aW1lb3V0OiBkZWxheVRpbWVvdXRcbiAgICB9KTtcbiAgICBmb3IgKGNvbnN0IGVsIG9mIGVsZW1lbnRzKSB7XG4gICAgICB0aGlzLmF1dG9jb25zZW50LmNvbmZpZy5sb2dzLnJ1bGVzdGVwcyAmJiBjb25zb2xlLmxvZyhcImhpZ2hsaWdodGluZ1wiLCBlbCk7XG4gICAgICBoaWdobGlnaHROb2RlKGVsKTtcbiAgICB9XG4gICAgYXdhaXQgdGhpcy53YWl0KGRlbGF5VGltZW91dCk7XG4gICAgZm9yIChjb25zdCBlbCBvZiBlbGVtZW50cykge1xuICAgICAgdW5oaWdobGlnaHROb2RlKGVsKTtcbiAgICB9XG4gIH1cbiAgLy8gSW1wbGVtZW50aW5nIERvbUFjdGlvbnNQcm92aWRlciBiZWxvdzpcbiAgYXN5bmMgY2xpY2tFbGVtZW50KGVsZW1lbnQpIHtcbiAgICBpZiAodGhpcy5hdXRvY29uc2VudC5jb25maWcudmlzdWFsVGVzdCkge1xuICAgICAgYXdhaXQgdGhpcy5oaWdobGlnaHRFbGVtZW50cyhbZWxlbWVudF0pO1xuICAgIH1cbiAgICB0aGlzLmF1dG9jb25zZW50LnVwZGF0ZVN0YXRlKHsgY2xpY2tzOiB0aGlzLmF1dG9jb25zZW50LnN0YXRlLmNsaWNrcyArIDEgfSk7XG4gICAgcmV0dXJuIHRoaXMuYXV0b2NvbnNlbnQuZG9tQWN0aW9ucy5jbGlja0VsZW1lbnQoZWxlbWVudCk7XG4gIH1cbiAgYXN5bmMgY2xpY2soc2VsZWN0b3IsIGFsbCA9IGZhbHNlKSB7XG4gICAgaWYgKHRoaXMuYXV0b2NvbnNlbnQuY29uZmlnLnZpc3VhbFRlc3QpIHtcbiAgICAgIGF3YWl0IHRoaXMuaGlnaGxpZ2h0RWxlbWVudHModGhpcy5lbGVtZW50U2VsZWN0b3Ioc2VsZWN0b3IpLCBhbGwpO1xuICAgIH1cbiAgICB0aGlzLmF1dG9jb25zZW50LnVwZGF0ZVN0YXRlKHsgY2xpY2tzOiB0aGlzLmF1dG9jb25zZW50LnN0YXRlLmNsaWNrcyArIDEgfSk7XG4gICAgcmV0dXJuIHRoaXMuYXV0b2NvbnNlbnQuZG9tQWN0aW9ucy5jbGljayhzZWxlY3RvciwgYWxsKTtcbiAgfVxuICBlbGVtZW50RXhpc3RzKHNlbGVjdG9yKSB7XG4gICAgcmV0dXJuIHRoaXMuYXV0b2NvbnNlbnQuZG9tQWN0aW9ucy5lbGVtZW50RXhpc3RzKHNlbGVjdG9yKTtcbiAgfVxuICBlbGVtZW50VmlzaWJsZShzZWxlY3RvciwgY2hlY2spIHtcbiAgICByZXR1cm4gdGhpcy5hdXRvY29uc2VudC5kb21BY3Rpb25zLmVsZW1lbnRWaXNpYmxlKHNlbGVjdG9yLCBjaGVjayk7XG4gIH1cbiAgd2FpdEZvckVsZW1lbnQoc2VsZWN0b3IsIHRpbWVvdXQpIHtcbiAgICByZXR1cm4gdGhpcy5hdXRvY29uc2VudC5kb21BY3Rpb25zLndhaXRGb3JFbGVtZW50KHNlbGVjdG9yLCB0aW1lb3V0KTtcbiAgfVxuICB3YWl0Rm9yVmlzaWJsZShzZWxlY3RvciwgdGltZW91dCwgY2hlY2spIHtcbiAgICByZXR1cm4gdGhpcy5hdXRvY29uc2VudC5kb21BY3Rpb25zLndhaXRGb3JWaXNpYmxlKHNlbGVjdG9yLCB0aW1lb3V0LCBjaGVjayk7XG4gIH1cbiAgYXN5bmMgd2FpdEZvclRoZW5DbGljayhzZWxlY3RvciwgdGltZW91dCwgYWxsKSB7XG4gICAgaWYgKHRoaXMuYXV0b2NvbnNlbnQuY29uZmlnLnZpc3VhbFRlc3QpIHtcbiAgICAgIGF3YWl0IHRoaXMuaGlnaGxpZ2h0RWxlbWVudHModGhpcy5lbGVtZW50U2VsZWN0b3Ioc2VsZWN0b3IpLCBhbGwpO1xuICAgIH1cbiAgICB0aGlzLmF1dG9jb25zZW50LnVwZGF0ZVN0YXRlKHsgY2xpY2tzOiB0aGlzLmF1dG9jb25zZW50LnN0YXRlLmNsaWNrcyArIDEgfSk7XG4gICAgcmV0dXJuIHRoaXMuYXV0b2NvbnNlbnQuZG9tQWN0aW9ucy53YWl0Rm9yVGhlbkNsaWNrKHNlbGVjdG9yLCB0aW1lb3V0LCBhbGwpO1xuICB9XG4gIHdhaXQobXMpIHtcbiAgICByZXR1cm4gdGhpcy5hdXRvY29uc2VudC5kb21BY3Rpb25zLndhaXQobXMpO1xuICB9XG4gIGhpZGUoc2VsZWN0b3IsIG1ldGhvZCkge1xuICAgIHJldHVybiB0aGlzLmF1dG9jb25zZW50LmRvbUFjdGlvbnMuaGlkZShzZWxlY3RvciwgbWV0aG9kKTtcbiAgfVxuICBjb29raWVDb250YWlucyhzdWJzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5hdXRvY29uc2VudC5kb21BY3Rpb25zLmNvb2tpZUNvbnRhaW5zKHN1YnN0cmluZyk7XG4gIH1cbiAgcHJlaGlkZShzZWxlY3Rvcikge1xuICAgIHJldHVybiB0aGlzLmF1dG9jb25zZW50LmRvbUFjdGlvbnMucHJlaGlkZShzZWxlY3Rvcik7XG4gIH1cbiAgdW5kb1ByZWhpZGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuYXV0b2NvbnNlbnQuZG9tQWN0aW9ucy51bmRvUHJlaGlkZSgpO1xuICB9XG4gIHF1ZXJ5U2luZ2xlUmVwbHlTZWxlY3RvcihzZWxlY3RvciwgcGFyZW50KSB7XG4gICAgcmV0dXJuIHRoaXMuYXV0b2NvbnNlbnQuZG9tQWN0aW9ucy5xdWVyeVNpbmdsZVJlcGx5U2VsZWN0b3Ioc2VsZWN0b3IsIHBhcmVudCk7XG4gIH1cbiAgcXVlcnlTZWxlY3RvckNoYWluKHNlbGVjdG9ycykge1xuICAgIHJldHVybiB0aGlzLmF1dG9jb25zZW50LmRvbUFjdGlvbnMucXVlcnlTZWxlY3RvckNoYWluKHNlbGVjdG9ycyk7XG4gIH1cbiAgZWxlbWVudFNlbGVjdG9yKHNlbGVjdG9yKSB7XG4gICAgcmV0dXJuIHRoaXMuYXV0b2NvbnNlbnQuZG9tQWN0aW9ucy5lbGVtZW50U2VsZWN0b3Ioc2VsZWN0b3IpO1xuICB9XG4gIHdhaXRGb3JNdXRhdGlvbihzZWxlY3Rvcikge1xuICAgIHJldHVybiB0aGlzLmF1dG9jb25zZW50LmRvbUFjdGlvbnMud2FpdEZvck11dGF0aW9uKHNlbGVjdG9yKTtcbiAgfVxufTtcbnZhciBBdXRvQ29uc2VudENNUCA9IGNsYXNzIGV4dGVuZHMgQXV0b0NvbnNlbnRDTVBCYXNlIHtcbiAgY29uc3RydWN0b3IocnVsZSwgYXV0b2NvbnNlbnRJbnN0YW5jZSkge1xuICAgIHN1cGVyKGF1dG9jb25zZW50SW5zdGFuY2UpO1xuICAgIHRoaXMucnVsZSA9IHJ1bGU7XG4gICAgdGhpcy5uYW1lID0gcnVsZS5uYW1lO1xuICAgIHRoaXMucnVuQ29udGV4dCA9IHJ1bGUucnVuQ29udGV4dCB8fCBkZWZhdWx0UnVuQ29udGV4dDtcbiAgfVxuICBnZXQgaGFzU2VsZlRlc3QoKSB7XG4gICAgcmV0dXJuICEhdGhpcy5ydWxlLnRlc3QgJiYgdGhpcy5ydWxlLnRlc3QubGVuZ3RoID4gMDtcbiAgfVxuICBnZXQgaXNJbnRlcm1lZGlhdGUoKSB7XG4gICAgcmV0dXJuICEhdGhpcy5ydWxlLmludGVybWVkaWF0ZTtcbiAgfVxuICBnZXQgaXNDb3NtZXRpYygpIHtcbiAgICByZXR1cm4gISF0aGlzLnJ1bGUuY29zbWV0aWM7XG4gIH1cbiAgZ2V0IHByZWhpZGVTZWxlY3RvcnMoKSB7XG4gICAgcmV0dXJuIHRoaXMucnVsZS5wcmVoaWRlU2VsZWN0b3JzIHx8IFtdO1xuICB9XG4gIGFzeW5jIGRldGVjdENtcCgpIHtcbiAgICBpZiAodGhpcy5ydWxlLmRldGVjdENtcCkge1xuICAgICAgcmV0dXJuIHRoaXMuX3J1blJ1bGVzU2VxdWVudGlhbGx5KHRoaXMucnVsZS5kZXRlY3RDbXAsIHRoaXMuYXV0b2NvbnNlbnQuY29uZmlnLmxvZ3MuZGV0ZWN0aW9uc3RlcHMpO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0UG9wdXAoKSB7XG4gICAgaWYgKHRoaXMucnVsZS5kZXRlY3RQb3B1cCkge1xuICAgICAgcmV0dXJuIHRoaXMuX3J1blJ1bGVzU2VxdWVudGlhbGx5KHRoaXMucnVsZS5kZXRlY3RQb3B1cCwgdGhpcy5hdXRvY29uc2VudC5jb25maWcubG9ncy5kZXRlY3Rpb25zdGVwcyk7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBhc3luYyBvcHRPdXQoKSB7XG4gICAgY29uc3QgbG9nc0NvbmZpZyA9IHRoaXMuYXV0b2NvbnNlbnQuY29uZmlnLmxvZ3M7XG4gICAgaWYgKHRoaXMucnVsZS5vcHRPdXQpIHtcbiAgICAgIGxvZ3NDb25maWcubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKFwiSW5pdGlhdGVkIG9wdE91dCgpXCIsIHRoaXMucnVsZS5vcHRPdXQpO1xuICAgICAgcmV0dXJuIHRoaXMuX3J1blJ1bGVzU2VxdWVudGlhbGx5KHRoaXMucnVsZS5vcHRPdXQsIHRoaXMuYXV0b2NvbnNlbnQuY29uZmlnLmxvZ3MucnVsZXN0ZXBzKTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGFzeW5jIG9wdEluKCkge1xuICAgIGNvbnN0IGxvZ3NDb25maWcgPSB0aGlzLmF1dG9jb25zZW50LmNvbmZpZy5sb2dzO1xuICAgIGlmICh0aGlzLnJ1bGUub3B0SW4pIHtcbiAgICAgIGxvZ3NDb25maWcubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKFwiSW5pdGlhdGVkIG9wdEluKClcIiwgdGhpcy5ydWxlLm9wdEluKTtcbiAgICAgIHJldHVybiB0aGlzLl9ydW5SdWxlc1NlcXVlbnRpYWxseSh0aGlzLnJ1bGUub3B0SW4sIHRoaXMuYXV0b2NvbnNlbnQuY29uZmlnLmxvZ3MucnVsZXN0ZXBzKTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGFzeW5jIG9wZW5DbXAoKSB7XG4gICAgaWYgKHRoaXMucnVsZS5vcGVuQ21wKSB7XG4gICAgICByZXR1cm4gdGhpcy5fcnVuUnVsZXNTZXF1ZW50aWFsbHkodGhpcy5ydWxlLm9wZW5DbXAsIHRoaXMuYXV0b2NvbnNlbnQuY29uZmlnLmxvZ3MucnVsZXN0ZXBzKTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGFzeW5jIHRlc3QoKSB7XG4gICAgaWYgKHRoaXMuaGFzU2VsZlRlc3QgJiYgdGhpcy5ydWxlLnRlc3QpIHtcbiAgICAgIHJldHVybiB0aGlzLl9ydW5SdWxlc1NlcXVlbnRpYWxseSh0aGlzLnJ1bGUudGVzdCwgdGhpcy5hdXRvY29uc2VudC5jb25maWcubG9ncy5ydWxlc3RlcHMpO1xuICAgIH1cbiAgICByZXR1cm4gc3VwZXIudGVzdCgpO1xuICB9XG4gIGFzeW5jIGV2YWx1YXRlUnVsZVN0ZXAocnVsZSkge1xuICAgIGNvbnN0IHJlc3VsdHMgPSBbXTtcbiAgICBjb25zdCBsb2dzQ29uZmlnID0gdGhpcy5hdXRvY29uc2VudC5jb25maWcubG9ncztcbiAgICBpZiAocnVsZS5leGlzdHMpIHtcbiAgICAgIHJlc3VsdHMucHVzaCh0aGlzLmVsZW1lbnRFeGlzdHMocnVsZS5leGlzdHMpKTtcbiAgICB9XG4gICAgaWYgKHJ1bGUudmlzaWJsZSkge1xuICAgICAgcmVzdWx0cy5wdXNoKHRoaXMuZWxlbWVudFZpc2libGUocnVsZS52aXNpYmxlLCBydWxlLmNoZWNrKSk7XG4gICAgfVxuICAgIGlmIChydWxlLmV2YWwpIHtcbiAgICAgIGNvbnN0IHJlcyA9IHRoaXMubWFpbldvcmxkRXZhbChydWxlLmV2YWwpO1xuICAgICAgcmVzdWx0cy5wdXNoKHJlcyk7XG4gICAgfVxuICAgIGlmIChydWxlLndhaXRGb3IpIHtcbiAgICAgIHJlc3VsdHMucHVzaCh0aGlzLndhaXRGb3JFbGVtZW50KHJ1bGUud2FpdEZvciwgcnVsZS50aW1lb3V0KSk7XG4gICAgfVxuICAgIGlmIChydWxlLndhaXRGb3JWaXNpYmxlKSB7XG4gICAgICByZXN1bHRzLnB1c2godGhpcy53YWl0Rm9yVmlzaWJsZShydWxlLndhaXRGb3JWaXNpYmxlLCBydWxlLnRpbWVvdXQsIHJ1bGUuY2hlY2spKTtcbiAgICB9XG4gICAgaWYgKHJ1bGUuY2xpY2spIHtcbiAgICAgIHJlc3VsdHMucHVzaCh0aGlzLmNsaWNrKHJ1bGUuY2xpY2ssIHJ1bGUuYWxsKSk7XG4gICAgfVxuICAgIGlmIChydWxlLndhaXRGb3JUaGVuQ2xpY2spIHtcbiAgICAgIHJlc3VsdHMucHVzaCh0aGlzLndhaXRGb3JUaGVuQ2xpY2socnVsZS53YWl0Rm9yVGhlbkNsaWNrLCBydWxlLnRpbWVvdXQsIHJ1bGUuYWxsKSk7XG4gICAgfVxuICAgIGlmIChydWxlLndhaXQpIHtcbiAgICAgIHJlc3VsdHMucHVzaCh0aGlzLndhaXQocnVsZS53YWl0KSk7XG4gICAgfVxuICAgIGlmIChydWxlLmhpZGUpIHtcbiAgICAgIHJlc3VsdHMucHVzaCh0aGlzLmhpZGUocnVsZS5oaWRlLCBydWxlLm1ldGhvZCkpO1xuICAgIH1cbiAgICBpZiAocnVsZS5jb29raWVDb250YWlucykge1xuICAgICAgcmVzdWx0cy5wdXNoKHRoaXMuY29va2llQ29udGFpbnMocnVsZS5jb29raWVDb250YWlucykpO1xuICAgIH1cbiAgICBpZiAocnVsZS5pZikge1xuICAgICAgaWYgKCFydWxlLmlmLmV4aXN0cyAmJiAhcnVsZS5pZi52aXNpYmxlKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJpbnZhbGlkIGNvbmRpdGlvbmFsIHJ1bGVcIiwgcnVsZS5pZik7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGlmICghcnVsZS50aGVuKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ2ludmFsaWQgY29uZGl0aW9uYWwgcnVsZSwgbWlzc2luZyBcInRoZW5cIiBzdGVwJywgcnVsZS5pZik7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNvbmRpdGlvbiA9IGF3YWl0IHRoaXMuZXZhbHVhdGVSdWxlU3RlcChydWxlLmlmKTtcbiAgICAgIGxvZ3NDb25maWcucnVsZXN0ZXBzICYmIGNvbnNvbGUubG9nKFwiQ29uZGl0aW9uIGlzXCIsIGNvbmRpdGlvbik7XG4gICAgICBpZiAoY29uZGl0aW9uKSB7XG4gICAgICAgIHJlc3VsdHMucHVzaCh0aGlzLl9ydW5SdWxlc1NlcXVlbnRpYWxseShydWxlLnRoZW4sIGxvZ3NDb25maWcucnVsZXN0ZXBzKSk7XG4gICAgICB9IGVsc2UgaWYgKHJ1bGUuZWxzZSkge1xuICAgICAgICByZXN1bHRzLnB1c2godGhpcy5fcnVuUnVsZXNTZXF1ZW50aWFsbHkocnVsZS5lbHNlLCBsb2dzQ29uZmlnLnJ1bGVzdGVwcykpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVzdWx0cy5wdXNoKHRydWUpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAocnVsZS5hbnkpIHtcbiAgICAgIGxldCByZXN1bHRPZkFueSA9IGZhbHNlO1xuICAgICAgZm9yIChjb25zdCBzdGVwIG9mIHJ1bGUuYW55KSB7XG4gICAgICAgIGlmIChhd2FpdCB0aGlzLmV2YWx1YXRlUnVsZVN0ZXAoc3RlcCkpIHtcbiAgICAgICAgICByZXN1bHRPZkFueSA9IHRydWU7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3VsdHMucHVzaChyZXN1bHRPZkFueSk7XG4gICAgfVxuICAgIGlmIChyZXN1bHRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgbG9nc0NvbmZpZy5lcnJvcnMgJiYgY29uc29sZS53YXJuKFwiVW5yZWNvZ25pemVkIHJ1bGVcIiwgcnVsZSk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IGFsbCA9IGF3YWl0IFByb21pc2UuYWxsKHJlc3VsdHMpO1xuICAgIGNvbnN0IHJlc3VsdCA9IGFsbC5yZWR1Y2UoKGEsIGIpID0+IGEgJiYgYiwgdHJ1ZSk7XG4gICAgaWYgKHJ1bGUubmVnYXRlZCkge1xuICAgICAgcmV0dXJuICFyZXN1bHQ7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbiAgYXN5bmMgX3J1blJ1bGVzUGFyYWxsZWwocnVsZXMpIHtcbiAgICBjb25zdCByZXN1bHRzID0gcnVsZXMubWFwKChydWxlKSA9PiB0aGlzLmV2YWx1YXRlUnVsZVN0ZXAocnVsZSkpO1xuICAgIGNvbnN0IGRldGVjdGlvbnMgPSBhd2FpdCBQcm9taXNlLmFsbChyZXN1bHRzKTtcbiAgICByZXR1cm4gZGV0ZWN0aW9ucy5ldmVyeSgocikgPT4gISFyKTtcbiAgfVxuICBhc3luYyBfcnVuUnVsZXNTZXF1ZW50aWFsbHkocnVsZXMsIGxvZ1N0ZXBzID0gdHJ1ZSkge1xuICAgIGZvciAoY29uc3QgcnVsZSBvZiBydWxlcykge1xuICAgICAgbG9nU3RlcHMgJiYgY29uc29sZS5sb2coXCJSdW5uaW5nIHJ1bGUuLi5cIiwgcnVsZSk7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLmV2YWx1YXRlUnVsZVN0ZXAocnVsZSk7XG4gICAgICBsb2dTdGVwcyAmJiBjb25zb2xlLmxvZyhcIi4uLnJ1bGUgcmVzdWx0XCIsIHJlc3VsdCk7XG4gICAgICBpZiAoIXJlc3VsdCAmJiAhcnVsZS5vcHRpb25hbCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9XG59O1xudmFyIEF1dG9Db25zZW50SGV1cmlzdGljQ01QID0gY2xhc3MgZXh0ZW5kcyBBdXRvQ29uc2VudENNUEJhc2Uge1xuICBjb25zdHJ1Y3RvcihhdXRvY29uc2VudEluc3RhbmNlKSB7XG4gICAgc3VwZXIoYXV0b2NvbnNlbnRJbnN0YW5jZSk7XG4gICAgdGhpcy5wb3B1cHMgPSBbXTtcbiAgICB0aGlzLm5hbWUgPSBcIkhFVVJJU1RJQ1wiO1xuICAgIHRoaXMucnVuQ29udGV4dCA9IHtcbiAgICAgIG1haW46IHRydWUsXG4gICAgICBmcmFtZTogZmFsc2VcbiAgICAgIC8vIGRvIG5vdCBydW4gaW4gaWZyYW1lcyBmb3Igc2VjdXJpdHkgcmVhc29uc1xuICAgIH07XG4gIH1cbiAgZ2V0IGhhc1NlbGZUZXN0KCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGdldCBpc0ludGVybWVkaWF0ZSgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZ2V0IGlzQ29zbWV0aWMoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGRldGVjdENtcCgpIHtcbiAgICB0aGlzLnBvcHVwcyA9IGdldEFjdGlvbmFibGVQb3B1cHMoKTtcbiAgICBpZiAodGhpcy5wb3B1cHMubGVuZ3RoID4gMCkge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh0cnVlKTtcbiAgICB9XG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShmYWxzZSk7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0UG9wdXAoKSB7XG4gICAgaWYgKHRoaXMucG9wdXBzLmxlbmd0aCA+IDApIHtcbiAgICAgIGlmICh0aGlzLnBvcHVwcy5sZW5ndGggPiAxIHx8IHRoaXMucG9wdXBzWzBdLnJlamVjdEJ1dHRvbnMgJiYgdGhpcy5wb3B1cHNbMF0ucmVqZWN0QnV0dG9ucy5sZW5ndGggPiAxKSB7XG4gICAgICAgIHRoaXMuYXV0b2NvbnNlbnQuY29uZmlnLmxvZ3MuZXJyb3JzICYmIGNvbnNvbGUud2FybihcIkhldXJpc3RpYyBmb3VuZCBtdWx0aXBsZSByZWplY3QgYnV0dG9uc1wiKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgb3B0T3V0KCkge1xuICAgIGNvbnN0IGJ1dHRvbiA9IHRoaXMucG9wdXBzWzBdPy5yZWplY3RCdXR0b25zPy5bMF07XG4gICAgaWYgKGJ1dHRvbikge1xuICAgICAgcmV0dXJuIHRoaXMuY2xpY2tFbGVtZW50KGJ1dHRvbi5lbGVtZW50KTtcbiAgICB9XG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShmYWxzZSk7XG4gIH1cbiAgb3B0SW4oKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTm90IEltcGxlbWVudGVkXCIpO1xuICB9XG4gIG9wZW5DbXAoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTm90IEltcGxlbWVudGVkXCIpO1xuICB9XG4gIGFzeW5jIHRlc3QoKSB7XG4gICAgY29uc3QgYnV0dG9uID0gdGhpcy5wb3B1cHNbMF0ucmVqZWN0QnV0dG9ucz8uWzBdO1xuICAgIGlmIChidXR0b24pIHtcbiAgICAgIGF3YWl0IHRoaXMud2FpdCg1MDApO1xuICAgICAgcmV0dXJuICFpc0VsZW1lbnRWaXNpYmxlKGJ1dHRvbi5lbGVtZW50KTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59O1xuXG4vLyBsaWIvY21wcy9jb25zZW50b21hdGljLnRzXG52YXIgQ29uc2VudE9NYXRpY0NNUCA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IobmFtZSwgY29uZmlnKSB7XG4gICAgdGhpcy5uYW1lID0gbmFtZTtcbiAgICB0aGlzLmNvbmZpZyA9IGNvbmZpZztcbiAgICB0aGlzLm1ldGhvZHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgIHRoaXMucnVuQ29udGV4dCA9IGRlZmF1bHRSdW5Db250ZXh0O1xuICAgIHRoaXMuaXNDb3NtZXRpYyA9IGZhbHNlO1xuICAgIGNvbmZpZy5tZXRob2RzLmZvckVhY2goKG1ldGhvZENvbmZpZykgPT4ge1xuICAgICAgaWYgKG1ldGhvZENvbmZpZy5hY3Rpb24pIHtcbiAgICAgICAgdGhpcy5tZXRob2RzLnNldChtZXRob2RDb25maWcubmFtZSwgbWV0aG9kQ29uZmlnLmFjdGlvbik7XG4gICAgICB9XG4gICAgfSk7XG4gICAgdGhpcy5oYXNTZWxmVGVzdCA9IGZhbHNlO1xuICB9XG4gIGdldCBpc0ludGVybWVkaWF0ZSgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgY2hlY2tSdW5Db250ZXh0KCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGNoZWNrRnJhbWVDb250ZXh0KGlzVG9wKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgaGFzTWF0Y2hpbmdVcmxQYXR0ZXJuKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBhc3luYyBkZXRlY3RDbXAoKSB7XG4gICAgY29uc3QgbWF0Y2hSZXN1bHRzID0gdGhpcy5jb25maWcuZGV0ZWN0b3JzLm1hcCgoZGV0ZWN0b3JDb25maWcpID0+IG1hdGNoZXMoZGV0ZWN0b3JDb25maWcucHJlc2VudE1hdGNoZXIpKTtcbiAgICByZXR1cm4gbWF0Y2hSZXN1bHRzLnNvbWUoKHIpID0+ICEhcik7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0UG9wdXAoKSB7XG4gICAgY29uc3QgbWF0Y2hSZXN1bHRzID0gdGhpcy5jb25maWcuZGV0ZWN0b3JzLm1hcCgoZGV0ZWN0b3JDb25maWcpID0+IG1hdGNoZXMoZGV0ZWN0b3JDb25maWcuc2hvd2luZ01hdGNoZXIpKTtcbiAgICByZXR1cm4gbWF0Y2hSZXN1bHRzLnNvbWUoKHIpID0+ICEhcik7XG4gIH1cbiAgYXN5bmMgZXhlY3V0ZUFjdGlvbihtZXRob2QsIHBhcmFtKSB7XG4gICAgaWYgKHRoaXMubWV0aG9kcy5oYXMobWV0aG9kKSkge1xuICAgICAgcmV0dXJuIGV4ZWN1dGVBY3Rpb24odGhpcy5tZXRob2RzLmdldChtZXRob2QpLCBwYXJhbSk7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIG9wdE91dCgpIHtcbiAgICBhd2FpdCB0aGlzLmV4ZWN1dGVBY3Rpb24oXCJISURFX0NNUFwiKTtcbiAgICBhd2FpdCB0aGlzLmV4ZWN1dGVBY3Rpb24oXCJPUEVOX09QVElPTlNcIik7XG4gICAgYXdhaXQgdGhpcy5leGVjdXRlQWN0aW9uKFwiSElERV9DTVBcIik7XG4gICAgYXdhaXQgdGhpcy5leGVjdXRlQWN0aW9uKFwiRE9fQ09OU0VOVFwiLCBbXSk7XG4gICAgYXdhaXQgdGhpcy5leGVjdXRlQWN0aW9uKFwiU0FWRV9DT05TRU5UXCIpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIG9wdEluKCkge1xuICAgIGF3YWl0IHRoaXMuZXhlY3V0ZUFjdGlvbihcIkhJREVfQ01QXCIpO1xuICAgIGF3YWl0IHRoaXMuZXhlY3V0ZUFjdGlvbihcIk9QRU5fT1BUSU9OU1wiKTtcbiAgICBhd2FpdCB0aGlzLmV4ZWN1dGVBY3Rpb24oXCJISURFX0NNUFwiKTtcbiAgICBhd2FpdCB0aGlzLmV4ZWN1dGVBY3Rpb24oXCJET19DT05TRU5UXCIsIFtcIkRcIiwgXCJBXCIsIFwiQlwiLCBcIkVcIiwgXCJGXCIsIFwiWFwiXSk7XG4gICAgYXdhaXQgdGhpcy5leGVjdXRlQWN0aW9uKFwiU0FWRV9DT05TRU5UXCIpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIG9wZW5DbXAoKSB7XG4gICAgYXdhaXQgdGhpcy5leGVjdXRlQWN0aW9uKFwiSElERV9DTVBcIik7XG4gICAgYXdhaXQgdGhpcy5leGVjdXRlQWN0aW9uKFwiT1BFTl9PUFRJT05TXCIpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIHRlc3QoKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbn07XG5cbi8vIGxpYi9ydWxlcy50c1xudmFyIFNVUFBPUlRFRF9SVUxFX1NURVBfVkVSU0lPTiA9IDE7XG5cbi8vIGxpYi9jbXBzL3RydXN0YXJjLXRvcC50c1xudmFyIGNvb2tpZVNldHRpbmdzQnV0dG9uID0gXCIjdHJ1c3RlLXNob3ctY29uc2VudFwiO1xudmFyIHNob3J0Y3V0T3B0T3V0ID0gXCIjdHJ1c3RlLWNvbnNlbnQtcmVxdWlyZWRcIjtcbnZhciBzaG9ydGN1dE9wdEluID0gXCIjdHJ1c3RlLWNvbnNlbnQtYnV0dG9uXCI7XG52YXIgcG9wdXBDb250ZW50ID0gXCIjdHJ1c3RlLWNvbnNlbnQtY29udGVudFwiO1xudmFyIGJhbm5lck92ZXJsYXkgPSBcIiN0cnVzdGFyYy1iYW5uZXItb3ZlcmxheVwiO1xudmFyIGJhbm5lckNvbnRhaW5lciA9IFwiI3RydXN0ZS1jb25zZW50LXRyYWNrXCI7XG52YXIgVHJ1c3RBcmNUb3AgPSBjbGFzcyBleHRlbmRzIEF1dG9Db25zZW50Q01QQmFzZSB7XG4gIGNvbnN0cnVjdG9yKGF1dG9jb25zZW50SW5zdGFuY2UpIHtcbiAgICBzdXBlcihhdXRvY29uc2VudEluc3RhbmNlKTtcbiAgICB0aGlzLm5hbWUgPSBcIlRydXN0QXJjLXRvcFwiO1xuICAgIHRoaXMucHJlaGlkZVNlbGVjdG9ycyA9IFtcIi50cnVzdGFyYy1iYW5uZXItY29udGFpbmVyXCIsIGAudHJ1c3RlX3BvcGZyYW1lLC50cnVzdGVfb3ZlcmxheSwudHJ1c3RlX2JveF9vdmVybGF5LCR7YmFubmVyQ29udGFpbmVyfWBdO1xuICAgIHRoaXMucnVuQ29udGV4dCA9IHtcbiAgICAgIG1haW46IHRydWUsXG4gICAgICBmcmFtZTogZmFsc2VcbiAgICB9O1xuICAgIHRoaXMuX3Nob3J0Y3V0QnV0dG9uID0gbnVsbDtcbiAgICB0aGlzLl9vcHRJbkRvbmUgPSBmYWxzZTtcbiAgfVxuICBnZXQgaGFzU2VsZlRlc3QoKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgZ2V0IGlzSW50ZXJtZWRpYXRlKCkge1xuICAgIGlmICh0aGlzLl9vcHRJbkRvbmUpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuICF0aGlzLl9zaG9ydGN1dEJ1dHRvbjtcbiAgfVxuICBnZXQgaXNDb3NtZXRpYygpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0Q21wKCkge1xuICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuZWxlbWVudEV4aXN0cyhgJHtjb29raWVTZXR0aW5nc0J1dHRvbn0sJHtiYW5uZXJDb250YWluZXJ9YCk7XG4gICAgaWYgKHJlc3VsdCkge1xuICAgICAgdGhpcy5fc2hvcnRjdXRCdXR0b24gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHNob3J0Y3V0T3B0T3V0KTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICBhc3luYyBkZXRlY3RQb3B1cCgpIHtcbiAgICByZXR1cm4gdGhpcy5lbGVtZW50VmlzaWJsZShgJHtwb3B1cENvbnRlbnR9LCR7YmFubmVyT3ZlcmxheX0sJHtiYW5uZXJDb250YWluZXJ9YCwgXCJhbnlcIik7XG4gIH1cbiAgYXN5bmMgb3B0T3V0KCkge1xuICAgIGlmICh0aGlzLl9zaG9ydGN1dEJ1dHRvbikge1xuICAgICAgdGhpcy5fc2hvcnRjdXRCdXR0b24uY2xpY2soKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBoaWRlRWxlbWVudHMoZ2V0U3R5bGVFbGVtZW50KCksIGAudHJ1c3RlX3BvcGZyYW1lLCAudHJ1c3RlX292ZXJsYXksIC50cnVzdGVfYm94X292ZXJsYXksICR7YmFubmVyQ29udGFpbmVyfWApO1xuICAgIGF3YWl0IHRoaXMuY2xpY2soY29va2llU2V0dGluZ3NCdXR0b24pO1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgZ2V0U3R5bGVFbGVtZW50KCkucmVtb3ZlKCk7XG4gICAgfSwgMWU0KTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBhc3luYyBvcHRJbigpIHtcbiAgICB0aGlzLl9vcHRJbkRvbmUgPSB0cnVlO1xuICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKHNob3J0Y3V0T3B0SW4pO1xuICB9XG4gIGFzeW5jIG9wZW5DbXAoKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgYXN5bmMgdGVzdCgpIHtcbiAgICBhd2FpdCB0aGlzLndhaXQoNTAwKTtcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5tYWluV29ybGRFdmFsKFwiRVZBTF9UUlVTVEFSQ19UT1BcIik7XG4gIH1cbn07XG5cbi8vIGxpYi9jbXBzL3RydXN0YXJjLWZyYW1lLnRzXG52YXIgVHJ1c3RBcmNGcmFtZSA9IGNsYXNzIGV4dGVuZHMgQXV0b0NvbnNlbnRDTVBCYXNlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICB0aGlzLm5hbWUgPSBcIlRydXN0QXJjLWZyYW1lXCI7XG4gICAgdGhpcy5ydW5Db250ZXh0ID0ge1xuICAgICAgbWFpbjogZmFsc2UsXG4gICAgICBmcmFtZTogdHJ1ZSxcbiAgICAgIHVybFBhdHRlcm46IFwiXmh0dHBzOi8vY29uc2VudC1wcmVmXFxcXC50cnVzdGFyY1xcXFwuY29tL1xcXFw/XCJcbiAgICB9O1xuICB9XG4gIGdldCBoYXNTZWxmVGVzdCgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBnZXQgaXNJbnRlcm1lZGlhdGUoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGdldCBpc0Nvc21ldGljKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBhc3luYyBkZXRlY3RDbXAoKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0UG9wdXAoKSB7XG4gICAgcmV0dXJuIHRoaXMuZWxlbWVudFZpc2libGUoXCIjZGVmYXVsdHByZWZlcmVuY2VtYW5hZ2VyXCIsIFwiYW55XCIpICYmIHRoaXMuZWxlbWVudFZpc2libGUoXCIubWFpbkNvbnRlbnRcIiwgXCJhbnlcIik7XG4gIH1cbiAgYXN5bmMgbmF2aWdhdGVUb1NldHRpbmdzKCkge1xuICAgIGF3YWl0IHdhaXRGb3IoXG4gICAgICBhc3luYyAoKSA9PiB7XG4gICAgICAgIHJldHVybiB0aGlzLmVsZW1lbnRFeGlzdHMoXCIuc2hwXCIpIHx8IHRoaXMuZWxlbWVudFZpc2libGUoXCIuYWR2YW5jZVwiLCBcImFueVwiKSB8fCB0aGlzLmVsZW1lbnRFeGlzdHMoXCIuc3dpdGNoIHNwYW46Zmlyc3QtY2hpbGRcIik7XG4gICAgICB9LFxuICAgICAgMTAsXG4gICAgICA1MDBcbiAgICApO1xuICAgIGlmICh0aGlzLmVsZW1lbnRFeGlzdHMoXCIuc2hwXCIpKSB7XG4gICAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLnNocFwiKTtcbiAgICB9XG4gICAgYXdhaXQgdGhpcy53YWl0Rm9yRWxlbWVudChcIi5wcmVmUGFuZWxcIiwgNWUzKTtcbiAgICBpZiAodGhpcy5lbGVtZW50VmlzaWJsZShcIi5hZHZhbmNlXCIsIFwiYW55XCIpKSB7XG4gICAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLmFkdmFuY2VcIik7XG4gICAgfVxuICAgIHJldHVybiBhd2FpdCB3YWl0Rm9yKCgpID0+IHRoaXMuZWxlbWVudFZpc2libGUoXCIuc3dpdGNoIHNwYW46Zmlyc3QtY2hpbGRcIiwgXCJhbnlcIiksIDUsIDFlMyk7XG4gIH1cbiAgYXN5bmMgb3B0T3V0KCkge1xuICAgIGlmIChhd2FpdCB0aGlzLm1haW5Xb3JsZEV2YWwoXCJFVkFMX1RSVVNUQVJDX0ZSQU1FX1RFU1RcIikpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBsZXQgdGltZW91dCA9IDNlMztcbiAgICBpZiAoYXdhaXQgdGhpcy5tYWluV29ybGRFdmFsKFwiRVZBTF9UUlVTVEFSQ19GUkFNRV9HVE1cIikpIHtcbiAgICAgIHRpbWVvdXQgPSAxNTAwO1xuICAgIH1cbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGRvY3VtZW50LnJlYWR5U3RhdGUgPT09IFwiY29tcGxldGVcIiwgMjAsIDEwMCk7XG4gICAgYXdhaXQgdGhpcy53YWl0Rm9yRWxlbWVudChcIi5tYWluQ29udGVudFthcmlhLWhpZGRlbj1mYWxzZV1cIiwgdGltZW91dCk7XG4gICAgaWYgKGF3YWl0IHRoaXMuY2xpY2soXCIucmVqZWN0QWxsXCIpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHRoaXMuZWxlbWVudEV4aXN0cyhcIi5wcmVmUGFuZWxcIikpIHtcbiAgICAgIGF3YWl0IHRoaXMud2FpdEZvckVsZW1lbnQoJy5wcmVmUGFuZWxbc3R5bGU9XCJ2aXNpYmlsaXR5OiB2aXNpYmxlO1wiXScsIHRpbWVvdXQpO1xuICAgIH1cbiAgICBpZiAoYXdhaXQgdGhpcy5jbGljayhcIiNjYXREZXRhaWxzMFwiKSkge1xuICAgICAgYXdhaXQgdGhpcy5jbGljayhcIi5zdWJtaXRcIik7XG4gICAgICB0aGlzLndhaXRGb3JUaGVuQ2xpY2soXCIjZ3d0LWRlYnVnLWNsb3NlX2lkXCIsIHRpbWVvdXQpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmIChhd2FpdCB0aGlzLmNsaWNrKFwiLnJlcXVpcmVkXCIpKSB7XG4gICAgICB0aGlzLndhaXRGb3JUaGVuQ2xpY2soXCIjZ3d0LWRlYnVnLWNsb3NlX2lkXCIsIHRpbWVvdXQpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGF3YWl0IHRoaXMubmF2aWdhdGVUb1NldHRpbmdzKCk7XG4gICAgYXdhaXQgdGhpcy5jbGljayhcIi5zd2l0Y2ggc3BhbjpudGgtY2hpbGQoMSk6bm90KC5hY3RpdmUpXCIsIHRydWUpO1xuICAgIGF3YWl0IHRoaXMuY2xpY2soXCIuc3VibWl0XCIpO1xuICAgIHRoaXMud2FpdEZvclRoZW5DbGljayhcIiNnd3QtZGVidWctY2xvc2VfaWRcIiwgdGltZW91dCAqIDEwKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBhc3luYyBvcHRJbigpIHtcbiAgICBpZiAoYXdhaXQgdGhpcy5jbGljayhcIi5jYWxsXCIpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgYXdhaXQgdGhpcy5uYXZpZ2F0ZVRvU2V0dGluZ3MoKTtcbiAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLnN3aXRjaCBzcGFuOm50aC1jaGlsZCgyKVwiLCB0cnVlKTtcbiAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLnN1Ym1pdFwiKTtcbiAgICB0aGlzLndhaXRGb3JFbGVtZW50KFwiI2d3dC1kZWJ1Zy1jbG9zZV9pZFwiLCAzZTUpLnRoZW4oKCkgPT4ge1xuICAgICAgdGhpcy5jbGljayhcIiNnd3QtZGVidWctY2xvc2VfaWRcIik7XG4gICAgfSk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgYXN5bmMgdGVzdCgpIHtcbiAgICBhd2FpdCB0aGlzLndhaXQoNTAwKTtcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5tYWluV29ybGRFdmFsKFwiRVZBTF9UUlVTVEFSQ19GUkFNRV9URVNUXCIpO1xuICB9XG59O1xuXG4vLyBsaWIvY21wcy9jb29raWVib3QudHNcbnZhciBDb29raWVib3QgPSBjbGFzcyBleHRlbmRzIEF1dG9Db25zZW50Q01QQmFzZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgdGhpcy5uYW1lID0gXCJDeWJvdGNvb2tpZWJvdFwiO1xuICAgIHRoaXMucHJlaGlkZVNlbGVjdG9ycyA9IFtcbiAgICAgIFwiI0N5Ym90Q29va2llYm90RGlhbG9nLCNDeWJvdENvb2tpZWJvdERpYWxvZ0JvZHlVbmRlcmxheSwjZHRjb29raWUtY29udGFpbmVyLCNjb29raWViYW5uZXIsI2NiLWNvb2tpZW92ZXJsYXksLm1vZGFsLS1jb29raWUtYmFubmVyLCNjb29raWViYW5uZXJfb3V0ZXIsI0Nvb2tpZUJhbm5lclwiXG4gICAgXTtcbiAgfVxuICBnZXQgaGFzU2VsZlRlc3QoKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgZ2V0IGlzSW50ZXJtZWRpYXRlKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBnZXQgaXNDb3NtZXRpYygpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0Q21wKCkge1xuICAgIHJldHVybiBhd2FpdCB0aGlzLm1haW5Xb3JsZEV2YWwoXCJFVkFMX0NPT0tJRUJPVF8xXCIpO1xuICB9XG4gIGFzeW5jIGRldGVjdFBvcHVwKCkge1xuICAgIHJldHVybiB0aGlzLm1haW5Xb3JsZEV2YWwoXCJFVkFMX0NPT0tJRUJPVF8yXCIpO1xuICB9XG4gIGFzeW5jIG9wdE91dCgpIHtcbiAgICBhd2FpdCB0aGlzLndhaXQoNTAwKTtcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5tYWluV29ybGRFdmFsKFwiRVZBTF9DT09LSUVCT1RfM1wiKTtcbiAgICBhd2FpdCB0aGlzLndhaXQoMWUzKTtcbiAgICByZXMgPSByZXMgJiYgYXdhaXQgdGhpcy5tYWluV29ybGRFdmFsKFwiRVZBTF9DT09LSUVCT1RfNFwiKTtcbiAgICByZXR1cm4gcmVzO1xuICB9XG4gIGFzeW5jIG9wdEluKCkge1xuICAgIGlmICh0aGlzLmVsZW1lbnRFeGlzdHMoXCIjZHRjb29raWUtY29udGFpbmVyXCIpKSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5jbGljayhcIi5oLWR0Y29va2llLWFjY2VwdFwiKTtcbiAgICB9XG4gICAgYXdhaXQgdGhpcy5jbGljayhcIi5DeWJvdENvb2tpZWJvdERpYWxvZ0JvZHlMZXZlbEJ1dHRvbjpub3QoOmNoZWNrZWQpOmVuYWJsZWRcIiwgdHJ1ZSk7XG4gICAgYXdhaXQgdGhpcy5jbGljayhcIiNDeWJvdENvb2tpZWJvdERpYWxvZ0JvZHlMZXZlbEJ1dHRvbkFjY2VwdFwiKTtcbiAgICBhd2FpdCB0aGlzLmNsaWNrKFwiI0N5Ym90Q29va2llYm90RGlhbG9nQm9keUJ1dHRvbkFjY2VwdFwiKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBhc3luYyB0ZXN0KCkge1xuICAgIGF3YWl0IHRoaXMud2FpdCg1MDApO1xuICAgIHJldHVybiBhd2FpdCB0aGlzLm1haW5Xb3JsZEV2YWwoXCJFVkFMX0NPT0tJRUJPVF81XCIpO1xuICB9XG59O1xuXG4vLyBsaWIvY21wcy9zb3VyY2Vwb2ludC1mcmFtZS50c1xudmFyIFNvdXJjZVBvaW50ID0gY2xhc3MgZXh0ZW5kcyBBdXRvQ29uc2VudENNUEJhc2Uge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgIHRoaXMubmFtZSA9IFwiU291cmNlcG9pbnQtZnJhbWVcIjtcbiAgICB0aGlzLnByZWhpZGVTZWxlY3RvcnMgPSBbXCJkaXZbaWRePSdzcF9tZXNzYWdlX2NvbnRhaW5lcl8nXSwubWVzc2FnZS1vdmVybGF5XCIsIFwiI3NwX3ByaXZhY3lfbWFuYWdlcl9jb250YWluZXJcIl07XG4gICAgdGhpcy5jY3BhTm90aWNlID0gZmFsc2U7XG4gICAgdGhpcy5jY3BhUG9wdXAgPSBmYWxzZTtcbiAgICB0aGlzLnJ1bkNvbnRleHQgPSB7XG4gICAgICBtYWluOiB0cnVlLFxuICAgICAgZnJhbWU6IHRydWVcbiAgICB9O1xuICB9XG4gIGdldCBoYXNTZWxmVGVzdCgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZ2V0IGlzSW50ZXJtZWRpYXRlKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBnZXQgaXNDb3NtZXRpYygpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0Q21wKCkge1xuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwobG9jYXRpb24uaHJlZik7XG4gICAgaWYgKHVybC5zZWFyY2hQYXJhbXMuaGFzKFwibWVzc2FnZV9pZFwiKSAmJiB1cmwuaG9zdG5hbWUgPT09IFwiY2NwYS1ub3RpY2Uuc3AtcHJvZC5uZXRcIikge1xuICAgICAgdGhpcy5jY3BhTm90aWNlID0gdHJ1ZTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAodXJsLmhvc3RuYW1lID09PSBcImNjcGEtcG0uc3AtcHJvZC5uZXRcIikge1xuICAgICAgdGhpcy5jY3BhUG9wdXAgPSB0cnVlO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiAodXJsLnBhdGhuYW1lID09PSBcIi9pbmRleC5odG1sXCIgfHwgdXJsLnBhdGhuYW1lID09PSBcIi9wcml2YWN5LW1hbmFnZXIvaW5kZXguaHRtbFwiIHx8IHVybC5wYXRobmFtZSA9PT0gXCIvY2NwYV9wbS9pbmRleC5odG1sXCIgfHwgdXJsLnBhdGhuYW1lID09PSBcIi91c19wbS9pbmRleC5odG1sXCIpICYmICh1cmwuc2VhcmNoUGFyYW1zLmhhcyhcIm1lc3NhZ2VfaWRcIikgfHwgdXJsLnNlYXJjaFBhcmFtcy5oYXMoXCJyZXF1ZXN0VVVJRFwiKSB8fCB1cmwuc2VhcmNoUGFyYW1zLmhhcyhcImNvbnNlbnRVVUlEXCIpKTtcbiAgfVxuICBhc3luYyBkZXRlY3RQb3B1cCgpIHtcbiAgICBpZiAodGhpcy5jY3BhTm90aWNlKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHRoaXMuY2NwYVBvcHVwKSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy53YWl0Rm9yRWxlbWVudChcIi5wcml2LXNhdmUtYnRuXCIsIDJlMyk7XG4gICAgfVxuICAgIGF3YWl0IHRoaXMud2FpdEZvckVsZW1lbnQoXG4gICAgICBcIi5zcF9jaG9pY2VfdHlwZV8xMSwuc3BfY2hvaWNlX3R5cGVfMTIsLnNwX2Nob2ljZV90eXBlXzEzLC5zcF9jaG9pY2VfdHlwZV9BQ0NFUFRfQUxMLC5zcF9jaG9pY2VfdHlwZV9TQVZFX0FORF9FWElUXCIsXG4gICAgICAyZTNcbiAgICApO1xuICAgIHJldHVybiAhdGhpcy5lbGVtZW50RXhpc3RzKFwiLnNwX2Nob2ljZV90eXBlXzlcIik7XG4gIH1cbiAgYXN5bmMgb3B0SW4oKSB7XG4gICAgYXdhaXQgdGhpcy53YWl0Rm9yRWxlbWVudChcIi5zcF9jaG9pY2VfdHlwZV8xMSwuc3BfY2hvaWNlX3R5cGVfQUNDRVBUX0FMTFwiLCAyZTMpO1xuICAgIGlmIChhd2FpdCB0aGlzLmNsaWNrKFwiLnNwX2Nob2ljZV90eXBlXzExXCIpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKGF3YWl0IHRoaXMuY2xpY2soXCIuc3BfY2hvaWNlX3R5cGVfQUNDRVBUX0FMTFwiKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpc01hbmFnZXJPcGVuKCkge1xuICAgIHJldHVybiBsb2NhdGlvbi5wYXRobmFtZSA9PT0gXCIvcHJpdmFjeS1tYW5hZ2VyL2luZGV4Lmh0bWxcIiB8fCBsb2NhdGlvbi5wYXRobmFtZSA9PT0gXCIvY2NwYV9wbS9pbmRleC5odG1sXCI7XG4gIH1cbiAgYXN5bmMgb3B0T3V0KCkge1xuICAgIGF3YWl0IHRoaXMud2FpdCg1MDApO1xuICAgIGNvbnN0IGxvZ3NDb25maWcgPSB0aGlzLmF1dG9jb25zZW50LmNvbmZpZy5sb2dzO1xuICAgIGlmICh0aGlzLmNjcGFQb3B1cCkge1xuICAgICAgY29uc3QgdG9nZ2xlcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXG4gICAgICAgIFwiLnByaXYtcHVycG9zZS1jb250YWluZXIgLnNwLXN3aXRjaC1hcnJvdy1ibG9jayBhLm5ldXRyYWwub24gLnJpZ2h0XCJcbiAgICAgICk7XG4gICAgICBmb3IgKGNvbnN0IHQgb2YgdG9nZ2xlcykge1xuICAgICAgICB0LmNsaWNrKCk7XG4gICAgICB9XG4gICAgICBjb25zdCBzd2l0Y2hlcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXG4gICAgICAgIFwiLnByaXYtcHVycG9zZS1jb250YWluZXIgLnNwLXN3aXRjaC1hcnJvdy1ibG9jayBhLnN3aXRjaC1iZy5vblwiXG4gICAgICApO1xuICAgICAgZm9yIChjb25zdCB0IG9mIHN3aXRjaGVzKSB7XG4gICAgICAgIHQuY2xpY2soKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKFwiLnByaXYtc2F2ZS1idG5cIik7XG4gICAgfVxuICAgIGlmICh0aGlzLmVsZW1lbnRWaXNpYmxlKFwiLnNwX2Nob2ljZV90eXBlX1NFXCIsIFwiYW55XCIpKSB7XG4gICAgICBhd2FpdCB0aGlzLmNsaWNrKFxuICAgICAgICBbXG4gICAgICAgICAgXCJ4cGF0aC8vL2Rpdltjb250YWlucyguLCAnRG8gbm90IHNoYXJlIG15IHBlcnNvbmFsIGluZm9ybWF0aW9uJykgYW5kIGNvbnRhaW5zKEBjbGFzcywgJ3N3aXRjaC1jb250YWluZXInKV1cIixcbiAgICAgICAgICBcIi5wbS1zd2l0Y2hbYXJpYS1jaGVja2VkPWZhbHNlXSAuc2xpZGVyXCJcbiAgICAgICAgXSxcbiAgICAgICAgZmFsc2VcbiAgICAgICk7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5jbGljayhcIi5zcF9jaG9pY2VfdHlwZV9TRVwiKTtcbiAgICB9XG4gICAgaWYgKCF0aGlzLmlzTWFuYWdlck9wZW4oKSkge1xuICAgICAgY29uc3QgYWN0aW9uYWJsZSA9IGF3YWl0IHRoaXMud2FpdEZvclZpc2libGUoJy5zcF9jaG9pY2VfdHlwZV8xMiwuc3BfY2hvaWNlX3R5cGVfMTMsW2RhdGEtY2hvaWNlPVwiMTczOTk2ODUwODc5OVwiXScpO1xuICAgICAgaWYgKCFhY3Rpb25hYmxlKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGlmICghdGhpcy5lbGVtZW50RXhpc3RzKCcuc3BfY2hvaWNlX3R5cGVfMTIsW2RhdGEtY2hvaWNlPVwiMTczOTk2ODUwODc5OVwiXScpKSB7XG4gICAgICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKFwiLnNwX2Nob2ljZV90eXBlXzEzXCIpO1xuICAgICAgfVxuICAgICAgYXdhaXQgdGhpcy5jbGljaygnLnNwX2Nob2ljZV90eXBlXzEyLFtkYXRhLWNob2ljZT1cIjE3Mzk5Njg1MDg3OTlcIl0nKTtcbiAgICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gdGhpcy5pc01hbmFnZXJPcGVuKCksIDIwMCwgMTAwKTtcbiAgICB9XG4gICAgYXdhaXQgdGhpcy53YWl0Rm9yRWxlbWVudChcIi50eXBlLW1vZGFsXCIsIDJlNCk7XG4gICAgaWYgKHRoaXMuZWxlbWVudEV4aXN0cyhcIltyb2xlPXRhYmxpc3RdXCIpKSB7XG4gICAgICBhd2FpdCB0aGlzLndhaXRGb3JFbGVtZW50KFwiW3JvbGU9dGFibGlzdF0gW3JvbGU9dGFiXVwiLCAxZTQpO1xuICAgIH1cbiAgICB0aGlzLndhaXRGb3JUaGVuQ2xpY2soXCIuY2NwYS1zdGFjayAucG0tc3dpdGNoW2FyaWEtY2hlY2tlZD10cnVlXSAuc2xpZGVyXCIsIDUwMCwgdHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlamVjdFNlbGVjdG9yMSA9IFwiLnNwX2Nob2ljZV90eXBlX1JFSkVDVF9BTExcIjtcbiAgICAgIGNvbnN0IHJlamVjdFNlbGVjdG9yMiA9IFwiLnJlamVjdC10b2dnbGVcIjtcbiAgICAgIGNvbnN0IHBhdGggPSBhd2FpdCBQcm9taXNlLnJhY2UoW1xuICAgICAgICB0aGlzLndhaXRGb3JFbGVtZW50KHJlamVjdFNlbGVjdG9yMSwgMmUzKS50aGVuKChzdWNjZXNzKSA9PiBzdWNjZXNzID8gMCA6IC0xKSxcbiAgICAgICAgdGhpcy53YWl0Rm9yRWxlbWVudChyZWplY3RTZWxlY3RvcjIsIDJlMykudGhlbigoc3VjY2VzcykgPT4gc3VjY2VzcyA/IDEgOiAtMSksXG4gICAgICAgIHRoaXMud2FpdEZvckVsZW1lbnQoXCIucG0tZmVhdHVyZXNcIiwgMmUzKS50aGVuKChzdWNjZXNzKSA9PiBzdWNjZXNzID8gMiA6IC0xKVxuICAgICAgXSk7XG4gICAgICBpZiAocGF0aCA9PT0gMCkge1xuICAgICAgICBhd2FpdCB0aGlzLndhaXRGb3JWaXNpYmxlKHJlamVjdFNlbGVjdG9yMSk7XG4gICAgICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKHJlamVjdFNlbGVjdG9yMSk7XG4gICAgICB9IGVsc2UgaWYgKHBhdGggPT09IDEpIHtcbiAgICAgICAgYXdhaXQgdGhpcy5jbGljayhyZWplY3RTZWxlY3RvcjIpO1xuICAgICAgfSBlbHNlIGlmIChwYXRoID09PSAyKSB7XG4gICAgICAgIGF3YWl0IHRoaXMud2FpdEZvckVsZW1lbnQoXCIucG0tZmVhdHVyZXNcIiwgMWU0KTtcbiAgICAgICAgYXdhaXQgdGhpcy5jbGljayhcIi5jaGVja2VkID4gc3BhblwiLCB0cnVlKTtcbiAgICAgICAgYXdhaXQgdGhpcy5jbGljayhcIi5jaGV2cm9uXCIpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGxvZ3NDb25maWcuZXJyb3JzICYmIGNvbnNvbGUud2FybihlKTtcbiAgICB9XG4gICAgcmV0dXJuIGF3YWl0IHRoaXMuY2xpY2soXCIuc3BfY2hvaWNlX3R5cGVfU0FWRV9BTkRfRVhJVFwiKTtcbiAgfVxufTtcblxuLy8gbGliL2NtcHMvY29uc2VudG1hbmFnZXIudHNcbnZhciBDb25zZW50TWFuYWdlciA9IGNsYXNzIGV4dGVuZHMgQXV0b0NvbnNlbnRDTVBCYXNlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICB0aGlzLm5hbWUgPSBcImNvbnNlbnRtYW5hZ2VyLm5ldFwiO1xuICAgIHRoaXMucHJlaGlkZVNlbGVjdG9ycyA9IFtcIiNjbXBib3gsI2NtcGJveDJcIl07XG4gICAgdGhpcy5hcGlBdmFpbGFibGUgPSBmYWxzZTtcbiAgfVxuICBnZXQgaGFzU2VsZlRlc3QoKSB7XG4gICAgcmV0dXJuIHRoaXMuYXBpQXZhaWxhYmxlO1xuICB9XG4gIGdldCBpc0ludGVybWVkaWF0ZSgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZ2V0IGlzQ29zbWV0aWMoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGFzeW5jIGRldGVjdENtcCgpIHtcbiAgICB0aGlzLmFwaUF2YWlsYWJsZSA9IGF3YWl0IHRoaXMubWFpbldvcmxkRXZhbChcIkVWQUxfQ09OU0VOVE1BTkFHRVJfMVwiKTtcbiAgICBpZiAoIXRoaXMuYXBpQXZhaWxhYmxlKSB7XG4gICAgICByZXR1cm4gdGhpcy5lbGVtZW50RXhpc3RzKFwiI2NtcGJveFwiKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9XG4gIGFzeW5jIGRldGVjdFBvcHVwKCkge1xuICAgIGlmICh0aGlzLmFwaUF2YWlsYWJsZSkge1xuICAgICAgYXdhaXQgdGhpcy53YWl0KDUwMCk7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5tYWluV29ybGRFdmFsKFwiRVZBTF9DT05TRU5UTUFOQUdFUl8yXCIpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5lbGVtZW50VmlzaWJsZShcIiNjbXBib3ggLmNtcG1vcmVcIiwgXCJhbnlcIik7XG4gIH1cbiAgYXN5bmMgb3B0T3V0KCkge1xuICAgIGF3YWl0IHRoaXMud2FpdCg1MDApO1xuICAgIGlmICh0aGlzLmFwaUF2YWlsYWJsZSkge1xuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubWFpbldvcmxkRXZhbChcIkVWQUxfQ09OU0VOVE1BTkFHRVJfM1wiKTtcbiAgICB9XG4gICAgaWYgKGF3YWl0IHRoaXMuY2xpY2soXCIuY21wYm94YnRubm9cIikpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAodGhpcy5lbGVtZW50RXhpc3RzKFwiLmNtcHdlbGNvbWVwcnBzYnRuXCIpKSB7XG4gICAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLmNtcHdlbGNvbWVwcnBzYnRuID4gYVthcmlhLWNoZWNrZWQ9dHJ1ZV1cIiwgdHJ1ZSk7XG4gICAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLmNtcGJveGJ0bnNhdmVcIik7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgYXdhaXQgdGhpcy5jbGljayhcIi5jbXBib3hidG5jdXN0b21cIik7XG4gICAgYXdhaXQgdGhpcy53YWl0Rm9yRWxlbWVudChcIi5jbXB0Ymxib3hcIiwgMmUzKTtcbiAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLmNtcHRkY2hvaWNlID4gYVthcmlhLWNoZWNrZWQ9dHJ1ZV1cIiwgdHJ1ZSk7XG4gICAgYXdhaXQgdGhpcy5jbGljayhcIi5jbXBib3hidG55ZXNjdXN0b21jaG9pY2VzXCIpO1xuICAgIHRoaXMuaGlkZShcIiNjbXB3cmFwcGVyLCNjbXBib3hcIiwgXCJkaXNwbGF5XCIpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIG9wdEluKCkge1xuICAgIGlmICh0aGlzLmFwaUF2YWlsYWJsZSkge1xuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubWFpbldvcmxkRXZhbChcIkVWQUxfQ09OU0VOVE1BTkFHRVJfNFwiKTtcbiAgICB9XG4gICAgcmV0dXJuIGF3YWl0IHRoaXMuY2xpY2soXCIuY21wYm94YnRueWVzXCIpO1xuICB9XG4gIGFzeW5jIHRlc3QoKSB7XG4gICAgaWYgKHRoaXMuYXBpQXZhaWxhYmxlKSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5tYWluV29ybGRFdmFsKFwiRVZBTF9DT05TRU5UTUFOQUdFUl81XCIpO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn07XG5cbi8vIGxpYi9jbXBzL2V2aWRvbi50c1xudmFyIEV2aWRvbiA9IGNsYXNzIGV4dGVuZHMgQXV0b0NvbnNlbnRDTVBCYXNlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICB0aGlzLm5hbWUgPSBcIkV2aWRvblwiO1xuICB9XG4gIGdldCBoYXNTZWxmVGVzdCgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZ2V0IGlzSW50ZXJtZWRpYXRlKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBnZXQgaXNDb3NtZXRpYygpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0Q21wKCkge1xuICAgIHJldHVybiB0aGlzLmVsZW1lbnRFeGlzdHMoXCIjX2V2aWRvbl9iYW5uZXJcIik7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0UG9wdXAoKSB7XG4gICAgcmV0dXJuIHRoaXMuZWxlbWVudFZpc2libGUoXCIjX2V2aWRvbl9iYW5uZXJcIiwgXCJhbnlcIik7XG4gIH1cbiAgYXN5bmMgb3B0T3V0KCkge1xuICAgIGlmIChhd2FpdCB0aGlzLmNsaWNrKFwiI19ldmlkb24tZGVjbGluZS1idXR0b25cIikpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBoaWRlRWxlbWVudHMoZ2V0U3R5bGVFbGVtZW50KCksIFwiI2V2aWRvbi1wcmVmZGlhZy1vdmVybGF5LCNldmlkb24tcHJlZmRpYWctYmFja2dyb3VuZCwjX2V2aWRvbi1iYWNrZ3JvdW5kXCIpO1xuICAgIGF3YWl0IHRoaXMud2FpdEZvclRoZW5DbGljayhcIiNfZXZpZG9uLW9wdGlvbi1idXR0b25cIik7XG4gICAgYXdhaXQgdGhpcy53YWl0Rm9yRWxlbWVudChcIiNldmlkb24tcHJlZmRpYWctb3ZlcmxheVwiLCA1ZTMpO1xuICAgIGF3YWl0IHRoaXMud2FpdCg1MDApO1xuICAgIGF3YWl0IHRoaXMud2FpdEZvclRoZW5DbGljayhcIiNldmlkb24tcHJlZmRpYWctZGVjbGluZVwiKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBhc3luYyBvcHRJbigpIHtcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5jbGljayhcIiNfZXZpZG9uLWFjY2VwdC1idXR0b25cIik7XG4gIH1cbn07XG5cbi8vIGxpYi9jbXBzL29uZXRydXN0LnRzXG52YXIgT25ldHJ1c3QgPSBjbGFzcyBleHRlbmRzIEF1dG9Db25zZW50Q01QQmFzZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgdGhpcy5uYW1lID0gXCJPbmV0cnVzdFwiO1xuICAgIHRoaXMucHJlaGlkZVNlbGVjdG9ycyA9IFtcIiNvbmV0cnVzdC1iYW5uZXItc2RrLCNvbmV0cnVzdC1jb25zZW50LXNkaywub25ldHJ1c3QtcGMtZGFyay1maWx0ZXIsLmpzLWNvbnNlbnQtYmFubmVyXCJdO1xuICB9XG4gIGdldCBoYXNTZWxmVGVzdCgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBnZXQgaXNJbnRlcm1lZGlhdGUoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGdldCBpc0Nvc21ldGljKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBhc3luYyBkZXRlY3RDbXAoKSB7XG4gICAgcmV0dXJuIHRoaXMuZWxlbWVudEV4aXN0cyhcIiNvbmV0cnVzdC1iYW5uZXItc2RrLCNvbmV0cnVzdC1wYy1zZGtcIik7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0UG9wdXAoKSB7XG4gICAgcmV0dXJuIHRoaXMuZWxlbWVudFZpc2libGUoXCIjb25ldHJ1c3QtYmFubmVyLXNkaywjb25ldHJ1c3QtcGMtc2RrXCIsIFwiYW55XCIpO1xuICB9XG4gIGFzeW5jIG9wdE91dCgpIHtcbiAgICBpZiAodGhpcy5lbGVtZW50VmlzaWJsZShcIiNvbmV0cnVzdC1yZWplY3QtYWxsLWhhbmRsZXIsLm90LXBjLXJlZnVzZS1hbGwtaGFuZGxlciwuanMtcmVqZWN0LWNvb2tpZXNcIiwgXCJhbnlcIikpIHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKFwiI29uZXRydXN0LXJlamVjdC1hbGwtaGFuZGxlciwub3QtcGMtcmVmdXNlLWFsbC1oYW5kbGVyLC5qcy1yZWplY3QtY29va2llc1wiKTtcbiAgICB9XG4gICAgaWYgKHRoaXMuZWxlbWVudEV4aXN0cyhcIiNvbmV0cnVzdC1wYy1idG4taGFuZGxlclwiKSkge1xuICAgICAgYXdhaXQgdGhpcy5jbGljayhcIiNvbmV0cnVzdC1wYy1idG4taGFuZGxlclwiKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgdGhpcy5jbGljayhcIi5vdC1zZGstc2hvdy1zZXR0aW5ncyxidXR0b24uanMtY29va2llLXNldHRpbmdzXCIpO1xuICAgIH1cbiAgICBhd2FpdCB0aGlzLndhaXRGb3JFbGVtZW50KFwiI29uZXRydXN0LWNvbnNlbnQtc2RrXCIsIDJlMyk7XG4gICAgYXdhaXQgdGhpcy53YWl0KDFlMyk7XG4gICAgYXdhaXQgdGhpcy5jbGljayhcIiNvbmV0cnVzdC1jb25zZW50LXNkayBpbnB1dC5jYXRlZ29yeS1zd2l0Y2gtaGFuZGxlcjpjaGVja2VkLC5qcy1lZGl0b3ItdG9nZ2xlLXN0YXRlOmNoZWNrZWRcIiwgdHJ1ZSk7XG4gICAgYXdhaXQgdGhpcy53YWl0KDFlMyk7XG4gICAgYXdhaXQgdGhpcy53YWl0Rm9yRWxlbWVudChcIi5zYXZlLXByZWZlcmVuY2UtYnRuLWhhbmRsZXIsLmpzLWNvbnNlbnQtc2F2ZVwiLCAyZTMpO1xuICAgIGF3YWl0IHRoaXMuY2xpY2soXCIuc2F2ZS1wcmVmZXJlbmNlLWJ0bi1oYW5kbGVyLC5qcy1jb25zZW50LXNhdmVcIik7XG4gICAgYXdhaXQgdGhpcy53YWl0Rm9yVmlzaWJsZShcIiNvbmV0cnVzdC1iYW5uZXItc2RrXCIsIDVlMywgXCJub25lXCIpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIG9wdEluKCkge1xuICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKFwiI29uZXRydXN0LWFjY2VwdC1idG4taGFuZGxlciwjYWNjZXB0LXJlY29tbWVuZGVkLWJ0bi1oYW5kbGVyLC5qcy1hY2NlcHQtY29va2llc1wiKTtcbiAgfVxuICBhc3luYyB0ZXN0KCkge1xuICAgIHJldHVybiBhd2FpdCB3YWl0Rm9yKCgpID0+IHRoaXMubWFpbldvcmxkRXZhbChcIkVWQUxfT05FVFJVU1RfMVwiKSwgMTAsIDUwMCk7XG4gIH1cbn07XG5cbi8vIGxpYi9jbXBzL2tsYXJvLnRzXG52YXIgS2xhcm8gPSBjbGFzcyBleHRlbmRzIEF1dG9Db25zZW50Q01QQmFzZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgdGhpcy5uYW1lID0gXCJLbGFyb1wiO1xuICAgIHRoaXMucHJlaGlkZVNlbGVjdG9ycyA9IFtcIi5rbGFyb1wiXTtcbiAgICB0aGlzLnNldHRpbmdzT3BlbiA9IGZhbHNlO1xuICB9XG4gIGdldCBoYXNTZWxmVGVzdCgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBnZXQgaXNJbnRlcm1lZGlhdGUoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGdldCBpc0Nvc21ldGljKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBhc3luYyBkZXRlY3RDbXAoKSB7XG4gICAgaWYgKHRoaXMuZWxlbWVudEV4aXN0cyhcIi5rbGFybyA+IC5jb29raWUtbW9kYWxcIikpIHtcbiAgICAgIHRoaXMuc2V0dGluZ3NPcGVuID0gdHJ1ZTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5lbGVtZW50RXhpc3RzKFwiLmtsYXJvID4gLmNvb2tpZS1ub3RpY2VcIik7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0UG9wdXAoKSB7XG4gICAgcmV0dXJuIHRoaXMuZWxlbWVudFZpc2libGUoXCIua2xhcm8gPiAuY29va2llLW5vdGljZSwua2xhcm8gPiAuY29va2llLW1vZGFsXCIsIFwiYW55XCIpO1xuICB9XG4gIGFzeW5jIG9wdE91dCgpIHtcbiAgICBjb25zdCBhcGlPcHRPdXRTdWNjZXNzID0gYXdhaXQgdGhpcy5tYWluV29ybGRFdmFsKFwiRVZBTF9LTEFST19UUllfQVBJX09QVF9PVVRcIik7XG4gICAgaWYgKGFwaU9wdE91dFN1Y2Nlc3MpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoYXdhaXQgdGhpcy5jbGljayhcIi5rbGFybyAuY24tZGVjbGluZVwiKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGF3YWl0IHRoaXMubWFpbldvcmxkRXZhbChcIkVWQUxfS0xBUk9fT1BFTl9QT1BVUFwiKTtcbiAgICBpZiAoYXdhaXQgdGhpcy5jbGljayhcIi5rbGFybyAuY24tZGVjbGluZVwiKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGF3YWl0IHRoaXMuY2xpY2soXG4gICAgICBcIi5jbS1wdXJwb3NlOm5vdCguY20tdG9nZ2xlLWFsbCkgPiBpbnB1dDpub3QoLmhhbGYtY2hlY2tlZCwucmVxdWlyZWQsLm9ubHktcmVxdWlyZWQpLC5jbS1wdXJwb3NlOm5vdCguY20tdG9nZ2xlLWFsbCkgPiBkaXYgPiBpbnB1dDpub3QoLmhhbGYtY2hlY2tlZCwucmVxdWlyZWQsLm9ubHktcmVxdWlyZWQpXCIsXG4gICAgICB0cnVlXG4gICAgKTtcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5jbGljayhcIi5jbS1idG4tYWNjZXB0LC5jbS1idXR0b25cIik7XG4gIH1cbiAgYXN5bmMgb3B0SW4oKSB7XG4gICAgaWYgKGF3YWl0IHRoaXMuY2xpY2soXCIua2xhcm8gLmNtLWJ0bi1hY2NlcHQtYWxsXCIpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHRoaXMuc2V0dGluZ3NPcGVuKSB7XG4gICAgICBhd2FpdCB0aGlzLmNsaWNrKFwiLmNtLXB1cnBvc2U6bm90KC5jbS10b2dnbGUtYWxsKSA+IGlucHV0LmhhbGYtY2hlY2tlZFwiLCB0cnVlKTtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKFwiLmNtLWJ0bi1hY2NlcHRcIik7XG4gICAgfVxuICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKFwiLmtsYXJvIC5jb29raWUtbm90aWNlIC5jbS1idG4tc3VjY2Vzc1wiKTtcbiAgfVxuICBhc3luYyB0ZXN0KCkge1xuICAgIHJldHVybiBhd2FpdCB0aGlzLm1haW5Xb3JsZEV2YWwoXCJFVkFMX0tMQVJPXzFcIik7XG4gIH1cbn07XG5cbi8vIGxpYi9jbXBzL3VuaWNvbnNlbnQudHNcbnZhciBVbmljb25zZW50ID0gY2xhc3MgZXh0ZW5kcyBBdXRvQ29uc2VudENNUEJhc2Uge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgIHRoaXMubmFtZSA9IFwiVW5pY29uc2VudFwiO1xuICB9XG4gIGdldCBwcmVoaWRlU2VsZWN0b3JzKCkge1xuICAgIHJldHVybiBbXCIudW5pY1wiLCBcIi5tb2RhbDpoYXMoLnVuaWMpXCJdO1xuICB9XG4gIGdldCBoYXNTZWxmVGVzdCgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBnZXQgaXNJbnRlcm1lZGlhdGUoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGdldCBpc0Nvc21ldGljKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBhc3luYyBkZXRlY3RDbXAoKSB7XG4gICAgcmV0dXJuIHRoaXMuZWxlbWVudEV4aXN0cyhcIi51bmljIC51bmljLWJveCwudW5pYyAudW5pYy1iYXIsLnVuaWMgLnVuaWMtbW9kYWxcIik7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0UG9wdXAoKSB7XG4gICAgcmV0dXJuIHRoaXMuZWxlbWVudFZpc2libGUoXCIudW5pYyAudW5pYy1ib3gsLnVuaWMgLnVuaWMtYmFyLC51bmljIC51bmljLW1vZGFsXCIsIFwiYW55XCIpO1xuICB9XG4gIGFzeW5jIG9wdE91dCgpIHtcbiAgICBhd2FpdCB0aGlzLndhaXRGb3JFbGVtZW50KFwiLnVuaWMgYnV0dG9uXCIsIDFlMyk7XG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi51bmljIGJ1dHRvblwiKS5mb3JFYWNoKChidXR0b24pID0+IHtcbiAgICAgIGNvbnN0IHRleHQgPSBidXR0b24udGV4dENvbnRlbnQ7XG4gICAgICBpZiAodGV4dC5pbmNsdWRlcyhcIk1hbmFnZSBPcHRpb25zXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJPcHRpb25lbiB2ZXJ3YWx0ZW5cIikpIHtcbiAgICAgICAgYnV0dG9uLmNsaWNrKCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgaWYgKGF3YWl0IHRoaXMud2FpdEZvckVsZW1lbnQoXCIudW5pYyBpbnB1dFt0eXBlPWNoZWNrYm94XVwiLCAxZTMpKSB7XG4gICAgICBhd2FpdCB0aGlzLndhaXRGb3JFbGVtZW50KFwiLnVuaWMgYnV0dG9uXCIsIDFlMyk7XG4gICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLnVuaWMgaW5wdXRbdHlwZT1jaGVja2JveF1cIikuZm9yRWFjaCgoYykgPT4ge1xuICAgICAgICBpZiAoYy5jaGVja2VkKSB7XG4gICAgICAgICAgYy5jbGljaygpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGZvciAoY29uc3QgYiBvZiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLnVuaWMgYnV0dG9uXCIpKSB7XG4gICAgICAgIGNvbnN0IHRleHQgPSBiLnRleHRDb250ZW50O1xuICAgICAgICBmb3IgKGNvbnN0IHBhdHRlcm4gb2YgW1wiQ29uZmlybSBDaG9pY2VzXCIsIFwiU2F2ZSBDaG9pY2VzXCIsIFwiQXVzd2FobCBzcGVpY2hlcm5cIl0pIHtcbiAgICAgICAgICBpZiAodGV4dC5pbmNsdWRlcyhwYXR0ZXJuKSkge1xuICAgICAgICAgICAgYi5jbGljaygpO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy53YWl0KDUwMCk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGFzeW5jIG9wdEluKCkge1xuICAgIHJldHVybiB0aGlzLndhaXRGb3JUaGVuQ2xpY2soXCIudW5pYyAjdW5pYy1hZ3JlZVwiKTtcbiAgfVxuICBhc3luYyB0ZXN0KCkge1xuICAgIGF3YWl0IHRoaXMud2FpdCgxZTMpO1xuICAgIGNvbnN0IHJlcyA9IHRoaXMuZWxlbWVudEV4aXN0cyhcIi51bmljIC51bmljLWJveCwudW5pYyAudW5pYy1iYXJcIik7XG4gICAgcmV0dXJuICFyZXM7XG4gIH1cbn07XG5cbi8vIGxpYi9jbXBzL2NvbnZlcnNhbnQudHNcbnZhciBDb252ZXJzYW50ID0gY2xhc3MgZXh0ZW5kcyBBdXRvQ29uc2VudENNUEJhc2Uge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgIHRoaXMucHJlaGlkZVNlbGVjdG9ycyA9IFtcIi5jbXAtcm9vdFwiXTtcbiAgICB0aGlzLm5hbWUgPSBcIkNvbnZlcnNhbnRcIjtcbiAgfVxuICBnZXQgaGFzU2VsZlRlc3QoKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgZ2V0IGlzSW50ZXJtZWRpYXRlKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBnZXQgaXNDb3NtZXRpYygpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0Q21wKCkge1xuICAgIHJldHVybiB0aGlzLmVsZW1lbnRFeGlzdHMoXCIuY21wLXJvb3QgLmNtcC1yZWNlcHRhY2xlXCIpO1xuICB9XG4gIGFzeW5jIGRldGVjdFBvcHVwKCkge1xuICAgIHJldHVybiB0aGlzLmVsZW1lbnRWaXNpYmxlKFwiLmNtcC1yb290IC5jbXAtcmVjZXB0YWNsZVwiLCBcImFueVwiKTtcbiAgfVxuICBhc3luYyBvcHRPdXQoKSB7XG4gICAgaWYgKCFhd2FpdCB0aGlzLndhaXRGb3JUaGVuQ2xpY2soXCIuY21wLW1haW4tYnV0dG9uOm5vdCguY21wLW1haW4tYnV0dG9uLS1wcmltYXJ5KVwiKSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAoIWF3YWl0IHRoaXMud2FpdEZvckVsZW1lbnQoXCIuY21wLXZpZXctdGFiLXRhYnNcIikpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgYXdhaXQgdGhpcy53YWl0Rm9yVGhlbkNsaWNrKFwiLmNtcC12aWV3LXRhYi10YWJzID4gOmZpcnN0LWNoaWxkXCIpO1xuICAgIGF3YWl0IHRoaXMud2FpdEZvclRoZW5DbGljayhcIi5jbXAtdmlldy10YWItdGFicyA+IC5jbXAtdmlldy10YWItLWFjdGl2ZTpmaXJzdC1jaGlsZFwiKTtcbiAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLmNtcC1hY2NvcmRpb24taXRlbVwiKSkpIHtcbiAgICAgIGl0ZW0ucXVlcnlTZWxlY3RvcihcIi5jbXAtYWNjb3JkaW9uLWl0ZW0tdGl0bGVcIikuY2xpY2soKTtcbiAgICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gISFpdGVtLnF1ZXJ5U2VsZWN0b3IoXCIuY21wLWFjY29yZGlvbi1pdGVtLWNvbnRlbnQuY21wLWFjdGl2ZVwiKSwgMTAsIDUwKTtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSBpdGVtLnF1ZXJ5U2VsZWN0b3IoXCIuY21wLWFjY29yZGlvbi1pdGVtLWNvbnRlbnQuY21wLWFjdGl2ZVwiKTtcbiAgICAgIGNvbnRlbnQucXVlcnlTZWxlY3RvckFsbChcIi5jbXAtdG9nZ2xlLWFjdGlvbnMgLmNtcC10b2dnbGUtZGVueTpub3QoLmNtcC10b2dnbGUtZGVueS0tYWN0aXZlKVwiKS5mb3JFYWNoKChlKSA9PiBlLmNsaWNrKCkpO1xuICAgICAgY29udGVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLmNtcC10b2dnbGUtYWN0aW9ucyAuY21wLXRvZ2dsZS1jaGVja2JveDpub3QoLmNtcC10b2dnbGUtY2hlY2tib3gtLWFjdGl2ZSlcIikuZm9yRWFjaCgoZSkgPT4gZS5jbGljaygpKTtcbiAgICB9XG4gICAgYXdhaXQgdGhpcy5jbGljayhcIi5jbXAtbWFpbi1idXR0b246bm90KC5jbXAtbWFpbi1idXR0b24tLXByaW1hcnkpXCIpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIG9wdEluKCkge1xuICAgIHJldHVybiB0aGlzLndhaXRGb3JUaGVuQ2xpY2soXCIuY21wLW1haW4tYnV0dG9uLmNtcC1tYWluLWJ1dHRvbi0tcHJpbWFyeVwiKTtcbiAgfVxuICBhc3luYyB0ZXN0KCkge1xuICAgIHJldHVybiBkb2N1bWVudC5jb29raWUuaW5jbHVkZXMoXCJjbXAtZGF0YT0wXCIpO1xuICB9XG59O1xuXG4vLyBsaWIvY21wcy90aWt0b2sudHNcbnZhciBUaWt0b2sgPSBjbGFzcyBleHRlbmRzIEF1dG9Db25zZW50Q01QQmFzZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgdGhpcy5uYW1lID0gXCJ0aWt0b2suY29tXCI7XG4gICAgdGhpcy5ydW5Db250ZXh0ID0ge1xuICAgICAgdXJsUGF0dGVybjogXCJ0aWt0b2tcIlxuICAgIH07XG4gIH1cbiAgZ2V0IGhhc1NlbGZUZXN0KCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGdldCBpc0ludGVybWVkaWF0ZSgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZ2V0IGlzQ29zbWV0aWMoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGdldFNoYWRvd1Jvb3QoKSB7XG4gICAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcInRpa3Rvay1jb29raWUtYmFubmVyXCIpO1xuICAgIGlmICghY29udGFpbmVyKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIGNvbnRhaW5lci5zaGFkb3dSb290O1xuICB9XG4gIGFzeW5jIGRldGVjdENtcCgpIHtcbiAgICByZXR1cm4gdGhpcy5lbGVtZW50RXhpc3RzKFwidGlrdG9rLWNvb2tpZS1iYW5uZXJcIik7XG4gIH1cbiAgYXN5bmMgZGV0ZWN0UG9wdXAoKSB7XG4gICAgY29uc3QgYmFubmVyID0gdGhpcy5nZXRTaGFkb3dSb290KCk/LnF1ZXJ5U2VsZWN0b3IoXCIudGlrdG9rLWNvb2tpZS1iYW5uZXJcIik7XG4gICAgcmV0dXJuIGlzRWxlbWVudFZpc2libGUoYmFubmVyKTtcbiAgfVxuICBhc3luYyBvcHRPdXQoKSB7XG4gICAgY29uc3QgbG9nc0NvbmZpZyA9IHRoaXMuYXV0b2NvbnNlbnQuY29uZmlnLmxvZ3M7XG4gICAgY29uc3QgZGVjbGluZUJ1dHRvbiA9IHRoaXMuZ2V0U2hhZG93Um9vdCgpPy5xdWVyeVNlbGVjdG9yKFwiLmJ1dHRvbi13cmFwcGVyIGJ1dHRvbjpmaXJzdC1jaGlsZFwiKTtcbiAgICBpZiAoZGVjbGluZUJ1dHRvbikge1xuICAgICAgbG9nc0NvbmZpZy5ydWxlc3RlcHMgJiYgY29uc29sZS5sb2coXCJbY2xpY2tpbmddXCIsIGRlY2xpbmVCdXR0b24pO1xuICAgICAgZGVjbGluZUJ1dHRvbi5jbGljaygpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIGxvZ3NDb25maWcuZXJyb3JzICYmIGNvbnNvbGUubG9nKFwibm8gZGVjbGluZSBidXR0b24gZm91bmRcIik7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG4gIGFzeW5jIG9wdEluKCkge1xuICAgIGNvbnN0IGxvZ3NDb25maWcgPSB0aGlzLmF1dG9jb25zZW50LmNvbmZpZy5sb2dzO1xuICAgIGNvbnN0IGFjY2VwdEJ1dHRvbiA9IHRoaXMuZ2V0U2hhZG93Um9vdCgpPy5xdWVyeVNlbGVjdG9yKFwiLmJ1dHRvbi13cmFwcGVyIGJ1dHRvbjpsYXN0LWNoaWxkXCIpO1xuICAgIGlmIChhY2NlcHRCdXR0b24pIHtcbiAgICAgIGxvZ3NDb25maWcucnVsZXN0ZXBzICYmIGNvbnNvbGUubG9nKFwiW2NsaWNraW5nXVwiLCBhY2NlcHRCdXR0b24pO1xuICAgICAgYWNjZXB0QnV0dG9uLmNsaWNrKCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgbG9nc0NvbmZpZy5lcnJvcnMgJiYgY29uc29sZS5sb2coXCJubyBhY2NlcHQgYnV0dG9uIGZvdW5kXCIpO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuICBhc3luYyB0ZXN0KCkge1xuICAgIGNvbnN0IG1hdGNoID0gZG9jdW1lbnQuY29va2llLm1hdGNoKC9jb29raWUtY29uc2VudD0oW147XSspLyk7XG4gICAgaWYgKCFtYXRjaCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCB2YWx1ZSA9IEpTT04ucGFyc2UoZGVjb2RlVVJJQ29tcG9uZW50KG1hdGNoWzFdKSk7XG4gICAgcmV0dXJuIE9iamVjdC52YWx1ZXModmFsdWUpLmV2ZXJ5KCh4KSA9PiB0eXBlb2YgeCAhPT0gXCJib29sZWFuXCIgfHwgeCA9PT0gZmFsc2UpO1xuICB9XG59O1xuXG4vLyBsaWIvY21wcy90dW1ibHItY29tLnRzXG52YXIgVHVtYmxyID0gY2xhc3MgZXh0ZW5kcyBBdXRvQ29uc2VudENNUEJhc2Uge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgIHRoaXMubmFtZSA9IFwidHVtYmxyLWNvbVwiO1xuICAgIHRoaXMucnVuQ29udGV4dCA9IHtcbiAgICAgIHVybFBhdHRlcm46IFwiXmh0dHBzOi8vKHd3d1xcXFwuKT90dW1ibHJcXFxcLmNvbS9cIlxuICAgIH07XG4gIH1cbiAgZ2V0IGhhc1NlbGZUZXN0KCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBnZXQgaXNJbnRlcm1lZGlhdGUoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGdldCBpc0Nvc21ldGljKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBnZXQgcHJlaGlkZVNlbGVjdG9ycygpIHtcbiAgICByZXR1cm4gW1wiI2NtcC1hcHAtY29udGFpbmVyXCJdO1xuICB9XG4gIGFzeW5jIGRldGVjdENtcCgpIHtcbiAgICByZXR1cm4gdGhpcy5lbGVtZW50RXhpc3RzKFwiI2NtcC1hcHAtY29udGFpbmVyXCIpO1xuICB9XG4gIGFzeW5jIGRldGVjdFBvcHVwKCkge1xuICAgIHJldHVybiB0aGlzLmVsZW1lbnRWaXNpYmxlKFwiI2NtcC1hcHAtY29udGFpbmVyXCIsIFwiYW55XCIpO1xuICB9XG4gIGFzeW5jIG9wdE91dCgpIHtcbiAgICBsZXQgaWZyYW1lID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNjbXAtYXBwLWNvbnRhaW5lciBpZnJhbWVcIik7XG4gICAgbGV0IHNldHRpbmdzQnV0dG9uID0gaWZyYW1lLmNvbnRlbnREb2N1bWVudD8ucXVlcnlTZWxlY3RvcihcIi5jbXAtY29tcG9uZW50cy1idXR0b24uaXMtc2Vjb25kYXJ5XCIpO1xuICAgIGlmICghc2V0dGluZ3NCdXR0b24pIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgc2V0dGluZ3NCdXR0b24uY2xpY2soKTtcbiAgICBhd2FpdCB3YWl0Rm9yKFxuICAgICAgKCkgPT4ge1xuICAgICAgICBjb25zdCBpZnJhbWUyID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNjbXAtYXBwLWNvbnRhaW5lciBpZnJhbWVcIik7XG4gICAgICAgIHJldHVybiAhIWlmcmFtZTIuY29udGVudERvY3VtZW50Py5xdWVyeVNlbGVjdG9yKFwiLmNtcF9fZGlhbG9nIGlucHV0XCIpO1xuICAgICAgfSxcbiAgICAgIDUsXG4gICAgICA1MDBcbiAgICApO1xuICAgIGlmcmFtZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjY21wLWFwcC1jb250YWluZXIgaWZyYW1lXCIpO1xuICAgIHNldHRpbmdzQnV0dG9uID0gaWZyYW1lLmNvbnRlbnREb2N1bWVudD8ucXVlcnlTZWxlY3RvcihcIi5jbXAtY29tcG9uZW50cy1idXR0b24uaXMtc2Vjb25kYXJ5XCIpO1xuICAgIGlmICghc2V0dGluZ3NCdXR0b24pIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgc2V0dGluZ3NCdXR0b24uY2xpY2soKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBhc3luYyBvcHRJbigpIHtcbiAgICBjb25zdCBpZnJhbWUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2NtcC1hcHAtY29udGFpbmVyIGlmcmFtZVwiKTtcbiAgICBjb25zdCBhY2NlcHRCdXR0b24gPSBpZnJhbWUuY29udGVudERvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuY21wLWNvbXBvbmVudHMtYnV0dG9uLmlzLXByaW1hcnlcIik7XG4gICAgaWYgKGFjY2VwdEJ1dHRvbikge1xuICAgICAgYWNjZXB0QnV0dG9uLmNsaWNrKCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59O1xuXG4vLyBsaWIvY21wcy9hZG1pcmFsLnRzXG52YXIgQWRtaXJhbCA9IGNsYXNzIGV4dGVuZHMgQXV0b0NvbnNlbnRDTVBCYXNlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICB0aGlzLm5hbWUgPSBcIkFkbWlyYWxcIjtcbiAgfVxuICBnZXQgaGFzU2VsZlRlc3QoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGdldCBpc0ludGVybWVkaWF0ZSgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZ2V0IGlzQ29zbWV0aWMoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGFzeW5jIGRldGVjdENtcCgpIHtcbiAgICByZXR1cm4gdGhpcy5lbGVtZW50RXhpc3RzKFwiZGl2ID4gZGl2W2NsYXNzKj1DYXJkXSA+IGRpdltjbGFzcyo9RnJhbWVdID4gZGl2W2NsYXNzKj1QaWxsc10gPiBidXR0b25bY2xhc3MqPVBpbGxzX19TdHlsZWRQaWxsXVwiKTtcbiAgfVxuICBhc3luYyBkZXRlY3RQb3B1cCgpIHtcbiAgICByZXR1cm4gdGhpcy5lbGVtZW50VmlzaWJsZShcbiAgICAgIFwiZGl2ID4gZGl2W2NsYXNzKj1DYXJkXSA+IGRpdltjbGFzcyo9RnJhbWVdID4gZGl2W2NsYXNzKj1QaWxsc10gPiBidXR0b25bY2xhc3MqPVBpbGxzX19TdHlsZWRQaWxsXVwiLFxuICAgICAgXCJhbnlcIlxuICAgICk7XG4gIH1cbiAgYXN5bmMgb3B0T3V0KCkge1xuICAgIGNvbnN0IHJlamVjdEFsbFNlbGVjdG9yID0gXCJ4cGF0aC8vL2J1dHRvbltjb250YWlucyguLCAnQWZ2aXMgYWxsZScpIG9yIGNvbnRhaW5zKC4sICdSZWplY3QgYWxsJykgb3IgY29udGFpbnMoLiwgJ09kYmFjaSBzdmUnKSBvciBjb250YWlucyguLCAnUmVjaGF6YXIgdG9kbycpIG9yIGNvbnRhaW5zKC4sICdBdG1lc3RpIHZpc3VzJykgb3IgY29udGFpbnMoLiwgJ09kbVxceEVEdG5vdXQgdlxcdTAxNjFlJykgb3IgY29udGFpbnMoLiwgJ1xcdTAzOTFcXHUwM0MwXFx1MDNDQ1xcdTAzQzFcXHUwM0MxXFx1MDNCOVxcdTAzQzhcXHUwM0I3IFxcdTAzQ0NcXHUwM0JCXFx1MDNDOVxcdTAzQkQnKSBvciBjb250YWlucyguLCAnUmVqZWl0YXIgdHVkbycpIG9yIGNvbnRhaW5zKC4sICdUXFx4RkNtXFx4RkNuXFx4RkMgcmVkZGV0Jykgb3IgY29udGFpbnMoLiwgJ1xcdTA0MUVcXHUwNDQyXFx1MDQzQVxcdTA0M0JcXHUwNDNFXFx1MDQzRFxcdTA0MzhcXHUwNDQyXFx1MDQ0QyBcXHUwNDMyXFx1MDQ0MVxcdTA0MzUnKSBvciBjb250YWlucyguLCAnTm9yYWlkXFx1MDEyQnQgdmlzdScpIG9yIGNvbnRhaW5zKC4sICdBdnZpc2EgYWxsYScpIG9yIGNvbnRhaW5zKC4sICdPZHJ6dVxcdTAxMDcgd3N6eXN0a2llJykgb3IgY29udGFpbnMoLiwgJ0FsbGVzIGFmd2lqemVuJykgb3IgY29udGFpbnMoLiwgJ1xcdTA0MUVcXHUwNDQyXFx1MDQ0NVxcdTA0MzJcXHUwNDRBXFx1MDQ0MFxcdTA0M0JcXHUwNDRGXFx1MDQzRFxcdTA0MzUgXFx1MDQzRFxcdTA0MzAgXFx1MDQzMlxcdTA0NDFcXHUwNDM4XFx1MDQ0N1xcdTA0M0FcXHUwNDM4Jykgb3IgY29udGFpbnMoLiwgJ1JpZml1dGEgdHV0dG8nKSBvciBjb250YWlucyguLCAnWmF2cm5pIHZzZScpIG9yIGNvbnRhaW5zKC4sICdBeiBcXHhGNnNzemVzIGVsdXRhc1xceEVEdFxceEUxc2EnKSBvciBjb250YWlucyguLCAnUmVzcGluZ2VcXHUwMjFCaSB0b3QnKSBvciBjb250YWlucyguLCAnQWxsZXMgYWJsZWhuZW4nKSBvciBjb250YWlucyguLCAnVG91dCByZWpldGVyJykgb3IgY29udGFpbnMoLiwgJ09kbWlldG51XFx1MDE2NSB2XFx1MDE2MWV0a28nKSBvciBjb250YWlucyguLCAnTFxceEZDa2thIGtcXHhGNWlrIHRhZ2FzaScpIG9yIGNvbnRhaW5zKC4sICdIeWxrXFx4RTRcXHhFNCBrYWlra2knKV1cIjtcbiAgICBpZiAoYXdhaXQgdGhpcy53YWl0Rm9yRWxlbWVudChyZWplY3RBbGxTZWxlY3RvciwgNTAwKSkge1xuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuY2xpY2socmVqZWN0QWxsU2VsZWN0b3IpO1xuICAgIH1cbiAgICBjb25zdCBwdXJwb3Nlc0J1dHRvblNlbGVjdG9yID0gXCJ4cGF0aC8vL2J1dHRvbltjb250YWlucyguLCAnWndlY2tlJykgb3IgY29udGFpbnMoLiwgJ1xcdTAzQTNcXHUwM0JBXFx1MDNCRlxcdTAzQzBcXHUwM0JGXFx1MDNBRicpIG9yIGNvbnRhaW5zKC4sICdQdXJwb3NlcycpIG9yIGNvbnRhaW5zKC4sICdcXHUwNDI2XFx1MDQzNVxcdTA0M0JcXHUwNDM4Jykgb3IgY29udGFpbnMoLiwgJ0Vlc21cXHhFNHJnaWQnKSBvciBjb250YWlucyguLCAnVGlrc2xhaScpIG9yIGNvbnRhaW5zKC4sICdTdnJoZScpIG9yIGNvbnRhaW5zKC4sICdDZWxlJykgb3IgY29udGFpbnMoLiwgJ1xceERBXFx1MDEwRGVseScpIG9yIGNvbnRhaW5zKC4sICdGaW5hbGlkYWRlcycpIG9yIGNvbnRhaW5zKC4sICdNXFx1MDExM3JcXHUwMTM3aScpIG9yIGNvbnRhaW5zKC4sICdTY29wdXJpJykgb3IgY29udGFpbnMoLiwgJ0ZpbmVzJykgb3IgY29udGFpbnMoLiwgJ1xceEM0bmRhbVxceEU1bCcpIG9yIGNvbnRhaW5zKC4sICdGaW5hbGl0XFx4RTlzJykgb3IgY29udGFpbnMoLiwgJ0RvZWxlaW5kZW4nKSBvciBjb250YWlucyguLCAnVGFya29pdHVrc2V0Jykgb3IgY29udGFpbnMoLiwgJ1Njb3BpJykgb3IgY29udGFpbnMoLiwgJ0FtYVxceEU3bGFyJykgb3IgY29udGFpbnMoLiwgJ05hbWVuaScpIG9yIGNvbnRhaW5zKC4sICdDXFx4RTlsb2snKSBvciBjb250YWlucyguLCAnRm9ybVxceEU1bCcpXVwiO1xuICAgIGNvbnN0IHNhdmVBbmRFeGl0U2VsZWN0b3IgPSBcInhwYXRoLy8vYnV0dG9uW2NvbnRhaW5zKC4sICdTcGFyYSAmIGF2c2x1dGEnKSBvciBjb250YWlucyguLCAnU2F2ZSAmIGV4aXQnKSBvciBjb250YWlucyguLCAnVWxvXFx1MDE3RWl0IGEgdWtvblxcdTAxMERpdCcpIG9yIGNvbnRhaW5zKC4sICdFbnJlZ2lzdHJlciBldCBxdWl0dGVyJykgb3IgY29udGFpbnMoLiwgJ1NwZWljaGVybiAmIFZlcmxhc3NlbicpIG9yIGNvbnRhaW5zKC4sICdUYWxsZW5uYSBqYSBwb2lzdHUnKSBvciBjb250YWlucyguLCAnSVxcdTAxNjFzYXVnb3RpIGlyIGlcXHUwMTYxZWl0aScpIG9yIGNvbnRhaW5zKC4sICdPcHNsYWFuICYgYWZzbHVpdGVuJykgb3IgY29udGFpbnMoLiwgJ0d1YXJkYXIgeSBzYWxpcicpIG9yIGNvbnRhaW5zKC4sICdTaHJhbmkgaW4gemFwcmknKSBvciBjb250YWlucyguLCAnVWxvXFx1MDE3RWlcXHUwMTY1IGEgdWtvblxcdTAxMERpXFx1MDE2NScpIG9yIGNvbnRhaW5zKC4sICdLYXlkZXQgdmUgXFx4RTdcXHUwMTMxa1xcdTAxMzFcXHUwMTVGIHlhcCcpIG9yIGNvbnRhaW5zKC4sICdcXHUwNDIxXFx1MDQzRVxcdTA0NDVcXHUwNDQwXFx1MDQzMFxcdTA0M0RcXHUwNDM4XFx1MDQ0MlxcdTA0NEMgXFx1MDQzOCBcXHUwNDMyXFx1MDQ0QlxcdTA0MzlcXHUwNDQyXFx1MDQzOCcpIG9yIGNvbnRhaW5zKC4sICdTYWx2ZXN0YSBqYSB2XFx4RTRsanUnKSBvciBjb250YWlucyguLCAnU2FsdmEgZWQgZXNjaScpIG9yIGNvbnRhaW5zKC4sICdHZW0gJiBhZnNsdXQnKSBvciBjb250YWlucyguLCAnXFx1MDM5MVxcdTAzQzBcXHUwM0JGXFx1MDNCOFxcdTAzQUVcXHUwM0JBXFx1MDNCNVxcdTAzQzVcXHUwM0MzXFx1MDNCNyBcXHUwM0JBXFx1MDNCMVxcdTAzQjkgXFx1MDNBRFxcdTAzQkVcXHUwM0JGXFx1MDNCNFxcdTAzQkZcXHUwM0MyJykgb3IgY29udGFpbnMoLiwgJ1NhZ2xhYlxcdTAxMDF0IHVuIGl6aWV0Jykgb3IgY29udGFpbnMoLiwgJ01lbnRcXHhFOXMgXFx4RTlzIGtpbFxceEU5cFxceEU5cycpIG9yIGNvbnRhaW5zKC4sICdHdWFyZGFyIGUgc2FpcicpIG9yIGNvbnRhaW5zKC4sICdaYXBpc3ogJiB6YWtvXFx1MDE0NGN6Jykgb3IgY29udGFpbnMoLiwgJ1NhbHZhcmUgXFx1MDIxOWkgaWVcXHUwMjE5aXJlJykgb3IgY29udGFpbnMoLiwgJ1NwcmVtaSBpIGl6YVxcdTAxMTFpJykgb3IgY29udGFpbnMoLiwgJ1xcdTA0MTdcXHUwNDMwXFx1MDQzRlxcdTA0MzBcXHUwNDM3XFx1MDQzMlxcdTA0MzBcXHUwNDNEXFx1MDQzNSBcXHUwNDM4IFxcdTA0MzhcXHUwNDM3XFx1MDQ0NVxcdTA0M0VcXHUwNDM0JyldXCI7XG4gICAgaWYgKGF3YWl0IHRoaXMud2FpdEZvclRoZW5DbGljayhwdXJwb3Nlc0J1dHRvblNlbGVjdG9yKSAmJiBhd2FpdCB0aGlzLndhaXRGb3JWaXNpYmxlKHNhdmVBbmRFeGl0U2VsZWN0b3IpKSB7XG4gICAgICBjb25zdCBwb3B1cEJvZHkgPSB0aGlzLmVsZW1lbnRTZWxlY3RvcihzYXZlQW5kRXhpdFNlbGVjdG9yKVswXS5wYXJlbnRFbGVtZW50Py5wYXJlbnRFbGVtZW50O1xuICAgICAgY29uc3QgY2hlY2tib3hlcyA9IHBvcHVwQm9keT8ucXVlcnlTZWxlY3RvckFsbChcImlucHV0W3R5cGU9Y2hlY2tib3hdOmNoZWNrZWRcIik7XG4gICAgICBjaGVja2JveGVzPy5mb3JFYWNoKChjaGVja2JveCkgPT4gY2hlY2tib3guY2xpY2soKSk7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5jbGljayhzYXZlQW5kRXhpdFNlbGVjdG9yKTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGFzeW5jIG9wdEluKCkge1xuICAgIHJldHVybiBhd2FpdCB0aGlzLmNsaWNrKFxuICAgICAgXCJ4cGF0aC8vL2J1dHRvbltjb250YWlucyguLCAnU3ByZWptaSB2c2UnKSBvciBjb250YWlucyguLCAnUHJpaHZhdGkgc3ZlJykgb3IgY29udGFpbnMoLiwgJ0dvZGtcXHhFNG5uIGFsbGEnKSBvciBjb250YWlucyguLCAnUHJpamFcXHUwMTY1IHZcXHUwMTYxZXRrbycpIG9yIGNvbnRhaW5zKC4sICdcXHUwNDFGXFx1MDQ0MFxcdTA0MzhcXHUwNDNEXFx1MDQ0RlxcdTA0NDJcXHUwNDRDIFxcdTA0MzJcXHUwNDQxXFx1MDQzNScpIG9yIGNvbnRhaW5zKC4sICdBY2VwdGFyIHRvZG8nKSBvciBjb250YWlucyguLCAnXFx1MDM5MVxcdTAzQzBcXHUwM0JGXFx1MDNCNFxcdTAzQkZcXHUwM0M3XFx1MDNBRSBcXHUwM0NDXFx1MDNCQlxcdTAzQzlcXHUwM0JEJykgb3IgY29udGFpbnMoLiwgJ1phYWtjZXB0dWogd3N6eXN0a2llJykgb3IgY29udGFpbnMoLiwgJ0FjY2V0dGEgdHV0dG8nKSBvciBjb250YWlucyguLCAnUHJpaW10aSB2aXN1cycpIG9yIGNvbnRhaW5zKC4sICdQaWVcXHUwMTQ2ZW10IHZpc3UnKSBvciBjb250YWlucyguLCAnVFxceEZDbVxceEZDblxceEZDIGthYnVsIGV0Jykgb3IgY29udGFpbnMoLiwgJ0F6IFxceEY2c3N6ZXMgZWxmb2dhZFxceEUxc2EnKSBvciBjb250YWlucyguLCAnQWNjZXB0IGFsbCcpIG9yIGNvbnRhaW5zKC4sICdcXHUwNDFGXFx1MDQ0MFxcdTA0MzhcXHUwNDM1XFx1MDQzQ1xcdTA0MzBcXHUwNDNEXFx1MDQzNSBcXHUwNDNEXFx1MDQzMCBcXHUwNDMyXFx1MDQ0MVxcdTA0MzhcXHUwNDQ3XFx1MDQzQVxcdTA0MzgnKSBvciBjb250YWlucyguLCAnQWNjZXB0ZXIgYWxsZScpIG9yIGNvbnRhaW5zKC4sICdIeXZcXHhFNGtzeSBrYWlra2knKSBvciBjb250YWlucyguLCAnVG91dCBhY2NlcHRlcicpIG9yIGNvbnRhaW5zKC4sICdBbGxlcyBhY2NlcHRlcmVuJykgb3IgY29udGFpbnMoLiwgJ0FrdHNlcHRlZXJpIGtcXHhGNWlrJykgb3IgY29udGFpbnMoLiwgJ1BcXHUwMTU5aWptb3V0IHZcXHUwMTYxZScpIG9yIGNvbnRhaW5zKC4sICdBbGxlcyBha3plcHRpZXJlbicpIG9yIGNvbnRhaW5zKC4sICdBY2VpdGFyIHR1ZG8nKSBvciBjb250YWlucyguLCAnQWNjZXB0YVxcdTAyMUJpIHRvdCcpXVwiXG4gICAgKTtcbiAgfVxufTtcblxuLy8gbGliL2NtcHMvYWxsLnRzXG52YXIgZHluYW1pY0NNUHMgPSBbXG4gIFRydXN0QXJjVG9wLFxuICBUcnVzdEFyY0ZyYW1lLFxuICBDb29raWVib3QsXG4gIFNvdXJjZVBvaW50LFxuICBDb25zZW50TWFuYWdlcixcbiAgRXZpZG9uLFxuICBPbmV0cnVzdCxcbiAgS2xhcm8sXG4gIFVuaWNvbnNlbnQsXG4gIENvbnZlcnNhbnQsXG4gIFRpa3RvayxcbiAgVHVtYmxyLFxuICBBZG1pcmFsXG5dO1xuXG4vLyBsaWIvZG9tLWFjdGlvbnMudHNcbnZhciBEb21BY3Rpb25zID0gY2xhc3Mge1xuICBjb25zdHJ1Y3RvcihhdXRvY29uc2VudEluc3RhbmNlKSB7XG4gICAgdGhpcy5hdXRvY29uc2VudEluc3RhbmNlID0gYXV0b2NvbnNlbnRJbnN0YW5jZTtcbiAgfVxuICBhc3luYyBjbGlja0VsZW1lbnQoZWxlbWVudCkge1xuICAgIGlmICghZWxlbWVudCB8fCAhKGVsZW1lbnQgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgdGhpcy5hdXRvY29uc2VudEluc3RhbmNlLmNvbmZpZy5sb2dzLnJ1bGVzdGVwcyAmJiBjb25zb2xlLmxvZyhcIltjbGlja0VsZW1lbnRdXCIsIGVsZW1lbnQpO1xuICAgIGVsZW1lbnQuY2xpY2soKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBhc3luYyBjbGljayhzZWxlY3RvciwgYWxsID0gZmFsc2UpIHtcbiAgICBjb25zdCBlbGVtZW50cyA9IHRoaXMuZWxlbWVudFNlbGVjdG9yKHNlbGVjdG9yKTtcbiAgICB0aGlzLmF1dG9jb25zZW50SW5zdGFuY2UuY29uZmlnLmxvZ3MucnVsZXN0ZXBzICYmIGNvbnNvbGUubG9nKFwiW2NsaWNrXVwiLCBzZWxlY3RvciwgYWxsLCBlbGVtZW50cyk7XG4gICAgaWYgKGVsZW1lbnRzLmxlbmd0aCA+IDApIHtcbiAgICAgIGlmIChhbGwpIHtcbiAgICAgICAgZWxlbWVudHMuZm9yRWFjaCgoZSkgPT4gZS5jbGljaygpKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGVsZW1lbnRzWzBdLmNsaWNrKCk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBlbGVtZW50cy5sZW5ndGggPiAwO1xuICB9XG4gIGVsZW1lbnRFeGlzdHMoc2VsZWN0b3IpIHtcbiAgICBjb25zdCBleGlzdHMgPSB0aGlzLmVsZW1lbnRTZWxlY3RvcihzZWxlY3RvcikubGVuZ3RoID4gMDtcbiAgICByZXR1cm4gZXhpc3RzO1xuICB9XG4gIGVsZW1lbnRWaXNpYmxlKHNlbGVjdG9yLCBjaGVjayA9IFwiYWxsXCIpIHtcbiAgICBjb25zdCBlbGVtID0gdGhpcy5lbGVtZW50U2VsZWN0b3Ioc2VsZWN0b3IpO1xuICAgIGNvbnN0IHJlc3VsdHMgPSBuZXcgQXJyYXkoZWxlbS5sZW5ndGgpO1xuICAgIGVsZW0uZm9yRWFjaCgoZSwgaSkgPT4ge1xuICAgICAgcmVzdWx0c1tpXSA9IGlzRWxlbWVudFZpc2libGUoZSk7XG4gICAgfSk7XG4gICAgaWYgKGNoZWNrID09PSBcIm5vbmVcIikge1xuICAgICAgcmV0dXJuIHJlc3VsdHMuZXZlcnkoKHIpID0+ICFyKTtcbiAgICB9IGVsc2UgaWYgKHJlc3VsdHMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfSBlbHNlIGlmIChjaGVjayA9PT0gXCJhbnlcIikge1xuICAgICAgcmV0dXJuIHJlc3VsdHMuc29tZSgocikgPT4gcik7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHRzLmV2ZXJ5KChyKSA9PiByKTtcbiAgfVxuICB3YWl0Rm9yRWxlbWVudChzZWxlY3RvciwgdGltZW91dCA9IDFlNCkge1xuICAgIGNvbnN0IGludGVydmFsID0gMjAwO1xuICAgIGNvbnN0IHRpbWVzID0gTWF0aC5jZWlsKHRpbWVvdXQgLyBpbnRlcnZhbCk7XG4gICAgdGhpcy5hdXRvY29uc2VudEluc3RhbmNlLmNvbmZpZy5sb2dzLnJ1bGVzdGVwcyAmJiBjb25zb2xlLmxvZyhcIlt3YWl0Rm9yRWxlbWVudF1cIiwgc2VsZWN0b3IpO1xuICAgIHJldHVybiB3YWl0Rm9yKCgpID0+IHRoaXMuZWxlbWVudFNlbGVjdG9yKHNlbGVjdG9yKS5sZW5ndGggPiAwLCB0aW1lcywgaW50ZXJ2YWwpO1xuICB9XG4gIHdhaXRGb3JWaXNpYmxlKHNlbGVjdG9yLCB0aW1lb3V0ID0gMWU0LCBjaGVjayA9IFwiYW55XCIpIHtcbiAgICBjb25zdCBpbnRlcnZhbCA9IDIwMDtcbiAgICBjb25zdCB0aW1lcyA9IE1hdGguY2VpbCh0aW1lb3V0IC8gaW50ZXJ2YWwpO1xuICAgIHRoaXMuYXV0b2NvbnNlbnRJbnN0YW5jZS5jb25maWcubG9ncy5ydWxlc3RlcHMgJiYgY29uc29sZS5sb2coXCJbd2FpdEZvclZpc2libGVdXCIsIHNlbGVjdG9yKTtcbiAgICByZXR1cm4gd2FpdEZvcigoKSA9PiB0aGlzLmVsZW1lbnRWaXNpYmxlKHNlbGVjdG9yLCBjaGVjayksIHRpbWVzLCBpbnRlcnZhbCk7XG4gIH1cbiAgYXN5bmMgd2FpdEZvclRoZW5DbGljayhzZWxlY3RvciwgdGltZW91dCA9IDFlNCwgYWxsID0gZmFsc2UpIHtcbiAgICBhd2FpdCB0aGlzLndhaXRGb3JFbGVtZW50KHNlbGVjdG9yLCB0aW1lb3V0KTtcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5jbGljayhzZWxlY3RvciwgYWxsKTtcbiAgfVxuICB3YWl0KG1zKSB7XG4gICAgdGhpcy5hdXRvY29uc2VudEluc3RhbmNlLmNvbmZpZy5sb2dzLnJ1bGVzdGVwcyAmJiB0aGlzLmF1dG9jb25zZW50SW5zdGFuY2UuY29uZmlnLmxvZ3Mud2FpdHMgJiYgY29uc29sZS5sb2coXCJbd2FpdF1cIiwgbXMpO1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHJlc29sdmUodHJ1ZSk7XG4gICAgICB9LCBtcyk7XG4gICAgfSk7XG4gIH1cbiAgY29va2llQ29udGFpbnMoc3Vic3RyaW5nKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LmNvb2tpZS5pbmNsdWRlcyhzdWJzdHJpbmcpO1xuICB9XG4gIGhpZGUoc2VsZWN0b3IsIG1ldGhvZCkge1xuICAgIHRoaXMuYXV0b2NvbnNlbnRJbnN0YW5jZS5jb25maWcubG9ncy5ydWxlc3RlcHMgJiYgY29uc29sZS5sb2coXCJbaGlkZV1cIiwgc2VsZWN0b3IpO1xuICAgIGNvbnN0IHN0eWxlRWwgPSBnZXRTdHlsZUVsZW1lbnQoKTtcbiAgICByZXR1cm4gaGlkZUVsZW1lbnRzKHN0eWxlRWwsIHNlbGVjdG9yLCBtZXRob2QpO1xuICB9XG4gIHByZWhpZGUoc2VsZWN0b3IpIHtcbiAgICBjb25zdCBzdHlsZUVsID0gZ2V0U3R5bGVFbGVtZW50KFwiYXV0b2NvbnNlbnQtcHJlaGlkZVwiKTtcbiAgICB0aGlzLmF1dG9jb25zZW50SW5zdGFuY2UuY29uZmlnLmxvZ3MubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKFwiW3ByZWhpZGVdXCIsIHN0eWxlRWwsIGxvY2F0aW9uLmhyZWYpO1xuICAgIHJldHVybiBoaWRlRWxlbWVudHMoc3R5bGVFbCwgc2VsZWN0b3IsIFwib3BhY2l0eVwiKTtcbiAgfVxuICB1bmRvUHJlaGlkZSgpIHtcbiAgICBjb25zdCBleGlzdGluZ0VsZW1lbnQgPSBnZXRTdHlsZUVsZW1lbnQoXCJhdXRvY29uc2VudC1wcmVoaWRlXCIpO1xuICAgIHRoaXMuYXV0b2NvbnNlbnRJbnN0YW5jZS5jb25maWcubG9ncy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coXCJbdW5kb3ByZWhpZGVdXCIsIGV4aXN0aW5nRWxlbWVudCwgbG9jYXRpb24uaHJlZik7XG4gICAgZXhpc3RpbmdFbGVtZW50LnJlbW92ZSgpO1xuICB9XG4gIGFzeW5jIGNyZWF0ZU9yVXBkYXRlU3R5bGVTaGVldChjc3NUZXh0LCBzdHlsZVNoZWV0KSB7XG4gICAgaWYgKCFzdHlsZVNoZWV0KSB7XG4gICAgICBzdHlsZVNoZWV0ID0gbmV3IENTU1N0eWxlU2hlZXQoKTtcbiAgICB9XG4gICAgc3R5bGVTaGVldCA9IGF3YWl0IHN0eWxlU2hlZXQucmVwbGFjZShjc3NUZXh0KTtcbiAgICByZXR1cm4gc3R5bGVTaGVldDtcbiAgfVxuICByZW1vdmVTdHlsZVNoZWV0KHN0eWxlU2hlZXQpIHtcbiAgICBpZiAoc3R5bGVTaGVldCkge1xuICAgICAgc3R5bGVTaGVldC5yZXBsYWNlKFwiXCIpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBxdWVyeVNpbmdsZVJlcGx5U2VsZWN0b3Ioc2VsZWN0b3IsIHBhcmVudCA9IGRvY3VtZW50KSB7XG4gICAgaWYgKHNlbGVjdG9yLnN0YXJ0c1dpdGgoXCJhcmlhL1wiKSkge1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICBpZiAoc2VsZWN0b3Iuc3RhcnRzV2l0aChcInhwYXRoL1wiKSkge1xuICAgICAgY29uc3QgeHBhdGggPSBzZWxlY3Rvci5zbGljZSg2KTtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGRvY3VtZW50LmV2YWx1YXRlKHhwYXRoLCBwYXJlbnQsIG51bGwsIFhQYXRoUmVzdWx0LkFOWV9UWVBFLCBudWxsKTtcbiAgICAgIGxldCBub2RlID0gbnVsbDtcbiAgICAgIGNvbnN0IGVsZW1lbnRzID0gW107XG4gICAgICB3aGlsZSAobm9kZSA9IHJlc3VsdC5pdGVyYXRlTmV4dCgpKSB7XG4gICAgICAgIGVsZW1lbnRzLnB1c2gobm9kZSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZWxlbWVudHM7XG4gICAgfVxuICAgIGlmIChzZWxlY3Rvci5zdGFydHNXaXRoKFwidGV4dC9cIikpIHtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgaWYgKHNlbGVjdG9yLnN0YXJ0c1dpdGgoXCJwaWVyY2UvXCIpKSB7XG4gICAgICByZXR1cm4gW107XG4gICAgfVxuICAgIGlmIChwYXJlbnQuc2hhZG93Um9vdCkge1xuICAgICAgcmV0dXJuIEFycmF5LmZyb20ocGFyZW50LnNoYWRvd1Jvb3QucXVlcnlTZWxlY3RvckFsbChzZWxlY3RvcikpO1xuICAgIH1cbiAgICBpZiAocGFyZW50LmNvbnRlbnREb2N1bWVudD8ucXVlcnlTZWxlY3RvckFsbCkge1xuICAgICAgcmV0dXJuIEFycmF5LmZyb20ocGFyZW50LmNvbnRlbnREb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yKSk7XG4gICAgfVxuICAgIHJldHVybiBBcnJheS5mcm9tKHBhcmVudC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yKSk7XG4gIH1cbiAgcXVlcnlTZWxlY3RvckNoYWluKHNlbGVjdG9ycykge1xuICAgIGxldCBwYXJlbnQgPSBkb2N1bWVudDtcbiAgICBsZXQgbWF0Y2hlczIgPSBbXTtcbiAgICBmb3IgKGNvbnN0IHNlbGVjdG9yIG9mIHNlbGVjdG9ycykge1xuICAgICAgbWF0Y2hlczIgPSB0aGlzLnF1ZXJ5U2luZ2xlUmVwbHlTZWxlY3RvcihzZWxlY3RvciwgcGFyZW50KTtcbiAgICAgIGlmIChtYXRjaGVzMi5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgICAgfVxuICAgICAgcGFyZW50ID0gbWF0Y2hlczJbMF07XG4gICAgfVxuICAgIHJldHVybiBtYXRjaGVzMjtcbiAgfVxuICBlbGVtZW50U2VsZWN0b3Ioc2VsZWN0b3IpIHtcbiAgICBpZiAodHlwZW9mIHNlbGVjdG9yID09PSBcInN0cmluZ1wiKSB7XG4gICAgICByZXR1cm4gdGhpcy5xdWVyeVNpbmdsZVJlcGx5U2VsZWN0b3Ioc2VsZWN0b3IpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5xdWVyeVNlbGVjdG9yQ2hhaW4oc2VsZWN0b3IpO1xuICB9XG4gIHdhaXRGb3JNdXRhdGlvbihzZWxlY3RvciwgdGltZW91dCA9IDZlNCkge1xuICAgIGNvbnN0IG5vZGUgPSB0aGlzLmVsZW1lbnRTZWxlY3RvcihzZWxlY3Rvcik7XG4gICAgaWYgKG5vZGUubGVuZ3RoID09PSAwKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7c2VsZWN0b3J9IGRpZCBub3QgbWF0Y2ggYW55IGVsZW1lbnRzYCk7XG4gICAgfVxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICByZWplY3QobmV3IEVycm9yKFwiVGltZWQgb3V0IHdhaXRpbmcgZm9yIG11dGF0aW9uXCIpKTtcbiAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgfSwgdGltZW91dCk7XG4gICAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKCgpID0+IHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICByZXNvbHZlKHRydWUpO1xuICAgICAgfSk7XG4gICAgICBvYnNlcnZlci5vYnNlcnZlKG5vZGVbMF0sIHtcbiAgICAgICAgc3VidHJlZTogdHJ1ZSxcbiAgICAgICAgY2hpbGRMaXN0OiB0cnVlLFxuICAgICAgICBhdHRyaWJ1dGVzOiB0cnVlXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxufTtcblxuLy8gbGliL2VuY29kaW5nLnRzXG52YXIgY29tcGFjdGVkUnVsZVN0ZXBzID0gW1xuICBbXCJleGlzdHNcIiwgXCJlXCJdLFxuICBbXCJ2aXNpYmxlXCIsIFwidlwiXSxcbiAgW1wid2FpdEZvclRoZW5DbGlja1wiLCBcImNcIl0sXG4gIFtcImNsaWNrXCIsIFwia1wiXSxcbiAgW1wid2FpdEZvclwiLCBcIndcIl0sXG4gIFtcIndhaXRGb3JWaXNpYmxlXCIsIFwid3ZcIl0sXG4gIFtcImhpZGVcIiwgXCJoXCJdLFxuICBbXCJjb29raWVDb250YWluc1wiLCBcImNjXCJdXG5dO1xuZnVuY3Rpb24gZW5jb2RlTnVsbGFibGVCb29sZWFuKHZhbHVlKSB7XG4gIGlmICh2YWx1ZSA9PT0gdHJ1ZSkge1xuICAgIHJldHVybiAxO1xuICB9XG4gIGlmICh2YWx1ZSA9PT0gZmFsc2UpIHtcbiAgICByZXR1cm4gMDtcbiAgfVxuICByZXR1cm4gMjtcbn1cbmZ1bmN0aW9uIGRlY29kZU51bGxhYmxlQm9vbGVhbih2YWx1ZSkge1xuICBpZiAodmFsdWUgPT09IDEpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAodmFsdWUgPT09IDApIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHZvaWQgMDtcbn1cbmZ1bmN0aW9uIGJ1aWxkU3RyaW5ncyhleGlzdGluZ1N0cmluZ3MsIHJ1bGVzKSB7XG4gIGNvbnN0IHVzZWRTdHJpbmdzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgZnVuY3Rpb24gY29sbGVjdFN0cmluZ3Moc3RlcCkge1xuICAgIGZvciAoY29uc3QgW2xvbmdLZXldIG9mIGNvbXBhY3RlZFJ1bGVTdGVwcykge1xuICAgICAgaWYgKHN0ZXBbbG9uZ0tleV0gJiYgdHlwZW9mIHN0ZXBbbG9uZ0tleV0gPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgdXNlZFN0cmluZ3MuYWRkKHN0ZXBbbG9uZ0tleV0pO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoc3RlcC5pZikge1xuICAgICAgY29sbGVjdFN0cmluZ3Moc3RlcC5pZik7XG4gICAgICBzdGVwLnRoZW4/LmZvckVhY2goY29sbGVjdFN0cmluZ3MpO1xuICAgICAgc3RlcC5lbHNlPy5mb3JFYWNoKGNvbGxlY3RTdHJpbmdzKTtcbiAgICB9XG4gICAgaWYgKHN0ZXAuYW55KSB7XG4gICAgICBzdGVwLmFueS5mb3JFYWNoKGNvbGxlY3RTdHJpbmdzKTtcbiAgICB9XG4gIH1cbiAgcnVsZXMuZm9yRWFjaCgocnVsZSkgPT4ge1xuICAgIChydWxlLnByZWhpZGVTZWxlY3RvcnMgfHwgW10pLmZvckVhY2goKHNlbGVjdG9yKSA9PiB1c2VkU3RyaW5ncy5hZGQoc2VsZWN0b3IpKTtcbiAgICBydWxlLmRldGVjdENtcC5mb3JFYWNoKGNvbGxlY3RTdHJpbmdzKTtcbiAgICBydWxlLmRldGVjdFBvcHVwLmZvckVhY2goY29sbGVjdFN0cmluZ3MpO1xuICAgIHJ1bGUub3B0T3V0LmZvckVhY2goY29sbGVjdFN0cmluZ3MpO1xuICAgIChydWxlLnRlc3QgfHwgW10pLmZvckVhY2goY29sbGVjdFN0cmluZ3MpO1xuICB9KTtcbiAgY29uc3Qgc3RyaW5ncyA9IG5ldyBBcnJheSh1c2VkU3RyaW5ncy5zaXplKS5maWxsKHZvaWQgMCk7XG4gIGV4aXN0aW5nU3RyaW5ncy5zbGljZSgwLCB1c2VkU3RyaW5ncy5zaXplKS5mb3JFYWNoKChzLCBpKSA9PiB7XG4gICAgaWYgKHVzZWRTdHJpbmdzLmhhcyhzKSkge1xuICAgICAgc3RyaW5nc1tpXSA9IHM7XG4gICAgICB1c2VkU3RyaW5ncy5kZWxldGUocyk7XG4gICAgfVxuICB9KTtcbiAgdXNlZFN0cmluZ3MuZm9yRWFjaCgocykgPT4ge1xuICAgIGlmIChzdHJpbmdzLmluZGV4T2YocykgPT09IC0xKSB7XG4gICAgICBjb25zdCBuZXh0RnJlZVNsb3QgPSBzdHJpbmdzLmluZGV4T2Yodm9pZCAwKTtcbiAgICAgIHN0cmluZ3NbbmV4dEZyZWVTbG90XSA9IHM7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIHN0cmluZ3M7XG59XG5mdW5jdGlvbiBlbmNvZGVSdWxlcyhydWxlcywgZXhpc3RpbmdDb21wYWN0UnVsZXMpIHtcbiAgcnVsZXMuc29ydCgoYSwgYikgPT4ge1xuICAgIGNvbnN0IGlzR2VuZXJpYyA9IChyKSA9PiAhci5ydW5Db250ZXh0Py51cmxQYXR0ZXJuO1xuICAgIGNvbnN0IGlzRnJhbWUgPSAocikgPT4gci5ydW5Db250ZXh0Py5mcmFtZSA9PT0gdHJ1ZTtcbiAgICBpZiAoaXNHZW5lcmljKGEpICYmICFpc0dlbmVyaWMoYikpIHtcbiAgICAgIHJldHVybiAtMTtcbiAgICB9XG4gICAgaWYgKCFpc0dlbmVyaWMoYSkgJiYgaXNHZW5lcmljKGIpKSB7XG4gICAgICByZXR1cm4gMTtcbiAgICB9XG4gICAgaWYgKGlzR2VuZXJpYyhhKSAmJiBpc0dlbmVyaWMoYikpIHtcbiAgICAgIGlmIChpc0ZyYW1lKGEpICYmICFpc0ZyYW1lKGIpKSB7XG4gICAgICAgIHJldHVybiAxO1xuICAgICAgfVxuICAgICAgaWYgKCFpc0ZyYW1lKGEpICYmIGlzRnJhbWUoYikpIHtcbiAgICAgICAgcmV0dXJuIC0xO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIWlzR2VuZXJpYyhhKSAmJiAhaXNHZW5lcmljKGIpKSB7XG4gICAgICBpZiAoaXNGcmFtZShhKSAmJiAhaXNGcmFtZShiKSkge1xuICAgICAgICByZXR1cm4gLTE7XG4gICAgICB9XG4gICAgICBpZiAoIWlzRnJhbWUoYSkgJiYgaXNGcmFtZShiKSkge1xuICAgICAgICByZXR1cm4gMTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGEubmFtZS5sb2NhbGVDb21wYXJlKGIubmFtZSk7XG4gIH0pO1xuICBsZXQgZ2VuZXJpY1J1bGVFbmQgPSBydWxlcy5maW5kSW5kZXgoKHIpID0+IHtcbiAgICByZXR1cm4gci5ydW5Db250ZXh0Py51cmxQYXR0ZXJuO1xuICB9KTtcbiAgaWYgKGdlbmVyaWNSdWxlRW5kID09PSAtMSkge1xuICAgIGdlbmVyaWNSdWxlRW5kID0gcnVsZXMubGVuZ3RoO1xuICB9XG4gIGxldCBmcmFtZVJ1bGVTdGFydCA9IHJ1bGVzLmZpbmRJbmRleCgocikgPT4ge1xuICAgIHJldHVybiByLnJ1bkNvbnRleHQ/LmZyYW1lID09PSB0cnVlO1xuICB9KTtcbiAgaWYgKGZyYW1lUnVsZVN0YXJ0ID09PSAtMSkge1xuICAgIGZyYW1lUnVsZVN0YXJ0ID0gZ2VuZXJpY1J1bGVFbmQ7XG4gIH1cbiAgbGV0IGZyYW1lUnVsZUVuZCA9IHJ1bGVzLmZpbmRJbmRleCgociwgaSkgPT4ge1xuICAgIHJldHVybiAhci5ydW5Db250ZXh0Py5mcmFtZSAmJiBpID49IGZyYW1lUnVsZVN0YXJ0O1xuICB9KTtcbiAgaWYgKGZyYW1lUnVsZUVuZCA9PT0gLTEpIHtcbiAgICBmcmFtZVJ1bGVFbmQgPSBydWxlcy5sZW5ndGg7XG4gIH1cbiAgY29uc3QgZ2VuZXJpY1N0cmluZ3MgPSBidWlsZFN0cmluZ3MoZXhpc3RpbmdDb21wYWN0UnVsZXM/LnMgfHwgW10sIHJ1bGVzLnNsaWNlKDAsIGdlbmVyaWNSdWxlRW5kKSk7XG4gIGNvbnN0IGZyYW1lU3RyaW5ncyA9IGJ1aWxkU3RyaW5ncyhnZW5lcmljU3RyaW5ncywgcnVsZXMuc2xpY2UoMCwgZnJhbWVSdWxlRW5kKSk7XG4gIGNvbnN0IHN0cmluZ3MgPSBidWlsZFN0cmluZ3MoZnJhbWVTdHJpbmdzLmNvbmNhdChleGlzdGluZ0NvbXBhY3RSdWxlcz8ucy5zbGljZShmcmFtZVN0cmluZ3MubGVuZ3RoKSB8fCBbXSksIHJ1bGVzKTtcbiAgZnVuY3Rpb24gZW5jb2RlUnVsZVN0ZXAoc3RlcCkge1xuICAgIGNvbnN0IGNsb25lZFN0ZXAgPSB7IC4uLnN0ZXAgfTtcbiAgICBpZiAoc3RlcC5jb21tZW50KSB7XG4gICAgICBkZWxldGUgY2xvbmVkU3RlcC5jb21tZW50O1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IFtsb25nS2V5LCBzaG9ydEtleV0gb2YgY29tcGFjdGVkUnVsZVN0ZXBzKSB7XG4gICAgICBpZiAoY2xvbmVkU3RlcFtsb25nS2V5XSAmJiB0eXBlb2YgY2xvbmVkU3RlcFtsb25nS2V5XSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICBjbG9uZWRTdGVwW3Nob3J0S2V5XSA9IHN0cmluZ3MuaW5kZXhPZihjbG9uZWRTdGVwW2xvbmdLZXldKTtcbiAgICAgICAgZGVsZXRlIGNsb25lZFN0ZXBbbG9uZ0tleV07XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChzdGVwLmlmKSB7XG4gICAgICBjbG9uZWRTdGVwLmlmID0gZW5jb2RlUnVsZVN0ZXAoc3RlcC5pZik7XG4gICAgICBjbG9uZWRTdGVwLnRoZW4gPSBzdGVwLnRoZW4gJiYgc3RlcC50aGVuLm1hcChlbmNvZGVSdWxlU3RlcCk7XG4gICAgICBpZiAoc3RlcC5lbHNlKSB7XG4gICAgICAgIGNsb25lZFN0ZXAuZWxzZSA9IHN0ZXAuZWxzZS5tYXAoZW5jb2RlUnVsZVN0ZXApO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoc3RlcC5hbnkpIHtcbiAgICAgIGNsb25lZFN0ZXAuYW55ID0gc3RlcC5hbnkubWFwKGVuY29kZVJ1bGVTdGVwKTtcbiAgICB9XG4gICAgcmV0dXJuIGNsb25lZFN0ZXA7XG4gIH1cbiAgY29uc3QgY29tcGFjdFJ1bGVzID0gcnVsZXMubWFwKChyKSA9PiB7XG4gICAgcmV0dXJuIFtcbiAgICAgIHIubWluaW11bVJ1bGVTdGVwVmVyc2lvbiB8fCAxLFxuICAgICAgci5uYW1lLFxuICAgICAgZW5jb2RlTnVsbGFibGVCb29sZWFuKHIuY29zbWV0aWMpLFxuICAgICAgci5ydW5Db250ZXh0Py51cmxQYXR0ZXJuIHx8IFwiXCIsXG4gICAgICBwYXJzZUludChgJHtlbmNvZGVOdWxsYWJsZUJvb2xlYW4oci5ydW5Db250ZXh0Py5tYWluKX0ke2VuY29kZU51bGxhYmxlQm9vbGVhbihyLnJ1bkNvbnRleHQ/LmZyYW1lKX1gKSxcbiAgICAgIChyLnByZWhpZGVTZWxlY3RvcnMgfHwgW10pLm1hcCgocykgPT4gc3RyaW5ncy5pbmRleE9mKHMpKSxcbiAgICAgIHIuZGV0ZWN0Q21wLm1hcChlbmNvZGVSdWxlU3RlcCksXG4gICAgICByLmRldGVjdFBvcHVwLm1hcChlbmNvZGVSdWxlU3RlcCksXG4gICAgICByLm9wdE91dC5tYXAoZW5jb2RlUnVsZVN0ZXApLFxuICAgICAgKHIudGVzdCB8fCBbXSkubWFwKGVuY29kZVJ1bGVTdGVwKSxcbiAgICAgIHIuaW50ZXJtZWRpYXRlICE9PSB2b2lkIDAgPyB7IGludGVybWVkaWF0ZTogci5pbnRlcm1lZGlhdGUgfSA6IHt9XG4gICAgXTtcbiAgfSk7XG4gIHJldHVybiB7XG4gICAgdjogMSxcbiAgICBzOiBzdHJpbmdzLFxuICAgIHI6IGNvbXBhY3RSdWxlcyxcbiAgICBpbmRleDoge1xuICAgICAgZ2VuZXJpY1J1bGVSYW5nZTogWzAsIGdlbmVyaWNSdWxlRW5kXSxcbiAgICAgIGZyYW1lUnVsZVJhbmdlOiBbZnJhbWVSdWxlU3RhcnQsIGZyYW1lUnVsZUVuZF0sXG4gICAgICBzcGVjaWZpY1J1bGVSYW5nZTogW2dlbmVyaWNSdWxlRW5kLCBjb21wYWN0UnVsZXMubGVuZ3RoXSxcbiAgICAgIGdlbmVyaWNTdHJpbmdFbmQ6IGdlbmVyaWNTdHJpbmdzLmxlbmd0aCxcbiAgICAgIGZyYW1lU3RyaW5nRW5kOiBmcmFtZVN0cmluZ3MubGVuZ3RoXG4gICAgfVxuICB9O1xufVxuZnVuY3Rpb24gZGVjb2RlUnVsZXMoZW5jb2RlZCkge1xuICBpZiAoZW5jb2RlZC52ID4gMSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIlVuc3VwcG9ydGVkIHJ1bGUgZm9ybWF0LlwiKTtcbiAgfVxuICByZXR1cm4gZW5jb2RlZC5yLmZpbHRlcigocikgPT4gclswXSA8PSBTVVBQT1JURURfUlVMRV9TVEVQX1ZFUlNJT04pLm1hcCgocnVsZSkgPT4gbmV3IENvbXBhY3RlZENNUFJ1bGUocnVsZSwgZW5jb2RlZC5zKSk7XG59XG52YXIgQ29tcGFjdGVkQ01QUnVsZSA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IocnVsZSwgc3RyaW5ncykge1xuICAgIHRoaXMuaW50ZXJtZWRpYXRlID0gZmFsc2U7XG4gICAgdGhpcy5vcHRJbiA9IFtdO1xuICAgIHRoaXMuciA9IHJ1bGU7XG4gICAgdGhpcy5zID0gc3RyaW5ncztcbiAgICBpZiAodGhpcy5yWzEwXSAmJiB0aGlzLnJbMTBdLmludGVybWVkaWF0ZSkge1xuICAgICAgdGhpcy5pbnRlcm1lZGlhdGUgPSB0aGlzLnJbMTBdLmludGVybWVkaWF0ZTtcbiAgICB9XG4gIH1cbiAgX2RlY29kZVJ1bGVTdGVwKHN0ZXApIHtcbiAgICBjb25zdCBjbG9uZWRTdGVwID0geyAuLi5zdGVwIH07XG4gICAgY29uc3QgZGVjb2RlUnVsZVN0ZXAgPSB0aGlzLl9kZWNvZGVSdWxlU3RlcC5iaW5kKHRoaXMpO1xuICAgIGZvciAoY29uc3QgW2xvbmdLZXksIHNob3J0S2V5XSBvZiBjb21wYWN0ZWRSdWxlU3RlcHMpIHtcbiAgICAgIGlmIChjbG9uZWRTdGVwW3Nob3J0S2V5XSAhPT0gdm9pZCAwKSB7XG4gICAgICAgIGNsb25lZFN0ZXBbbG9uZ0tleV0gPSB0aGlzLnNbY2xvbmVkU3RlcFtzaG9ydEtleV1dO1xuICAgICAgICBkZWxldGUgY2xvbmVkU3RlcFtzaG9ydEtleV07XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChzdGVwLmlmKSB7XG4gICAgICBjbG9uZWRTdGVwLmlmID0gZGVjb2RlUnVsZVN0ZXAoc3RlcC5pZik7XG4gICAgICBjbG9uZWRTdGVwLnRoZW4gPSBzdGVwLnRoZW4gJiYgc3RlcC50aGVuLm1hcChkZWNvZGVSdWxlU3RlcCk7XG4gICAgICBpZiAoc3RlcC5lbHNlKSB7XG4gICAgICAgIGNsb25lZFN0ZXAuZWxzZSA9IHN0ZXAuZWxzZS5tYXAoZGVjb2RlUnVsZVN0ZXApO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoc3RlcC5hbnkpIHtcbiAgICAgIGNsb25lZFN0ZXAuYW55ID0gc3RlcC5hbnkubWFwKGRlY29kZVJ1bGVTdGVwKTtcbiAgICB9XG4gICAgcmV0dXJuIHsgLi4uY2xvbmVkU3RlcCB9O1xuICB9XG4gIGdldCBuYW1lKCkge1xuICAgIHJldHVybiB0aGlzLnJbMV07XG4gIH1cbiAgZ2V0IGNvc21ldGljKCkge1xuICAgIHJldHVybiBkZWNvZGVOdWxsYWJsZUJvb2xlYW4odGhpcy5yWzJdKTtcbiAgfVxuICBnZXQgcnVuQ29udGV4dCgpIHtcbiAgICBjb25zdCBydW5Db250ZXh0ID0ge307XG4gICAgY29uc3QgdXJsUGF0dGVybiA9IHRoaXMuclszXTtcbiAgICBjb25zdCBtYWluRnJhbWUgPSB0aGlzLnJbNF07XG4gICAgY29uc3QgcnVuSW5NYWluRnJhbWUgPSBkZWNvZGVOdWxsYWJsZUJvb2xlYW4oTWF0aC5mbG9vcihtYWluRnJhbWUgLyAxMCkgJSAxMCk7XG4gICAgY29uc3QgcnVuSW5TdWJGcmFtZSA9IGRlY29kZU51bGxhYmxlQm9vbGVhbihtYWluRnJhbWUgJSAxMCk7XG4gICAgaWYgKHJ1bkluTWFpbkZyYW1lICE9PSB2b2lkIDApIHtcbiAgICAgIHJ1bkNvbnRleHQubWFpbiA9IHJ1bkluTWFpbkZyYW1lO1xuICAgIH1cbiAgICBpZiAocnVuSW5TdWJGcmFtZSAhPT0gdm9pZCAwKSB7XG4gICAgICBydW5Db250ZXh0LmZyYW1lID0gcnVuSW5TdWJGcmFtZTtcbiAgICB9XG4gICAgaWYgKHVybFBhdHRlcm4gIT09IFwiXCIpIHtcbiAgICAgIHJ1bkNvbnRleHQudXJsUGF0dGVybiA9IHVybFBhdHRlcm47XG4gICAgfVxuICAgIHJldHVybiBydW5Db250ZXh0O1xuICB9XG4gIGdldCBwcmVoaWRlU2VsZWN0b3JzKCkge1xuICAgIHJldHVybiB0aGlzLnJbNV0ubWFwKChpKSA9PiB0aGlzLnNbaV0udG9TdHJpbmcoKSk7XG4gIH1cbiAgZ2V0IGRldGVjdENtcCgpIHtcbiAgICByZXR1cm4gdGhpcy5yWzZdLm1hcCh0aGlzLl9kZWNvZGVSdWxlU3RlcC5iaW5kKHRoaXMpKTtcbiAgfVxuICBnZXQgZGV0ZWN0UG9wdXAoKSB7XG4gICAgcmV0dXJuIHRoaXMucls3XS5tYXAodGhpcy5fZGVjb2RlUnVsZVN0ZXAuYmluZCh0aGlzKSk7XG4gIH1cbiAgZ2V0IG9wdE91dCgpIHtcbiAgICByZXR1cm4gdGhpcy5yWzhdLm1hcCh0aGlzLl9kZWNvZGVSdWxlU3RlcC5iaW5kKHRoaXMpKTtcbiAgfVxuICBnZXQgdGVzdCgpIHtcbiAgICByZXR1cm4gdGhpcy5yWzldLm1hcCh0aGlzLl9kZWNvZGVSdWxlU3RlcC5iaW5kKHRoaXMpKTtcbiAgfVxufTtcbmZ1bmN0aW9uIGNsZWFyVW51c2VkU3RyaW5ncyhydWxlc2V0LCBpZ25vcmVCZWZvcmVJbmRleCA9IDApIHtcbiAgY29uc3QgeyB2LCBzLCByIH0gPSBydWxlc2V0O1xuICBjb25zdCB1c2VkU3RyaW5nSWRzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgZnVuY3Rpb24gYWRkU3RyaW5nSWRzRnJvbVJ1bGVTdGVwcyhzdGVwcykge1xuICAgIHN0ZXBzLmZvckVhY2goKHN0ZXApID0+IHtcbiAgICAgIGZvciAoY29uc3QgWywgc2hvcnRLZXldIG9mIGNvbXBhY3RlZFJ1bGVTdGVwcykge1xuICAgICAgICBpZiAoc3RlcFtzaG9ydEtleV0gIT09IHZvaWQgMCkge1xuICAgICAgICAgIHVzZWRTdHJpbmdJZHMuYWRkKHN0ZXBbc2hvcnRLZXldKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHN0ZXAuaWYpIHtcbiAgICAgICAgYWRkU3RyaW5nSWRzRnJvbVJ1bGVTdGVwcyhbc3RlcC5pZl0pO1xuICAgICAgfVxuICAgICAgaWYgKHN0ZXAudGhlbikge1xuICAgICAgICBhZGRTdHJpbmdJZHNGcm9tUnVsZVN0ZXBzKHN0ZXAudGhlbik7XG4gICAgICB9XG4gICAgICBpZiAoc3RlcC5lbHNlKSB7XG4gICAgICAgIGFkZFN0cmluZ0lkc0Zyb21SdWxlU3RlcHMoc3RlcC5lbHNlKTtcbiAgICAgIH1cbiAgICAgIGlmIChzdGVwLmFueSkge1xuICAgICAgICBhZGRTdHJpbmdJZHNGcm9tUnVsZVN0ZXBzKHN0ZXAuYW55KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBydWxlc2V0LnIuZm9yRWFjaCgocnVsZSkgPT4ge1xuICAgIGFkZFN0cmluZ0lkc0Zyb21SdWxlU3RlcHMocnVsZVs2XSk7XG4gICAgYWRkU3RyaW5nSWRzRnJvbVJ1bGVTdGVwcyhydWxlWzddKTtcbiAgICBhZGRTdHJpbmdJZHNGcm9tUnVsZVN0ZXBzKHJ1bGVbOF0pO1xuICAgIGFkZFN0cmluZ0lkc0Zyb21SdWxlU3RlcHMocnVsZVs5XSk7XG4gICAgcnVsZVs1XS5mb3JFYWNoKChpZCkgPT4gdXNlZFN0cmluZ0lkcy5hZGQoaWQpKTtcbiAgfSk7XG4gIHJldHVybiB7XG4gICAgdixcbiAgICByLFxuICAgIHM6IHMuc2xpY2UoMCwgTWF0aC5tYXgoLi4udXNlZFN0cmluZ0lkcykgKyAxKS5tYXAoKHN0ciwgaWR4KSA9PiB7XG4gICAgICBpZiAoaWR4IDwgaWdub3JlQmVmb3JlSW5kZXggfHwgdXNlZFN0cmluZ0lkcy5oYXMoaWR4KSkge1xuICAgICAgICByZXR1cm4gc3RyO1xuICAgICAgfVxuICAgICAgcmV0dXJuIFwiXCI7XG4gICAgfSlcbiAgfTtcbn1cbmZ1bmN0aW9uIHNob3VsZFJ1blJ1bGVJbkNvbnRleHQocnVsZSwgbWFpbkZyYW1lLCB1cmwpIHtcbiAgY29uc3QgcnVuQ29udGV4dCA9IHJ1bGVbNF07XG4gIGlmIChtYWluRnJhbWUgJiYgcnVuQ29udGV4dCA9PT0gMSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoIW1haW5GcmFtZSAmJiBbMjAsIDIyLCAxMCwgMTJdLmluY2x1ZGVzKHJ1bkNvbnRleHQpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGNvbnN0IHVybFBhdHRlcm4gPSBydWxlWzNdO1xuICBpZiAodXJsUGF0dGVybiAmJiB1cmxQYXR0ZXJuICE9PSBcIlwiICYmIHVybC5tYXRjaCh1cmxQYXR0ZXJuKSA9PT0gbnVsbCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGZpbHRlckNvbXBhY3RSdWxlcyhydWxlcywgY29udGV4dCkge1xuICBjb25zdCB7IHYsIHMsIHIsIGluZGV4IH0gPSBydWxlcztcbiAgY29uc3QgeyB1cmwsIG1haW5GcmFtZSB9ID0gY29udGV4dDtcbiAgY29uc3Qgc2hvdWxkUnVuSW5Db250ZXh0ID0gKHJ1bGUpID0+IHNob3VsZFJ1blJ1bGVJbkNvbnRleHQocnVsZSwgbWFpbkZyYW1lLCB1cmwpO1xuICBpZiAoIW1haW5GcmFtZSkge1xuICAgIGNvbnN0IHJ1bGVzZXQgPSB7XG4gICAgICB2LFxuICAgICAgczogcy5zbGljZSgwLCBpbmRleC5mcmFtZVN0cmluZ0VuZCksXG4gICAgICByOiByLnNsaWNlKGluZGV4LmZyYW1lUnVsZVJhbmdlWzBdLCBpbmRleC5mcmFtZVJ1bGVSYW5nZVsxXSkuZmlsdGVyKHNob3VsZFJ1bkluQ29udGV4dClcbiAgICB9O1xuICAgIHJldHVybiBjbGVhclVudXNlZFN0cmluZ3MocnVsZXNldCk7XG4gIH1cbiAgY29uc3QgZ2VuZXJpY1J1bGVzID0gci5zbGljZShpbmRleC5nZW5lcmljUnVsZVJhbmdlWzBdLCBpbmRleC5nZW5lcmljUnVsZVJhbmdlWzFdKTtcbiAgY29uc3Qgc3BlY2lmaWNSdWxlcyA9IHIuc2xpY2UoaW5kZXguc3BlY2lmaWNSdWxlUmFuZ2VbMF0sIGluZGV4LnNwZWNpZmljUnVsZVJhbmdlWzFdKS5maWx0ZXIoc2hvdWxkUnVuSW5Db250ZXh0KTtcbiAgaWYgKHNwZWNpZmljUnVsZXMubGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IHJ1bGVzZXQgPSB7XG4gICAgICB2LFxuICAgICAgcyxcbiAgICAgIHI6IFsuLi5nZW5lcmljUnVsZXMsIC4uLnNwZWNpZmljUnVsZXNdXG4gICAgfTtcbiAgICByZXR1cm4gY2xlYXJVbnVzZWRTdHJpbmdzKHJ1bGVzZXQpO1xuICB9XG4gIHJldHVybiB7XG4gICAgdixcbiAgICBzOiBzLnNsaWNlKDAsIGluZGV4LmdlbmVyaWNTdHJpbmdFbmQpLFxuICAgIHI6IGdlbmVyaWNSdWxlc1xuICB9O1xufVxuXG4vLyBsaWIvd2ViLnRzXG5mdW5jdGlvbiBmaWx0ZXJDTVBzKHJ1bGVzLCBjb25maWcpIHtcbiAgcmV0dXJuIHJ1bGVzLmZpbHRlcigoY21wKSA9PiB7XG4gICAgcmV0dXJuICghY29uZmlnLmRpc2FibGVkQ21wcyB8fCAhY29uZmlnLmRpc2FibGVkQ21wcy5pbmNsdWRlcyhjbXAubmFtZSkpICYmIC8vIENNUCBpcyBub3QgZGlzYWJsZWRcbiAgICAoY29uZmlnLmVuYWJsZUNvc21ldGljUnVsZXMgfHwgIWNtcC5pc0Nvc21ldGljKSAmJiAvLyBDTVAgaXMgbm90IGNvc21ldGljIG9yIGNvc21ldGljIHJ1bGVzIGFyZSBlbmFibGVkXG4gICAgKGNvbmZpZy5lbmFibGVHZW5lcmF0ZWRSdWxlcyB8fCAhY21wLm5hbWUuc3RhcnRzV2l0aChcImF1dG9fXCIpKTtcbiAgfSk7XG59XG52YXIgX2NvbmZpZztcbnZhciBBdXRvQ29uc2VudCA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3Ioc2VuZENvbnRlbnRNZXNzYWdlLCBjb25maWcgPSBudWxsLCBkZWNsYXJhdGl2ZVJ1bGVzID0gbnVsbCkge1xuICAgIHRoaXMuaWQgPSBnZXRSYW5kb21JRCgpO1xuICAgIHRoaXMucnVsZXMgPSBbXTtcbiAgICBfX3ByaXZhdGVBZGQodGhpcywgX2NvbmZpZyk7XG4gICAgdGhpcy5zdGF0ZSA9IHtcbiAgICAgIGNvc21ldGljRmlsdGVyc09uOiBmYWxzZSxcbiAgICAgIGZpbHRlckxpc3RSZXBvcnRlZDogZmFsc2UsXG4gICAgICBsaWZlY3ljbGU6IFwibG9hZGluZ1wiLFxuICAgICAgcHJlaGlkZU9uOiBmYWxzZSxcbiAgICAgIGZpbmRDbXBBdHRlbXB0czogMCxcbiAgICAgIGRldGVjdGVkQ21wczogW10sXG4gICAgICBkZXRlY3RlZFBvcHVwczogW10sXG4gICAgICBoZXVyaXN0aWNQYXR0ZXJuczogW10sXG4gICAgICBoZXVyaXN0aWNTbmlwcGV0czogW10sXG4gICAgICBzZWxmVGVzdDogbnVsbCxcbiAgICAgIGNsaWNrczogMCxcbiAgICAgIHN0YXJ0VGltZTogMCxcbiAgICAgIGVuZFRpbWU6IDBcbiAgICB9O1xuICAgIGV2YWxTdGF0ZS5zZW5kQ29udGVudE1lc3NhZ2UgPSBzZW5kQ29udGVudE1lc3NhZ2U7XG4gICAgdGhpcy5zZW5kQ29udGVudE1lc3NhZ2UgPSBzZW5kQ29udGVudE1lc3NhZ2U7XG4gICAgdGhpcy5ydWxlcyA9IFtdO1xuICAgIHRoaXMudXBkYXRlU3RhdGUoeyBsaWZlY3ljbGU6IFwibG9hZGluZ1wiIH0pO1xuICAgIHRoaXMuYWRkRHluYW1pY1J1bGVzKCk7XG4gICAgaWYgKGNvbmZpZykge1xuICAgICAgdGhpcy5pbml0aWFsaXplKGNvbmZpZywgZGVjbGFyYXRpdmVSdWxlcyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChkZWNsYXJhdGl2ZVJ1bGVzKSB7XG4gICAgICAgIHRoaXMucGFyc2VEZWNsYXJhdGl2ZVJ1bGVzKGRlY2xhcmF0aXZlUnVsZXMpO1xuICAgICAgfVxuICAgICAgY29uc3QgaW5pdE1zZyA9IHtcbiAgICAgICAgdHlwZTogXCJpbml0XCIsXG4gICAgICAgIHVybDogd2luZG93LmxvY2F0aW9uLmhyZWZcbiAgICAgIH07XG4gICAgICBzZW5kQ29udGVudE1lc3NhZ2UoaW5pdE1zZyk7XG4gICAgICB0aGlzLnVwZGF0ZVN0YXRlKHsgbGlmZWN5Y2xlOiBcIndhaXRpbmdGb3JJbml0UmVzcG9uc2VcIiB9KTtcbiAgICB9XG4gICAgdGhpcy5kb21BY3Rpb25zID0gbmV3IERvbUFjdGlvbnModGhpcyk7XG4gIH1cbiAgZ2V0IGNvbmZpZygpIHtcbiAgICBpZiAoIV9fcHJpdmF0ZUdldCh0aGlzLCBfY29uZmlnKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQXV0b0NvbnNlbnQgaXMgbm90IGluaXRpYWxpemVkIHlldFwiKTtcbiAgICB9XG4gICAgcmV0dXJuIF9fcHJpdmF0ZUdldCh0aGlzLCBfY29uZmlnKTtcbiAgfVxuICBpbml0aWFsaXplKGNvbmZpZywgZGVjbGFyYXRpdmVSdWxlcykge1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRDb25maWcgPSBub3JtYWxpemVDb25maWcoY29uZmlnKTtcbiAgICBub3JtYWxpemVkQ29uZmlnLmxvZ3MubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKFwiYXV0b2NvbnNlbnQgaW5pdFwiLCB3aW5kb3cubG9jYXRpb24uaHJlZik7XG4gICAgX19wcml2YXRlU2V0KHRoaXMsIF9jb25maWcsIG5vcm1hbGl6ZWRDb25maWcpO1xuICAgIGlmICghbm9ybWFsaXplZENvbmZpZy5lbmFibGVkKSB7XG4gICAgICBub3JtYWxpemVkQ29uZmlnLmxvZ3MubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKFwiYXV0b2NvbnNlbnQgaXMgZGlzYWJsZWRcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChkZWNsYXJhdGl2ZVJ1bGVzKSB7XG4gICAgICB0aGlzLnBhcnNlRGVjbGFyYXRpdmVSdWxlcyhkZWNsYXJhdGl2ZVJ1bGVzKTtcbiAgICB9XG4gICAgaWYgKGNvbmZpZy5lbmFibGVGaWx0ZXJMaXN0KSB7XG4gICAgICB0aGlzLmluaXRpYWxpemVGaWx0ZXJMaXN0KCk7XG4gICAgfVxuICAgIHRoaXMucnVsZXMgPSBmaWx0ZXJDTVBzKHRoaXMucnVsZXMsIG5vcm1hbGl6ZWRDb25maWcpO1xuICAgIGlmICh0aGlzLnNob3VsZFByZWhpZGUpIHtcbiAgICAgIGlmIChkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpIHtcbiAgICAgICAgdGhpcy5wcmVoaWRlRWxlbWVudHMoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGRlbGF5ZWRQcmVoaWRlID0gKCkgPT4ge1xuICAgICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwiRE9NQ29udGVudExvYWRlZFwiLCBkZWxheWVkUHJlaGlkZSk7XG4gICAgICAgICAgdGhpcy5wcmVoaWRlRWxlbWVudHMoKTtcbiAgICAgICAgfTtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJET01Db250ZW50TG9hZGVkXCIsIGRlbGF5ZWRQcmVoaWRlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGRvY3VtZW50LnJlYWR5U3RhdGUgPT09IFwibG9hZGluZ1wiKSB7XG4gICAgICBjb25zdCBvblJlYWR5ID0gKCkgPT4ge1xuICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIkRPTUNvbnRlbnRMb2FkZWRcIiwgb25SZWFkeSk7XG4gICAgICAgIHRoaXMuc3RhcnQoKTtcbiAgICAgIH07XG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIkRPTUNvbnRlbnRMb2FkZWRcIiwgb25SZWFkeSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuc3RhcnQoKTtcbiAgICB9XG4gICAgdGhpcy51cGRhdGVTdGF0ZSh7IGxpZmVjeWNsZTogXCJpbml0aWFsaXplZFwiIH0pO1xuICB9XG4gIGluaXRpYWxpemVGaWx0ZXJMaXN0KCkge1xuICB9XG4gIGdldCBzaG91bGRQcmVoaWRlKCkge1xuICAgIHJldHVybiB0aGlzLmNvbmZpZy5lbmFibGVQcmVoaWRlICYmICF0aGlzLmNvbmZpZy52aXN1YWxUZXN0O1xuICB9XG4gIHNhdmVGb2N1cygpIHtcbiAgICB0aGlzLmZvY3VzZWRFbGVtZW50ID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudDtcbiAgICBpZiAodGhpcy5mb2N1c2VkRWxlbWVudCkge1xuICAgICAgdGhpcy5jb25maWcubG9ncy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coXCJzYXZpbmcgZm9jdXNcIiwgdGhpcy5mb2N1c2VkRWxlbWVudCwgbG9jYXRpb24uaHJlZik7XG4gICAgfVxuICB9XG4gIHJlc3RvcmVGb2N1cygpIHtcbiAgICBpZiAodGhpcy5mb2N1c2VkRWxlbWVudCkge1xuICAgICAgdGhpcy5jb25maWcubG9ncy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coXCJyZXN0b3JpbmcgZm9jdXNcIiwgdGhpcy5mb2N1c2VkRWxlbWVudCwgbG9jYXRpb24uaHJlZik7XG4gICAgICB0cnkge1xuICAgICAgICB0aGlzLmZvY3VzZWRFbGVtZW50LmZvY3VzKHsgcHJldmVudFNjcm9sbDogdHJ1ZSB9KTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdGhpcy5jb25maWcubG9ncy5lcnJvcnMgJiYgY29uc29sZS53YXJuKFwiZXJyb3IgcmVzdG9yaW5nIGZvY3VzXCIsIGUpO1xuICAgICAgfVxuICAgICAgdGhpcy5mb2N1c2VkRWxlbWVudCA9IHZvaWQgMDtcbiAgICB9XG4gIH1cbiAgYWRkRHluYW1pY1J1bGVzKCkge1xuICAgIGR5bmFtaWNDTVBzLmZvckVhY2goKENtcCkgPT4ge1xuICAgICAgdGhpcy5ydWxlcy5wdXNoKG5ldyBDbXAodGhpcykpO1xuICAgIH0pO1xuICB9XG4gIHBhcnNlRGVjbGFyYXRpdmVSdWxlcyhkZWNsYXJhdGl2ZVJ1bGVzKSB7XG4gICAgaWYgKGRlY2xhcmF0aXZlUnVsZXMuY29uc2VudG9tYXRpYykge1xuICAgICAgZm9yIChjb25zdCBbbmFtZSwgcnVsZV0gb2YgT2JqZWN0LmVudHJpZXMoZGVjbGFyYXRpdmVSdWxlcy5jb25zZW50b21hdGljKSkge1xuICAgICAgICB0aGlzLmFkZENvbnNlbnRvbWF0aWNDTVAobmFtZSwgcnVsZSk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChkZWNsYXJhdGl2ZVJ1bGVzLmF1dG9jb25zZW50KSB7XG4gICAgICBkZWNsYXJhdGl2ZVJ1bGVzLmF1dG9jb25zZW50LmZvckVhY2goKHJ1bGVzZXQpID0+IHtcbiAgICAgICAgdGhpcy5hZGREZWNsYXJhdGl2ZUNNUChydWxlc2V0KTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoZGVjbGFyYXRpdmVSdWxlcy5jb21wYWN0KSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBydWxlcyA9IGRlY29kZVJ1bGVzKGRlY2xhcmF0aXZlUnVsZXMuY29tcGFjdCk7XG4gICAgICAgIHJ1bGVzLmZvckVhY2godGhpcy5hZGREZWNsYXJhdGl2ZUNNUC5iaW5kKHRoaXMpKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdGhpcy5jb25maWcubG9ncy5lcnJvcnMgJiYgY29uc29sZS5lcnJvcihlKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgYWRkRGVjbGFyYXRpdmVDTVAocnVsZXNldCkge1xuICAgIGlmICgocnVsZXNldC5taW5pbXVtUnVsZVN0ZXBWZXJzaW9uIHx8IDEpIDw9IFNVUFBPUlRFRF9SVUxFX1NURVBfVkVSU0lPTikge1xuICAgICAgdGhpcy5ydWxlcy5wdXNoKG5ldyBBdXRvQ29uc2VudENNUChydWxlc2V0LCB0aGlzKSk7XG4gICAgfVxuICB9XG4gIGFkZENvbnNlbnRvbWF0aWNDTVAobmFtZSwgY29uZmlnKSB7XG4gICAgdGhpcy5ydWxlcy5wdXNoKG5ldyBDb25zZW50T01hdGljQ01QKGBjb21fJHtuYW1lfWAsIGNvbmZpZykpO1xuICB9XG4gIC8vIHN0YXJ0IHRoZSBkZXRlY3Rpb24gcHJvY2VzcywgcG9zc2libHkgd2l0aCBhIGRlbGF5XG4gIHN0YXJ0KCkge1xuICAgIHNjaGVkdWxlV2hlbklkbGUoKCkgPT4gdGhpcy5fc3RhcnQoKSk7XG4gIH1cbiAgYXN5bmMgX3N0YXJ0KCkge1xuICAgIGNvbnN0IGxvZ3NDb25maWcgPSB0aGlzLmNvbmZpZy5sb2dzO1xuICAgIGxvZ3NDb25maWcubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKGBEZXRlY3RpbmcgQ01QcyBvbiAke3dpbmRvdy5sb2NhdGlvbi5ocmVmfWApO1xuICAgIHRoaXMudXBkYXRlU3RhdGUoeyBsaWZlY3ljbGU6IFwic3RhcnRlZFwiIH0pO1xuICAgIGNvbnN0IGZvdW5kQ21wcyA9IGF3YWl0IHRoaXMuZmluZENtcCh0aGlzLmNvbmZpZy5kZXRlY3RSZXRyaWVzKTtcbiAgICB0aGlzLnVwZGF0ZVN0YXRlKHsgZGV0ZWN0ZWRDbXBzOiBmb3VuZENtcHMubWFwKChjKSA9PiBjLm5hbWUpIH0pO1xuICAgIGlmIChmb3VuZENtcHMubGVuZ3RoID09PSAwKSB7XG4gICAgICBsb2dzQ29uZmlnLmxpZmVjeWNsZSAmJiBjb25zb2xlLmxvZyhcIm5vIENNUCBmb3VuZFwiLCBsb2NhdGlvbi5ocmVmKTtcbiAgICAgIGlmICh0aGlzLnNob3VsZFByZWhpZGUpIHtcbiAgICAgICAgdGhpcy51bmRvUHJlaGlkZSgpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXMuZmlsdGVyTGlzdEZhbGxiYWNrKCk7XG4gICAgfVxuICAgIHRoaXMudXBkYXRlU3RhdGUoeyBsaWZlY3ljbGU6IFwiY21wRGV0ZWN0ZWRcIiB9KTtcbiAgICBjb25zdCBzdGF0aWNDbXBzID0gW107XG4gICAgY29uc3QgY29zbWV0aWNDbXBzID0gW107XG4gICAgZm9yIChjb25zdCBjbXAgb2YgZm91bmRDbXBzKSB7XG4gICAgICBpZiAoY21wLmlzQ29zbWV0aWMpIHtcbiAgICAgICAgY29zbWV0aWNDbXBzLnB1c2goY21wKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHN0YXRpY0NtcHMucHVzaChjbXApO1xuICAgICAgfVxuICAgIH1cbiAgICBsZXQgcmVzdWx0ID0gZmFsc2U7XG4gICAgbGV0IGZvdW5kUG9wdXBzID0gYXdhaXQgdGhpcy5kZXRlY3RQb3B1cHMoc3RhdGljQ21wcywgYXN5bmMgKGNtcCkgPT4ge1xuICAgICAgcmVzdWx0ID0gYXdhaXQgdGhpcy5oYW5kbGVQb3B1cChjbXApO1xuICAgIH0pO1xuICAgIGlmIChmb3VuZFBvcHVwcy5sZW5ndGggPT09IDApIHtcbiAgICAgIGZvdW5kUG9wdXBzID0gYXdhaXQgdGhpcy5kZXRlY3RQb3B1cHMoY29zbWV0aWNDbXBzLCBhc3luYyAoY21wKSA9PiB7XG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IHRoaXMuaGFuZGxlUG9wdXAoY21wKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoZm91bmRQb3B1cHMubGVuZ3RoID09PSAwKSB7XG4gICAgICBsb2dzQ29uZmlnLmxpZmVjeWNsZSAmJiBjb25zb2xlLmxvZyhcIm5vIHBvcHVwIGZvdW5kXCIpO1xuICAgICAgaWYgKHRoaXMuc2hvdWxkUHJlaGlkZSkge1xuICAgICAgICB0aGlzLnVuZG9QcmVoaWRlKCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmIChmb3VuZFBvcHVwcy5sZW5ndGggPiAxKSB7XG4gICAgICBjb25zdCBlcnJvckRldGFpbHMgPSB7XG4gICAgICAgIG1zZzogYEZvdW5kIG11bHRpcGxlIENNUHMsIGNoZWNrIHRoZSBkZXRlY3Rpb24gcnVsZXMuYCxcbiAgICAgICAgY21wczogZm91bmRQb3B1cHMubWFwKChjbXApID0+IGNtcC5uYW1lKVxuICAgICAgfTtcbiAgICAgIGxvZ3NDb25maWcuZXJyb3JzICYmIGNvbnNvbGUud2FybihlcnJvckRldGFpbHMubXNnLCBlcnJvckRldGFpbHMuY21wcyk7XG4gICAgICB0aGlzLnNlbmRDb250ZW50TWVzc2FnZSh7XG4gICAgICAgIHR5cGU6IFwiYXV0b2NvbnNlbnRFcnJvclwiLFxuICAgICAgICBkZXRhaWxzOiBlcnJvckRldGFpbHNcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIGFzeW5jIGZpbmRDbXAocmV0cmllcykge1xuICAgIGNvbnN0IGxvZ3NDb25maWcgPSB0aGlzLmNvbmZpZy5sb2dzO1xuICAgIHRoaXMudXBkYXRlU3RhdGUoeyBmaW5kQ21wQXR0ZW1wdHM6IHRoaXMuc3RhdGUuZmluZENtcEF0dGVtcHRzICsgMSB9KTtcbiAgICBjb25zdCBmb3VuZENNUHMgPSBbXTtcbiAgICBjb25zdCBpc1RvcCA9IGlzVG9wRnJhbWUoKTtcbiAgICBjb25zdCBzaXRlU3BlY2lmaWNSdWxlcyA9IFtdO1xuICAgIGNvbnN0IGdlbmVyaWNSdWxlcyA9IFtdO1xuICAgIHRoaXMucnVsZXMuZm9yRWFjaCgoY21wKSA9PiB7XG4gICAgICBpZiAoY21wLmNoZWNrRnJhbWVDb250ZXh0KGlzVG9wKSkge1xuICAgICAgICBjb25zdCBpc1NpdGVTcGVjaWZpYyA9ICEhY21wLnJ1bkNvbnRleHQudXJsUGF0dGVybjtcbiAgICAgICAgaWYgKGNtcC5oYXNNYXRjaGluZ1VybFBhdHRlcm4oKSkge1xuICAgICAgICAgIHNpdGVTcGVjaWZpY1J1bGVzLnB1c2goY21wKTtcbiAgICAgICAgfSBlbHNlIGlmICghaXNTaXRlU3BlY2lmaWMpIHtcbiAgICAgICAgICBnZW5lcmljUnVsZXMucHVzaChjbXApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG4gICAgY29uc3QgaGV1cmlzdGljUnVsZXMgPSBpc1RvcCAmJiB0aGlzLmNvbmZpZy5lbmFibGVIZXVyaXN0aWNBY3Rpb24gPyBbbmV3IEF1dG9Db25zZW50SGV1cmlzdGljQ01QKHRoaXMpXSA6IFtdO1xuICAgIGNvbnN0IHJ1bGVzUHJpb3JpdHlTdGFnZXMgPSBbXG4gICAgICBbXCJzaXRlLXNwZWNpZmljXCIsIHNpdGVTcGVjaWZpY1J1bGVzXSxcbiAgICAgIFtcImdlbmVyaWNcIiwgZ2VuZXJpY1J1bGVzXSxcbiAgICAgIFtcImhldXJpc3RpY1wiLCBoZXVyaXN0aWNSdWxlc11cbiAgICBdO1xuICAgIGNvbnN0IHJ1bkRldGVjdENtcCA9IGFzeW5jIChjbXApID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNtcC5kZXRlY3RDbXAoKTtcbiAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgIGxvZ3NDb25maWcubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKGBGb3VuZCBDTVA6ICR7Y21wLm5hbWV9ICR7d2luZG93LmxvY2F0aW9uLmhyZWZ9YCk7XG4gICAgICAgICAgdGhpcy5zZW5kQ29udGVudE1lc3NhZ2Uoe1xuICAgICAgICAgICAgdHlwZTogXCJjbXBEZXRlY3RlZFwiLFxuICAgICAgICAgICAgdXJsOiBsb2NhdGlvbi5ocmVmLFxuICAgICAgICAgICAgY21wOiBjbXAubmFtZVxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGZvdW5kQ01Qcy5wdXNoKGNtcCk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgbG9nc0NvbmZpZy5lcnJvcnMgJiYgY29uc29sZS53YXJuKGBlcnJvciBkZXRlY3RpbmcgJHtjbXAubmFtZX1gLCBlKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IG11dGF0aW9uT2JzZXJ2ZXIgPSB0aGlzLmRvbUFjdGlvbnMud2FpdEZvck11dGF0aW9uKFwiaHRtbFwiKTtcbiAgICBtdXRhdGlvbk9ic2VydmVyLmNhdGNoKCgpID0+IHtcbiAgICB9KTtcbiAgICBmb3IgKGNvbnN0IFtzdGFnZU5hbWUsIHJ1bGVHcm91cF0gb2YgcnVsZXNQcmlvcml0eVN0YWdlcykge1xuICAgICAgbG9nc0NvbmZpZy5saWZlY3ljbGUgJiYgcnVsZUdyb3VwLmxlbmd0aCA+IDAgJiYgY29uc29sZS5sb2coXG4gICAgICAgIGBUcnlpbmcgJHtzdGFnZU5hbWV9IHJ1bGVzYCxcbiAgICAgICAgcnVsZUdyb3VwLm1hcCgocikgPT4gci5uYW1lKVxuICAgICAgKTtcbiAgICAgIGF3YWl0IFByb21pc2UuYWxsKHJ1bGVHcm91cC5tYXAocnVuRGV0ZWN0Q21wKSk7XG4gICAgICBpZiAoZm91bmRDTVBzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMuZGV0ZWN0SGV1cmlzdGljcygpO1xuICAgIGlmIChmb3VuZENNUHMubGVuZ3RoID09PSAwICYmIHJldHJpZXMgPiAwKSB7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBQcm9taXNlLmFsbChbdGhpcy5kb21BY3Rpb25zLndhaXQoNTAwKSwgbXV0YXRpb25PYnNlcnZlcl0pO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICByZXR1cm4gW107XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5maW5kQ21wKHJldHJpZXMgLSAxKTtcbiAgICB9XG4gICAgcmV0dXJuIGZvdW5kQ01QcztcbiAgfVxuICBkZXRlY3RIZXVyaXN0aWNzKCkge1xuICAgIGlmICh0aGlzLmNvbmZpZy5lbmFibGVIZXVyaXN0aWNEZXRlY3Rpb24pIHtcbiAgICAgIGNvbnN0IHsgcGF0dGVybnMsIHNuaXBwZXRzOiBzbmlwcGV0czIgfSA9IGNoZWNrSGV1cmlzdGljUGF0dGVybnMoZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50Py5pbm5lclRleHQgfHwgXCJcIik7XG4gICAgICBpZiAocGF0dGVybnMubGVuZ3RoID4gMCAmJiAocGF0dGVybnMubGVuZ3RoICE9PSB0aGlzLnN0YXRlLmhldXJpc3RpY1BhdHRlcm5zLmxlbmd0aCB8fCB0aGlzLnN0YXRlLmhldXJpc3RpY1BhdHRlcm5zLnNvbWUoKHAsIGkpID0+IHAgIT09IHBhdHRlcm5zW2ldKSkpIHtcbiAgICAgICAgdGhpcy5jb25maWcubG9ncy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coXCJIZXVyaXN0aWMgcGF0dGVybnMgZm91bmRcIiwgcGF0dGVybnMsIHNuaXBwZXRzMik7XG4gICAgICAgIHRoaXMudXBkYXRlU3RhdGUoeyBoZXVyaXN0aWNQYXR0ZXJuczogcGF0dGVybnMsIGhldXJpc3RpY1NuaXBwZXRzOiBzbmlwcGV0czIgfSk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBEZXRlY3QgaWYgYSBDTVAgaGFzIGEgcG9wdXAgb3Blbi4gRnVsbGZpbHMgd2l0aCB0aGUgQ01QIGlmIGEgcG9wdXAgaXMgb3Blbiwgb3RoZXJ3aXNlIHJlamVjdHMuXG4gICAqL1xuICBhc3luYyBkZXRlY3RQb3B1cChjbXApIHtcbiAgICBjb25zdCBpc09wZW4gPSBhd2FpdCB0aGlzLndhaXRGb3JQb3B1cChjbXApLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgdGhpcy5jb25maWcubG9ncy5lcnJvcnMgJiYgY29uc29sZS53YXJuKGBlcnJvciB3YWl0aW5nIGZvciBhIHBvcHVwIGZvciAke2NtcC5uYW1lfWAsIGVycm9yKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9KTtcbiAgICBpZiAoaXNPcGVuKSB7XG4gICAgICB0aGlzLnVwZGF0ZVN0YXRlKHsgZGV0ZWN0ZWRQb3B1cHM6IHRoaXMuc3RhdGUuZGV0ZWN0ZWRQb3B1cHMuY29uY2F0KFtjbXAubmFtZV0pIH0pO1xuICAgICAgdGhpcy5zZW5kQ29udGVudE1lc3NhZ2Uoe1xuICAgICAgICB0eXBlOiBcInBvcHVwRm91bmRcIixcbiAgICAgICAgY21wOiBjbXAubmFtZSxcbiAgICAgICAgdXJsOiBsb2NhdGlvbi5ocmVmXG4gICAgICB9KTtcbiAgICAgIHJldHVybiBjbXA7XG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcihcIlBvcHVwIGlzIG5vdCBzaG93blwiKTtcbiAgfVxuICAvKipcbiAgICogRGV0ZWN0IGlmIGFueSBvZiB0aGUgQ01QcyBoYXMgYSBwb3B1cCBvcGVuLiBSZXR1cm5zIGEgbGlzdCBvZiBDTVBzIHdpdGggb3BlbiBwb3B1cHMuXG4gICAqL1xuICBhc3luYyBkZXRlY3RQb3B1cHMoY21wcywgb25GaXJzdFBvcHVwQXBwZWFycykge1xuICAgIGNvbnN0IHRhc2tzID0gY21wcy5tYXAoKGNtcCkgPT4gdGhpcy5kZXRlY3RQb3B1cChjbXApKTtcbiAgICBhd2FpdCBQcm9taXNlLmFueSh0YXNrcykudGhlbigoY21wKSA9PiB7XG4gICAgICB0aGlzLmRldGVjdEhldXJpc3RpY3MoKTtcbiAgICAgIG9uRmlyc3RQb3B1cEFwcGVhcnMoY21wKTtcbiAgICB9KS5jYXRjaCgoKSA9PiB7XG4gICAgfSk7XG4gICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IFByb21pc2UuYWxsU2V0dGxlZCh0YXNrcyk7XG4gICAgY29uc3QgcG9wdXBzID0gW107XG4gICAgZm9yIChjb25zdCByZXN1bHQgb2YgcmVzdWx0cykge1xuICAgICAgaWYgKHJlc3VsdC5zdGF0dXMgPT09IFwiZnVsZmlsbGVkXCIpIHtcbiAgICAgICAgcG9wdXBzLnB1c2gocmVzdWx0LnZhbHVlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHBvcHVwcztcbiAgfVxuICBhc3luYyBoYW5kbGVQb3B1cChjbXApIHtcbiAgICB0aGlzLnVwZGF0ZVN0YXRlKHsgbGlmZWN5Y2xlOiBcIm9wZW5Qb3B1cERldGVjdGVkXCIsIHN0YXJ0VGltZTogRGF0ZS5ub3coKSB9KTtcbiAgICBpZiAodGhpcy5zaG91bGRQcmVoaWRlICYmICF0aGlzLnN0YXRlLnByZWhpZGVPbikge1xuICAgICAgdGhpcy5wcmVoaWRlRWxlbWVudHMoKTtcbiAgICB9XG4gICAgaWYgKHRoaXMuc3RhdGUuY29zbWV0aWNGaWx0ZXJzT24pIHtcbiAgICAgIHRoaXMudW5kb0Nvc21ldGljcygpO1xuICAgIH1cbiAgICB0aGlzLmZvdW5kQ21wID0gY21wO1xuICAgIGlmICh0aGlzLmNvbmZpZy5hdXRvQWN0aW9uID09PSBcIm9wdE91dFwiKSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5kb09wdE91dCgpO1xuICAgIH0gZWxzZSBpZiAodGhpcy5jb25maWcuYXV0b0FjdGlvbiA9PT0gXCJvcHRJblwiKSB7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5kb09wdEluKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuY29uZmlnLmxvZ3MubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKFwid2FpdGluZyBmb3Igb3B0LW91dCBzaWduYWwuLi5cIiwgbG9jYXRpb24uaHJlZik7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH1cbiAgYXN5bmMgZG9PcHRPdXQoKSB7XG4gICAgY29uc3QgbG9nc0NvbmZpZyA9IHRoaXMuY29uZmlnLmxvZ3M7XG4gICAgdGhpcy51cGRhdGVTdGF0ZSh7IGxpZmVjeWNsZTogXCJydW5uaW5nT3B0T3V0XCIgfSk7XG4gICAgdGhpcy5zYXZlRm9jdXMoKTtcbiAgICBsZXQgb3B0T3V0UmVzdWx0O1xuICAgIGlmICghdGhpcy5mb3VuZENtcCkge1xuICAgICAgbG9nc0NvbmZpZy5lcnJvcnMgJiYgY29uc29sZS5sb2coXCJubyBDTVAgdG8gb3B0IG91dFwiKTtcbiAgICAgIG9wdE91dFJlc3VsdCA9IGZhbHNlO1xuICAgIH0gZWxzZSB7XG4gICAgICBsb2dzQ29uZmlnLmxpZmVjeWNsZSAmJiBjb25zb2xlLmxvZyhgQ01QICR7dGhpcy5mb3VuZENtcC5uYW1lfTogb3B0IG91dCBvbiAke3dpbmRvdy5sb2NhdGlvbi5ocmVmfWApO1xuICAgICAgb3B0T3V0UmVzdWx0ID0gYXdhaXQgdGhpcy5mb3VuZENtcC5vcHRPdXQoKTtcbiAgICAgIGxvZ3NDb25maWcubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKGAke3RoaXMuZm91bmRDbXAubmFtZX06IG9wdCBvdXQgcmVzdWx0ICR7b3B0T3V0UmVzdWx0fWApO1xuICAgIH1cbiAgICBpZiAodGhpcy5zaG91bGRQcmVoaWRlKSB7XG4gICAgICB0aGlzLnVuZG9QcmVoaWRlKCk7XG4gICAgfVxuICAgIHRoaXMuc2VuZENvbnRlbnRNZXNzYWdlKHtcbiAgICAgIHR5cGU6IFwib3B0T3V0UmVzdWx0XCIsXG4gICAgICBjbXA6IHRoaXMuZm91bmRDbXAgPyB0aGlzLmZvdW5kQ21wLm5hbWUgOiBcIm5vbmVcIixcbiAgICAgIHJlc3VsdDogb3B0T3V0UmVzdWx0LFxuICAgICAgc2NoZWR1bGVTZWxmVGVzdDogQm9vbGVhbih0aGlzLmZvdW5kQ21wICYmIHRoaXMuZm91bmRDbXAuaGFzU2VsZlRlc3QpLFxuICAgICAgdXJsOiBsb2NhdGlvbi5ocmVmXG4gICAgfSk7XG4gICAgaWYgKG9wdE91dFJlc3VsdCAmJiB0aGlzLmZvdW5kQ21wICYmICF0aGlzLmZvdW5kQ21wLmlzSW50ZXJtZWRpYXRlKSB7XG4gICAgICB0aGlzLnN0YXRlLmVuZFRpbWUgPSBEYXRlLm5vdygpO1xuICAgICAgbG9nc0NvbmZpZy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coXG4gICAgICAgIGAke3RoaXMuZm91bmRDbXAubmFtZX06IGRvbmUgaW4gJHt0aGlzLnN0YXRlLmVuZFRpbWUgLSB0aGlzLnN0YXRlLnN0YXJ0VGltZX1tcyB3aXRoICR7dGhpcy5zdGF0ZS5jbGlja3N9IGNsaWNrc2BcbiAgICAgICk7XG4gICAgICB0aGlzLnNlbmRDb250ZW50TWVzc2FnZSh7XG4gICAgICAgIHR5cGU6IFwiYXV0b2NvbnNlbnREb25lXCIsXG4gICAgICAgIGNtcDogdGhpcy5mb3VuZENtcD8ubmFtZSxcbiAgICAgICAgaXNDb3NtZXRpYzogdGhpcy5mb3VuZENtcD8uaXNDb3NtZXRpYyxcbiAgICAgICAgdXJsOiBsb2NhdGlvbi5ocmVmLFxuICAgICAgICBkdXJhdGlvbjogdGhpcy5zdGF0ZS5lbmRUaW1lIC0gdGhpcy5zdGF0ZS5zdGFydFRpbWUsXG4gICAgICAgIHRvdGFsQ2xpY2tzOiB0aGlzLnN0YXRlLmNsaWNrc1xuICAgICAgfSk7XG4gICAgICB0aGlzLnVwZGF0ZVN0YXRlKHsgbGlmZWN5Y2xlOiBcImRvbmVcIiB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy51cGRhdGVTdGF0ZSh7IGxpZmVjeWNsZTogb3B0T3V0UmVzdWx0ID8gXCJvcHRPdXRTdWNjZWVkZWRcIiA6IFwib3B0T3V0RmFpbGVkXCIgfSk7XG4gICAgfVxuICAgIHRoaXMucmVzdG9yZUZvY3VzKCk7XG4gICAgcmV0dXJuIG9wdE91dFJlc3VsdDtcbiAgfVxuICBhc3luYyBkb09wdEluKCkge1xuICAgIGNvbnN0IGxvZ3NDb25maWcgPSB0aGlzLmNvbmZpZy5sb2dzO1xuICAgIHRoaXMudXBkYXRlU3RhdGUoeyBsaWZlY3ljbGU6IFwicnVubmluZ09wdEluXCIgfSk7XG4gICAgdGhpcy5zYXZlRm9jdXMoKTtcbiAgICBsZXQgb3B0SW5SZXN1bHQ7XG4gICAgaWYgKCF0aGlzLmZvdW5kQ21wKSB7XG4gICAgICBsb2dzQ29uZmlnLmVycm9ycyAmJiBjb25zb2xlLmxvZyhcIm5vIENNUCB0byBvcHQgaW5cIik7XG4gICAgICBvcHRJblJlc3VsdCA9IGZhbHNlO1xuICAgIH0gZWxzZSB7XG4gICAgICBsb2dzQ29uZmlnLmxpZmVjeWNsZSAmJiBjb25zb2xlLmxvZyhgQ01QICR7dGhpcy5mb3VuZENtcC5uYW1lfTogb3B0IGluIG9uICR7d2luZG93LmxvY2F0aW9uLmhyZWZ9YCk7XG4gICAgICBvcHRJblJlc3VsdCA9IGF3YWl0IHRoaXMuZm91bmRDbXAub3B0SW4oKTtcbiAgICAgIGxvZ3NDb25maWcubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKGAke3RoaXMuZm91bmRDbXAubmFtZX06IG9wdCBpbiByZXN1bHQgJHtvcHRJblJlc3VsdH1gKTtcbiAgICB9XG4gICAgaWYgKHRoaXMuc2hvdWxkUHJlaGlkZSkge1xuICAgICAgdGhpcy51bmRvUHJlaGlkZSgpO1xuICAgIH1cbiAgICB0aGlzLnNlbmRDb250ZW50TWVzc2FnZSh7XG4gICAgICB0eXBlOiBcIm9wdEluUmVzdWx0XCIsXG4gICAgICBjbXA6IHRoaXMuZm91bmRDbXAgPyB0aGlzLmZvdW5kQ21wLm5hbWUgOiBcIm5vbmVcIixcbiAgICAgIHJlc3VsdDogb3B0SW5SZXN1bHQsXG4gICAgICBzY2hlZHVsZVNlbGZUZXN0OiBmYWxzZSxcbiAgICAgIC8vIHNlbGYtdGVzdHMgYXJlIG9ubHkgZm9yIG9wdC1vdXQgYXQgdGhlIG1vbWVudFxuICAgICAgdXJsOiBsb2NhdGlvbi5ocmVmXG4gICAgfSk7XG4gICAgaWYgKG9wdEluUmVzdWx0ICYmIHRoaXMuZm91bmRDbXAgJiYgIXRoaXMuZm91bmRDbXAuaXNJbnRlcm1lZGlhdGUpIHtcbiAgICAgIHRoaXMuc3RhdGUuZW5kVGltZSA9IERhdGUubm93KCk7XG4gICAgICBsb2dzQ29uZmlnLmxpZmVjeWNsZSAmJiBjb25zb2xlLmxvZyhcbiAgICAgICAgYCR7dGhpcy5mb3VuZENtcC5uYW1lfTogZG9uZSBpbiAke3RoaXMuc3RhdGUuZW5kVGltZSAtIHRoaXMuc3RhdGUuc3RhcnRUaW1lfW1zIHdpdGggJHt0aGlzLnN0YXRlLmNsaWNrc30gY2xpY2tzYFxuICAgICAgKTtcbiAgICAgIHRoaXMuc2VuZENvbnRlbnRNZXNzYWdlKHtcbiAgICAgICAgdHlwZTogXCJhdXRvY29uc2VudERvbmVcIixcbiAgICAgICAgY21wOiB0aGlzLmZvdW5kQ21wLm5hbWUsXG4gICAgICAgIGlzQ29zbWV0aWM6IHRoaXMuZm91bmRDbXAuaXNDb3NtZXRpYyxcbiAgICAgICAgdXJsOiBsb2NhdGlvbi5ocmVmLFxuICAgICAgICBkdXJhdGlvbjogdGhpcy5zdGF0ZS5lbmRUaW1lIC0gdGhpcy5zdGF0ZS5zdGFydFRpbWUsXG4gICAgICAgIHRvdGFsQ2xpY2tzOiB0aGlzLnN0YXRlLmNsaWNrc1xuICAgICAgfSk7XG4gICAgICB0aGlzLnVwZGF0ZVN0YXRlKHsgbGlmZWN5Y2xlOiBcImRvbmVcIiB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy51cGRhdGVTdGF0ZSh7IGxpZmVjeWNsZTogb3B0SW5SZXN1bHQgPyBcIm9wdEluU3VjY2VlZGVkXCIgOiBcIm9wdEluRmFpbGVkXCIgfSk7XG4gICAgfVxuICAgIHRoaXMucmVzdG9yZUZvY3VzKCk7XG4gICAgcmV0dXJuIG9wdEluUmVzdWx0O1xuICB9XG4gIGFzeW5jIGRvU2VsZlRlc3QoKSB7XG4gICAgY29uc3QgbG9nc0NvbmZpZyA9IHRoaXMuY29uZmlnLmxvZ3M7XG4gICAgbGV0IHNlbGZUZXN0UmVzdWx0O1xuICAgIGlmICghdGhpcy5mb3VuZENtcCkge1xuICAgICAgbG9nc0NvbmZpZy5lcnJvcnMgJiYgY29uc29sZS5sb2coXCJubyBDTVAgdG8gc2VsZiB0ZXN0XCIpO1xuICAgICAgc2VsZlRlc3RSZXN1bHQgPSBmYWxzZTtcbiAgICB9IGVsc2Uge1xuICAgICAgbG9nc0NvbmZpZy5saWZlY3ljbGUgJiYgY29uc29sZS5sb2coYENNUCAke3RoaXMuZm91bmRDbXAubmFtZX06IHNlbGYtdGVzdCBvbiAke3dpbmRvdy5sb2NhdGlvbi5ocmVmfWApO1xuICAgICAgc2VsZlRlc3RSZXN1bHQgPSBhd2FpdCB0aGlzLmZvdW5kQ21wLnRlc3QoKTtcbiAgICB9XG4gICAgdGhpcy5zZW5kQ29udGVudE1lc3NhZ2Uoe1xuICAgICAgdHlwZTogXCJzZWxmVGVzdFJlc3VsdFwiLFxuICAgICAgY21wOiB0aGlzLmZvdW5kQ21wID8gdGhpcy5mb3VuZENtcC5uYW1lIDogXCJub25lXCIsXG4gICAgICByZXN1bHQ6IHNlbGZUZXN0UmVzdWx0LFxuICAgICAgdXJsOiBsb2NhdGlvbi5ocmVmXG4gICAgfSk7XG4gICAgdGhpcy51cGRhdGVTdGF0ZSh7IHNlbGZUZXN0OiBzZWxmVGVzdFJlc3VsdCB9KTtcbiAgICByZXR1cm4gc2VsZlRlc3RSZXN1bHQ7XG4gIH1cbiAgLy8gVE9ETzogdXNlIE11dGF0aW9uT2JzZXJ2ZXIgbGlrZSBpbiBmaW5kQ21wKClcbiAgYXN5bmMgd2FpdEZvclBvcHVwKGNtcCwgcmV0cmllcyA9IDEwLCBpbnRlcnZhbCA9IDUwMCkge1xuICAgIGNvbnN0IGxvZ3NDb25maWcgPSB0aGlzLmNvbmZpZy5sb2dzO1xuICAgIGxvZ3NDb25maWcubGlmZWN5Y2xlICYmIGNvbnNvbGUubG9nKFwiY2hlY2tpbmcgaWYgcG9wdXAgaXMgb3Blbi4uLlwiLCBjbXAubmFtZSk7XG4gICAgY29uc3QgaXNPcGVuID0gYXdhaXQgY21wLmRldGVjdFBvcHVwKCkuY2F0Y2goKGUpID0+IHtcbiAgICAgIGxvZ3NDb25maWcuZXJyb3JzICYmIGNvbnNvbGUud2FybihgZXJyb3IgZGV0ZWN0aW5nIHBvcHVwIGZvciAke2NtcC5uYW1lfWAsIGUpO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0pO1xuICAgIGlmICghaXNPcGVuICYmIHJldHJpZXMgPiAwKSB7XG4gICAgICBhd2FpdCB0aGlzLmRvbUFjdGlvbnMud2FpdChpbnRlcnZhbCk7XG4gICAgICByZXR1cm4gdGhpcy53YWl0Rm9yUG9wdXAoY21wLCByZXRyaWVzIC0gMSwgaW50ZXJ2YWwpO1xuICAgIH1cbiAgICBsb2dzQ29uZmlnLmxpZmVjeWNsZSAmJiBjb25zb2xlLmxvZyhjbXAubmFtZSwgYHBvcHVwIGlzICR7aXNPcGVuID8gXCJvcGVuXCIgOiBcIm5vdCBvcGVuXCJ9YCk7XG4gICAgcmV0dXJuIGlzT3BlbjtcbiAgfVxuICBwcmVoaWRlRWxlbWVudHMoKSB7XG4gICAgY29uc3QgbG9nc0NvbmZpZyA9IHRoaXMuY29uZmlnLmxvZ3M7XG4gICAgY29uc3QgZ2xvYmFsSGlkZGVuID0gW1xuICAgICAgXCIjZGlkb21pLXBvcHVwLC5kaWRvbWktcG9wdXAtY29udGFpbmVyLC5kaWRvbWktcG9wdXAtbm90aWNlLC5kaWRvbWktY29uc2VudC1wb3B1cC1wcmVmZXJlbmNlcywjZGlkb21pLW5vdGljZSwuZGlkb21pLXBvcHVwLWJhY2tkcm9wLC5kaWRvbWktc2NyZWVuLW1lZGl1bVwiXG4gICAgXTtcbiAgICBjb25zdCBzZWxlY3RvcnMgPSB0aGlzLnJ1bGVzLmZpbHRlcigocnVsZSkgPT4gcnVsZS5wcmVoaWRlU2VsZWN0b3JzICYmIHJ1bGUuY2hlY2tSdW5Db250ZXh0KCkpLnJlZHVjZSgoc2VsZWN0b3JMaXN0LCBydWxlKSA9PiBbLi4uc2VsZWN0b3JMaXN0IHx8IFtdLCAuLi5ydWxlLnByZWhpZGVTZWxlY3RvcnMgfHwgW11dLCBnbG9iYWxIaWRkZW4pO1xuICAgIHRoaXMudXBkYXRlU3RhdGUoeyBwcmVoaWRlT246IHRydWUgfSk7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBpZiAodGhpcy5zaG91bGRQcmVoaWRlICYmIHRoaXMuc3RhdGUucHJlaGlkZU9uICYmICFbXCJydW5uaW5nT3B0T3V0XCIsIFwicnVubmluZ09wdEluXCJdLmluY2x1ZGVzKHRoaXMuc3RhdGUubGlmZWN5Y2xlKSkge1xuICAgICAgICBsb2dzQ29uZmlnLmxpZmVjeWNsZSAmJiBjb25zb2xlLmxvZyhcIlByb2Nlc3MgaXMgdGFraW5nIHRvbyBsb25nLCB1bmhpZGluZyBlbGVtZW50c1wiKTtcbiAgICAgICAgdGhpcy51bmRvUHJlaGlkZSgpO1xuICAgICAgfVxuICAgIH0sIHRoaXMuY29uZmlnLnByZWhpZGVUaW1lb3V0IHx8IDJlMyk7XG4gICAgcmV0dXJuIHRoaXMuZG9tQWN0aW9ucy5wcmVoaWRlKHNlbGVjdG9ycy5qb2luKFwiLFwiKSk7XG4gIH1cbiAgdW5kb1ByZWhpZGUoKSB7XG4gICAgdGhpcy51cGRhdGVTdGF0ZSh7IHByZWhpZGVPbjogZmFsc2UgfSk7XG4gICAgdGhpcy5kb21BY3Rpb25zLnVuZG9QcmVoaWRlKCk7XG4gIH1cbiAgdW5kb0Nvc21ldGljcygpIHtcbiAgfVxuICByZXBvcnRGaWx0ZXJsaXN0KCkge1xuICAgIHRoaXMuc2VuZENvbnRlbnRNZXNzYWdlKHtcbiAgICAgIHR5cGU6IFwiY21wRGV0ZWN0ZWRcIixcbiAgICAgIHVybDogbG9jYXRpb24uaHJlZixcbiAgICAgIGNtcDogXCJmaWx0ZXJMaXN0XCJcbiAgICB9KTtcbiAgICB0aGlzLnNlbmRDb250ZW50TWVzc2FnZSh7XG4gICAgICB0eXBlOiBcInBvcHVwRm91bmRcIixcbiAgICAgIGNtcDogXCJmaWx0ZXJMaXN0XCIsXG4gICAgICB1cmw6IGxvY2F0aW9uLmhyZWZcbiAgICB9KTtcbiAgICB0aGlzLnVwZGF0ZVN0YXRlKHsgZmlsdGVyTGlzdFJlcG9ydGVkOiB0cnVlIH0pO1xuICB9XG4gIGZpbHRlckxpc3RGYWxsYmFjaygpIHtcbiAgICB0aGlzLnVwZGF0ZVN0YXRlKHsgbGlmZWN5Y2xlOiBcIm5vdGhpbmdEZXRlY3RlZFwiIH0pO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICB1cGRhdGVTdGF0ZShjaGFuZ2UpIHtcbiAgICBPYmplY3QuYXNzaWduKHRoaXMuc3RhdGUsIGNoYW5nZSk7XG4gICAgdGhpcy5zZW5kQ29udGVudE1lc3NhZ2Uoe1xuICAgICAgdHlwZTogXCJyZXBvcnRcIixcbiAgICAgIGluc3RhbmNlSWQ6IHRoaXMuaWQsXG4gICAgICB1cmw6IHdpbmRvdy5sb2NhdGlvbi5ocmVmLFxuICAgICAgbWFpbkZyYW1lOiBpc1RvcEZyYW1lKCksXG4gICAgICBzdGF0ZTogdGhpcy5zdGF0ZVxuICAgIH0pO1xuICB9XG4gIGFzeW5jIHJlY2VpdmVNZXNzYWdlQ2FsbGJhY2sobWVzc2FnZSkge1xuICAgIGNvbnN0IGxvZ3NDb25maWcgPSBfX3ByaXZhdGVHZXQodGhpcywgX2NvbmZpZyk/LmxvZ3M7XG4gICAgaWYgKGxvZ3NDb25maWc/Lm1lc3NhZ2VzKSB7XG4gICAgICBjb25zb2xlLmxvZyhcInJlY2VpdmVkIGZyb20gYmFja2dyb3VuZFwiLCBtZXNzYWdlLCB3aW5kb3cubG9jYXRpb24uaHJlZik7XG4gICAgfVxuICAgIHN3aXRjaCAobWVzc2FnZS50eXBlKSB7XG4gICAgICBjYXNlIFwiaW5pdFJlc3BcIjpcbiAgICAgICAgdGhpcy5pbml0aWFsaXplKG1lc3NhZ2UuY29uZmlnLCBtZXNzYWdlLnJ1bGVzKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwib3B0SW5cIjpcbiAgICAgICAgYXdhaXQgdGhpcy5kb09wdEluKCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcIm9wdE91dFwiOlxuICAgICAgICBhd2FpdCB0aGlzLmRvT3B0T3V0KCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcInNlbGZUZXN0XCI6XG4gICAgICAgIGF3YWl0IHRoaXMuZG9TZWxmVGVzdCgpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJldmFsUmVzcFwiOlxuICAgICAgICByZXNvbHZlRXZhbChtZXNzYWdlLmlkLCBtZXNzYWdlLnJlc3VsdCk7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxufTtcbl9jb25maWcgPSBuZXcgV2Vha01hcCgpO1xuZXhwb3J0IHtcbiAgZGVjb2RlUnVsZXMsXG4gIEF1dG9Db25zZW50IGFzIGRlZmF1bHQsXG4gIGVuY29kZVJ1bGVzLFxuICBzbmlwcGV0cyBhcyBldmFsU25pcHBldHMsXG4gIGZpbHRlckNvbXBhY3RSdWxlc1xufTtcbiIsICJpbXBvcnQgQXV0b0NvbnNlbnQgZnJvbSAnQGR1Y2tkdWNrZ28vYXV0b2NvbnNlbnQnO1xuXG5jb25zdCBjb25zZW50ID0gbmV3IEF1dG9Db25zZW50KGFzeW5jIChtc2cpID0+IHtcbiAgICBhd2FpdCBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7XG4gICAgICAgIG1lc3NhZ2VUeXBlOiAnYXV0b2NvbnNlbnQnLFxuICAgICAgICBhdXRvY29uc2VudFBheWxvYWQ6IG1zZyxcbiAgICB9KTtcbn0pO1xuXG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1lc3NhZ2UpID0+IHtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGNvbnNlbnQucmVjZWl2ZU1lc3NhZ2VDYWxsYmFjayhtZXNzYWdlKSk7XG59KTtcbiJdLAogICJtYXBwaW5ncyI6ICI7OztBQUFBLE1BQUksY0FBYyxDQUFDLFFBQVE7QUFDekIsVUFBTSxVQUFVLEdBQUc7QUFBQSxFQUNyQjtBQUNBLE1BQUksZ0JBQWdCLENBQUMsS0FBSyxRQUFRLFFBQVEsT0FBTyxJQUFJLEdBQUcsS0FBSyxZQUFZLFlBQVksR0FBRztBQUN4RixNQUFJLGVBQWUsQ0FBQyxLQUFLLFFBQVEsWUFBWSxjQUFjLEtBQUssUUFBUSx5QkFBeUIsR0FBRyxTQUFTLE9BQU8sS0FBSyxHQUFHLElBQUksT0FBTyxJQUFJLEdBQUc7QUFDOUksTUFBSSxlQUFlLENBQUMsS0FBSyxRQUFRLFVBQVUsT0FBTyxJQUFJLEdBQUcsSUFBSSxZQUFZLG1EQUFtRCxJQUFJLGtCQUFrQixVQUFVLE9BQU8sSUFBSSxHQUFHLElBQUksT0FBTyxJQUFJLEtBQUssS0FBSztBQUNuTSxNQUFJLGVBQWUsQ0FBQyxLQUFLLFFBQVEsT0FBTyxZQUFZLGNBQWMsS0FBSyxRQUFRLHdCQUF3QixHQUFHLFNBQVMsT0FBTyxLQUFLLEtBQUssS0FBSyxJQUFJLE9BQU8sSUFBSSxLQUFLLEtBQUssR0FBRztBQUdySyxNQUFJLFNBQVMsTUFBTUEsUUFBTztBQUFBLElBQ3hCLE9BQU8sUUFBUSxNQUFNO0FBQ25CLE1BQUFBLFFBQU8sT0FBTztBQUFBLElBQ2hCO0FBQUEsSUFDQSxPQUFPLFlBQVksU0FBUyxTQUFTLE1BQU0sV0FBVyxPQUFPO0FBQzNELFVBQUksa0JBQWtCO0FBQ3RCLFVBQUksVUFBVSxNQUFNO0FBQ2xCLDBCQUFrQixNQUFNLEtBQUssT0FBTyxpQkFBaUIsUUFBUSxRQUFRLENBQUM7QUFBQSxNQUN4RSxPQUFPO0FBQ0wsWUFBSUEsUUFBTyxRQUFRLE1BQU07QUFDdkIsNEJBQWtCLE1BQU07QUFBQSxZQUN0QkEsUUFBTyxLQUFLLGlCQUFpQixRQUFRLFFBQVE7QUFBQSxVQUMvQztBQUFBLFFBQ0YsT0FBTztBQUNMLDRCQUFrQixNQUFNO0FBQUEsWUFDdEIsU0FBUyxpQkFBaUIsUUFBUSxRQUFRO0FBQUEsVUFDNUM7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLFVBQUksUUFBUSxjQUFjLE1BQU07QUFDOUIsMEJBQWtCLGdCQUFnQixPQUFPLENBQUMsbUJBQW1CO0FBQzNELGdCQUFNLGNBQWMsZUFBZSxZQUFZLFlBQVk7QUFDM0QsY0FBSSxNQUFNLFFBQVEsUUFBUSxVQUFVLEdBQUc7QUFDckMsZ0JBQUksWUFBWTtBQUNoQix1QkFBVyxRQUFRLFFBQVEsWUFBWTtBQUNyQyxrQkFBSSxZQUFZLFFBQVEsS0FBSyxZQUFZLENBQUMsTUFBTSxJQUFJO0FBQ2xELDRCQUFZO0FBQ1o7QUFBQSxjQUNGO0FBQUEsWUFDRjtBQUNBLG1CQUFPO0FBQUEsVUFDVCxXQUFXLFFBQVEsY0FBYyxNQUFNO0FBQ3JDLG1CQUFPLFlBQVksUUFBUSxRQUFRLFdBQVcsWUFBWSxDQUFDLE1BQU07QUFBQSxVQUNuRTtBQUNBLGlCQUFPO0FBQUEsUUFDVCxDQUFDO0FBQUEsTUFDSDtBQUNBLFVBQUksUUFBUSxnQkFBZ0IsTUFBTTtBQUNoQywwQkFBa0IsZ0JBQWdCLE9BQU8sQ0FBQyxtQkFBbUI7QUFDM0QsZ0JBQU0sU0FBUyxPQUFPLGlCQUFpQixjQUFjO0FBQ3JELGNBQUksT0FBTztBQUNYLHFCQUFXLGVBQWUsUUFBUSxjQUFjO0FBQzlDLGtCQUFNLFNBQVMsT0FBTyxZQUFZLE1BQU07QUFDeEMsZ0JBQUksWUFBWSxTQUFTO0FBQ3ZCLHFCQUFPLFFBQVEsV0FBVyxZQUFZO0FBQUEsWUFDeEMsT0FBTztBQUNMLHFCQUFPLFFBQVEsV0FBVyxZQUFZO0FBQUEsWUFDeEM7QUFBQSxVQUNGO0FBQ0EsaUJBQU87QUFBQSxRQUNULENBQUM7QUFBQSxNQUNIO0FBQ0EsVUFBSSxRQUFRLGlCQUFpQixNQUFNO0FBQ2pDLDBCQUFrQixnQkFBZ0IsT0FBTyxDQUFDLG1CQUFtQjtBQUMzRCxjQUFJLFFBQVEsZUFBZTtBQUN6QixtQkFBTyxlQUFlLGlCQUFpQjtBQUFBLFVBQ3pDLE9BQU87QUFDTCxtQkFBTyxlQUFlLGlCQUFpQjtBQUFBLFVBQ3pDO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSDtBQUNBLFVBQUksUUFBUSxnQkFBZ0IsTUFBTTtBQUNoQywwQkFBa0IsZ0JBQWdCLE9BQU8sTUFBTTtBQUM3QyxjQUFJLFFBQVEsY0FBYztBQUN4QixtQkFBTyxPQUFPLGFBQWEsT0FBTyxPQUFPO0FBQUEsVUFDM0MsT0FBTztBQUNMLG1CQUFPLE9BQU8sYUFBYSxPQUFPLE9BQU87QUFBQSxVQUMzQztBQUFBLFFBQ0YsQ0FBQztBQUFBLE1BQ0g7QUFDQSxVQUFJLFFBQVEsZUFBZSxNQUFNO0FBQy9CLDBCQUFrQixnQkFBZ0IsT0FBTyxDQUFDLG1CQUFtQjtBQUMzRCxnQkFBTSxVQUFVQSxRQUFPO0FBQ3ZCLFVBQUFBLFFBQU8sUUFBUSxjQUFjO0FBQzdCLGdCQUFNLGVBQWVBLFFBQU8sS0FBSyxRQUFRLFdBQVc7QUFDcEQsVUFBQUEsUUFBTyxRQUFRLE9BQU87QUFDdEIsaUJBQU8sYUFBYSxVQUFVO0FBQUEsUUFDaEMsQ0FBQztBQUFBLE1BQ0g7QUFDQSxVQUFJLFVBQVU7QUFDWixlQUFPO0FBQUEsTUFDVCxPQUFPO0FBQ0wsWUFBSSxnQkFBZ0IsU0FBUyxHQUFHO0FBQzlCLGtCQUFRO0FBQUEsWUFDTjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0EsZUFBTyxnQkFBZ0IsQ0FBQztBQUFBLE1BQzFCO0FBQUEsSUFDRjtBQUFBLElBQ0EsT0FBTyxLQUFLLFNBQVMsV0FBVyxPQUFPO0FBQ3JDLFlBQU0sVUFBVSxDQUFDO0FBQ2pCLFVBQUksUUFBUSxVQUFVLE1BQU07QUFDMUIsY0FBTSxTQUFTQSxRQUFPLFlBQVksUUFBUSxRQUFRLE1BQU0sUUFBUTtBQUNoRSxZQUFJLFVBQVUsTUFBTTtBQUNsQixjQUFJLGtCQUFrQixPQUFPO0FBQzNCLG1CQUFPLFFBQVEsQ0FBQyxNQUFNO0FBQ3BCLG9CQUFNLFVBQVVBLFFBQU8sWUFBWSxRQUFRLFFBQVEsR0FBRyxRQUFRO0FBQzlELGtCQUFJLG1CQUFtQixPQUFPO0FBQzVCLHdCQUFRLFFBQVEsQ0FBQyxXQUFXO0FBQzFCLDBCQUFRLEtBQUs7QUFBQSxvQkFDWCxRQUFRO0FBQUEsb0JBQ1I7QUFBQSxrQkFDRixDQUFDO0FBQUEsZ0JBQ0gsQ0FBQztBQUFBLGNBQ0gsT0FBTztBQUNMLHdCQUFRLEtBQUs7QUFBQSxrQkFDWCxRQUFRO0FBQUEsa0JBQ1IsUUFBUTtBQUFBLGdCQUNWLENBQUM7QUFBQSxjQUNIO0FBQUEsWUFDRixDQUFDO0FBQ0QsbUJBQU87QUFBQSxVQUNULE9BQU87QUFDTCxrQkFBTSxVQUFVQSxRQUFPLFlBQVksUUFBUSxRQUFRLFFBQVEsUUFBUTtBQUNuRSxnQkFBSSxtQkFBbUIsT0FBTztBQUM1QixzQkFBUSxRQUFRLENBQUMsV0FBVztBQUMxQix3QkFBUSxLQUFLO0FBQUEsa0JBQ1g7QUFBQSxrQkFDQTtBQUFBLGdCQUNGLENBQUM7QUFBQSxjQUNILENBQUM7QUFBQSxZQUNILE9BQU87QUFDTCxzQkFBUSxLQUFLO0FBQUEsZ0JBQ1g7QUFBQSxnQkFDQSxRQUFRO0FBQUEsY0FDVixDQUFDO0FBQUEsWUFDSDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRixPQUFPO0FBQ0wsY0FBTSxVQUFVQSxRQUFPLFlBQVksUUFBUSxRQUFRLE1BQU0sUUFBUTtBQUNqRSxZQUFJLG1CQUFtQixPQUFPO0FBQzVCLGtCQUFRLFFBQVEsQ0FBQyxXQUFXO0FBQzFCLG9CQUFRLEtBQUs7QUFBQSxjQUNYLFFBQVE7QUFBQSxjQUNSO0FBQUEsWUFDRixDQUFDO0FBQUEsVUFDSCxDQUFDO0FBQUEsUUFDSCxPQUFPO0FBQ0wsa0JBQVEsS0FBSztBQUFBLFlBQ1gsUUFBUTtBQUFBLFlBQ1IsUUFBUTtBQUFBLFVBQ1YsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQ0EsVUFBSSxRQUFRLFdBQVcsR0FBRztBQUN4QixnQkFBUSxLQUFLO0FBQUEsVUFDWCxRQUFRO0FBQUEsVUFDUixRQUFRO0FBQUEsUUFDVixDQUFDO0FBQUEsTUFDSDtBQUNBLFVBQUksVUFBVTtBQUNaLGVBQU87QUFBQSxNQUNULE9BQU87QUFDTCxZQUFJLFFBQVEsV0FBVyxHQUFHO0FBQ3hCLGtCQUFRO0FBQUEsWUFDTjtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBLGVBQU8sUUFBUSxDQUFDO0FBQUEsTUFDbEI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU8sT0FBTztBQUNkLE1BQUksUUFBUTtBQUdaLFdBQVMsUUFBUSxRQUFRO0FBQ3ZCLFVBQU0sU0FBUyxNQUFNLEtBQUssTUFBTTtBQUNoQyxRQUFJLE9BQU8sU0FBUyxPQUFPO0FBQ3pCLGFBQU8sQ0FBQyxDQUFDLE9BQU87QUFBQSxJQUNsQixXQUFXLE9BQU8sU0FBUyxZQUFZO0FBQ3JDLGFBQU8sQ0FBQyxDQUFDLE9BQU8sVUFBVSxPQUFPLE9BQU87QUFBQSxJQUMxQztBQUFBLEVBQ0Y7QUFDQSxpQkFBZSxjQUFjLFFBQVEsT0FBTztBQUMxQyxZQUFRLE9BQU8sTUFBTTtBQUFBLE1BQ25CLEtBQUs7QUFDSCxlQUFPLFlBQVksTUFBTTtBQUFBLE1BQzNCLEtBQUs7QUFDSCxlQUFPLFdBQVcsUUFBUSxLQUFLO0FBQUEsTUFDakMsS0FBSztBQUNILGVBQU8sY0FBYyxRQUFRLEtBQUs7QUFBQSxNQUNwQyxLQUFLO0FBQ0gsZUFBTyxZQUFZLFFBQVEsS0FBSztBQUFBLE1BQ2xDLEtBQUs7QUFDSCxlQUFPLGNBQWMsTUFBTTtBQUFBLE1BQzdCLEtBQUs7QUFDSCxlQUFPLGNBQWMsUUFBUSxLQUFLO0FBQUEsTUFDcEMsS0FBSztBQUNILGVBQU8sV0FBVyxNQUFNO0FBQUEsTUFDMUIsS0FBSztBQUNILGVBQU8sWUFBWSxNQUFNO0FBQUEsTUFDM0IsS0FBSztBQUNILGVBQU8sWUFBWTtBQUFBLE1BQ3JCLEtBQUs7QUFDSCxlQUFPLFdBQVcsTUFBTTtBQUFBLE1BQzFCLEtBQUs7QUFDSCxlQUFPLFdBQVcsTUFBTTtBQUFBLE1BQzFCO0FBQ0UsY0FBTSxJQUFJLE1BQU0sMEJBQTBCLE9BQU8sSUFBSTtBQUFBLElBQ3pEO0FBQUEsRUFDRjtBQUNBLE1BQUksZUFBZTtBQUNuQixXQUFTLFlBQVksU0FBUztBQUM1QixXQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUIsaUJBQVcsTUFBTTtBQUNmLGdCQUFRO0FBQUEsTUFDVixHQUFHLE9BQU87QUFBQSxJQUNaLENBQUM7QUFBQSxFQUNIO0FBQ0EsaUJBQWUsWUFBWSxRQUFRO0FBQ2pDLFVBQU0sU0FBUyxNQUFNLEtBQUssTUFBTTtBQUNoQyxRQUFJLE9BQU8sVUFBVSxNQUFNO0FBQ3pCLGFBQU8sT0FBTyxNQUFNO0FBQUEsSUFDdEI7QUFDQSxXQUFPLFlBQVksWUFBWTtBQUFBLEVBQ2pDO0FBQ0EsaUJBQWUsV0FBVyxRQUFRLE9BQU87QUFDdkMsZUFBVyxVQUFVLE9BQU8sU0FBUztBQUNuQyxZQUFNLGNBQWMsUUFBUSxLQUFLO0FBQUEsSUFDbkM7QUFBQSxFQUNGO0FBQ0EsaUJBQWUsY0FBYyxRQUFRLGNBQWM7QUFDakQsZUFBVyxpQkFBaUIsT0FBTyxVQUFVO0FBQzNDLFlBQU0sZUFBZSxhQUFhLFFBQVEsY0FBYyxJQUFJLE1BQU07QUFDbEUsVUFBSSxjQUFjLFdBQVcsY0FBYyxjQUFjO0FBQ3ZELGNBQU0sWUFBWSxRQUFRLGNBQWMsT0FBTztBQUMvQyxZQUFJLGNBQWMsY0FBYztBQUM5QixnQkFBTSxjQUFjLGNBQWMsWUFBWTtBQUFBLFFBQ2hEO0FBQUEsTUFDRixPQUFPO0FBQ0wsWUFBSSxjQUFjO0FBQ2hCLGdCQUFNLGNBQWMsY0FBYyxVQUFVO0FBQUEsUUFDOUMsT0FBTztBQUNMLGdCQUFNLGNBQWMsY0FBYyxXQUFXO0FBQUEsUUFDL0M7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxpQkFBZSxZQUFZLFFBQVEsT0FBTztBQUN4QyxVQUFNLFNBQVMsTUFBTSxLQUFLLE1BQU07QUFDaEMsUUFBSSxDQUFDLE9BQU8sUUFBUTtBQUNsQixVQUFJLE9BQU8sWUFBWTtBQUNyQixjQUFNLGNBQWMsT0FBTyxZQUFZLEtBQUs7QUFBQSxNQUM5QztBQUFBLElBQ0YsT0FBTztBQUNMLFVBQUksT0FBTyxhQUFhO0FBQ3RCLGNBQU0sY0FBYyxPQUFPLGFBQWEsS0FBSztBQUFBLE1BQy9DO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxpQkFBZSxjQUFjLFFBQVE7QUFDbkMsVUFBTSxJQUFJLFFBQVEsQ0FBQyxZQUFZO0FBQzdCLFVBQUksYUFBYSxPQUFPLFdBQVc7QUFDbkMsWUFBTSxXQUFXLE9BQU8sWUFBWTtBQUNwQyxZQUFNLFdBQVcsTUFBTTtBQUNyQixjQUFNLFNBQVMsTUFBTSxLQUFLLE1BQU07QUFDaEMsWUFBSSxPQUFPLFdBQVcsT0FBTyxVQUFVLENBQUMsT0FBTyxXQUFXLENBQUMsT0FBTyxRQUFRO0FBQ3hFLGNBQUksYUFBYSxHQUFHO0FBQ2xCLDBCQUFjO0FBQ2QsdUJBQVcsVUFBVSxRQUFRO0FBQUEsVUFDL0IsT0FBTztBQUNMLG9CQUFRO0FBQUEsVUFDVjtBQUFBLFFBQ0YsT0FBTztBQUNMLGtCQUFRO0FBQUEsUUFDVjtBQUFBLE1BQ0Y7QUFDQSxlQUFTO0FBQUEsSUFDWCxDQUFDO0FBQUEsRUFDSDtBQUNBLGlCQUFlLGNBQWMsUUFBUSxPQUFPO0FBQzFDLFVBQU0sVUFBVSxNQUFNLEtBQUssUUFBUSxJQUFJO0FBQ3ZDLFVBQU0sVUFBVSxNQUFNO0FBQ3RCLGVBQVcsVUFBVSxTQUFTO0FBQzVCLFVBQUksT0FBTyxRQUFRO0FBQ2pCLGNBQU0sUUFBUSxPQUFPLE1BQU07QUFDM0IsY0FBTSxjQUFjLE9BQU8sUUFBUSxLQUFLO0FBQUEsTUFDMUM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxRQUFRLE9BQU87QUFBQSxFQUN2QjtBQUNBLGlCQUFlLFdBQVcsUUFBUTtBQUNoQyxVQUFNLFNBQVMsTUFBTSxLQUFLLE1BQU07QUFDaEMsUUFBSSxPQUFPLFFBQVE7QUFDakIsYUFBTyxPQUFPLFVBQVUsSUFBSSxvQkFBb0I7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxpQkFBZSxZQUFZLFFBQVE7QUFDakMsVUFBTSxTQUFTLE1BQU0sS0FBSyxNQUFNO0FBQ2hDLFVBQU0sYUFBYSxNQUFNLEtBQUssT0FBTyxVQUFVO0FBQy9DLFFBQUksT0FBTyxRQUFRO0FBQ2pCLFlBQU0sZUFBZSxPQUFPLE9BQU8sc0JBQXNCO0FBQ3pELFlBQU0sbUJBQW1CLFdBQVcsT0FBTyxzQkFBc0I7QUFDakUsVUFBSSxRQUFRLGlCQUFpQixNQUFNLGFBQWE7QUFDaEQsVUFBSSxRQUFRLGlCQUFpQixPQUFPLGFBQWE7QUFDakQsVUFBSSxLQUFLLE9BQU8sS0FBSyxZQUFZLE1BQU0sS0FBSztBQUMxQyxnQkFBUTtBQUFBLE1BQ1Y7QUFDQSxVQUFJLEtBQUssT0FBTyxLQUFLLFlBQVksTUFBTSxLQUFLO0FBQzFDLGdCQUFRO0FBQUEsTUFDVjtBQUNBLFlBQU0sVUFBVSxPQUFPLFVBQVUsYUFBYSxPQUFPLGFBQWEsUUFBUTtBQUMxRSxZQUFNLFVBQVUsT0FBTyxVQUFVLGFBQWEsTUFBTSxhQUFhLFNBQVM7QUFDMUUsWUFBTSxVQUFVLGFBQWEsT0FBTyxhQUFhLFFBQVE7QUFDekQsWUFBTSxVQUFVLGFBQWEsTUFBTSxhQUFhLFNBQVM7QUFDekQsWUFBTSxZQUFZLFNBQVMsWUFBWSxhQUFhO0FBQ3BELGdCQUFVO0FBQUEsUUFDUjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLE9BQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxZQUFZLFNBQVMsWUFBWSxhQUFhO0FBQ3BELGdCQUFVO0FBQUEsUUFDUjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLFVBQVU7QUFBQSxRQUNWLFVBQVU7QUFBQSxRQUNWLFVBQVU7QUFBQSxRQUNWLFVBQVU7QUFBQSxRQUNWO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsT0FBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLFVBQVUsU0FBUyxZQUFZLGFBQWE7QUFDbEQsY0FBUTtBQUFBLFFBQ047QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxVQUFVO0FBQUEsUUFDVixVQUFVO0FBQUEsUUFDVixVQUFVO0FBQUEsUUFDVixVQUFVO0FBQUEsUUFDVjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLE9BQU87QUFBQSxNQUNUO0FBQ0EsYUFBTyxPQUFPLGNBQWMsU0FBUztBQUNyQyxZQUFNLEtBQUssWUFBWSxFQUFFO0FBQ3pCLGFBQU8sT0FBTyxjQUFjLFNBQVM7QUFDckMsWUFBTSxLQUFLLFlBQVksRUFBRTtBQUN6QixhQUFPLE9BQU8sY0FBYyxPQUFPO0FBQUEsSUFDckM7QUFBQSxFQUNGO0FBQ0EsaUJBQWUsV0FBVyxRQUFRO0FBQ2hDLFVBQU0sWUFBWSxPQUFPLFFBQVE7QUFBQSxFQUNuQztBQUNBLGlCQUFlLGNBQWM7QUFDM0IsV0FBTyxNQUFNO0FBQUEsRUFDZjtBQUNBLGlCQUFlLFdBQVcsUUFBUTtBQUNoQyxZQUFRLElBQUksU0FBUyxPQUFPLElBQUk7QUFDaEMsV0FBTyxJQUFJLFFBQVEsQ0FBQyxZQUFZO0FBQzlCLFVBQUk7QUFDRixZQUFJLE9BQU8sT0FBTztBQUNoQixpQkFBTyxLQUFLLE9BQU8sSUFBSTtBQUN2QixxQkFBVyxNQUFNO0FBQ2Ysb0JBQVEsT0FBTyxLQUFLLDZCQUE2QixDQUFDO0FBQUEsVUFDcEQsR0FBRyxPQUFPLFdBQVcsR0FBRztBQUFBLFFBQzFCLE9BQU87QUFDTCxrQkFBUSxPQUFPLEtBQUssT0FBTyxJQUFJLENBQUM7QUFBQSxRQUNsQztBQUFBLE1BQ0YsU0FBUyxHQUFHO0FBQ1YsZ0JBQVEsS0FBSyxjQUFjLEdBQUcsT0FBTyxJQUFJO0FBQ3pDLGdCQUFRLEtBQUs7QUFBQSxNQUNmO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUdBLFdBQVMsY0FBYztBQUNyQixRQUFJLFVBQVUsT0FBTyxPQUFPLGVBQWUsYUFBYTtBQUN0RCxhQUFPLE9BQU8sV0FBVztBQUFBLElBQzNCO0FBQ0EsV0FBTyxLQUFLLE9BQU8sRUFBRSxTQUFTO0FBQUEsRUFDaEM7QUFHQSxNQUFJLFdBQVcsTUFBTTtBQUFBLElBQ25CLFlBQVksSUFBSSxVQUFVLEtBQUs7QUFDN0IsV0FBSyxLQUFLO0FBQ1YsV0FBSyxVQUFVLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVztBQUM5QyxhQUFLLFVBQVU7QUFDZixhQUFLLFNBQVM7QUFBQSxNQUNoQixDQUFDO0FBQ0QsV0FBSyxRQUFRLE9BQU8sV0FBVyxNQUFNO0FBQ25DLGFBQUssT0FBTyxJQUFJLE1BQU0sU0FBUyxDQUFDO0FBQUEsTUFDbEMsR0FBRyxPQUFPO0FBQUEsSUFDWjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFlBQVk7QUFBQSxJQUNkLFNBQXlCLG9CQUFJLElBQUk7QUFBQSxJQUNqQyxvQkFBb0I7QUFBQSxFQUN0QjtBQUNBLFdBQVMsWUFBWSxNQUFNLFdBQVc7QUFDcEMsVUFBTSxLQUFLLFlBQVk7QUFDdkIsY0FBVSxtQkFBbUI7QUFBQSxNQUMzQixNQUFNO0FBQUEsTUFDTjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQ0QsVUFBTSxXQUFXLElBQUksU0FBUyxFQUFFO0FBQ2hDLGNBQVUsUUFBUSxJQUFJLFNBQVMsSUFBSSxRQUFRO0FBQzNDLFdBQU8sU0FBUztBQUFBLEVBQ2xCO0FBQ0EsV0FBUyxZQUFZLElBQUksT0FBTztBQUM5QixVQUFNLFdBQVcsVUFBVSxRQUFRLElBQUksRUFBRTtBQUN6QyxRQUFJLFVBQVU7QUFDWixnQkFBVSxRQUFRLE9BQU8sRUFBRTtBQUMzQixlQUFTLFNBQVMsT0FBTyxhQUFhLFNBQVMsS0FBSztBQUNwRCxlQUFTLFFBQVEsS0FBSztBQUFBLElBQ3hCLE9BQU87QUFDTCxjQUFRLEtBQUssYUFBYSxFQUFFO0FBQUEsSUFDOUI7QUFBQSxFQUNGO0FBR0EsTUFBSSxXQUFXO0FBQUE7QUFBQSxJQUViLFFBQVEsTUFBTSxRQUFRLElBQUksQ0FBQztBQUFBLElBQzNCLHVCQUF1QixNQUFNLE9BQU8sU0FBUyxPQUFPLE1BQU0sWUFBWSxNQUFNO0FBQUEsSUFDNUUsdUJBQXVCLE1BQU0sQ0FBQyxNQUFNLGVBQWUsRUFBRTtBQUFBLElBQ3JELHVCQUF1QixNQUFNLE1BQU0sY0FBYyxDQUFDO0FBQUEsSUFDbEQsdUJBQXVCLE1BQU0sTUFBTSxjQUFjLENBQUM7QUFBQSxJQUNsRCx1QkFBdUIsTUFBTSxNQUFNLGVBQWUsRUFBRTtBQUFBLElBQ3BELGtCQUFrQixNQUFNLENBQUMsQ0FBQyxPQUFPO0FBQUEsSUFDakMsa0JBQWtCLE1BQU0sQ0FBQyxPQUFPLFVBQVUsZUFBZSxPQUFPLFVBQVUsUUFBUSxZQUFZO0FBQUEsSUFDOUYsa0JBQWtCLE1BQU0sT0FBTyxVQUFVLFNBQVMsS0FBSztBQUFBLElBQ3ZELGtCQUFrQixNQUFNLE9BQU8sVUFBVSxLQUFLLEtBQUs7QUFBQSxJQUNuRCxrQkFBa0IsTUFBTSxPQUFPLFVBQVUsYUFBYTtBQUFBLElBQ3RELGNBQWMsTUFBTTtBQUNsQixZQUFNLFNBQVMsV0FBVyxlQUFlLFdBQVcsT0FBTyxjQUFjLFdBQVcsTUFBTSxXQUFXLEVBQUU7QUFDdkcsVUFBSSxDQUFDLFFBQVE7QUFDWCxlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sb0JBQW9CLE9BQU8sWUFBWSxPQUFPLE1BQU0sT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUk7QUFDdEcsVUFBSSxTQUFTLE1BQU0sWUFBWTtBQUM3QixjQUFNLFVBQVUsTUFBTSxXQUFXO0FBQ2pDLGVBQU8saUJBQWlCLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxTQUFTLElBQUksQ0FBQztBQUFBLE1BQ2pFLFdBQVcsZUFBZSxZQUFZLGtCQUFrQixVQUFVO0FBQ2hFLGNBQU0sYUFBYSxZQUFZLGNBQWMsWUFBWTtBQUN6RCxjQUFNLFdBQVcsS0FBSztBQUFBLFVBQ3BCO0FBQUEsWUFDRSxTQUFTLE9BQU8sTUFBTSxHQUFHLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsV0FBVyxVQUFVLENBQUMsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsVUFDdEY7QUFBQSxRQUNGO0FBQ0EsZUFBTyxPQUFPLEtBQUssUUFBUSxFQUFFLE9BQU8sQ0FBQyxNQUFNLGlCQUFpQixTQUFTLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLFNBQVMsQ0FBQyxNQUFNLEtBQUs7QUFBQSxNQUM3RztBQUFBLElBQ0Y7QUFBQSxJQUNBLHVCQUF1QixNQUFNO0FBQzNCLFlBQU0sS0FBSyxRQUFRLElBQUk7QUFBQSxJQUN6QjtBQUFBLElBQ0EsNEJBQTRCLE1BQU07QUFDaEMsVUFBSSxPQUFPLFNBQVMsT0FBTyxNQUFNLFNBQVMsY0FBYyxPQUFPLE1BQU0sZUFBZSxZQUFZO0FBQzlGLFlBQUk7QUFDRixnQkFBTSxXQUFXLEVBQUUsVUFBVSxLQUFLO0FBQ2xDLGdCQUFNLFdBQVcsRUFBRSxxQkFBcUI7QUFDeEMsaUJBQU87QUFBQSxRQUNULFNBQVMsR0FBRztBQUNWLGtCQUFRLEtBQUssQ0FBQztBQUNkLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsaUJBQWlCLE1BQU0sT0FBTyxxQkFBcUIsTUFBTSxHQUFHLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsRUFBRSxVQUFVO0FBQUEsSUFDcEcsbUJBQW1CLE1BQU0sVUFBVSxPQUFPLFVBQVUsT0FBTyxPQUFPLEdBQUcsUUFBUSxlQUFlO0FBQUEsSUFDNUYsMEJBQTBCLE1BQU0sVUFBVSxPQUFPLGVBQWUsT0FBTyxZQUFZLGdCQUFnQjtBQUFBLElBQ25HLHlCQUF5QixNQUFNLFVBQVUsT0FBTyxlQUFlLE9BQU8sWUFBWSxRQUFRO0FBQUE7QUFBQSxJQUUxRixpQkFBaUIsTUFBTSxDQUFDLENBQUMsYUFBYSxRQUFRLGtCQUFrQjtBQUFBLElBQ2hFLDZCQUE2QixNQUFNLENBQUMsQ0FBQyxhQUFhLFFBQVEsZUFBZTtBQUFBLElBQ3pFLGdCQUFnQixNQUFNLEtBQUssS0FBSyxzQkFBc0IsRUFBRSxXQUFXO0FBQUEsSUFDbkUseUNBQXlDLE1BQU0sQ0FBQyxFQUFFLE9BQU8sa0JBQWtCLE9BQU8sZUFBZTtBQUFBLElBQ2pHLGdCQUFnQixNQUFNLENBQUMsS0FBSztBQUFBLE1BQzFCO0FBQUEsUUFDRSxTQUFTLE9BQU8sTUFBTSxHQUFHLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLGdCQUFnQixNQUFNLEVBQUUsRUFBRSxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7QUFBQSxNQUM1RjtBQUFBLElBQ0YsRUFBRSxTQUFTO0FBQUEsSUFDWCxtQkFBbUIsTUFBTSxDQUFDLENBQUMsU0FBUyxPQUFPLE1BQU0sb0JBQW9CO0FBQUEsSUFDckUsaUJBQWlCLE1BQU0sS0FBSyxNQUFNLG1CQUFtQixTQUFTLE9BQU8sTUFBTSw0REFBNEQsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsVUFBVTtBQUFBLElBQ2hLLHdCQUF3QixNQUFNO0FBQzVCLFVBQUksSUFBSSxrQkFBbUIsS0FBSSxrQkFBa0I7QUFDakQsVUFBSSxJQUFJLGFBQWMsS0FBSSxhQUFhO0FBQ3ZDLGVBQVMsS0FBSyxVQUFVLE9BQU8sbUJBQW1CO0FBQ2xELGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSw2QkFBNkIsTUFBTSxDQUFDLENBQUMsT0FBTztBQUFBLElBQzVDLDZCQUE2QixNQUFNLEtBQUs7QUFBQSxNQUN0QyxTQUFTLE9BQU8sTUFBTSxHQUFHLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsV0FBVyxhQUFhLENBQUMsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDekYsRUFBRSxXQUFXO0FBQUEsSUFDYixvQkFBb0IsTUFBTSxTQUFTLGNBQWMsTUFBTSxFQUFFLGdCQUFnQixPQUFPLEtBQUs7QUFBQSxJQUNyRixvQkFBb0IsTUFBTSxTQUFTLGNBQWMsTUFBTSxFQUFFLGdCQUFnQixPQUFPLEtBQUs7QUFBQSxJQUNyRixvQkFBb0IsTUFBTSxPQUFPLGNBQWMsYUFBYTtBQUFBLElBQzVELG9CQUFvQixPQUFPLENBQUMsTUFBTSxFQUFFLGdCQUFnQixTQUFTLEVBQUUsZUFBZSxTQUFTLEVBQUUsZ0JBQWdCO0FBQUEsTUFDdkcsS0FBSztBQUFBLFFBQ0g7QUFBQSxVQUNFLFNBQVMsT0FBTyxNQUFNLEdBQUcsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsYUFBYSxNQUFNLEVBQUUsRUFBRSxLQUFLO0FBQUEsUUFDL0UsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDaEI7QUFBQSxJQUNGO0FBQUEsSUFDQSxvQkFBb0IsTUFBTSxTQUFTLGlCQUFpQiwyRUFBMkUsRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLGFBQWEsY0FBYyxNQUFNLFVBQVUsRUFBRSxNQUFNLENBQUMsS0FBSztBQUFBLElBQzNNLDBCQUEwQixNQUFNLGtCQUFrQixxQkFBcUIsS0FBSztBQUFBLElBQzVFLDBCQUEwQixNQUFNLGtCQUFrQixvQkFBb0IsS0FBSztBQUFBLElBQzNFLGFBQWEsTUFBTSxTQUFTLGlCQUFpQiwwQkFBMEIsRUFBRSxRQUFRLENBQUMsV0FBVztBQUMzRixhQUFPLFVBQVU7QUFBQSxJQUNuQixDQUFDLEtBQUs7QUFBQSxJQUNOLGFBQWEsTUFBTSxTQUFTLGNBQWMsa0RBQWtELEVBQUUsTUFBTSxLQUFLO0FBQUEsSUFDekcsY0FBYyxNQUFNLE1BQU0scUJBQXFCO0FBQUEsSUFDL0MseUJBQXlCLE1BQU0sT0FBTyxPQUFPO0FBQUEsSUFDN0MsbUNBQW1DLE1BQU0sQ0FBQyxDQUFDLE9BQU87QUFBQSxJQUNsRCw2QkFBNkIsTUFBTSxDQUFDLENBQUMsT0FBTyxTQUFTO0FBQUEsSUFDckQsZ0JBQWdCLE1BQU0sU0FBUyxpQkFBaUIscURBQXFELEVBQUUsUUFBUSxDQUFDLE1BQU07QUFDcEgsVUFBSSxFQUFFLFFBQVMsR0FBRSxNQUFNO0FBQUEsSUFDekIsQ0FBQyxLQUFLO0FBQUEsSUFDTixnQkFBZ0IsTUFBTSxDQUFDLENBQUMsU0FBUyxPQUFPLE1BQU0sY0FBYztBQUFBLElBQzVELGtCQUFrQixNQUFNLFNBQVMsaUJBQWlCLHVEQUF1RCxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQUEsSUFDckosa0JBQWtCLE1BQU0sTUFBTSxLQUFLLFNBQVMsaUJBQWlCLGNBQWMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxPQUFPLEdBQUcsVUFBVSxNQUFNLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sS0FBSztBQUFBLElBQ2xKLGtCQUFrQixNQUFNLE1BQU0sS0FBSyxTQUFTLGlCQUFpQixjQUFjLENBQUMsRUFBRSxPQUFPLENBQUMsT0FBTyxHQUFHLFVBQVUsTUFBTSxpQkFBaUIsQ0FBQyxFQUFFLENBQUMsRUFBRSxNQUFNLEtBQUs7QUFBQSxJQUNsSixrQkFBa0IsTUFBTSxDQUFDLENBQUMsU0FBUyxPQUFPLE1BQU0sV0FBVztBQUFBLElBQzNELGNBQWMsTUFBTSxTQUFTLGlCQUFpQixnQ0FBZ0MsRUFBRSxRQUFRLENBQUMsTUFBTTtBQUM3RixVQUFJLENBQUMsRUFBRSxTQUFVLEdBQUUsVUFBVSxFQUFFLFNBQVMsK0JBQStCLEVBQUUsT0FBTztBQUFBLElBQ2xGLENBQUMsS0FBSztBQUFBLElBQ04sb0JBQW9CLE1BQU0sQ0FBQyxDQUFDLGFBQWEsUUFBUSxrQkFBa0I7QUFBQSxJQUNuRSxtQkFBbUIsTUFBTSxDQUFDLENBQUMsT0FBTyxPQUFPLElBQUk7QUFBQSxJQUM3QyxxQkFBcUIsTUFBTSxTQUFTLE9BQU8sU0FBUyxrQkFBa0IsS0FBSyxLQUFLO0FBQUEsTUFDOUU7QUFBQSxRQUNFLFNBQVMsT0FBTyxNQUFNLEdBQUcsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxXQUFXLGlCQUFpQixDQUFDLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQzdGO0FBQUEsSUFDRixFQUFFLFdBQVc7QUFBQSxJQUNiLGtCQUFrQixNQUFNLE9BQU8sUUFBUSxLQUFLLEtBQUs7QUFBQSxJQUNqRCxnQkFBZ0IsTUFBTSxTQUFTLE9BQU8sU0FBUyxjQUFjLE1BQU0sU0FBUyxPQUFPLE1BQU0sZUFBZSxLQUFLLFNBQVMsT0FBTyxNQUFNLGVBQWUsS0FBSyxTQUFTLE9BQU8sTUFBTSxlQUFlO0FBQUEsSUFDNUwsc0JBQXNCLE1BQU0sQ0FBQyxDQUFDLGFBQWEsUUFBUSxpQkFBaUI7QUFBQSxJQUNwRSxtQkFBbUIsTUFBTSxTQUFTLE9BQU8sU0FBUyx1QkFBdUIsS0FBSyxTQUFTLE9BQU8sU0FBUyxvQkFBb0IsS0FBSyxLQUFLO0FBQUEsTUFDbkk7QUFBQSxRQUNFLFNBQVMsT0FBTyxNQUFNLEdBQUcsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxXQUFXLG1CQUFtQixDQUFDLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQy9GO0FBQUEsSUFDRixFQUFFLFNBQVMsTUFBTTtBQUFBLElBQ2pCLHNCQUFzQixNQUFNLFNBQVMsT0FBTyxNQUFNLDJCQUEyQixLQUFLLENBQUMsU0FBUyxPQUFPLE1BQU0sdUJBQXVCO0FBQUEsSUFDaEksNkJBQTZCLE1BQU07QUFDakMsZUFBUyxnQkFBZ0IsVUFBVSxRQUFRLENBQUMsUUFBUTtBQUNsRCxZQUFJLElBQUksV0FBVyxTQUFTLEVBQUcsVUFBUyxnQkFBZ0IsVUFBVSxPQUFPLEdBQUc7QUFBQSxNQUM5RSxDQUFDO0FBQ0QsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLHFCQUFxQixNQUFNLEtBQUs7QUFBQSxNQUM5QjtBQUFBLFFBQ0UsU0FBUyxPQUFPLE1BQU0sR0FBRyxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLFdBQVcsZ0JBQWdCLENBQUMsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDNUY7QUFBQSxJQUNGLEVBQUUscUJBQXFCO0FBQUEsSUFDdkIsaUJBQWlCLE1BQU0sU0FBUyxLQUFLLFVBQVUsT0FBTyxRQUFRLE1BQU0sU0FBUyxLQUFLLFFBQVEsT0FBTztBQUFBLElBQ2pHLHNCQUFzQixNQUFNLGNBQWMsY0FBYyxXQUFXLEtBQUssS0FBSztBQUFBLElBQzdFLHNCQUFzQixNQUFNLGNBQWMsY0FBYyxXQUFXLElBQUksS0FBSztBQUFBLElBQzVFLHNCQUFzQixNQUFNLFNBQVMsT0FBTyxNQUFNLHFCQUFxQixJQUFJLENBQUMsRUFBRSxTQUFTLE9BQU87QUFBQSxJQUM5RixnQkFBZ0IsTUFBTSxPQUFPLE9BQU8sU0FBUyxlQUFlLE9BQU8sS0FBSyxTQUFTO0FBQUEsSUFDakYsZ0JBQWdCLE1BQU0sS0FBSyxLQUFLLGdCQUFnQixLQUFLLEtBQUs7QUFBQSxJQUMxRCx3QkFBd0IsTUFBTSxLQUFLLEtBQUssS0FBSyxZQUFZLEtBQUssS0FBSztBQUFBLElBQ25FLGdCQUFnQixNQUFNLEtBQUssS0FBSyxnQkFBZ0IsSUFBSSxLQUFLO0FBQUEsSUFDekQsZ0JBQWdCLE1BQU0sS0FBSyxLQUFLLGdCQUFnQixNQUFNO0FBQUEsSUFDdEQsOEJBQThCLE1BQU0sS0FBSyxLQUFLLEtBQUssWUFBWSxNQUFNO0FBQUEsSUFDckUsbUJBQW1CLE1BQU0sQ0FBQyxDQUFDLFNBQVMsY0FBYyxhQUFhO0FBQUEsSUFDL0QsZ0JBQWdCLE1BQU0sT0FBTyxRQUFRLFFBQVEsQ0FBQyxNQUFNO0FBQUEsSUFDcEQseUJBQXlCLE1BQU0sT0FBTyxRQUFRLFFBQVEsQ0FBQyxNQUFNO0FBQUEsSUFDN0QsMEJBQTBCLE1BQU0sTUFBTSxhQUFhLEtBQUssTUFBTSxVQUFVLEtBQUs7QUFBQSxJQUM3RSwwQkFBMEIsTUFBTSxNQUFNLFNBQVMsS0FBSztBQUFBLElBQ3BELHlCQUF5QixNQUFNLE9BQU8sVUFBVTtBQUFBLElBQ2hELHlCQUF5QixNQUFNLENBQUMsQ0FBQyxNQUFNLFNBQVM7QUFBQSxJQUNoRCx5QkFBeUIsTUFBTSxDQUFDLENBQUMsTUFBTSxnQkFBZ0I7QUFBQSxJQUN2RCx5QkFBeUIsTUFBTSxDQUFDLENBQUMsTUFBTSxrQkFBa0I7QUFBQSxJQUN6RCx5QkFBeUIsTUFBTSxDQUFDLENBQUMsTUFBTSxTQUFTO0FBQUEsSUFDaEQseUJBQXlCLE1BQU0sTUFBTSx1QkFBdUIsTUFBTTtBQUFBLElBQ2xFLHlCQUF5QixNQUFNLE1BQU0sdUJBQXVCLE1BQU07QUFBQSxJQUNsRSw0QkFBNEIsTUFBTSxLQUFLLE1BQU0sYUFBYSxRQUFRLGNBQWMsQ0FBQyxFQUFFLFNBQVMsTUFBTSxDQUFDLE1BQU0sRUFBRSxlQUFlLENBQUMsRUFBRSxhQUFhO0FBQUEsSUFDMUksaUJBQWlCLE1BQU0sTUFBTSxLQUFLLFNBQVMsaUJBQWlCLCtCQUErQixDQUFDLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsS0FBSztBQUFBLEVBQzdIO0FBQ0EsV0FBUyxnQkFBZ0IsYUFBYTtBQUNwQyxVQUFNLGFBQWEsWUFBWSxTQUFTO0FBQ3hDLFdBQU8sSUFBSSxVQUFVO0FBQUEsRUFDdkI7QUFHQSxXQUFTLGdCQUFnQix5QkFBeUIseUJBQXlCO0FBQ3pFLFVBQU0sZ0JBQWdCLFNBQVMsc0JBQXNCO0FBQ3JELFVBQU0sa0JBQWtCLFNBQVMsY0FBYyxhQUFhO0FBQzVELFFBQUksbUJBQW1CLDJCQUEyQixrQkFBa0I7QUFDbEUsYUFBTztBQUFBLElBQ1QsT0FBTztBQUNMLFlBQU0sU0FBUyxTQUFTLFFBQVEsU0FBUyxxQkFBcUIsTUFBTSxFQUFFLENBQUMsS0FBSyxTQUFTO0FBQ3JGLFlBQU0sTUFBTSxTQUFTLGNBQWMsT0FBTztBQUMxQyxVQUFJLEtBQUs7QUFDVCxhQUFPLFlBQVksR0FBRztBQUN0QixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDQSxXQUFTLGVBQWUsUUFBUTtBQUM5QixVQUFNLGdCQUFnQixXQUFXLFlBQVksZUFBZTtBQUM1RCxXQUFPLEdBQUcsYUFBYTtBQUFBLEVBQ3pCO0FBQ0EsV0FBUyxhQUFhLFNBQVMsVUFBVSxTQUFTLFdBQVc7QUFDM0QsVUFBTSxPQUFPLEdBQUcsUUFBUSxNQUFNLGVBQWUsTUFBTSxDQUFDO0FBQ3BELFFBQUksbUJBQW1CLGtCQUFrQjtBQUN2QyxjQUFRLGFBQWE7QUFDckIsYUFBTyxTQUFTLFNBQVM7QUFBQSxJQUMzQjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0EsaUJBQWUsUUFBUSxXQUFXLFVBQVUsVUFBVTtBQUNwRCxVQUFNLFNBQVMsTUFBTSxVQUFVO0FBQy9CLFFBQUksQ0FBQyxVQUFVLFdBQVcsR0FBRztBQUMzQixhQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUIsbUJBQVcsWUFBWTtBQUNyQixrQkFBUSxRQUFRLFdBQVcsV0FBVyxHQUFHLFFBQVEsQ0FBQztBQUFBLFFBQ3BELEdBQUcsUUFBUTtBQUFBLE1BQ2IsQ0FBQztBQUFBLElBQ0g7QUFDQSxXQUFPLFFBQVEsUUFBUSxNQUFNO0FBQUEsRUFDL0I7QUFDQSxXQUFTLGlCQUFpQixNQUFNO0FBQzlCLFFBQUksQ0FBQyxNQUFNO0FBQ1QsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLEtBQUssaUJBQWlCLE1BQU07QUFDOUIsYUFBTztBQUFBLElBQ1QsT0FBTztBQUNMLFlBQU0sTUFBTSxPQUFPLGlCQUFpQixJQUFJO0FBQ3hDLFVBQUksSUFBSSxhQUFhLFdBQVcsSUFBSSxZQUFZLFFBQVE7QUFDdEQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxXQUFTLFdBQVcsTUFBTTtBQUN4QixRQUFJLFdBQVcsaUJBQWlCO0FBQzlCLGFBQU8sZ0JBQWdCLElBQUk7QUFBQSxJQUM3QjtBQUNBLFdBQU8sS0FBSyxNQUFNLEtBQUssVUFBVSxJQUFJLENBQUM7QUFBQSxFQUN4QztBQUNBLFdBQVMsZ0JBQWdCLGdCQUFnQjtBQUN2QyxVQUFNLGdCQUFnQjtBQUFBLE1BQ3BCLFNBQVM7QUFBQSxNQUNULFlBQVk7QUFBQTtBQUFBLE1BRVosY0FBYyxDQUFDO0FBQUEsTUFDZixlQUFlO0FBQUEsTUFDZixxQkFBcUI7QUFBQSxNQUNyQixzQkFBc0I7QUFBQSxNQUN0QiwwQkFBMEI7QUFBQSxNQUMxQix1QkFBdUI7QUFBQSxNQUN2QixlQUFlO0FBQUEsTUFDZixhQUFhO0FBQUEsTUFDYixnQkFBZ0I7QUFBQSxNQUNoQixrQkFBa0I7QUFBQSxNQUNsQixZQUFZO0FBQUEsTUFDWixNQUFNO0FBQUEsUUFDSixXQUFXO0FBQUEsUUFDWCxXQUFXO0FBQUEsUUFDWCxnQkFBZ0I7QUFBQSxRQUNoQixPQUFPO0FBQUEsUUFDUCxRQUFRO0FBQUEsUUFDUixVQUFVO0FBQUEsUUFDVixPQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFDQSxVQUFNLGdCQUFnQixXQUFXLGFBQWE7QUFDOUMsZUFBVyxPQUFPLE9BQU8sS0FBSyxhQUFhLEdBQUc7QUFDNUMsVUFBSSxPQUFPLGVBQWUsR0FBRyxNQUFNLGFBQWE7QUFDOUMsc0JBQWMsR0FBRyxJQUFJLGVBQWUsR0FBRztBQUFBLE1BQ3pDO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0EsV0FBUyxpQkFBaUIsVUFBVSxVQUFVLEtBQUs7QUFDakQsUUFBSSxXQUFXLHFCQUFxQjtBQUNsQywwQkFBb0IsVUFBVSxFQUFFLFFBQVEsQ0FBQztBQUFBLElBQzNDLE9BQU87QUFDTCxpQkFBVyxVQUFVLENBQUM7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFDQSxXQUFTLGNBQWMsTUFBTTtBQUMzQixRQUFJLENBQUMsS0FBSyxNQUFPO0FBQ2pCLFFBQUksS0FBSyxnQkFBZ0IsUUFBUTtBQUMvQjtBQUFBLElBQ0Y7QUFDQSxRQUFJLEtBQUssYUFBYSxPQUFPLEdBQUc7QUFDOUIsV0FBSyxjQUFjLEtBQUssTUFBTTtBQUFBLElBQ2hDO0FBQ0EsU0FBSyxNQUFNLFlBQVk7QUFDdkIsU0FBSyxNQUFNLFVBQVU7QUFDckIsUUFBSSxXQUFXLFNBQVMsY0FBYyxnQ0FBZ0M7QUFDdEUsUUFBSSxDQUFDLFVBQVU7QUFDYixpQkFBVyxTQUFTLGNBQWMsT0FBTztBQUN6QyxlQUFTLEtBQUs7QUFBQSxJQUNoQjtBQUNBLGFBQVMsY0FBYztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWdCdkIsYUFBUyxLQUFLLFlBQVksUUFBUTtBQUFBLEVBQ3BDO0FBQ0EsV0FBUyxnQkFBZ0IsTUFBTTtBQUM3QixRQUFJLENBQUMsS0FBSyxTQUFTLENBQUMsS0FBSyxhQUFhLE9BQU8sRUFBRztBQUNoRCxRQUFJLEtBQUssZ0JBQWdCLFFBQVE7QUFDL0IsV0FBSyxNQUFNLFVBQVUsS0FBSztBQUMxQixhQUFPLEtBQUs7QUFBQSxJQUNkLE9BQU87QUFDTCxXQUFLLGdCQUFnQixPQUFPO0FBQUEsSUFDOUI7QUFBQSxFQUNGO0FBQ0EsV0FBUyxhQUFhO0FBQ3BCLFdBQU8sT0FBTyxRQUFRLFdBQVcsQ0FBQyxXQUFXLFNBQVMsbUJBQW1CLFdBQVcsU0FBUyxnQkFBZ0IsV0FBVztBQUFBLEVBQzFIO0FBR0EsTUFBSSxrQkFBa0I7QUFBQSxJQUNwQjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBO0FBQUEsSUFFQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUE7QUFBQSxJQUVBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQTtBQUFBLElBRUE7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsTUFBSSwwQkFBMEI7QUFBQTtBQUFBO0FBQUEsSUFHNUI7QUFBQTtBQUFBLElBRUE7QUFBQTtBQUFBLElBRUE7QUFBQTtBQUFBO0FBQUEsSUFHQTtBQUFBO0FBQUE7QUFBQSxJQUdBO0FBQUE7QUFBQTtBQUFBLElBR0E7QUFBQTtBQUFBO0FBQUEsSUFHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1GO0FBQ0EsTUFBSSx3QkFBd0I7QUFBQSxJQUMxQjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLE1BQUkseUJBQXlCO0FBQUEsSUFDM0I7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxNQUFJLHlCQUF5QjtBQUFBLElBQzNCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsTUFBSSwwQkFBMEI7QUFBQSxJQUM1QjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsTUFBSSx1Q0FBdUM7QUFBQTtBQUFBLElBRXpDO0FBQUE7QUFBQSxJQUVBO0FBQUE7QUFBQSxJQUVBO0FBQUE7QUFBQSxJQUVBO0FBQUE7QUFBQSxJQUVBO0FBQUE7QUFBQSxJQUVBO0FBQUEsRUFDRjtBQUNBLE1BQUksMEJBQTBCO0FBQUEsSUFDNUI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsTUFBSSwwQkFBMEI7QUFBQSxJQUM1QjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxNQUFJLGtCQUFrQjtBQUFBLElBQ3BCLEdBQUc7QUFBQSxJQUNILEdBQUc7QUFBQSxJQUNILEdBQUc7QUFBQSxJQUNILEdBQUc7QUFBQSxJQUNILEdBQUc7QUFBQSxJQUNILEdBQUc7QUFBQSxJQUNILEdBQUc7QUFBQSxJQUNILEdBQUc7QUFBQSxFQUNMO0FBQ0EsTUFBSSx1QkFBdUI7QUFBQSxJQUN6QjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFHQSxNQUFJLCtCQUErQjtBQUNuQyxNQUFJLGFBQWE7QUFDakIsV0FBUyx1QkFBdUIsU0FBUyxpQkFBaUIsaUJBQWlCO0FBQ3pFLGNBQVUsUUFBUSxNQUFNLEdBQUcsVUFBVTtBQUNyQyxVQUFNLFdBQVcsQ0FBQztBQUNsQixVQUFNLFlBQVksQ0FBQztBQUNuQixlQUFXLEtBQUssZ0JBQWdCO0FBQzlCLFlBQU0sV0FBVyxTQUFTLE1BQU0sQ0FBQztBQUNqQyxVQUFJLFVBQVU7QUFDWixpQkFBUyxLQUFLLEVBQUUsU0FBUyxDQUFDO0FBQzFCLGtCQUFVLEtBQUssR0FBRyxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsVUFBVSxHQUFHLEdBQUcsQ0FBQyxDQUFDO0FBQUEsTUFDNUQ7QUFBQSxJQUNGO0FBQ0EsV0FBTyxFQUFFLFVBQVUsVUFBVSxVQUFVO0FBQUEsRUFDekM7QUFDQSxXQUFTLHNCQUFzQjtBQUM3QixVQUFNLFNBQVMsbUJBQW1CO0FBQ2xDLFVBQU0sU0FBUyxPQUFPLE9BQU8sQ0FBQyxLQUFLLFVBQVU7QUFDM0MsWUFBTSxZQUFZLE1BQU0sTUFBTSxLQUFLO0FBQ25DLFVBQUksV0FBVztBQUNiLGNBQU0sRUFBRSxTQUFTLElBQUksdUJBQXVCLFNBQVM7QUFDckQsWUFBSSxTQUFTLFNBQVMsR0FBRztBQUN2QixnQkFBTSxFQUFFLGVBQWUsYUFBYSxJQUFJLGdCQUFnQixNQUFNLE9BQU87QUFDckUsY0FBSSxjQUFjLFNBQVMsR0FBRztBQUM1QixnQkFBSSxLQUFLO0FBQUEsY0FDUCxHQUFHO0FBQUEsY0FDSDtBQUFBLGNBQ0E7QUFBQSxZQUNGLENBQUM7QUFBQSxVQUNIO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVCxHQUFHLENBQUMsQ0FBQztBQUNMLFdBQU87QUFBQSxFQUNUO0FBQ0EsV0FBUyxnQkFBZ0IsU0FBUztBQUNoQyxVQUFNLGdCQUFnQixDQUFDO0FBQ3ZCLFVBQU0sZUFBZSxDQUFDO0FBQ3RCLGVBQVcsVUFBVSxTQUFTO0FBQzVCLFVBQUksZUFBZSxPQUFPLElBQUksR0FBRztBQUMvQixzQkFBYyxLQUFLLE1BQU07QUFBQSxNQUMzQixPQUFPO0FBQ0wscUJBQWEsS0FBSyxNQUFNO0FBQUEsTUFDMUI7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLE1BQ0w7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxXQUFTLGVBQWUsWUFBWSxpQkFBaUIsaUJBQWlCLHFCQUFxQixzQkFBc0I7QUFDL0csUUFBSSxDQUFDLFlBQVk7QUFDZixhQUFPO0FBQUEsSUFDVDtBQUNBLFVBQU0sb0JBQW9CLGdCQUFnQixVQUFVO0FBQ3BELFdBQU8sQ0FBQyxtQkFBbUIsS0FBSyxDQUFDLE1BQU0sRUFBRSxLQUFLLGlCQUFpQixDQUFDLEtBQUssZUFBZSxLQUFLLENBQUMsTUFBTSxhQUFhLFVBQVUsRUFBRSxLQUFLLGlCQUFpQixLQUFLLE1BQU0saUJBQWlCO0FBQUEsRUFDN0s7QUFDQSxXQUFTLGdCQUFnQixZQUFZO0FBQ25DLFFBQUksU0FBUyxXQUFXLFlBQVk7QUFDcEMsYUFBUyxPQUFPLFFBQVEsZ0NBQWdDLEVBQUU7QUFDMUQsYUFBUyxPQUFPO0FBQUEsTUFDZDtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsYUFBUyxPQUFPLFFBQVEsUUFBUSxHQUFHO0FBQ25DLGFBQVMsT0FBTyxRQUFRLFFBQVEsR0FBRztBQUNuQyxhQUFTLE9BQU8sS0FBSztBQUNyQixXQUFPO0FBQUEsRUFDVDtBQUNBLFdBQVMscUJBQXFCO0FBQzVCLFVBQU0sV0FBVyxDQUFDLFdBQVc7QUFDN0IsUUFBSSxZQUFZLE9BQU8sVUFBVSxPQUFPLFdBQVcsT0FBTyxLQUFLO0FBQzdELGFBQU8sQ0FBQztBQUFBLElBQ1Y7QUFDQSxXQUFPLHVCQUF1QixRQUFRO0FBQUEsRUFDeEM7QUFDQSxXQUFTLHVCQUF1QixVQUFVO0FBQ3hDLFFBQUksV0FBVyxDQUFDO0FBQ2hCLFFBQUksQ0FBQyxVQUFVO0FBQ2IsaUJBQVcscUJBQXFCO0FBQUEsSUFDbEMsT0FBTztBQUNMLFlBQU0sTUFBTSxTQUFTLFFBQVEsU0FBUztBQUN0QyxVQUFJLE9BQU8saUJBQWlCLEdBQUcsS0FBSyxJQUFJLFdBQVc7QUFDakQsaUJBQVMsS0FBSyxHQUFHO0FBQUEsTUFDbkI7QUFBQSxJQUNGO0FBQ0EsVUFBTSxrQkFBa0IsQ0FBQztBQUN6QixlQUFXLE1BQU0sVUFBVTtBQUN6QixVQUFJLEdBQUcsV0FBVztBQUNoQix3QkFBZ0IsS0FBSztBQUFBLFVBQ25CLE1BQU0sR0FBRztBQUFBLFVBQ1QsU0FBUztBQUFBLFVBQ1QsU0FBUyxjQUFjLEVBQUU7QUFBQSxRQUMzQixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLFdBQVMsdUJBQXVCO0FBQzlCLFVBQU0sU0FBUyxTQUFTO0FBQUEsTUFDdEIsU0FBUztBQUFBLE1BQ1QsV0FBVztBQUFBO0FBQUEsTUFFWDtBQUFBLFFBQ0UsV0FBVyxNQUFNO0FBQ2YsY0FBSSxLQUFLLFlBQVksUUFBUTtBQUMzQixtQkFBTyxXQUFXO0FBQUEsVUFDcEI7QUFDQSxnQkFBTSxjQUFjLE9BQU8saUJBQWlCLElBQUksRUFBRTtBQUNsRCxlQUFLLGdCQUFnQixXQUFXLGdCQUFnQixhQUFhLGlCQUFpQixJQUFJLEdBQUc7QUFDbkYsbUJBQU8sV0FBVztBQUFBLFVBQ3BCO0FBQ0EsaUJBQU8sV0FBVztBQUFBLFFBQ3BCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxVQUFNLFFBQVEsQ0FBQztBQUNmLGFBQVMsT0FBTyxPQUFPLFNBQVMsR0FBRyxNQUFNLE9BQU8sT0FBTyxTQUFTLEdBQUc7QUFDakUsWUFBTSxLQUFLLElBQUk7QUFBQSxJQUNqQjtBQUNBLFdBQU8sa0JBQWtCLEtBQUs7QUFBQSxFQUNoQztBQUNBLFdBQVMsY0FBYyxJQUFJO0FBQ3pCLFVBQU0sb0JBQW9CLGtCQUFrQixzQkFBc0IsRUFBRSxDQUFDLEVBQUU7QUFBQSxNQUNyRSxDQUFDLE1BQU0saUJBQWlCLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsVUFBVSxLQUFLO0FBQUEsTUFDbEUsYUFBYSxvQkFBb0IsQ0FBQyxVQUFVLFFBQVEsRUFBRSxTQUFTLEVBQUUsSUFBSSxLQUFLLEVBQUUsT0FBTyxLQUFLO0FBQUEsSUFDMUY7QUFDQSxXQUFPLGtCQUFrQixJQUFJLENBQUMsT0FBTztBQUFBLE1BQ25DLE9BQU8sRUFBRSxhQUFhLEVBQUUsZUFBZSxJQUFJLEtBQUssS0FBSyxFQUFFLE9BQU8sS0FBSyxLQUFLO0FBQUEsTUFDeEUsU0FBUztBQUFBLElBQ1gsRUFBRTtBQUFBLEVBQ0o7QUFDQSxXQUFTLHNCQUFzQixJQUFJO0FBQ2pDLFdBQU8sTUFBTSxLQUFLLEdBQUcsaUJBQWlCLDRCQUE0QixDQUFDO0FBQUEsRUFDckU7QUFDQSxXQUFTLFdBQVcsSUFBSTtBQUN0QixXQUFPLGNBQWMsTUFBTSxRQUFRLEdBQUcsUUFBUSxLQUFLLEdBQUcsYUFBYSxVQUFVO0FBQUEsRUFDL0U7QUFDQSxXQUFTLGtCQUFrQixVQUFVO0FBQ25DLFVBQU0sVUFBVSxDQUFDO0FBQ2pCLFFBQUksU0FBUyxTQUFTLEdBQUc7QUFDdkIsZUFBUyxJQUFJLFNBQVMsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0FBQzdDLFlBQUksWUFBWTtBQUNoQixpQkFBUyxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztBQUN4QyxjQUFJLE1BQU0sS0FBSyxTQUFTLENBQUMsRUFBRSxTQUFTLFNBQVMsQ0FBQyxDQUFDLEdBQUc7QUFDaEQsd0JBQVk7QUFDWjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0EsWUFBSSxDQUFDLFdBQVc7QUFDZCxrQkFBUSxLQUFLLFNBQVMsQ0FBQyxDQUFDO0FBQUEsUUFDMUI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBR0EsTUFBSSxvQkFBb0I7QUFBQSxJQUN0QixNQUFNO0FBQUEsSUFDTixPQUFPO0FBQUEsSUFDUCxZQUFZO0FBQUEsRUFDZDtBQUNBLE1BQUkscUJBQXFCLE1BQU07QUFBQSxJQUM3QixZQUFZLHFCQUFxQjtBQUMvQixXQUFLLE9BQU87QUFDWixXQUFLLGFBQWE7QUFDbEIsV0FBSyxjQUFjO0FBQUEsSUFDckI7QUFBQSxJQUNBLElBQUksY0FBYztBQUNoQixZQUFNLElBQUksTUFBTSxpQkFBaUI7QUFBQSxJQUNuQztBQUFBLElBQ0EsSUFBSSxpQkFBaUI7QUFDbkIsWUFBTSxJQUFJLE1BQU0saUJBQWlCO0FBQUEsSUFDbkM7QUFBQSxJQUNBLElBQUksYUFBYTtBQUNmLFlBQU0sSUFBSSxNQUFNLGlCQUFpQjtBQUFBLElBQ25DO0FBQUEsSUFDQSxjQUFjLFdBQVc7QUFDdkIsWUFBTSxVQUFVLFNBQVMsU0FBUztBQUNsQyxVQUFJLENBQUMsU0FBUztBQUNaLGFBQUssWUFBWSxPQUFPLEtBQUssVUFBVSxRQUFRLEtBQUsscUJBQXFCLFNBQVM7QUFDbEYsZUFBTyxRQUFRLFFBQVEsS0FBSztBQUFBLE1BQzlCO0FBQ0EsWUFBTSxhQUFhLEtBQUssWUFBWSxPQUFPO0FBQzNDLFVBQUksS0FBSyxZQUFZLE9BQU8sYUFBYTtBQUN2QyxtQkFBVyxTQUFTLFFBQVEsSUFBSSxnQkFBZ0IsV0FBVyxPQUFPO0FBQ2xFLFlBQUksU0FBUztBQUNiLFlBQUk7QUFDRixtQkFBUyxDQUFDLENBQUMsUUFBUSxLQUFLLFVBQVU7QUFBQSxRQUNwQyxTQUFTLEdBQUc7QUFDVixxQkFBVyxTQUFTLFFBQVEsTUFBTSx5QkFBeUIsV0FBVyxDQUFDO0FBQUEsUUFDekU7QUFDQSxlQUFPLFFBQVEsUUFBUSxNQUFNO0FBQUEsTUFDL0I7QUFDQSxZQUFNLGFBQWEsZ0JBQWdCLE9BQU87QUFDMUMsaUJBQVcsU0FBUyxRQUFRLElBQUksZUFBZSxXQUFXLFVBQVU7QUFDcEUsYUFBTyxZQUFZLFlBQVksU0FBUyxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JELG1CQUFXLFNBQVMsUUFBUSxNQUFNLHlCQUF5QixXQUFXLENBQUM7QUFDdkUsZUFBTztBQUFBLE1BQ1QsQ0FBQztBQUFBLElBQ0g7QUFBQSxJQUNBLGtCQUFrQjtBQUNoQixVQUFJLENBQUMsS0FBSyxrQkFBa0IsV0FBVyxDQUFDLEdBQUc7QUFDekMsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLEtBQUssV0FBVyxjQUFjLENBQUMsS0FBSyxzQkFBc0IsR0FBRztBQUMvRCxlQUFPO0FBQUEsTUFDVDtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxrQkFBa0IsT0FBTztBQUN2QixZQUFNLFNBQVM7QUFBQSxRQUNiLEdBQUc7QUFBQSxRQUNILEdBQUcsS0FBSztBQUFBLE1BQ1Y7QUFDQSxVQUFJLFNBQVMsQ0FBQyxPQUFPLE1BQU07QUFDekIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sT0FBTztBQUMzQixlQUFPO0FBQUEsTUFDVDtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSx3QkFBd0I7QUFDdEIsYUFBTyxRQUFRLEtBQUssWUFBWSxjQUFjLE9BQU8sU0FBUyxLQUFLLE1BQU0sS0FBSyxXQUFXLFVBQVUsQ0FBQztBQUFBLElBQ3RHO0FBQUEsSUFDQSxZQUFZO0FBQ1YsWUFBTSxJQUFJLE1BQU0saUJBQWlCO0FBQUEsSUFDbkM7QUFBQSxJQUNBLE1BQU0sY0FBYztBQUNsQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsU0FBUztBQUNQLFlBQU0sSUFBSSxNQUFNLGlCQUFpQjtBQUFBLElBQ25DO0FBQUEsSUFDQSxRQUFRO0FBQ04sWUFBTSxJQUFJLE1BQU0saUJBQWlCO0FBQUEsSUFDbkM7QUFBQSxJQUNBLFVBQVU7QUFDUixZQUFNLElBQUksTUFBTSxpQkFBaUI7QUFBQSxJQUNuQztBQUFBLElBQ0EsTUFBTSxPQUFPO0FBQ1gsYUFBTyxRQUFRLFFBQVEsSUFBSTtBQUFBLElBQzdCO0FBQUEsSUFDQSxNQUFNLGtCQUFrQixVQUFVLE1BQU0sT0FBTyxlQUFlLEtBQUs7QUFDakUsVUFBSSxTQUFTLFdBQVcsR0FBRztBQUN6QjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLENBQUMsS0FBSztBQUNSLG1CQUFXLENBQUMsU0FBUyxDQUFDLENBQUM7QUFBQSxNQUN6QjtBQUNBLFdBQUssWUFBWSxtQkFBbUI7QUFBQSxRQUNsQyxNQUFNO0FBQUEsUUFDTixTQUFTO0FBQUEsTUFDWCxDQUFDO0FBQ0QsaUJBQVcsTUFBTSxVQUFVO0FBQ3pCLGFBQUssWUFBWSxPQUFPLEtBQUssYUFBYSxRQUFRLElBQUksZ0JBQWdCLEVBQUU7QUFDeEUsc0JBQWMsRUFBRTtBQUFBLE1BQ2xCO0FBQ0EsWUFBTSxLQUFLLEtBQUssWUFBWTtBQUM1QixpQkFBVyxNQUFNLFVBQVU7QUFDekIsd0JBQWdCLEVBQUU7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFBQTtBQUFBLElBRUEsTUFBTSxhQUFhLFNBQVM7QUFDMUIsVUFBSSxLQUFLLFlBQVksT0FBTyxZQUFZO0FBQ3RDLGNBQU0sS0FBSyxrQkFBa0IsQ0FBQyxPQUFPLENBQUM7QUFBQSxNQUN4QztBQUNBLFdBQUssWUFBWSxZQUFZLEVBQUUsUUFBUSxLQUFLLFlBQVksTUFBTSxTQUFTLEVBQUUsQ0FBQztBQUMxRSxhQUFPLEtBQUssWUFBWSxXQUFXLGFBQWEsT0FBTztBQUFBLElBQ3pEO0FBQUEsSUFDQSxNQUFNLE1BQU0sVUFBVSxNQUFNLE9BQU87QUFDakMsVUFBSSxLQUFLLFlBQVksT0FBTyxZQUFZO0FBQ3RDLGNBQU0sS0FBSyxrQkFBa0IsS0FBSyxnQkFBZ0IsUUFBUSxHQUFHLEdBQUc7QUFBQSxNQUNsRTtBQUNBLFdBQUssWUFBWSxZQUFZLEVBQUUsUUFBUSxLQUFLLFlBQVksTUFBTSxTQUFTLEVBQUUsQ0FBQztBQUMxRSxhQUFPLEtBQUssWUFBWSxXQUFXLE1BQU0sVUFBVSxHQUFHO0FBQUEsSUFDeEQ7QUFBQSxJQUNBLGNBQWMsVUFBVTtBQUN0QixhQUFPLEtBQUssWUFBWSxXQUFXLGNBQWMsUUFBUTtBQUFBLElBQzNEO0FBQUEsSUFDQSxlQUFlLFVBQVUsT0FBTztBQUM5QixhQUFPLEtBQUssWUFBWSxXQUFXLGVBQWUsVUFBVSxLQUFLO0FBQUEsSUFDbkU7QUFBQSxJQUNBLGVBQWUsVUFBVSxTQUFTO0FBQ2hDLGFBQU8sS0FBSyxZQUFZLFdBQVcsZUFBZSxVQUFVLE9BQU87QUFBQSxJQUNyRTtBQUFBLElBQ0EsZUFBZSxVQUFVLFNBQVMsT0FBTztBQUN2QyxhQUFPLEtBQUssWUFBWSxXQUFXLGVBQWUsVUFBVSxTQUFTLEtBQUs7QUFBQSxJQUM1RTtBQUFBLElBQ0EsTUFBTSxpQkFBaUIsVUFBVSxTQUFTLEtBQUs7QUFDN0MsVUFBSSxLQUFLLFlBQVksT0FBTyxZQUFZO0FBQ3RDLGNBQU0sS0FBSyxrQkFBa0IsS0FBSyxnQkFBZ0IsUUFBUSxHQUFHLEdBQUc7QUFBQSxNQUNsRTtBQUNBLFdBQUssWUFBWSxZQUFZLEVBQUUsUUFBUSxLQUFLLFlBQVksTUFBTSxTQUFTLEVBQUUsQ0FBQztBQUMxRSxhQUFPLEtBQUssWUFBWSxXQUFXLGlCQUFpQixVQUFVLFNBQVMsR0FBRztBQUFBLElBQzVFO0FBQUEsSUFDQSxLQUFLLElBQUk7QUFDUCxhQUFPLEtBQUssWUFBWSxXQUFXLEtBQUssRUFBRTtBQUFBLElBQzVDO0FBQUEsSUFDQSxLQUFLLFVBQVUsUUFBUTtBQUNyQixhQUFPLEtBQUssWUFBWSxXQUFXLEtBQUssVUFBVSxNQUFNO0FBQUEsSUFDMUQ7QUFBQSxJQUNBLGVBQWUsV0FBVztBQUN4QixhQUFPLEtBQUssWUFBWSxXQUFXLGVBQWUsU0FBUztBQUFBLElBQzdEO0FBQUEsSUFDQSxRQUFRLFVBQVU7QUFDaEIsYUFBTyxLQUFLLFlBQVksV0FBVyxRQUFRLFFBQVE7QUFBQSxJQUNyRDtBQUFBLElBQ0EsY0FBYztBQUNaLGFBQU8sS0FBSyxZQUFZLFdBQVcsWUFBWTtBQUFBLElBQ2pEO0FBQUEsSUFDQSx5QkFBeUIsVUFBVSxRQUFRO0FBQ3pDLGFBQU8sS0FBSyxZQUFZLFdBQVcseUJBQXlCLFVBQVUsTUFBTTtBQUFBLElBQzlFO0FBQUEsSUFDQSxtQkFBbUIsV0FBVztBQUM1QixhQUFPLEtBQUssWUFBWSxXQUFXLG1CQUFtQixTQUFTO0FBQUEsSUFDakU7QUFBQSxJQUNBLGdCQUFnQixVQUFVO0FBQ3hCLGFBQU8sS0FBSyxZQUFZLFdBQVcsZ0JBQWdCLFFBQVE7QUFBQSxJQUM3RDtBQUFBLElBQ0EsZ0JBQWdCLFVBQVU7QUFDeEIsYUFBTyxLQUFLLFlBQVksV0FBVyxnQkFBZ0IsUUFBUTtBQUFBLElBQzdEO0FBQUEsRUFDRjtBQUNBLE1BQUksaUJBQWlCLGNBQWMsbUJBQW1CO0FBQUEsSUFDcEQsWUFBWSxNQUFNLHFCQUFxQjtBQUNyQyxZQUFNLG1CQUFtQjtBQUN6QixXQUFLLE9BQU87QUFDWixXQUFLLE9BQU8sS0FBSztBQUNqQixXQUFLLGFBQWEsS0FBSyxjQUFjO0FBQUEsSUFDdkM7QUFBQSxJQUNBLElBQUksY0FBYztBQUNoQixhQUFPLENBQUMsQ0FBQyxLQUFLLEtBQUssUUFBUSxLQUFLLEtBQUssS0FBSyxTQUFTO0FBQUEsSUFDckQ7QUFBQSxJQUNBLElBQUksaUJBQWlCO0FBQ25CLGFBQU8sQ0FBQyxDQUFDLEtBQUssS0FBSztBQUFBLElBQ3JCO0FBQUEsSUFDQSxJQUFJLGFBQWE7QUFDZixhQUFPLENBQUMsQ0FBQyxLQUFLLEtBQUs7QUFBQSxJQUNyQjtBQUFBLElBQ0EsSUFBSSxtQkFBbUI7QUFDckIsYUFBTyxLQUFLLEtBQUssb0JBQW9CLENBQUM7QUFBQSxJQUN4QztBQUFBLElBQ0EsTUFBTSxZQUFZO0FBQ2hCLFVBQUksS0FBSyxLQUFLLFdBQVc7QUFDdkIsZUFBTyxLQUFLLHNCQUFzQixLQUFLLEtBQUssV0FBVyxLQUFLLFlBQVksT0FBTyxLQUFLLGNBQWM7QUFBQSxNQUNwRztBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLGNBQWM7QUFDbEIsVUFBSSxLQUFLLEtBQUssYUFBYTtBQUN6QixlQUFPLEtBQUssc0JBQXNCLEtBQUssS0FBSyxhQUFhLEtBQUssWUFBWSxPQUFPLEtBQUssY0FBYztBQUFBLE1BQ3RHO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sU0FBUztBQUNiLFlBQU0sYUFBYSxLQUFLLFlBQVksT0FBTztBQUMzQyxVQUFJLEtBQUssS0FBSyxRQUFRO0FBQ3BCLG1CQUFXLGFBQWEsUUFBUSxJQUFJLHNCQUFzQixLQUFLLEtBQUssTUFBTTtBQUMxRSxlQUFPLEtBQUssc0JBQXNCLEtBQUssS0FBSyxRQUFRLEtBQUssWUFBWSxPQUFPLEtBQUssU0FBUztBQUFBLE1BQzVGO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sUUFBUTtBQUNaLFlBQU0sYUFBYSxLQUFLLFlBQVksT0FBTztBQUMzQyxVQUFJLEtBQUssS0FBSyxPQUFPO0FBQ25CLG1CQUFXLGFBQWEsUUFBUSxJQUFJLHFCQUFxQixLQUFLLEtBQUssS0FBSztBQUN4RSxlQUFPLEtBQUssc0JBQXNCLEtBQUssS0FBSyxPQUFPLEtBQUssWUFBWSxPQUFPLEtBQUssU0FBUztBQUFBLE1BQzNGO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sVUFBVTtBQUNkLFVBQUksS0FBSyxLQUFLLFNBQVM7QUFDckIsZUFBTyxLQUFLLHNCQUFzQixLQUFLLEtBQUssU0FBUyxLQUFLLFlBQVksT0FBTyxLQUFLLFNBQVM7QUFBQSxNQUM3RjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLE9BQU87QUFDWCxVQUFJLEtBQUssZUFBZSxLQUFLLEtBQUssTUFBTTtBQUN0QyxlQUFPLEtBQUssc0JBQXNCLEtBQUssS0FBSyxNQUFNLEtBQUssWUFBWSxPQUFPLEtBQUssU0FBUztBQUFBLE1BQzFGO0FBQ0EsYUFBTyxNQUFNLEtBQUs7QUFBQSxJQUNwQjtBQUFBLElBQ0EsTUFBTSxpQkFBaUIsTUFBTTtBQUMzQixZQUFNLFVBQVUsQ0FBQztBQUNqQixZQUFNLGFBQWEsS0FBSyxZQUFZLE9BQU87QUFDM0MsVUFBSSxLQUFLLFFBQVE7QUFDZixnQkFBUSxLQUFLLEtBQUssY0FBYyxLQUFLLE1BQU0sQ0FBQztBQUFBLE1BQzlDO0FBQ0EsVUFBSSxLQUFLLFNBQVM7QUFDaEIsZ0JBQVEsS0FBSyxLQUFLLGVBQWUsS0FBSyxTQUFTLEtBQUssS0FBSyxDQUFDO0FBQUEsTUFDNUQ7QUFDQSxVQUFJLEtBQUssTUFBTTtBQUNiLGNBQU0sTUFBTSxLQUFLLGNBQWMsS0FBSyxJQUFJO0FBQ3hDLGdCQUFRLEtBQUssR0FBRztBQUFBLE1BQ2xCO0FBQ0EsVUFBSSxLQUFLLFNBQVM7QUFDaEIsZ0JBQVEsS0FBSyxLQUFLLGVBQWUsS0FBSyxTQUFTLEtBQUssT0FBTyxDQUFDO0FBQUEsTUFDOUQ7QUFDQSxVQUFJLEtBQUssZ0JBQWdCO0FBQ3ZCLGdCQUFRLEtBQUssS0FBSyxlQUFlLEtBQUssZ0JBQWdCLEtBQUssU0FBUyxLQUFLLEtBQUssQ0FBQztBQUFBLE1BQ2pGO0FBQ0EsVUFBSSxLQUFLLE9BQU87QUFDZCxnQkFBUSxLQUFLLEtBQUssTUFBTSxLQUFLLE9BQU8sS0FBSyxHQUFHLENBQUM7QUFBQSxNQUMvQztBQUNBLFVBQUksS0FBSyxrQkFBa0I7QUFDekIsZ0JBQVEsS0FBSyxLQUFLLGlCQUFpQixLQUFLLGtCQUFrQixLQUFLLFNBQVMsS0FBSyxHQUFHLENBQUM7QUFBQSxNQUNuRjtBQUNBLFVBQUksS0FBSyxNQUFNO0FBQ2IsZ0JBQVEsS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJLENBQUM7QUFBQSxNQUNuQztBQUNBLFVBQUksS0FBSyxNQUFNO0FBQ2IsZ0JBQVEsS0FBSyxLQUFLLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxDQUFDO0FBQUEsTUFDaEQ7QUFDQSxVQUFJLEtBQUssZ0JBQWdCO0FBQ3ZCLGdCQUFRLEtBQUssS0FBSyxlQUFlLEtBQUssY0FBYyxDQUFDO0FBQUEsTUFDdkQ7QUFDQSxVQUFJLEtBQUssSUFBSTtBQUNYLFlBQUksQ0FBQyxLQUFLLEdBQUcsVUFBVSxDQUFDLEtBQUssR0FBRyxTQUFTO0FBQ3ZDLGtCQUFRLE1BQU0sNEJBQTRCLEtBQUssRUFBRTtBQUNqRCxpQkFBTztBQUFBLFFBQ1Q7QUFDQSxZQUFJLENBQUMsS0FBSyxNQUFNO0FBQ2Qsa0JBQVEsTUFBTSxpREFBaUQsS0FBSyxFQUFFO0FBQ3RFLGlCQUFPO0FBQUEsUUFDVDtBQUNBLGNBQU0sWUFBWSxNQUFNLEtBQUssaUJBQWlCLEtBQUssRUFBRTtBQUNyRCxtQkFBVyxhQUFhLFFBQVEsSUFBSSxnQkFBZ0IsU0FBUztBQUM3RCxZQUFJLFdBQVc7QUFDYixrQkFBUSxLQUFLLEtBQUssc0JBQXNCLEtBQUssTUFBTSxXQUFXLFNBQVMsQ0FBQztBQUFBLFFBQzFFLFdBQVcsS0FBSyxNQUFNO0FBQ3BCLGtCQUFRLEtBQUssS0FBSyxzQkFBc0IsS0FBSyxNQUFNLFdBQVcsU0FBUyxDQUFDO0FBQUEsUUFDMUUsT0FBTztBQUNMLGtCQUFRLEtBQUssSUFBSTtBQUFBLFFBQ25CO0FBQUEsTUFDRjtBQUNBLFVBQUksS0FBSyxLQUFLO0FBQ1osWUFBSSxjQUFjO0FBQ2xCLG1CQUFXLFFBQVEsS0FBSyxLQUFLO0FBQzNCLGNBQUksTUFBTSxLQUFLLGlCQUFpQixJQUFJLEdBQUc7QUFDckMsMEJBQWM7QUFDZDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0EsZ0JBQVEsS0FBSyxXQUFXO0FBQUEsTUFDMUI7QUFDQSxVQUFJLFFBQVEsV0FBVyxHQUFHO0FBQ3hCLG1CQUFXLFVBQVUsUUFBUSxLQUFLLHFCQUFxQixJQUFJO0FBQzNELGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxNQUFNLE1BQU0sUUFBUSxJQUFJLE9BQU87QUFDckMsWUFBTSxTQUFTLElBQUksT0FBTyxDQUFDLEdBQUcsTUFBTSxLQUFLLEdBQUcsSUFBSTtBQUNoRCxVQUFJLEtBQUssU0FBUztBQUNoQixlQUFPLENBQUM7QUFBQSxNQUNWO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sa0JBQWtCLE9BQU87QUFDN0IsWUFBTSxVQUFVLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxpQkFBaUIsSUFBSSxDQUFDO0FBQy9ELFlBQU0sYUFBYSxNQUFNLFFBQVEsSUFBSSxPQUFPO0FBQzVDLGFBQU8sV0FBVyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUFBLElBQ3BDO0FBQUEsSUFDQSxNQUFNLHNCQUFzQixPQUFPLFdBQVcsTUFBTTtBQUNsRCxpQkFBVyxRQUFRLE9BQU87QUFDeEIsb0JBQVksUUFBUSxJQUFJLG1CQUFtQixJQUFJO0FBQy9DLGNBQU0sU0FBUyxNQUFNLEtBQUssaUJBQWlCLElBQUk7QUFDL0Msb0JBQVksUUFBUSxJQUFJLGtCQUFrQixNQUFNO0FBQ2hELFlBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxVQUFVO0FBQzdCLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLDBCQUEwQixjQUFjLG1CQUFtQjtBQUFBLElBQzdELFlBQVkscUJBQXFCO0FBQy9CLFlBQU0sbUJBQW1CO0FBQ3pCLFdBQUssU0FBUyxDQUFDO0FBQ2YsV0FBSyxPQUFPO0FBQ1osV0FBSyxhQUFhO0FBQUEsUUFDaEIsTUFBTTtBQUFBLFFBQ04sT0FBTztBQUFBO0FBQUEsTUFFVDtBQUFBLElBQ0Y7QUFBQSxJQUNBLElBQUksY0FBYztBQUNoQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSSxpQkFBaUI7QUFDbkIsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLElBQUksYUFBYTtBQUNmLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxZQUFZO0FBQ1YsV0FBSyxTQUFTLG9CQUFvQjtBQUNsQyxVQUFJLEtBQUssT0FBTyxTQUFTLEdBQUc7QUFDMUIsZUFBTyxRQUFRLFFBQVEsSUFBSTtBQUFBLE1BQzdCO0FBQ0EsYUFBTyxRQUFRLFFBQVEsS0FBSztBQUFBLElBQzlCO0FBQUEsSUFDQSxNQUFNLGNBQWM7QUFDbEIsVUFBSSxLQUFLLE9BQU8sU0FBUyxHQUFHO0FBQzFCLFlBQUksS0FBSyxPQUFPLFNBQVMsS0FBSyxLQUFLLE9BQU8sQ0FBQyxFQUFFLGlCQUFpQixLQUFLLE9BQU8sQ0FBQyxFQUFFLGNBQWMsU0FBUyxHQUFHO0FBQ3JHLGVBQUssWUFBWSxPQUFPLEtBQUssVUFBVSxRQUFRLEtBQUsseUNBQXlDO0FBQUEsUUFDL0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxTQUFTO0FBQ1AsWUFBTSxTQUFTLEtBQUssT0FBTyxDQUFDLEdBQUcsZ0JBQWdCLENBQUM7QUFDaEQsVUFBSSxRQUFRO0FBQ1YsZUFBTyxLQUFLLGFBQWEsT0FBTyxPQUFPO0FBQUEsTUFDekM7QUFDQSxhQUFPLFFBQVEsUUFBUSxLQUFLO0FBQUEsSUFDOUI7QUFBQSxJQUNBLFFBQVE7QUFDTixZQUFNLElBQUksTUFBTSxpQkFBaUI7QUFBQSxJQUNuQztBQUFBLElBQ0EsVUFBVTtBQUNSLFlBQU0sSUFBSSxNQUFNLGlCQUFpQjtBQUFBLElBQ25DO0FBQUEsSUFDQSxNQUFNLE9BQU87QUFDWCxZQUFNLFNBQVMsS0FBSyxPQUFPLENBQUMsRUFBRSxnQkFBZ0IsQ0FBQztBQUMvQyxVQUFJLFFBQVE7QUFDVixjQUFNLEtBQUssS0FBSyxHQUFHO0FBQ25CLGVBQU8sQ0FBQyxpQkFBaUIsT0FBTyxPQUFPO0FBQUEsTUFDekM7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFHQSxNQUFJLG1CQUFtQixNQUFNO0FBQUEsSUFDM0IsWUFBWSxNQUFNLFFBQVE7QUFDeEIsV0FBSyxPQUFPO0FBQ1osV0FBSyxTQUFTO0FBQ2QsV0FBSyxVQUEwQixvQkFBSSxJQUFJO0FBQ3ZDLFdBQUssYUFBYTtBQUNsQixXQUFLLGFBQWE7QUFDbEIsYUFBTyxRQUFRLFFBQVEsQ0FBQyxpQkFBaUI7QUFDdkMsWUFBSSxhQUFhLFFBQVE7QUFDdkIsZUFBSyxRQUFRLElBQUksYUFBYSxNQUFNLGFBQWEsTUFBTTtBQUFBLFFBQ3pEO0FBQUEsTUFDRixDQUFDO0FBQ0QsV0FBSyxjQUFjO0FBQUEsSUFDckI7QUFBQSxJQUNBLElBQUksaUJBQWlCO0FBQ25CLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxrQkFBa0I7QUFDaEIsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLGtCQUFrQixPQUFPO0FBQ3ZCLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSx3QkFBd0I7QUFDdEIsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sWUFBWTtBQUNoQixZQUFNLGVBQWUsS0FBSyxPQUFPLFVBQVUsSUFBSSxDQUFDLG1CQUFtQixRQUFRLGVBQWUsY0FBYyxDQUFDO0FBQ3pHLGFBQU8sYUFBYSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUFBLElBQ3JDO0FBQUEsSUFDQSxNQUFNLGNBQWM7QUFDbEIsWUFBTSxlQUFlLEtBQUssT0FBTyxVQUFVLElBQUksQ0FBQyxtQkFBbUIsUUFBUSxlQUFlLGNBQWMsQ0FBQztBQUN6RyxhQUFPLGFBQWEsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFBQSxJQUNyQztBQUFBLElBQ0EsTUFBTSxjQUFjLFFBQVEsT0FBTztBQUNqQyxVQUFJLEtBQUssUUFBUSxJQUFJLE1BQU0sR0FBRztBQUM1QixlQUFPLGNBQWMsS0FBSyxRQUFRLElBQUksTUFBTSxHQUFHLEtBQUs7QUFBQSxNQUN0RDtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLFNBQVM7QUFDYixZQUFNLEtBQUssY0FBYyxVQUFVO0FBQ25DLFlBQU0sS0FBSyxjQUFjLGNBQWM7QUFDdkMsWUFBTSxLQUFLLGNBQWMsVUFBVTtBQUNuQyxZQUFNLEtBQUssY0FBYyxjQUFjLENBQUMsQ0FBQztBQUN6QyxZQUFNLEtBQUssY0FBYyxjQUFjO0FBQ3ZDLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLFFBQVE7QUFDWixZQUFNLEtBQUssY0FBYyxVQUFVO0FBQ25DLFlBQU0sS0FBSyxjQUFjLGNBQWM7QUFDdkMsWUFBTSxLQUFLLGNBQWMsVUFBVTtBQUNuQyxZQUFNLEtBQUssY0FBYyxjQUFjLENBQUMsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEdBQUcsQ0FBQztBQUNyRSxZQUFNLEtBQUssY0FBYyxjQUFjO0FBQ3ZDLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLFVBQVU7QUFDZCxZQUFNLEtBQUssY0FBYyxVQUFVO0FBQ25DLFlBQU0sS0FBSyxjQUFjLGNBQWM7QUFDdkMsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sT0FBTztBQUNYLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUdBLE1BQUksOEJBQThCO0FBR2xDLE1BQUksdUJBQXVCO0FBQzNCLE1BQUksaUJBQWlCO0FBQ3JCLE1BQUksZ0JBQWdCO0FBQ3BCLE1BQUksZUFBZTtBQUNuQixNQUFJLGdCQUFnQjtBQUNwQixNQUFJLGtCQUFrQjtBQUN0QixNQUFJLGNBQWMsY0FBYyxtQkFBbUI7QUFBQSxJQUNqRCxZQUFZLHFCQUFxQjtBQUMvQixZQUFNLG1CQUFtQjtBQUN6QixXQUFLLE9BQU87QUFDWixXQUFLLG1CQUFtQixDQUFDLDhCQUE4Qix3REFBd0QsZUFBZSxFQUFFO0FBQ2hJLFdBQUssYUFBYTtBQUFBLFFBQ2hCLE1BQU07QUFBQSxRQUNOLE9BQU87QUFBQSxNQUNUO0FBQ0EsV0FBSyxrQkFBa0I7QUFDdkIsV0FBSyxhQUFhO0FBQUEsSUFDcEI7QUFBQSxJQUNBLElBQUksY0FBYztBQUNoQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSSxpQkFBaUI7QUFDbkIsVUFBSSxLQUFLLFlBQVk7QUFDbkIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPLENBQUMsS0FBSztBQUFBLElBQ2Y7QUFBQSxJQUNBLElBQUksYUFBYTtBQUNmLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLFlBQVk7QUFDaEIsWUFBTSxTQUFTLEtBQUssY0FBYyxHQUFHLG9CQUFvQixJQUFJLGVBQWUsRUFBRTtBQUM5RSxVQUFJLFFBQVE7QUFDVixhQUFLLGtCQUFrQixTQUFTLGNBQWMsY0FBYztBQUFBLE1BQzlEO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sY0FBYztBQUNsQixhQUFPLEtBQUssZUFBZSxHQUFHLFlBQVksSUFBSSxhQUFhLElBQUksZUFBZSxJQUFJLEtBQUs7QUFBQSxJQUN6RjtBQUFBLElBQ0EsTUFBTSxTQUFTO0FBQ2IsVUFBSSxLQUFLLGlCQUFpQjtBQUN4QixhQUFLLGdCQUFnQixNQUFNO0FBQzNCLGVBQU87QUFBQSxNQUNUO0FBQ0EsbUJBQWEsZ0JBQWdCLEdBQUcsMkRBQTJELGVBQWUsRUFBRTtBQUM1RyxZQUFNLEtBQUssTUFBTSxvQkFBb0I7QUFDckMsaUJBQVcsTUFBTTtBQUNmLHdCQUFnQixFQUFFLE9BQU87QUFBQSxNQUMzQixHQUFHLEdBQUc7QUFDTixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsTUFBTSxRQUFRO0FBQ1osV0FBSyxhQUFhO0FBQ2xCLGFBQU8sTUFBTSxLQUFLLE1BQU0sYUFBYTtBQUFBLElBQ3ZDO0FBQUEsSUFDQSxNQUFNLFVBQVU7QUFDZCxhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsTUFBTSxPQUFPO0FBQ1gsWUFBTSxLQUFLLEtBQUssR0FBRztBQUNuQixhQUFPLE1BQU0sS0FBSyxjQUFjLG1CQUFtQjtBQUFBLElBQ3JEO0FBQUEsRUFDRjtBQUdBLE1BQUksZ0JBQWdCLGNBQWMsbUJBQW1CO0FBQUEsSUFDbkQsY0FBYztBQUNaLFlBQU0sR0FBRyxTQUFTO0FBQ2xCLFdBQUssT0FBTztBQUNaLFdBQUssYUFBYTtBQUFBLFFBQ2hCLE1BQU07QUFBQSxRQUNOLE9BQU87QUFBQSxRQUNQLFlBQVk7QUFBQSxNQUNkO0FBQUEsSUFDRjtBQUFBLElBQ0EsSUFBSSxjQUFjO0FBQ2hCLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxJQUFJLGlCQUFpQjtBQUNuQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSSxhQUFhO0FBQ2YsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sWUFBWTtBQUNoQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsTUFBTSxjQUFjO0FBQ2xCLGFBQU8sS0FBSyxlQUFlLDZCQUE2QixLQUFLLEtBQUssS0FBSyxlQUFlLGdCQUFnQixLQUFLO0FBQUEsSUFDN0c7QUFBQSxJQUNBLE1BQU0scUJBQXFCO0FBQ3pCLFlBQU07QUFBQSxRQUNKLFlBQVk7QUFDVixpQkFBTyxLQUFLLGNBQWMsTUFBTSxLQUFLLEtBQUssZUFBZSxZQUFZLEtBQUssS0FBSyxLQUFLLGNBQWMsMEJBQTBCO0FBQUEsUUFDOUg7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxVQUFJLEtBQUssY0FBYyxNQUFNLEdBQUc7QUFDOUIsY0FBTSxLQUFLLE1BQU0sTUFBTTtBQUFBLE1BQ3pCO0FBQ0EsWUFBTSxLQUFLLGVBQWUsY0FBYyxHQUFHO0FBQzNDLFVBQUksS0FBSyxlQUFlLFlBQVksS0FBSyxHQUFHO0FBQzFDLGNBQU0sS0FBSyxNQUFNLFVBQVU7QUFBQSxNQUM3QjtBQUNBLGFBQU8sTUFBTSxRQUFRLE1BQU0sS0FBSyxlQUFlLDRCQUE0QixLQUFLLEdBQUcsR0FBRyxHQUFHO0FBQUEsSUFDM0Y7QUFBQSxJQUNBLE1BQU0sU0FBUztBQUNiLFVBQUksTUFBTSxLQUFLLGNBQWMsMEJBQTBCLEdBQUc7QUFDeEQsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFVBQVU7QUFDZCxVQUFJLE1BQU0sS0FBSyxjQUFjLHlCQUF5QixHQUFHO0FBQ3ZELGtCQUFVO0FBQUEsTUFDWjtBQUNBLFlBQU0sUUFBUSxNQUFNLFNBQVMsZUFBZSxZQUFZLElBQUksR0FBRztBQUMvRCxZQUFNLEtBQUssZUFBZSxtQ0FBbUMsT0FBTztBQUNwRSxVQUFJLE1BQU0sS0FBSyxNQUFNLFlBQVksR0FBRztBQUNsQyxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksS0FBSyxjQUFjLFlBQVksR0FBRztBQUNwQyxjQUFNLEtBQUssZUFBZSw0Q0FBNEMsT0FBTztBQUFBLE1BQy9FO0FBQ0EsVUFBSSxNQUFNLEtBQUssTUFBTSxjQUFjLEdBQUc7QUFDcEMsY0FBTSxLQUFLLE1BQU0sU0FBUztBQUMxQixhQUFLLGlCQUFpQix1QkFBdUIsT0FBTztBQUNwRCxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksTUFBTSxLQUFLLE1BQU0sV0FBVyxHQUFHO0FBQ2pDLGFBQUssaUJBQWlCLHVCQUF1QixPQUFPO0FBQ3BELGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxLQUFLLG1CQUFtQjtBQUM5QixZQUFNLEtBQUssTUFBTSwwQ0FBMEMsSUFBSTtBQUMvRCxZQUFNLEtBQUssTUFBTSxTQUFTO0FBQzFCLFdBQUssaUJBQWlCLHVCQUF1QixVQUFVLEVBQUU7QUFDekQsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sUUFBUTtBQUNaLFVBQUksTUFBTSxLQUFLLE1BQU0sT0FBTyxHQUFHO0FBQzdCLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxLQUFLLG1CQUFtQjtBQUM5QixZQUFNLEtBQUssTUFBTSw2QkFBNkIsSUFBSTtBQUNsRCxZQUFNLEtBQUssTUFBTSxTQUFTO0FBQzFCLFdBQUssZUFBZSx1QkFBdUIsR0FBRyxFQUFFLEtBQUssTUFBTTtBQUN6RCxhQUFLLE1BQU0scUJBQXFCO0FBQUEsTUFDbEMsQ0FBQztBQUNELGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLE9BQU87QUFDWCxZQUFNLEtBQUssS0FBSyxHQUFHO0FBQ25CLGFBQU8sTUFBTSxLQUFLLGNBQWMsMEJBQTBCO0FBQUEsSUFDNUQ7QUFBQSxFQUNGO0FBR0EsTUFBSSxZQUFZLGNBQWMsbUJBQW1CO0FBQUEsSUFDL0MsY0FBYztBQUNaLFlBQU0sR0FBRyxTQUFTO0FBQ2xCLFdBQUssT0FBTztBQUNaLFdBQUssbUJBQW1CO0FBQUEsUUFDdEI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsSUFBSSxjQUFjO0FBQ2hCLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxJQUFJLGlCQUFpQjtBQUNuQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSSxhQUFhO0FBQ2YsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sWUFBWTtBQUNoQixhQUFPLE1BQU0sS0FBSyxjQUFjLGtCQUFrQjtBQUFBLElBQ3BEO0FBQUEsSUFDQSxNQUFNLGNBQWM7QUFDbEIsYUFBTyxLQUFLLGNBQWMsa0JBQWtCO0FBQUEsSUFDOUM7QUFBQSxJQUNBLE1BQU0sU0FBUztBQUNiLFlBQU0sS0FBSyxLQUFLLEdBQUc7QUFDbkIsVUFBSSxNQUFNLE1BQU0sS0FBSyxjQUFjLGtCQUFrQjtBQUNyRCxZQUFNLEtBQUssS0FBSyxHQUFHO0FBQ25CLFlBQU0sT0FBTyxNQUFNLEtBQUssY0FBYyxrQkFBa0I7QUFDeEQsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sUUFBUTtBQUNaLFVBQUksS0FBSyxjQUFjLHFCQUFxQixHQUFHO0FBQzdDLGVBQU8sTUFBTSxLQUFLLE1BQU0sb0JBQW9CO0FBQUEsTUFDOUM7QUFDQSxZQUFNLEtBQUssTUFBTSw4REFBOEQsSUFBSTtBQUNuRixZQUFNLEtBQUssTUFBTSw0Q0FBNEM7QUFDN0QsWUFBTSxLQUFLLE1BQU0sdUNBQXVDO0FBQ3hELGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLE9BQU87QUFDWCxZQUFNLEtBQUssS0FBSyxHQUFHO0FBQ25CLGFBQU8sTUFBTSxLQUFLLGNBQWMsa0JBQWtCO0FBQUEsSUFDcEQ7QUFBQSxFQUNGO0FBR0EsTUFBSSxjQUFjLGNBQWMsbUJBQW1CO0FBQUEsSUFDakQsY0FBYztBQUNaLFlBQU0sR0FBRyxTQUFTO0FBQ2xCLFdBQUssT0FBTztBQUNaLFdBQUssbUJBQW1CLENBQUMscURBQXFELCtCQUErQjtBQUM3RyxXQUFLLGFBQWE7QUFDbEIsV0FBSyxZQUFZO0FBQ2pCLFdBQUssYUFBYTtBQUFBLFFBQ2hCLE1BQU07QUFBQSxRQUNOLE9BQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBLElBQ0EsSUFBSSxjQUFjO0FBQ2hCLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxJQUFJLGlCQUFpQjtBQUNuQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSSxhQUFhO0FBQ2YsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sWUFBWTtBQUNoQixZQUFNLE1BQU0sSUFBSSxJQUFJLFNBQVMsSUFBSTtBQUNqQyxVQUFJLElBQUksYUFBYSxJQUFJLFlBQVksS0FBSyxJQUFJLGFBQWEsMkJBQTJCO0FBQ3BGLGFBQUssYUFBYTtBQUNsQixlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksSUFBSSxhQUFhLHVCQUF1QjtBQUMxQyxhQUFLLFlBQVk7QUFDakIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxjQUFRLElBQUksYUFBYSxpQkFBaUIsSUFBSSxhQUFhLGlDQUFpQyxJQUFJLGFBQWEseUJBQXlCLElBQUksYUFBYSx5QkFBeUIsSUFBSSxhQUFhLElBQUksWUFBWSxLQUFLLElBQUksYUFBYSxJQUFJLGFBQWEsS0FBSyxJQUFJLGFBQWEsSUFBSSxhQUFhO0FBQUEsSUFDalM7QUFBQSxJQUNBLE1BQU0sY0FBYztBQUNsQixVQUFJLEtBQUssWUFBWTtBQUNuQixlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksS0FBSyxXQUFXO0FBQ2xCLGVBQU8sTUFBTSxLQUFLLGVBQWUsa0JBQWtCLEdBQUc7QUFBQSxNQUN4RDtBQUNBLFlBQU0sS0FBSztBQUFBLFFBQ1Q7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBLGFBQU8sQ0FBQyxLQUFLLGNBQWMsbUJBQW1CO0FBQUEsSUFDaEQ7QUFBQSxJQUNBLE1BQU0sUUFBUTtBQUNaLFlBQU0sS0FBSyxlQUFlLGlEQUFpRCxHQUFHO0FBQzlFLFVBQUksTUFBTSxLQUFLLE1BQU0sb0JBQW9CLEdBQUc7QUFDMUMsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLE1BQU0sS0FBSyxNQUFNLDRCQUE0QixHQUFHO0FBQ2xELGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLGdCQUFnQjtBQUNkLGFBQU8sU0FBUyxhQUFhLGlDQUFpQyxTQUFTLGFBQWE7QUFBQSxJQUN0RjtBQUFBLElBQ0EsTUFBTSxTQUFTO0FBQ2IsWUFBTSxLQUFLLEtBQUssR0FBRztBQUNuQixZQUFNLGFBQWEsS0FBSyxZQUFZLE9BQU87QUFDM0MsVUFBSSxLQUFLLFdBQVc7QUFDbEIsY0FBTSxVQUFVLFNBQVM7QUFBQSxVQUN2QjtBQUFBLFFBQ0Y7QUFDQSxtQkFBVyxLQUFLLFNBQVM7QUFDdkIsWUFBRSxNQUFNO0FBQUEsUUFDVjtBQUNBLGNBQU0sV0FBVyxTQUFTO0FBQUEsVUFDeEI7QUFBQSxRQUNGO0FBQ0EsbUJBQVcsS0FBSyxVQUFVO0FBQ3hCLFlBQUUsTUFBTTtBQUFBLFFBQ1Y7QUFDQSxlQUFPLE1BQU0sS0FBSyxNQUFNLGdCQUFnQjtBQUFBLE1BQzFDO0FBQ0EsVUFBSSxLQUFLLGVBQWUsc0JBQXNCLEtBQUssR0FBRztBQUNwRCxjQUFNLEtBQUs7QUFBQSxVQUNUO0FBQUEsWUFDRTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDQSxlQUFPLE1BQU0sS0FBSyxNQUFNLG9CQUFvQjtBQUFBLE1BQzlDO0FBQ0EsVUFBSSxDQUFDLEtBQUssY0FBYyxHQUFHO0FBQ3pCLGNBQU0sYUFBYSxNQUFNLEtBQUssZUFBZSxxRUFBcUU7QUFDbEgsWUFBSSxDQUFDLFlBQVk7QUFDZixpQkFBTztBQUFBLFFBQ1Q7QUFDQSxZQUFJLENBQUMsS0FBSyxjQUFjLGtEQUFrRCxHQUFHO0FBQzNFLGlCQUFPLE1BQU0sS0FBSyxNQUFNLG9CQUFvQjtBQUFBLFFBQzlDO0FBQ0EsY0FBTSxLQUFLLE1BQU0sa0RBQWtEO0FBQ25FLGNBQU0sUUFBUSxNQUFNLEtBQUssY0FBYyxHQUFHLEtBQUssR0FBRztBQUFBLE1BQ3BEO0FBQ0EsWUFBTSxLQUFLLGVBQWUsZUFBZSxHQUFHO0FBQzVDLFVBQUksS0FBSyxjQUFjLGdCQUFnQixHQUFHO0FBQ3hDLGNBQU0sS0FBSyxlQUFlLDZCQUE2QixHQUFHO0FBQUEsTUFDNUQ7QUFDQSxXQUFLLGlCQUFpQixxREFBcUQsS0FBSyxJQUFJO0FBQ3BGLFVBQUk7QUFDRixjQUFNLGtCQUFrQjtBQUN4QixjQUFNLGtCQUFrQjtBQUN4QixjQUFNLE9BQU8sTUFBTSxRQUFRLEtBQUs7QUFBQSxVQUM5QixLQUFLLGVBQWUsaUJBQWlCLEdBQUcsRUFBRSxLQUFLLENBQUMsWUFBWSxVQUFVLElBQUksRUFBRTtBQUFBLFVBQzVFLEtBQUssZUFBZSxpQkFBaUIsR0FBRyxFQUFFLEtBQUssQ0FBQyxZQUFZLFVBQVUsSUFBSSxFQUFFO0FBQUEsVUFDNUUsS0FBSyxlQUFlLGdCQUFnQixHQUFHLEVBQUUsS0FBSyxDQUFDLFlBQVksVUFBVSxJQUFJLEVBQUU7QUFBQSxRQUM3RSxDQUFDO0FBQ0QsWUFBSSxTQUFTLEdBQUc7QUFDZCxnQkFBTSxLQUFLLGVBQWUsZUFBZTtBQUN6QyxpQkFBTyxNQUFNLEtBQUssTUFBTSxlQUFlO0FBQUEsUUFDekMsV0FBVyxTQUFTLEdBQUc7QUFDckIsZ0JBQU0sS0FBSyxNQUFNLGVBQWU7QUFBQSxRQUNsQyxXQUFXLFNBQVMsR0FBRztBQUNyQixnQkFBTSxLQUFLLGVBQWUsZ0JBQWdCLEdBQUc7QUFDN0MsZ0JBQU0sS0FBSyxNQUFNLG1CQUFtQixJQUFJO0FBQ3hDLGdCQUFNLEtBQUssTUFBTSxVQUFVO0FBQUEsUUFDN0I7QUFBQSxNQUNGLFNBQVMsR0FBRztBQUNWLG1CQUFXLFVBQVUsUUFBUSxLQUFLLENBQUM7QUFBQSxNQUNyQztBQUNBLGFBQU8sTUFBTSxLQUFLLE1BQU0sK0JBQStCO0FBQUEsSUFDekQ7QUFBQSxFQUNGO0FBR0EsTUFBSSxpQkFBaUIsY0FBYyxtQkFBbUI7QUFBQSxJQUNwRCxjQUFjO0FBQ1osWUFBTSxHQUFHLFNBQVM7QUFDbEIsV0FBSyxPQUFPO0FBQ1osV0FBSyxtQkFBbUIsQ0FBQyxrQkFBa0I7QUFDM0MsV0FBSyxlQUFlO0FBQUEsSUFDdEI7QUFBQSxJQUNBLElBQUksY0FBYztBQUNoQixhQUFPLEtBQUs7QUFBQSxJQUNkO0FBQUEsSUFDQSxJQUFJLGlCQUFpQjtBQUNuQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSSxhQUFhO0FBQ2YsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sWUFBWTtBQUNoQixXQUFLLGVBQWUsTUFBTSxLQUFLLGNBQWMsdUJBQXVCO0FBQ3BFLFVBQUksQ0FBQyxLQUFLLGNBQWM7QUFDdEIsZUFBTyxLQUFLLGNBQWMsU0FBUztBQUFBLE1BQ3JDLE9BQU87QUFDTCxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxJQUNBLE1BQU0sY0FBYztBQUNsQixVQUFJLEtBQUssY0FBYztBQUNyQixjQUFNLEtBQUssS0FBSyxHQUFHO0FBQ25CLGVBQU8sTUFBTSxLQUFLLGNBQWMsdUJBQXVCO0FBQUEsTUFDekQ7QUFDQSxhQUFPLEtBQUssZUFBZSxvQkFBb0IsS0FBSztBQUFBLElBQ3REO0FBQUEsSUFDQSxNQUFNLFNBQVM7QUFDYixZQUFNLEtBQUssS0FBSyxHQUFHO0FBQ25CLFVBQUksS0FBSyxjQUFjO0FBQ3JCLGVBQU8sTUFBTSxLQUFLLGNBQWMsdUJBQXVCO0FBQUEsTUFDekQ7QUFDQSxVQUFJLE1BQU0sS0FBSyxNQUFNLGNBQWMsR0FBRztBQUNwQyxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksS0FBSyxjQUFjLG9CQUFvQixHQUFHO0FBQzVDLGNBQU0sS0FBSyxNQUFNLDZDQUE2QyxJQUFJO0FBQ2xFLGNBQU0sS0FBSyxNQUFNLGdCQUFnQjtBQUNqQyxlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sS0FBSyxNQUFNLGtCQUFrQjtBQUNuQyxZQUFNLEtBQUssZUFBZSxjQUFjLEdBQUc7QUFDM0MsWUFBTSxLQUFLLE1BQU0sdUNBQXVDLElBQUk7QUFDNUQsWUFBTSxLQUFLLE1BQU0sNEJBQTRCO0FBQzdDLFdBQUssS0FBSyx1QkFBdUIsU0FBUztBQUMxQyxhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsTUFBTSxRQUFRO0FBQ1osVUFBSSxLQUFLLGNBQWM7QUFDckIsZUFBTyxNQUFNLEtBQUssY0FBYyx1QkFBdUI7QUFBQSxNQUN6RDtBQUNBLGFBQU8sTUFBTSxLQUFLLE1BQU0sZUFBZTtBQUFBLElBQ3pDO0FBQUEsSUFDQSxNQUFNLE9BQU87QUFDWCxVQUFJLEtBQUssY0FBYztBQUNyQixlQUFPLE1BQU0sS0FBSyxjQUFjLHVCQUF1QjtBQUFBLE1BQ3pEO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBR0EsTUFBSSxTQUFTLGNBQWMsbUJBQW1CO0FBQUEsSUFDNUMsY0FBYztBQUNaLFlBQU0sR0FBRyxTQUFTO0FBQ2xCLFdBQUssT0FBTztBQUFBLElBQ2Q7QUFBQSxJQUNBLElBQUksY0FBYztBQUNoQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSSxpQkFBaUI7QUFDbkIsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLElBQUksYUFBYTtBQUNmLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLFlBQVk7QUFDaEIsYUFBTyxLQUFLLGNBQWMsaUJBQWlCO0FBQUEsSUFDN0M7QUFBQSxJQUNBLE1BQU0sY0FBYztBQUNsQixhQUFPLEtBQUssZUFBZSxtQkFBbUIsS0FBSztBQUFBLElBQ3JEO0FBQUEsSUFDQSxNQUFNLFNBQVM7QUFDYixVQUFJLE1BQU0sS0FBSyxNQUFNLHlCQUF5QixHQUFHO0FBQy9DLGVBQU87QUFBQSxNQUNUO0FBQ0EsbUJBQWEsZ0JBQWdCLEdBQUcsMEVBQTBFO0FBQzFHLFlBQU0sS0FBSyxpQkFBaUIsd0JBQXdCO0FBQ3BELFlBQU0sS0FBSyxlQUFlLDRCQUE0QixHQUFHO0FBQ3pELFlBQU0sS0FBSyxLQUFLLEdBQUc7QUFDbkIsWUFBTSxLQUFLLGlCQUFpQiwwQkFBMEI7QUFDdEQsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sUUFBUTtBQUNaLGFBQU8sTUFBTSxLQUFLLE1BQU0sd0JBQXdCO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBR0EsTUFBSSxXQUFXLGNBQWMsbUJBQW1CO0FBQUEsSUFDOUMsY0FBYztBQUNaLFlBQU0sR0FBRyxTQUFTO0FBQ2xCLFdBQUssT0FBTztBQUNaLFdBQUssbUJBQW1CLENBQUMsd0ZBQXdGO0FBQUEsSUFDbkg7QUFBQSxJQUNBLElBQUksY0FBYztBQUNoQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSSxpQkFBaUI7QUFDbkIsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLElBQUksYUFBYTtBQUNmLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLFlBQVk7QUFDaEIsYUFBTyxLQUFLLGNBQWMsdUNBQXVDO0FBQUEsSUFDbkU7QUFBQSxJQUNBLE1BQU0sY0FBYztBQUNsQixhQUFPLEtBQUssZUFBZSx5Q0FBeUMsS0FBSztBQUFBLElBQzNFO0FBQUEsSUFDQSxNQUFNLFNBQVM7QUFDYixVQUFJLEtBQUssZUFBZSw2RUFBNkUsS0FBSyxHQUFHO0FBQzNHLGVBQU8sTUFBTSxLQUFLLE1BQU0sMkVBQTJFO0FBQUEsTUFDckc7QUFDQSxVQUFJLEtBQUssY0FBYywwQkFBMEIsR0FBRztBQUNsRCxjQUFNLEtBQUssTUFBTSwwQkFBMEI7QUFBQSxNQUM3QyxPQUFPO0FBQ0wsY0FBTSxLQUFLLE1BQU0saURBQWlEO0FBQUEsTUFDcEU7QUFDQSxZQUFNLEtBQUssZUFBZSx5QkFBeUIsR0FBRztBQUN0RCxZQUFNLEtBQUssS0FBSyxHQUFHO0FBQ25CLFlBQU0sS0FBSyxNQUFNLCtGQUErRixJQUFJO0FBQ3BILFlBQU0sS0FBSyxLQUFLLEdBQUc7QUFDbkIsWUFBTSxLQUFLLGVBQWUsaURBQWlELEdBQUc7QUFDOUUsWUFBTSxLQUFLLE1BQU0sK0NBQStDO0FBQ2hFLFlBQU0sS0FBSyxlQUFlLHdCQUF3QixLQUFLLE1BQU07QUFDN0QsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sUUFBUTtBQUNaLGFBQU8sTUFBTSxLQUFLLE1BQU0saUZBQWlGO0FBQUEsSUFDM0c7QUFBQSxJQUNBLE1BQU0sT0FBTztBQUNYLGFBQU8sTUFBTSxRQUFRLE1BQU0sS0FBSyxjQUFjLGlCQUFpQixHQUFHLElBQUksR0FBRztBQUFBLElBQzNFO0FBQUEsRUFDRjtBQUdBLE1BQUksUUFBUSxjQUFjLG1CQUFtQjtBQUFBLElBQzNDLGNBQWM7QUFDWixZQUFNLEdBQUcsU0FBUztBQUNsQixXQUFLLE9BQU87QUFDWixXQUFLLG1CQUFtQixDQUFDLFFBQVE7QUFDakMsV0FBSyxlQUFlO0FBQUEsSUFDdEI7QUFBQSxJQUNBLElBQUksY0FBYztBQUNoQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSSxpQkFBaUI7QUFDbkIsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLElBQUksYUFBYTtBQUNmLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLFlBQVk7QUFDaEIsVUFBSSxLQUFLLGNBQWMsd0JBQXdCLEdBQUc7QUFDaEQsYUFBSyxlQUFlO0FBQ3BCLGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTyxLQUFLLGNBQWMseUJBQXlCO0FBQUEsSUFDckQ7QUFBQSxJQUNBLE1BQU0sY0FBYztBQUNsQixhQUFPLEtBQUssZUFBZSxrREFBa0QsS0FBSztBQUFBLElBQ3BGO0FBQUEsSUFDQSxNQUFNLFNBQVM7QUFDYixZQUFNLG1CQUFtQixNQUFNLEtBQUssY0FBYyw0QkFBNEI7QUFDOUUsVUFBSSxrQkFBa0I7QUFDcEIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLE1BQU0sS0FBSyxNQUFNLG9CQUFvQixHQUFHO0FBQzFDLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxLQUFLLGNBQWMsdUJBQXVCO0FBQ2hELFVBQUksTUFBTSxLQUFLLE1BQU0sb0JBQW9CLEdBQUc7QUFDMUMsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLEtBQUs7QUFBQSxRQUNUO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxhQUFPLE1BQU0sS0FBSyxNQUFNLDJCQUEyQjtBQUFBLElBQ3JEO0FBQUEsSUFDQSxNQUFNLFFBQVE7QUFDWixVQUFJLE1BQU0sS0FBSyxNQUFNLDJCQUEyQixHQUFHO0FBQ2pELGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxLQUFLLGNBQWM7QUFDckIsY0FBTSxLQUFLLE1BQU0sd0RBQXdELElBQUk7QUFDN0UsZUFBTyxNQUFNLEtBQUssTUFBTSxnQkFBZ0I7QUFBQSxNQUMxQztBQUNBLGFBQU8sTUFBTSxLQUFLLE1BQU0sdUNBQXVDO0FBQUEsSUFDakU7QUFBQSxJQUNBLE1BQU0sT0FBTztBQUNYLGFBQU8sTUFBTSxLQUFLLGNBQWMsY0FBYztBQUFBLElBQ2hEO0FBQUEsRUFDRjtBQUdBLE1BQUksYUFBYSxjQUFjLG1CQUFtQjtBQUFBLElBQ2hELGNBQWM7QUFDWixZQUFNLEdBQUcsU0FBUztBQUNsQixXQUFLLE9BQU87QUFBQSxJQUNkO0FBQUEsSUFDQSxJQUFJLG1CQUFtQjtBQUNyQixhQUFPLENBQUMsU0FBUyxtQkFBbUI7QUFBQSxJQUN0QztBQUFBLElBQ0EsSUFBSSxjQUFjO0FBQ2hCLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxJQUFJLGlCQUFpQjtBQUNuQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSSxhQUFhO0FBQ2YsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sWUFBWTtBQUNoQixhQUFPLEtBQUssY0FBYyxtREFBbUQ7QUFBQSxJQUMvRTtBQUFBLElBQ0EsTUFBTSxjQUFjO0FBQ2xCLGFBQU8sS0FBSyxlQUFlLHFEQUFxRCxLQUFLO0FBQUEsSUFDdkY7QUFBQSxJQUNBLE1BQU0sU0FBUztBQUNiLFlBQU0sS0FBSyxlQUFlLGdCQUFnQixHQUFHO0FBQzdDLGVBQVMsaUJBQWlCLGNBQWMsRUFBRSxRQUFRLENBQUMsV0FBVztBQUM1RCxjQUFNLE9BQU8sT0FBTztBQUNwQixZQUFJLEtBQUssU0FBUyxnQkFBZ0IsS0FBSyxLQUFLLFNBQVMsb0JBQW9CLEdBQUc7QUFDMUUsaUJBQU8sTUFBTTtBQUFBLFFBQ2Y7QUFBQSxNQUNGLENBQUM7QUFDRCxVQUFJLE1BQU0sS0FBSyxlQUFlLDhCQUE4QixHQUFHLEdBQUc7QUFDaEUsY0FBTSxLQUFLLGVBQWUsZ0JBQWdCLEdBQUc7QUFDN0MsaUJBQVMsaUJBQWlCLDRCQUE0QixFQUFFLFFBQVEsQ0FBQyxNQUFNO0FBQ3JFLGNBQUksRUFBRSxTQUFTO0FBQ2IsY0FBRSxNQUFNO0FBQUEsVUFDVjtBQUFBLFFBQ0YsQ0FBQztBQUNELG1CQUFXLEtBQUssU0FBUyxpQkFBaUIsY0FBYyxHQUFHO0FBQ3pELGdCQUFNLE9BQU8sRUFBRTtBQUNmLHFCQUFXLFdBQVcsQ0FBQyxtQkFBbUIsZ0JBQWdCLG1CQUFtQixHQUFHO0FBQzlFLGdCQUFJLEtBQUssU0FBUyxPQUFPLEdBQUc7QUFDMUIsZ0JBQUUsTUFBTTtBQUNSLG9CQUFNLEtBQUssS0FBSyxHQUFHO0FBQ25CLHFCQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLFFBQVE7QUFDWixhQUFPLEtBQUssaUJBQWlCLG1CQUFtQjtBQUFBLElBQ2xEO0FBQUEsSUFDQSxNQUFNLE9BQU87QUFDWCxZQUFNLEtBQUssS0FBSyxHQUFHO0FBQ25CLFlBQU0sTUFBTSxLQUFLLGNBQWMsaUNBQWlDO0FBQ2hFLGFBQU8sQ0FBQztBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBR0EsTUFBSSxhQUFhLGNBQWMsbUJBQW1CO0FBQUEsSUFDaEQsY0FBYztBQUNaLFlBQU0sR0FBRyxTQUFTO0FBQ2xCLFdBQUssbUJBQW1CLENBQUMsV0FBVztBQUNwQyxXQUFLLE9BQU87QUFBQSxJQUNkO0FBQUEsSUFDQSxJQUFJLGNBQWM7QUFDaEIsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLElBQUksaUJBQWlCO0FBQ25CLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxJQUFJLGFBQWE7QUFDZixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsTUFBTSxZQUFZO0FBQ2hCLGFBQU8sS0FBSyxjQUFjLDJCQUEyQjtBQUFBLElBQ3ZEO0FBQUEsSUFDQSxNQUFNLGNBQWM7QUFDbEIsYUFBTyxLQUFLLGVBQWUsNkJBQTZCLEtBQUs7QUFBQSxJQUMvRDtBQUFBLElBQ0EsTUFBTSxTQUFTO0FBQ2IsVUFBSSxDQUFDLE1BQU0sS0FBSyxpQkFBaUIsaURBQWlELEdBQUc7QUFDbkYsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLENBQUMsTUFBTSxLQUFLLGVBQWUsb0JBQW9CLEdBQUc7QUFDcEQsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLEtBQUssaUJBQWlCLG1DQUFtQztBQUMvRCxZQUFNLEtBQUssaUJBQWlCLHdEQUF3RDtBQUNwRixpQkFBVyxRQUFRLE1BQU0sS0FBSyxTQUFTLGlCQUFpQixxQkFBcUIsQ0FBQyxHQUFHO0FBQy9FLGFBQUssY0FBYywyQkFBMkIsRUFBRSxNQUFNO0FBQ3RELGNBQU0sUUFBUSxNQUFNLENBQUMsQ0FBQyxLQUFLLGNBQWMsd0NBQXdDLEdBQUcsSUFBSSxFQUFFO0FBQzFGLGNBQU0sVUFBVSxLQUFLLGNBQWMsd0NBQXdDO0FBQzNFLGdCQUFRLGlCQUFpQixvRUFBb0UsRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQztBQUN2SCxnQkFBUSxpQkFBaUIsNEVBQTRFLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUM7QUFBQSxNQUNqSTtBQUNBLFlBQU0sS0FBSyxNQUFNLGlEQUFpRDtBQUNsRSxhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsTUFBTSxRQUFRO0FBQ1osYUFBTyxLQUFLLGlCQUFpQiwyQ0FBMkM7QUFBQSxJQUMxRTtBQUFBLElBQ0EsTUFBTSxPQUFPO0FBQ1gsYUFBTyxTQUFTLE9BQU8sU0FBUyxZQUFZO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBR0EsTUFBSSxTQUFTLGNBQWMsbUJBQW1CO0FBQUEsSUFDNUMsY0FBYztBQUNaLFlBQU0sR0FBRyxTQUFTO0FBQ2xCLFdBQUssT0FBTztBQUNaLFdBQUssYUFBYTtBQUFBLFFBQ2hCLFlBQVk7QUFBQSxNQUNkO0FBQUEsSUFDRjtBQUFBLElBQ0EsSUFBSSxjQUFjO0FBQ2hCLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxJQUFJLGlCQUFpQjtBQUNuQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSSxhQUFhO0FBQ2YsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLGdCQUFnQjtBQUNkLFlBQU0sWUFBWSxTQUFTLGNBQWMsc0JBQXNCO0FBQy9ELFVBQUksQ0FBQyxXQUFXO0FBQ2QsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPLFVBQVU7QUFBQSxJQUNuQjtBQUFBLElBQ0EsTUFBTSxZQUFZO0FBQ2hCLGFBQU8sS0FBSyxjQUFjLHNCQUFzQjtBQUFBLElBQ2xEO0FBQUEsSUFDQSxNQUFNLGNBQWM7QUFDbEIsWUFBTSxTQUFTLEtBQUssY0FBYyxHQUFHLGNBQWMsdUJBQXVCO0FBQzFFLGFBQU8saUJBQWlCLE1BQU07QUFBQSxJQUNoQztBQUFBLElBQ0EsTUFBTSxTQUFTO0FBQ2IsWUFBTSxhQUFhLEtBQUssWUFBWSxPQUFPO0FBQzNDLFlBQU0sZ0JBQWdCLEtBQUssY0FBYyxHQUFHLGNBQWMsb0NBQW9DO0FBQzlGLFVBQUksZUFBZTtBQUNqQixtQkFBVyxhQUFhLFFBQVEsSUFBSSxjQUFjLGFBQWE7QUFDL0Qsc0JBQWMsTUFBTTtBQUNwQixlQUFPO0FBQUEsTUFDVCxPQUFPO0FBQ0wsbUJBQVcsVUFBVSxRQUFRLElBQUkseUJBQXlCO0FBQzFELGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBLElBQ0EsTUFBTSxRQUFRO0FBQ1osWUFBTSxhQUFhLEtBQUssWUFBWSxPQUFPO0FBQzNDLFlBQU0sZUFBZSxLQUFLLGNBQWMsR0FBRyxjQUFjLG1DQUFtQztBQUM1RixVQUFJLGNBQWM7QUFDaEIsbUJBQVcsYUFBYSxRQUFRLElBQUksY0FBYyxZQUFZO0FBQzlELHFCQUFhLE1BQU07QUFDbkIsZUFBTztBQUFBLE1BQ1QsT0FBTztBQUNMLG1CQUFXLFVBQVUsUUFBUSxJQUFJLHdCQUF3QjtBQUN6RCxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxJQUNBLE1BQU0sT0FBTztBQUNYLFlBQU0sUUFBUSxTQUFTLE9BQU8sTUFBTSx3QkFBd0I7QUFDNUQsVUFBSSxDQUFDLE9BQU87QUFDVixlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sUUFBUSxLQUFLLE1BQU0sbUJBQW1CLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDckQsYUFBTyxPQUFPLE9BQU8sS0FBSyxFQUFFLE1BQU0sQ0FBQyxNQUFNLE9BQU8sTUFBTSxhQUFhLE1BQU0sS0FBSztBQUFBLElBQ2hGO0FBQUEsRUFDRjtBQUdBLE1BQUksU0FBUyxjQUFjLG1CQUFtQjtBQUFBLElBQzVDLGNBQWM7QUFDWixZQUFNLEdBQUcsU0FBUztBQUNsQixXQUFLLE9BQU87QUFDWixXQUFLLGFBQWE7QUFBQSxRQUNoQixZQUFZO0FBQUEsTUFDZDtBQUFBLElBQ0Y7QUFBQSxJQUNBLElBQUksY0FBYztBQUNoQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSSxpQkFBaUI7QUFDbkIsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLElBQUksYUFBYTtBQUNmLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxJQUFJLG1CQUFtQjtBQUNyQixhQUFPLENBQUMsb0JBQW9CO0FBQUEsSUFDOUI7QUFBQSxJQUNBLE1BQU0sWUFBWTtBQUNoQixhQUFPLEtBQUssY0FBYyxvQkFBb0I7QUFBQSxJQUNoRDtBQUFBLElBQ0EsTUFBTSxjQUFjO0FBQ2xCLGFBQU8sS0FBSyxlQUFlLHNCQUFzQixLQUFLO0FBQUEsSUFDeEQ7QUFBQSxJQUNBLE1BQU0sU0FBUztBQUNiLFVBQUksU0FBUyxTQUFTLGNBQWMsMkJBQTJCO0FBQy9ELFVBQUksaUJBQWlCLE9BQU8saUJBQWlCLGNBQWMscUNBQXFDO0FBQ2hHLFVBQUksQ0FBQyxnQkFBZ0I7QUFDbkIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxxQkFBZSxNQUFNO0FBQ3JCLFlBQU07QUFBQSxRQUNKLE1BQU07QUFDSixnQkFBTSxVQUFVLFNBQVMsY0FBYywyQkFBMkI7QUFDbEUsaUJBQU8sQ0FBQyxDQUFDLFFBQVEsaUJBQWlCLGNBQWMsb0JBQW9CO0FBQUEsUUFDdEU7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxlQUFTLFNBQVMsY0FBYywyQkFBMkI7QUFDM0QsdUJBQWlCLE9BQU8saUJBQWlCLGNBQWMscUNBQXFDO0FBQzVGLFVBQUksQ0FBQyxnQkFBZ0I7QUFDbkIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxxQkFBZSxNQUFNO0FBQ3JCLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLFFBQVE7QUFDWixZQUFNLFNBQVMsU0FBUyxjQUFjLDJCQUEyQjtBQUNqRSxZQUFNLGVBQWUsT0FBTyxnQkFBZ0IsY0FBYyxtQ0FBbUM7QUFDN0YsVUFBSSxjQUFjO0FBQ2hCLHFCQUFhLE1BQU07QUFDbkIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFHQSxNQUFJLFVBQVUsY0FBYyxtQkFBbUI7QUFBQSxJQUM3QyxjQUFjO0FBQ1osWUFBTSxHQUFHLFNBQVM7QUFDbEIsV0FBSyxPQUFPO0FBQUEsSUFDZDtBQUFBLElBQ0EsSUFBSSxjQUFjO0FBQ2hCLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxJQUFJLGlCQUFpQjtBQUNuQixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSSxhQUFhO0FBQ2YsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sWUFBWTtBQUNoQixhQUFPLEtBQUssY0FBYyxtR0FBbUc7QUFBQSxJQUMvSDtBQUFBLElBQ0EsTUFBTSxjQUFjO0FBQ2xCLGFBQU8sS0FBSztBQUFBLFFBQ1Y7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLE1BQU0sU0FBUztBQUNiLFlBQU0sb0JBQW9CO0FBQzFCLFVBQUksTUFBTSxLQUFLLGVBQWUsbUJBQW1CLEdBQUcsR0FBRztBQUNyRCxlQUFPLE1BQU0sS0FBSyxNQUFNLGlCQUFpQjtBQUFBLE1BQzNDO0FBQ0EsWUFBTSx5QkFBeUI7QUFDL0IsWUFBTSxzQkFBc0I7QUFDNUIsVUFBSSxNQUFNLEtBQUssaUJBQWlCLHNCQUFzQixLQUFLLE1BQU0sS0FBSyxlQUFlLG1CQUFtQixHQUFHO0FBQ3pHLGNBQU0sWUFBWSxLQUFLLGdCQUFnQixtQkFBbUIsRUFBRSxDQUFDLEVBQUUsZUFBZTtBQUM5RSxjQUFNLGFBQWEsV0FBVyxpQkFBaUIsOEJBQThCO0FBQzdFLG9CQUFZLFFBQVEsQ0FBQyxhQUFhLFNBQVMsTUFBTSxDQUFDO0FBQ2xELGVBQU8sTUFBTSxLQUFLLE1BQU0sbUJBQW1CO0FBQUEsTUFDN0M7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsTUFBTSxRQUFRO0FBQ1osYUFBTyxNQUFNLEtBQUs7QUFBQSxRQUNoQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUdBLE1BQUksY0FBYztBQUFBLElBQ2hCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUdBLE1BQUksYUFBYSxNQUFNO0FBQUEsSUFDckIsWUFBWSxxQkFBcUI7QUFDL0IsV0FBSyxzQkFBc0I7QUFBQSxJQUM3QjtBQUFBLElBQ0EsTUFBTSxhQUFhLFNBQVM7QUFDMUIsVUFBSSxDQUFDLFdBQVcsRUFBRSxtQkFBbUIsY0FBYztBQUNqRCxlQUFPO0FBQUEsTUFDVDtBQUNBLFdBQUssb0JBQW9CLE9BQU8sS0FBSyxhQUFhLFFBQVEsSUFBSSxrQkFBa0IsT0FBTztBQUN2RixjQUFRLE1BQU07QUFDZCxhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsTUFBTSxNQUFNLFVBQVUsTUFBTSxPQUFPO0FBQ2pDLFlBQU0sV0FBVyxLQUFLLGdCQUFnQixRQUFRO0FBQzlDLFdBQUssb0JBQW9CLE9BQU8sS0FBSyxhQUFhLFFBQVEsSUFBSSxXQUFXLFVBQVUsS0FBSyxRQUFRO0FBQ2hHLFVBQUksU0FBUyxTQUFTLEdBQUc7QUFDdkIsWUFBSSxLQUFLO0FBQ1AsbUJBQVMsUUFBUSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUM7QUFBQSxRQUNuQyxPQUFPO0FBQ0wsbUJBQVMsQ0FBQyxFQUFFLE1BQU07QUFBQSxRQUNwQjtBQUFBLE1BQ0Y7QUFDQSxhQUFPLFNBQVMsU0FBUztBQUFBLElBQzNCO0FBQUEsSUFDQSxjQUFjLFVBQVU7QUFDdEIsWUFBTSxTQUFTLEtBQUssZ0JBQWdCLFFBQVEsRUFBRSxTQUFTO0FBQ3ZELGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxlQUFlLFVBQVUsUUFBUSxPQUFPO0FBQ3RDLFlBQU0sT0FBTyxLQUFLLGdCQUFnQixRQUFRO0FBQzFDLFlBQU0sVUFBVSxJQUFJLE1BQU0sS0FBSyxNQUFNO0FBQ3JDLFdBQUssUUFBUSxDQUFDLEdBQUcsTUFBTTtBQUNyQixnQkFBUSxDQUFDLElBQUksaUJBQWlCLENBQUM7QUFBQSxNQUNqQyxDQUFDO0FBQ0QsVUFBSSxVQUFVLFFBQVE7QUFDcEIsZUFBTyxRQUFRLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUFBLE1BQ2hDLFdBQVcsUUFBUSxXQUFXLEdBQUc7QUFDL0IsZUFBTztBQUFBLE1BQ1QsV0FBVyxVQUFVLE9BQU87QUFDMUIsZUFBTyxRQUFRLEtBQUssQ0FBQyxNQUFNLENBQUM7QUFBQSxNQUM5QjtBQUNBLGFBQU8sUUFBUSxNQUFNLENBQUMsTUFBTSxDQUFDO0FBQUEsSUFDL0I7QUFBQSxJQUNBLGVBQWUsVUFBVSxVQUFVLEtBQUs7QUFDdEMsWUFBTSxXQUFXO0FBQ2pCLFlBQU0sUUFBUSxLQUFLLEtBQUssVUFBVSxRQUFRO0FBQzFDLFdBQUssb0JBQW9CLE9BQU8sS0FBSyxhQUFhLFFBQVEsSUFBSSxvQkFBb0IsUUFBUTtBQUMxRixhQUFPLFFBQVEsTUFBTSxLQUFLLGdCQUFnQixRQUFRLEVBQUUsU0FBUyxHQUFHLE9BQU8sUUFBUTtBQUFBLElBQ2pGO0FBQUEsSUFDQSxlQUFlLFVBQVUsVUFBVSxLQUFLLFFBQVEsT0FBTztBQUNyRCxZQUFNLFdBQVc7QUFDakIsWUFBTSxRQUFRLEtBQUssS0FBSyxVQUFVLFFBQVE7QUFDMUMsV0FBSyxvQkFBb0IsT0FBTyxLQUFLLGFBQWEsUUFBUSxJQUFJLG9CQUFvQixRQUFRO0FBQzFGLGFBQU8sUUFBUSxNQUFNLEtBQUssZUFBZSxVQUFVLEtBQUssR0FBRyxPQUFPLFFBQVE7QUFBQSxJQUM1RTtBQUFBLElBQ0EsTUFBTSxpQkFBaUIsVUFBVSxVQUFVLEtBQUssTUFBTSxPQUFPO0FBQzNELFlBQU0sS0FBSyxlQUFlLFVBQVUsT0FBTztBQUMzQyxhQUFPLE1BQU0sS0FBSyxNQUFNLFVBQVUsR0FBRztBQUFBLElBQ3ZDO0FBQUEsSUFDQSxLQUFLLElBQUk7QUFDUCxXQUFLLG9CQUFvQixPQUFPLEtBQUssYUFBYSxLQUFLLG9CQUFvQixPQUFPLEtBQUssU0FBUyxRQUFRLElBQUksVUFBVSxFQUFFO0FBQ3hILGFBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM5QixtQkFBVyxNQUFNO0FBQ2Ysa0JBQVEsSUFBSTtBQUFBLFFBQ2QsR0FBRyxFQUFFO0FBQUEsTUFDUCxDQUFDO0FBQUEsSUFDSDtBQUFBLElBQ0EsZUFBZSxXQUFXO0FBQ3hCLGFBQU8sU0FBUyxPQUFPLFNBQVMsU0FBUztBQUFBLElBQzNDO0FBQUEsSUFDQSxLQUFLLFVBQVUsUUFBUTtBQUNyQixXQUFLLG9CQUFvQixPQUFPLEtBQUssYUFBYSxRQUFRLElBQUksVUFBVSxRQUFRO0FBQ2hGLFlBQU0sVUFBVSxnQkFBZ0I7QUFDaEMsYUFBTyxhQUFhLFNBQVMsVUFBVSxNQUFNO0FBQUEsSUFDL0M7QUFBQSxJQUNBLFFBQVEsVUFBVTtBQUNoQixZQUFNLFVBQVUsZ0JBQWdCLHFCQUFxQjtBQUNyRCxXQUFLLG9CQUFvQixPQUFPLEtBQUssYUFBYSxRQUFRLElBQUksYUFBYSxTQUFTLFNBQVMsSUFBSTtBQUNqRyxhQUFPLGFBQWEsU0FBUyxVQUFVLFNBQVM7QUFBQSxJQUNsRDtBQUFBLElBQ0EsY0FBYztBQUNaLFlBQU0sa0JBQWtCLGdCQUFnQixxQkFBcUI7QUFDN0QsV0FBSyxvQkFBb0IsT0FBTyxLQUFLLGFBQWEsUUFBUSxJQUFJLGlCQUFpQixpQkFBaUIsU0FBUyxJQUFJO0FBQzdHLHNCQUFnQixPQUFPO0FBQUEsSUFDekI7QUFBQSxJQUNBLE1BQU0seUJBQXlCLFNBQVMsWUFBWTtBQUNsRCxVQUFJLENBQUMsWUFBWTtBQUNmLHFCQUFhLElBQUksY0FBYztBQUFBLE1BQ2pDO0FBQ0EsbUJBQWEsTUFBTSxXQUFXLFFBQVEsT0FBTztBQUM3QyxhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsaUJBQWlCLFlBQVk7QUFDM0IsVUFBSSxZQUFZO0FBQ2QsbUJBQVcsUUFBUSxFQUFFO0FBQ3JCLGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLHlCQUF5QixVQUFVLFNBQVMsVUFBVTtBQUNwRCxVQUFJLFNBQVMsV0FBVyxPQUFPLEdBQUc7QUFDaEMsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUNBLFVBQUksU0FBUyxXQUFXLFFBQVEsR0FBRztBQUNqQyxjQUFNLFFBQVEsU0FBUyxNQUFNLENBQUM7QUFDOUIsY0FBTSxTQUFTLFNBQVMsU0FBUyxPQUFPLFFBQVEsTUFBTSxZQUFZLFVBQVUsSUFBSTtBQUNoRixZQUFJLE9BQU87QUFDWCxjQUFNLFdBQVcsQ0FBQztBQUNsQixlQUFPLE9BQU8sT0FBTyxZQUFZLEdBQUc7QUFDbEMsbUJBQVMsS0FBSyxJQUFJO0FBQUEsUUFDcEI7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksU0FBUyxXQUFXLE9BQU8sR0FBRztBQUNoQyxlQUFPLENBQUM7QUFBQSxNQUNWO0FBQ0EsVUFBSSxTQUFTLFdBQVcsU0FBUyxHQUFHO0FBQ2xDLGVBQU8sQ0FBQztBQUFBLE1BQ1Y7QUFDQSxVQUFJLE9BQU8sWUFBWTtBQUNyQixlQUFPLE1BQU0sS0FBSyxPQUFPLFdBQVcsaUJBQWlCLFFBQVEsQ0FBQztBQUFBLE1BQ2hFO0FBQ0EsVUFBSSxPQUFPLGlCQUFpQixrQkFBa0I7QUFDNUMsZUFBTyxNQUFNLEtBQUssT0FBTyxnQkFBZ0IsaUJBQWlCLFFBQVEsQ0FBQztBQUFBLE1BQ3JFO0FBQ0EsYUFBTyxNQUFNLEtBQUssT0FBTyxpQkFBaUIsUUFBUSxDQUFDO0FBQUEsSUFDckQ7QUFBQSxJQUNBLG1CQUFtQixXQUFXO0FBQzVCLFVBQUksU0FBUztBQUNiLFVBQUksV0FBVyxDQUFDO0FBQ2hCLGlCQUFXLFlBQVksV0FBVztBQUNoQyxtQkFBVyxLQUFLLHlCQUF5QixVQUFVLE1BQU07QUFDekQsWUFBSSxTQUFTLFdBQVcsR0FBRztBQUN6QixpQkFBTyxDQUFDO0FBQUEsUUFDVjtBQUNBLGlCQUFTLFNBQVMsQ0FBQztBQUFBLE1BQ3JCO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLGdCQUFnQixVQUFVO0FBQ3hCLFVBQUksT0FBTyxhQUFhLFVBQVU7QUFDaEMsZUFBTyxLQUFLLHlCQUF5QixRQUFRO0FBQUEsTUFDL0M7QUFDQSxhQUFPLEtBQUssbUJBQW1CLFFBQVE7QUFBQSxJQUN6QztBQUFBLElBQ0EsZ0JBQWdCLFVBQVUsVUFBVSxLQUFLO0FBQ3ZDLFlBQU0sT0FBTyxLQUFLLGdCQUFnQixRQUFRO0FBQzFDLFVBQUksS0FBSyxXQUFXLEdBQUc7QUFDckIsY0FBTSxJQUFJLE1BQU0sR0FBRyxRQUFRLDZCQUE2QjtBQUFBLE1BQzFEO0FBQ0EsYUFBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDdEMsY0FBTSxRQUFRLFdBQVcsTUFBTTtBQUM3QixpQkFBTyxJQUFJLE1BQU0sZ0NBQWdDLENBQUM7QUFDbEQsbUJBQVMsV0FBVztBQUFBLFFBQ3RCLEdBQUcsT0FBTztBQUNWLGNBQU0sV0FBVyxJQUFJLGlCQUFpQixNQUFNO0FBQzFDLHVCQUFhLEtBQUs7QUFDbEIsbUJBQVMsV0FBVztBQUNwQixrQkFBUSxJQUFJO0FBQUEsUUFDZCxDQUFDO0FBQ0QsaUJBQVMsUUFBUSxLQUFLLENBQUMsR0FBRztBQUFBLFVBQ3hCLFNBQVM7QUFBQSxVQUNULFdBQVc7QUFBQSxVQUNYLFlBQVk7QUFBQSxRQUNkLENBQUM7QUFBQSxNQUNILENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUdBLE1BQUkscUJBQXFCO0FBQUEsSUFDdkIsQ0FBQyxVQUFVLEdBQUc7QUFBQSxJQUNkLENBQUMsV0FBVyxHQUFHO0FBQUEsSUFDZixDQUFDLG9CQUFvQixHQUFHO0FBQUEsSUFDeEIsQ0FBQyxTQUFTLEdBQUc7QUFBQSxJQUNiLENBQUMsV0FBVyxHQUFHO0FBQUEsSUFDZixDQUFDLGtCQUFrQixJQUFJO0FBQUEsSUFDdkIsQ0FBQyxRQUFRLEdBQUc7QUFBQSxJQUNaLENBQUMsa0JBQWtCLElBQUk7QUFBQSxFQUN6QjtBQVVBLFdBQVMsc0JBQXNCLE9BQU87QUFDcEMsUUFBSSxVQUFVLEdBQUc7QUFDZixhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksVUFBVSxHQUFHO0FBQ2YsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQTRJQSxXQUFTLFlBQVksU0FBUztBQUM1QixRQUFJLFFBQVEsSUFBSSxHQUFHO0FBQ2pCLFlBQU0sSUFBSSxNQUFNLDBCQUEwQjtBQUFBLElBQzVDO0FBQ0EsV0FBTyxRQUFRLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEtBQUssMkJBQTJCLEVBQUUsSUFBSSxDQUFDLFNBQVMsSUFBSSxpQkFBaUIsTUFBTSxRQUFRLENBQUMsQ0FBQztBQUFBLEVBQ3pIO0FBQ0EsTUFBSSxtQkFBbUIsTUFBTTtBQUFBLElBQzNCLFlBQVksTUFBTSxTQUFTO0FBQ3pCLFdBQUssZUFBZTtBQUNwQixXQUFLLFFBQVEsQ0FBQztBQUNkLFdBQUssSUFBSTtBQUNULFdBQUssSUFBSTtBQUNULFVBQUksS0FBSyxFQUFFLEVBQUUsS0FBSyxLQUFLLEVBQUUsRUFBRSxFQUFFLGNBQWM7QUFDekMsYUFBSyxlQUFlLEtBQUssRUFBRSxFQUFFLEVBQUU7QUFBQSxNQUNqQztBQUFBLElBQ0Y7QUFBQSxJQUNBLGdCQUFnQixNQUFNO0FBQ3BCLFlBQU0sYUFBYSxFQUFFLEdBQUcsS0FBSztBQUM3QixZQUFNLGlCQUFpQixLQUFLLGdCQUFnQixLQUFLLElBQUk7QUFDckQsaUJBQVcsQ0FBQyxTQUFTLFFBQVEsS0FBSyxvQkFBb0I7QUFDcEQsWUFBSSxXQUFXLFFBQVEsTUFBTSxRQUFRO0FBQ25DLHFCQUFXLE9BQU8sSUFBSSxLQUFLLEVBQUUsV0FBVyxRQUFRLENBQUM7QUFDakQsaUJBQU8sV0FBVyxRQUFRO0FBQUEsUUFDNUI7QUFBQSxNQUNGO0FBQ0EsVUFBSSxLQUFLLElBQUk7QUFDWCxtQkFBVyxLQUFLLGVBQWUsS0FBSyxFQUFFO0FBQ3RDLG1CQUFXLE9BQU8sS0FBSyxRQUFRLEtBQUssS0FBSyxJQUFJLGNBQWM7QUFDM0QsWUFBSSxLQUFLLE1BQU07QUFDYixxQkFBVyxPQUFPLEtBQUssS0FBSyxJQUFJLGNBQWM7QUFBQSxRQUNoRDtBQUFBLE1BQ0Y7QUFDQSxVQUFJLEtBQUssS0FBSztBQUNaLG1CQUFXLE1BQU0sS0FBSyxJQUFJLElBQUksY0FBYztBQUFBLE1BQzlDO0FBQ0EsYUFBTyxFQUFFLEdBQUcsV0FBVztBQUFBLElBQ3pCO0FBQUEsSUFDQSxJQUFJLE9BQU87QUFDVCxhQUFPLEtBQUssRUFBRSxDQUFDO0FBQUEsSUFDakI7QUFBQSxJQUNBLElBQUksV0FBVztBQUNiLGFBQU8sc0JBQXNCLEtBQUssRUFBRSxDQUFDLENBQUM7QUFBQSxJQUN4QztBQUFBLElBQ0EsSUFBSSxhQUFhO0FBQ2YsWUFBTSxhQUFhLENBQUM7QUFDcEIsWUFBTSxhQUFhLEtBQUssRUFBRSxDQUFDO0FBQzNCLFlBQU0sWUFBWSxLQUFLLEVBQUUsQ0FBQztBQUMxQixZQUFNLGlCQUFpQixzQkFBc0IsS0FBSyxNQUFNLFlBQVksRUFBRSxJQUFJLEVBQUU7QUFDNUUsWUFBTSxnQkFBZ0Isc0JBQXNCLFlBQVksRUFBRTtBQUMxRCxVQUFJLG1CQUFtQixRQUFRO0FBQzdCLG1CQUFXLE9BQU87QUFBQSxNQUNwQjtBQUNBLFVBQUksa0JBQWtCLFFBQVE7QUFDNUIsbUJBQVcsUUFBUTtBQUFBLE1BQ3JCO0FBQ0EsVUFBSSxlQUFlLElBQUk7QUFDckIsbUJBQVcsYUFBYTtBQUFBLE1BQzFCO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLElBQUksbUJBQW1CO0FBQ3JCLGFBQU8sS0FBSyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxLQUFLLEVBQUUsQ0FBQyxFQUFFLFNBQVMsQ0FBQztBQUFBLElBQ2xEO0FBQUEsSUFDQSxJQUFJLFlBQVk7QUFDZCxhQUFPLEtBQUssRUFBRSxDQUFDLEVBQUUsSUFBSSxLQUFLLGdCQUFnQixLQUFLLElBQUksQ0FBQztBQUFBLElBQ3REO0FBQUEsSUFDQSxJQUFJLGNBQWM7QUFDaEIsYUFBTyxLQUFLLEVBQUUsQ0FBQyxFQUFFLElBQUksS0FBSyxnQkFBZ0IsS0FBSyxJQUFJLENBQUM7QUFBQSxJQUN0RDtBQUFBLElBQ0EsSUFBSSxTQUFTO0FBQ1gsYUFBTyxLQUFLLEVBQUUsQ0FBQyxFQUFFLElBQUksS0FBSyxnQkFBZ0IsS0FBSyxJQUFJLENBQUM7QUFBQSxJQUN0RDtBQUFBLElBQ0EsSUFBSSxPQUFPO0FBQ1QsYUFBTyxLQUFLLEVBQUUsQ0FBQyxFQUFFLElBQUksS0FBSyxnQkFBZ0IsS0FBSyxJQUFJLENBQUM7QUFBQSxJQUN0RDtBQUFBLEVBQ0Y7QUF1RkEsV0FBUyxXQUFXLE9BQU8sUUFBUTtBQUNqQyxXQUFPLE1BQU0sT0FBTyxDQUFDLFFBQVE7QUFDM0IsY0FBUSxDQUFDLE9BQU8sZ0JBQWdCLENBQUMsT0FBTyxhQUFhLFNBQVMsSUFBSSxJQUFJO0FBQUEsT0FDckUsT0FBTyx1QkFBdUIsQ0FBQyxJQUFJO0FBQUEsT0FDbkMsT0FBTyx3QkFBd0IsQ0FBQyxJQUFJLEtBQUssV0FBVyxPQUFPO0FBQUEsSUFDOUQsQ0FBQztBQUFBLEVBQ0g7QUFDQSxNQUFJO0FBQ0osTUFBSSxjQUFjLE1BQU07QUFBQSxJQUN0QixZQUFZLG9CQUFvQixTQUFTLE1BQU0sbUJBQW1CLE1BQU07QUFDdEUsV0FBSyxLQUFLLFlBQVk7QUFDdEIsV0FBSyxRQUFRLENBQUM7QUFDZCxtQkFBYSxNQUFNLE9BQU87QUFDMUIsV0FBSyxRQUFRO0FBQUEsUUFDWCxtQkFBbUI7QUFBQSxRQUNuQixvQkFBb0I7QUFBQSxRQUNwQixXQUFXO0FBQUEsUUFDWCxXQUFXO0FBQUEsUUFDWCxpQkFBaUI7QUFBQSxRQUNqQixjQUFjLENBQUM7QUFBQSxRQUNmLGdCQUFnQixDQUFDO0FBQUEsUUFDakIsbUJBQW1CLENBQUM7QUFBQSxRQUNwQixtQkFBbUIsQ0FBQztBQUFBLFFBQ3BCLFVBQVU7QUFBQSxRQUNWLFFBQVE7QUFBQSxRQUNSLFdBQVc7QUFBQSxRQUNYLFNBQVM7QUFBQSxNQUNYO0FBQ0EsZ0JBQVUscUJBQXFCO0FBQy9CLFdBQUsscUJBQXFCO0FBQzFCLFdBQUssUUFBUSxDQUFDO0FBQ2QsV0FBSyxZQUFZLEVBQUUsV0FBVyxVQUFVLENBQUM7QUFDekMsV0FBSyxnQkFBZ0I7QUFDckIsVUFBSSxRQUFRO0FBQ1YsYUFBSyxXQUFXLFFBQVEsZ0JBQWdCO0FBQUEsTUFDMUMsT0FBTztBQUNMLFlBQUksa0JBQWtCO0FBQ3BCLGVBQUssc0JBQXNCLGdCQUFnQjtBQUFBLFFBQzdDO0FBQ0EsY0FBTSxVQUFVO0FBQUEsVUFDZCxNQUFNO0FBQUEsVUFDTixLQUFLLE9BQU8sU0FBUztBQUFBLFFBQ3ZCO0FBQ0EsMkJBQW1CLE9BQU87QUFDMUIsYUFBSyxZQUFZLEVBQUUsV0FBVyx5QkFBeUIsQ0FBQztBQUFBLE1BQzFEO0FBQ0EsV0FBSyxhQUFhLElBQUksV0FBVyxJQUFJO0FBQUEsSUFDdkM7QUFBQSxJQUNBLElBQUksU0FBUztBQUNYLFVBQUksQ0FBQyxhQUFhLE1BQU0sT0FBTyxHQUFHO0FBQ2hDLGNBQU0sSUFBSSxNQUFNLG9DQUFvQztBQUFBLE1BQ3REO0FBQ0EsYUFBTyxhQUFhLE1BQU0sT0FBTztBQUFBLElBQ25DO0FBQUEsSUFDQSxXQUFXLFFBQVEsa0JBQWtCO0FBQ25DLFlBQU0sbUJBQW1CLGdCQUFnQixNQUFNO0FBQy9DLHVCQUFpQixLQUFLLGFBQWEsUUFBUSxJQUFJLG9CQUFvQixPQUFPLFNBQVMsSUFBSTtBQUN2RixtQkFBYSxNQUFNLFNBQVMsZ0JBQWdCO0FBQzVDLFVBQUksQ0FBQyxpQkFBaUIsU0FBUztBQUM3Qix5QkFBaUIsS0FBSyxhQUFhLFFBQVEsSUFBSSx5QkFBeUI7QUFDeEU7QUFBQSxNQUNGO0FBQ0EsVUFBSSxrQkFBa0I7QUFDcEIsYUFBSyxzQkFBc0IsZ0JBQWdCO0FBQUEsTUFDN0M7QUFDQSxVQUFJLE9BQU8sa0JBQWtCO0FBQzNCLGFBQUsscUJBQXFCO0FBQUEsTUFDNUI7QUFDQSxXQUFLLFFBQVEsV0FBVyxLQUFLLE9BQU8sZ0JBQWdCO0FBQ3BELFVBQUksS0FBSyxlQUFlO0FBQ3RCLFlBQUksU0FBUyxpQkFBaUI7QUFDNUIsZUFBSyxnQkFBZ0I7QUFBQSxRQUN2QixPQUFPO0FBQ0wsZ0JBQU0saUJBQWlCLE1BQU07QUFDM0IsbUJBQU8sb0JBQW9CLG9CQUFvQixjQUFjO0FBQzdELGlCQUFLLGdCQUFnQjtBQUFBLFVBQ3ZCO0FBQ0EsaUJBQU8saUJBQWlCLG9CQUFvQixjQUFjO0FBQUEsUUFDNUQ7QUFBQSxNQUNGO0FBQ0EsVUFBSSxTQUFTLGVBQWUsV0FBVztBQUNyQyxjQUFNLFVBQVUsTUFBTTtBQUNwQixpQkFBTyxvQkFBb0Isb0JBQW9CLE9BQU87QUFDdEQsZUFBSyxNQUFNO0FBQUEsUUFDYjtBQUNBLGVBQU8saUJBQWlCLG9CQUFvQixPQUFPO0FBQUEsTUFDckQsT0FBTztBQUNMLGFBQUssTUFBTTtBQUFBLE1BQ2I7QUFDQSxXQUFLLFlBQVksRUFBRSxXQUFXLGNBQWMsQ0FBQztBQUFBLElBQy9DO0FBQUEsSUFDQSx1QkFBdUI7QUFBQSxJQUN2QjtBQUFBLElBQ0EsSUFBSSxnQkFBZ0I7QUFDbEIsYUFBTyxLQUFLLE9BQU8saUJBQWlCLENBQUMsS0FBSyxPQUFPO0FBQUEsSUFDbkQ7QUFBQSxJQUNBLFlBQVk7QUFDVixXQUFLLGlCQUFpQixTQUFTO0FBQy9CLFVBQUksS0FBSyxnQkFBZ0I7QUFDdkIsYUFBSyxPQUFPLEtBQUssYUFBYSxRQUFRLElBQUksZ0JBQWdCLEtBQUssZ0JBQWdCLFNBQVMsSUFBSTtBQUFBLE1BQzlGO0FBQUEsSUFDRjtBQUFBLElBQ0EsZUFBZTtBQUNiLFVBQUksS0FBSyxnQkFBZ0I7QUFDdkIsYUFBSyxPQUFPLEtBQUssYUFBYSxRQUFRLElBQUksbUJBQW1CLEtBQUssZ0JBQWdCLFNBQVMsSUFBSTtBQUMvRixZQUFJO0FBQ0YsZUFBSyxlQUFlLE1BQU0sRUFBRSxlQUFlLEtBQUssQ0FBQztBQUFBLFFBQ25ELFNBQVMsR0FBRztBQUNWLGVBQUssT0FBTyxLQUFLLFVBQVUsUUFBUSxLQUFLLHlCQUF5QixDQUFDO0FBQUEsUUFDcEU7QUFDQSxhQUFLLGlCQUFpQjtBQUFBLE1BQ3hCO0FBQUEsSUFDRjtBQUFBLElBQ0Esa0JBQWtCO0FBQ2hCLGtCQUFZLFFBQVEsQ0FBQyxRQUFRO0FBQzNCLGFBQUssTUFBTSxLQUFLLElBQUksSUFBSSxJQUFJLENBQUM7QUFBQSxNQUMvQixDQUFDO0FBQUEsSUFDSDtBQUFBLElBQ0Esc0JBQXNCLGtCQUFrQjtBQUN0QyxVQUFJLGlCQUFpQixlQUFlO0FBQ2xDLG1CQUFXLENBQUMsTUFBTSxJQUFJLEtBQUssT0FBTyxRQUFRLGlCQUFpQixhQUFhLEdBQUc7QUFDekUsZUFBSyxvQkFBb0IsTUFBTSxJQUFJO0FBQUEsUUFDckM7QUFBQSxNQUNGO0FBQ0EsVUFBSSxpQkFBaUIsYUFBYTtBQUNoQyx5QkFBaUIsWUFBWSxRQUFRLENBQUMsWUFBWTtBQUNoRCxlQUFLLGtCQUFrQixPQUFPO0FBQUEsUUFDaEMsQ0FBQztBQUFBLE1BQ0g7QUFDQSxVQUFJLGlCQUFpQixTQUFTO0FBQzVCLFlBQUk7QUFDRixnQkFBTSxRQUFRLFlBQVksaUJBQWlCLE9BQU87QUFDbEQsZ0JBQU0sUUFBUSxLQUFLLGtCQUFrQixLQUFLLElBQUksQ0FBQztBQUFBLFFBQ2pELFNBQVMsR0FBRztBQUNWLGVBQUssT0FBTyxLQUFLLFVBQVUsUUFBUSxNQUFNLENBQUM7QUFBQSxRQUM1QztBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxrQkFBa0IsU0FBUztBQUN6QixXQUFLLFFBQVEsMEJBQTBCLE1BQU0sNkJBQTZCO0FBQ3hFLGFBQUssTUFBTSxLQUFLLElBQUksZUFBZSxTQUFTLElBQUksQ0FBQztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUFBLElBQ0Esb0JBQW9CLE1BQU0sUUFBUTtBQUNoQyxXQUFLLE1BQU0sS0FBSyxJQUFJLGlCQUFpQixPQUFPLElBQUksSUFBSSxNQUFNLENBQUM7QUFBQSxJQUM3RDtBQUFBO0FBQUEsSUFFQSxRQUFRO0FBQ04sdUJBQWlCLE1BQU0sS0FBSyxPQUFPLENBQUM7QUFBQSxJQUN0QztBQUFBLElBQ0EsTUFBTSxTQUFTO0FBQ2IsWUFBTSxhQUFhLEtBQUssT0FBTztBQUMvQixpQkFBVyxhQUFhLFFBQVEsSUFBSSxxQkFBcUIsT0FBTyxTQUFTLElBQUksRUFBRTtBQUMvRSxXQUFLLFlBQVksRUFBRSxXQUFXLFVBQVUsQ0FBQztBQUN6QyxZQUFNLFlBQVksTUFBTSxLQUFLLFFBQVEsS0FBSyxPQUFPLGFBQWE7QUFDOUQsV0FBSyxZQUFZLEVBQUUsY0FBYyxVQUFVLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUM7QUFDL0QsVUFBSSxVQUFVLFdBQVcsR0FBRztBQUMxQixtQkFBVyxhQUFhLFFBQVEsSUFBSSxnQkFBZ0IsU0FBUyxJQUFJO0FBQ2pFLFlBQUksS0FBSyxlQUFlO0FBQ3RCLGVBQUssWUFBWTtBQUFBLFFBQ25CO0FBQ0EsZUFBTyxLQUFLLG1CQUFtQjtBQUFBLE1BQ2pDO0FBQ0EsV0FBSyxZQUFZLEVBQUUsV0FBVyxjQUFjLENBQUM7QUFDN0MsWUFBTSxhQUFhLENBQUM7QUFDcEIsWUFBTSxlQUFlLENBQUM7QUFDdEIsaUJBQVcsT0FBTyxXQUFXO0FBQzNCLFlBQUksSUFBSSxZQUFZO0FBQ2xCLHVCQUFhLEtBQUssR0FBRztBQUFBLFFBQ3ZCLE9BQU87QUFDTCxxQkFBVyxLQUFLLEdBQUc7QUFBQSxRQUNyQjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLFNBQVM7QUFDYixVQUFJLGNBQWMsTUFBTSxLQUFLLGFBQWEsWUFBWSxPQUFPLFFBQVE7QUFDbkUsaUJBQVMsTUFBTSxLQUFLLFlBQVksR0FBRztBQUFBLE1BQ3JDLENBQUM7QUFDRCxVQUFJLFlBQVksV0FBVyxHQUFHO0FBQzVCLHNCQUFjLE1BQU0sS0FBSyxhQUFhLGNBQWMsT0FBTyxRQUFRO0FBQ2pFLG1CQUFTLE1BQU0sS0FBSyxZQUFZLEdBQUc7QUFBQSxRQUNyQyxDQUFDO0FBQUEsTUFDSDtBQUNBLFVBQUksWUFBWSxXQUFXLEdBQUc7QUFDNUIsbUJBQVcsYUFBYSxRQUFRLElBQUksZ0JBQWdCO0FBQ3BELFlBQUksS0FBSyxlQUFlO0FBQ3RCLGVBQUssWUFBWTtBQUFBLFFBQ25CO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFlBQVksU0FBUyxHQUFHO0FBQzFCLGNBQU0sZUFBZTtBQUFBLFVBQ25CLEtBQUs7QUFBQSxVQUNMLE1BQU0sWUFBWSxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUk7QUFBQSxRQUN6QztBQUNBLG1CQUFXLFVBQVUsUUFBUSxLQUFLLGFBQWEsS0FBSyxhQUFhLElBQUk7QUFDckUsYUFBSyxtQkFBbUI7QUFBQSxVQUN0QixNQUFNO0FBQUEsVUFDTixTQUFTO0FBQUEsUUFDWCxDQUFDO0FBQUEsTUFDSDtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLFFBQVEsU0FBUztBQUNyQixZQUFNLGFBQWEsS0FBSyxPQUFPO0FBQy9CLFdBQUssWUFBWSxFQUFFLGlCQUFpQixLQUFLLE1BQU0sa0JBQWtCLEVBQUUsQ0FBQztBQUNwRSxZQUFNLFlBQVksQ0FBQztBQUNuQixZQUFNLFFBQVEsV0FBVztBQUN6QixZQUFNLG9CQUFvQixDQUFDO0FBQzNCLFlBQU0sZUFBZSxDQUFDO0FBQ3RCLFdBQUssTUFBTSxRQUFRLENBQUMsUUFBUTtBQUMxQixZQUFJLElBQUksa0JBQWtCLEtBQUssR0FBRztBQUNoQyxnQkFBTSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksV0FBVztBQUN4QyxjQUFJLElBQUksc0JBQXNCLEdBQUc7QUFDL0IsOEJBQWtCLEtBQUssR0FBRztBQUFBLFVBQzVCLFdBQVcsQ0FBQyxnQkFBZ0I7QUFDMUIseUJBQWEsS0FBSyxHQUFHO0FBQUEsVUFDdkI7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBQ0QsWUFBTSxpQkFBaUIsU0FBUyxLQUFLLE9BQU8sd0JBQXdCLENBQUMsSUFBSSx3QkFBd0IsSUFBSSxDQUFDLElBQUksQ0FBQztBQUMzRyxZQUFNLHNCQUFzQjtBQUFBLFFBQzFCLENBQUMsaUJBQWlCLGlCQUFpQjtBQUFBLFFBQ25DLENBQUMsV0FBVyxZQUFZO0FBQUEsUUFDeEIsQ0FBQyxhQUFhLGNBQWM7QUFBQSxNQUM5QjtBQUNBLFlBQU0sZUFBZSxPQUFPLFFBQVE7QUFDbEMsWUFBSTtBQUNGLGdCQUFNLFNBQVMsTUFBTSxJQUFJLFVBQVU7QUFDbkMsY0FBSSxRQUFRO0FBQ1YsdUJBQVcsYUFBYSxRQUFRLElBQUksY0FBYyxJQUFJLElBQUksSUFBSSxPQUFPLFNBQVMsSUFBSSxFQUFFO0FBQ3BGLGlCQUFLLG1CQUFtQjtBQUFBLGNBQ3RCLE1BQU07QUFBQSxjQUNOLEtBQUssU0FBUztBQUFBLGNBQ2QsS0FBSyxJQUFJO0FBQUEsWUFDWCxDQUFDO0FBQ0Qsc0JBQVUsS0FBSyxHQUFHO0FBQUEsVUFDcEI7QUFBQSxRQUNGLFNBQVMsR0FBRztBQUNWLHFCQUFXLFVBQVUsUUFBUSxLQUFLLG1CQUFtQixJQUFJLElBQUksSUFBSSxDQUFDO0FBQUEsUUFDcEU7QUFBQSxNQUNGO0FBQ0EsWUFBTSxtQkFBbUIsS0FBSyxXQUFXLGdCQUFnQixNQUFNO0FBQy9ELHVCQUFpQixNQUFNLE1BQU07QUFBQSxNQUM3QixDQUFDO0FBQ0QsaUJBQVcsQ0FBQyxXQUFXLFNBQVMsS0FBSyxxQkFBcUI7QUFDeEQsbUJBQVcsYUFBYSxVQUFVLFNBQVMsS0FBSyxRQUFRO0FBQUEsVUFDdEQsVUFBVSxTQUFTO0FBQUEsVUFDbkIsVUFBVSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUk7QUFBQSxRQUM3QjtBQUNBLGNBQU0sUUFBUSxJQUFJLFVBQVUsSUFBSSxZQUFZLENBQUM7QUFDN0MsWUFBSSxVQUFVLFNBQVMsR0FBRztBQUN4QjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsV0FBSyxpQkFBaUI7QUFDdEIsVUFBSSxVQUFVLFdBQVcsS0FBSyxVQUFVLEdBQUc7QUFDekMsWUFBSTtBQUNGLGdCQUFNLFFBQVEsSUFBSSxDQUFDLEtBQUssV0FBVyxLQUFLLEdBQUcsR0FBRyxnQkFBZ0IsQ0FBQztBQUFBLFFBQ2pFLFNBQVMsR0FBRztBQUNWLGlCQUFPLENBQUM7QUFBQSxRQUNWO0FBQ0EsZUFBTyxLQUFLLFFBQVEsVUFBVSxDQUFDO0FBQUEsTUFDakM7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsbUJBQW1CO0FBQ2pCLFVBQUksS0FBSyxPQUFPLDBCQUEwQjtBQUN4QyxjQUFNLEVBQUUsVUFBVSxVQUFVLFVBQVUsSUFBSSx1QkFBdUIsU0FBUyxpQkFBaUIsYUFBYSxFQUFFO0FBQzFHLFlBQUksU0FBUyxTQUFTLE1BQU0sU0FBUyxXQUFXLEtBQUssTUFBTSxrQkFBa0IsVUFBVSxLQUFLLE1BQU0sa0JBQWtCLEtBQUssQ0FBQyxHQUFHLE1BQU0sTUFBTSxTQUFTLENBQUMsQ0FBQyxJQUFJO0FBQ3RKLGVBQUssT0FBTyxLQUFLLGFBQWEsUUFBUSxJQUFJLDRCQUE0QixVQUFVLFNBQVM7QUFDekYsZUFBSyxZQUFZLEVBQUUsbUJBQW1CLFVBQVUsbUJBQW1CLFVBQVUsQ0FBQztBQUFBLFFBQ2hGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUlBLE1BQU0sWUFBWSxLQUFLO0FBQ3JCLFlBQU0sU0FBUyxNQUFNLEtBQUssYUFBYSxHQUFHLEVBQUUsTUFBTSxDQUFDLFVBQVU7QUFDM0QsYUFBSyxPQUFPLEtBQUssVUFBVSxRQUFRLEtBQUssaUNBQWlDLElBQUksSUFBSSxJQUFJLEtBQUs7QUFDMUYsZUFBTztBQUFBLE1BQ1QsQ0FBQztBQUNELFVBQUksUUFBUTtBQUNWLGFBQUssWUFBWSxFQUFFLGdCQUFnQixLQUFLLE1BQU0sZUFBZSxPQUFPLENBQUMsSUFBSSxJQUFJLENBQUMsRUFBRSxDQUFDO0FBQ2pGLGFBQUssbUJBQW1CO0FBQUEsVUFDdEIsTUFBTTtBQUFBLFVBQ04sS0FBSyxJQUFJO0FBQUEsVUFDVCxLQUFLLFNBQVM7QUFBQSxRQUNoQixDQUFDO0FBQ0QsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLElBQUksTUFBTSxvQkFBb0I7QUFBQSxJQUN0QztBQUFBO0FBQUE7QUFBQTtBQUFBLElBSUEsTUFBTSxhQUFhLE1BQU0scUJBQXFCO0FBQzVDLFlBQU0sUUFBUSxLQUFLLElBQUksQ0FBQyxRQUFRLEtBQUssWUFBWSxHQUFHLENBQUM7QUFDckQsWUFBTSxRQUFRLElBQUksS0FBSyxFQUFFLEtBQUssQ0FBQyxRQUFRO0FBQ3JDLGFBQUssaUJBQWlCO0FBQ3RCLDRCQUFvQixHQUFHO0FBQUEsTUFDekIsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLE1BQ2YsQ0FBQztBQUNELFlBQU0sVUFBVSxNQUFNLFFBQVEsV0FBVyxLQUFLO0FBQzlDLFlBQU0sU0FBUyxDQUFDO0FBQ2hCLGlCQUFXLFVBQVUsU0FBUztBQUM1QixZQUFJLE9BQU8sV0FBVyxhQUFhO0FBQ2pDLGlCQUFPLEtBQUssT0FBTyxLQUFLO0FBQUEsUUFDMUI7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sWUFBWSxLQUFLO0FBQ3JCLFdBQUssWUFBWSxFQUFFLFdBQVcscUJBQXFCLFdBQVcsS0FBSyxJQUFJLEVBQUUsQ0FBQztBQUMxRSxVQUFJLEtBQUssaUJBQWlCLENBQUMsS0FBSyxNQUFNLFdBQVc7QUFDL0MsYUFBSyxnQkFBZ0I7QUFBQSxNQUN2QjtBQUNBLFVBQUksS0FBSyxNQUFNLG1CQUFtQjtBQUNoQyxhQUFLLGNBQWM7QUFBQSxNQUNyQjtBQUNBLFdBQUssV0FBVztBQUNoQixVQUFJLEtBQUssT0FBTyxlQUFlLFVBQVU7QUFDdkMsZUFBTyxNQUFNLEtBQUssU0FBUztBQUFBLE1BQzdCLFdBQVcsS0FBSyxPQUFPLGVBQWUsU0FBUztBQUM3QyxlQUFPLE1BQU0sS0FBSyxRQUFRO0FBQUEsTUFDNUIsT0FBTztBQUNMLGFBQUssT0FBTyxLQUFLLGFBQWEsUUFBUSxJQUFJLGlDQUFpQyxTQUFTLElBQUk7QUFDeEYsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUEsSUFDQSxNQUFNLFdBQVc7QUFDZixZQUFNLGFBQWEsS0FBSyxPQUFPO0FBQy9CLFdBQUssWUFBWSxFQUFFLFdBQVcsZ0JBQWdCLENBQUM7QUFDL0MsV0FBSyxVQUFVO0FBQ2YsVUFBSTtBQUNKLFVBQUksQ0FBQyxLQUFLLFVBQVU7QUFDbEIsbUJBQVcsVUFBVSxRQUFRLElBQUksbUJBQW1CO0FBQ3BELHVCQUFlO0FBQUEsTUFDakIsT0FBTztBQUNMLG1CQUFXLGFBQWEsUUFBUSxJQUFJLE9BQU8sS0FBSyxTQUFTLElBQUksZ0JBQWdCLE9BQU8sU0FBUyxJQUFJLEVBQUU7QUFDbkcsdUJBQWUsTUFBTSxLQUFLLFNBQVMsT0FBTztBQUMxQyxtQkFBVyxhQUFhLFFBQVEsSUFBSSxHQUFHLEtBQUssU0FBUyxJQUFJLG9CQUFvQixZQUFZLEVBQUU7QUFBQSxNQUM3RjtBQUNBLFVBQUksS0FBSyxlQUFlO0FBQ3RCLGFBQUssWUFBWTtBQUFBLE1BQ25CO0FBQ0EsV0FBSyxtQkFBbUI7QUFBQSxRQUN0QixNQUFNO0FBQUEsUUFDTixLQUFLLEtBQUssV0FBVyxLQUFLLFNBQVMsT0FBTztBQUFBLFFBQzFDLFFBQVE7QUFBQSxRQUNSLGtCQUFrQixRQUFRLEtBQUssWUFBWSxLQUFLLFNBQVMsV0FBVztBQUFBLFFBQ3BFLEtBQUssU0FBUztBQUFBLE1BQ2hCLENBQUM7QUFDRCxVQUFJLGdCQUFnQixLQUFLLFlBQVksQ0FBQyxLQUFLLFNBQVMsZ0JBQWdCO0FBQ2xFLGFBQUssTUFBTSxVQUFVLEtBQUssSUFBSTtBQUM5QixtQkFBVyxhQUFhLFFBQVE7QUFBQSxVQUM5QixHQUFHLEtBQUssU0FBUyxJQUFJLGFBQWEsS0FBSyxNQUFNLFVBQVUsS0FBSyxNQUFNLFNBQVMsV0FBVyxLQUFLLE1BQU0sTUFBTTtBQUFBLFFBQ3pHO0FBQ0EsYUFBSyxtQkFBbUI7QUFBQSxVQUN0QixNQUFNO0FBQUEsVUFDTixLQUFLLEtBQUssVUFBVTtBQUFBLFVBQ3BCLFlBQVksS0FBSyxVQUFVO0FBQUEsVUFDM0IsS0FBSyxTQUFTO0FBQUEsVUFDZCxVQUFVLEtBQUssTUFBTSxVQUFVLEtBQUssTUFBTTtBQUFBLFVBQzFDLGFBQWEsS0FBSyxNQUFNO0FBQUEsUUFDMUIsQ0FBQztBQUNELGFBQUssWUFBWSxFQUFFLFdBQVcsT0FBTyxDQUFDO0FBQUEsTUFDeEMsT0FBTztBQUNMLGFBQUssWUFBWSxFQUFFLFdBQVcsZUFBZSxvQkFBb0IsZUFBZSxDQUFDO0FBQUEsTUFDbkY7QUFDQSxXQUFLLGFBQWE7QUFDbEIsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE1BQU0sVUFBVTtBQUNkLFlBQU0sYUFBYSxLQUFLLE9BQU87QUFDL0IsV0FBSyxZQUFZLEVBQUUsV0FBVyxlQUFlLENBQUM7QUFDOUMsV0FBSyxVQUFVO0FBQ2YsVUFBSTtBQUNKLFVBQUksQ0FBQyxLQUFLLFVBQVU7QUFDbEIsbUJBQVcsVUFBVSxRQUFRLElBQUksa0JBQWtCO0FBQ25ELHNCQUFjO0FBQUEsTUFDaEIsT0FBTztBQUNMLG1CQUFXLGFBQWEsUUFBUSxJQUFJLE9BQU8sS0FBSyxTQUFTLElBQUksZUFBZSxPQUFPLFNBQVMsSUFBSSxFQUFFO0FBQ2xHLHNCQUFjLE1BQU0sS0FBSyxTQUFTLE1BQU07QUFDeEMsbUJBQVcsYUFBYSxRQUFRLElBQUksR0FBRyxLQUFLLFNBQVMsSUFBSSxtQkFBbUIsV0FBVyxFQUFFO0FBQUEsTUFDM0Y7QUFDQSxVQUFJLEtBQUssZUFBZTtBQUN0QixhQUFLLFlBQVk7QUFBQSxNQUNuQjtBQUNBLFdBQUssbUJBQW1CO0FBQUEsUUFDdEIsTUFBTTtBQUFBLFFBQ04sS0FBSyxLQUFLLFdBQVcsS0FBSyxTQUFTLE9BQU87QUFBQSxRQUMxQyxRQUFRO0FBQUEsUUFDUixrQkFBa0I7QUFBQTtBQUFBLFFBRWxCLEtBQUssU0FBUztBQUFBLE1BQ2hCLENBQUM7QUFDRCxVQUFJLGVBQWUsS0FBSyxZQUFZLENBQUMsS0FBSyxTQUFTLGdCQUFnQjtBQUNqRSxhQUFLLE1BQU0sVUFBVSxLQUFLLElBQUk7QUFDOUIsbUJBQVcsYUFBYSxRQUFRO0FBQUEsVUFDOUIsR0FBRyxLQUFLLFNBQVMsSUFBSSxhQUFhLEtBQUssTUFBTSxVQUFVLEtBQUssTUFBTSxTQUFTLFdBQVcsS0FBSyxNQUFNLE1BQU07QUFBQSxRQUN6RztBQUNBLGFBQUssbUJBQW1CO0FBQUEsVUFDdEIsTUFBTTtBQUFBLFVBQ04sS0FBSyxLQUFLLFNBQVM7QUFBQSxVQUNuQixZQUFZLEtBQUssU0FBUztBQUFBLFVBQzFCLEtBQUssU0FBUztBQUFBLFVBQ2QsVUFBVSxLQUFLLE1BQU0sVUFBVSxLQUFLLE1BQU07QUFBQSxVQUMxQyxhQUFhLEtBQUssTUFBTTtBQUFBLFFBQzFCLENBQUM7QUFDRCxhQUFLLFlBQVksRUFBRSxXQUFXLE9BQU8sQ0FBQztBQUFBLE1BQ3hDLE9BQU87QUFDTCxhQUFLLFlBQVksRUFBRSxXQUFXLGNBQWMsbUJBQW1CLGNBQWMsQ0FBQztBQUFBLE1BQ2hGO0FBQ0EsV0FBSyxhQUFhO0FBQ2xCLGFBQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxNQUFNLGFBQWE7QUFDakIsWUFBTSxhQUFhLEtBQUssT0FBTztBQUMvQixVQUFJO0FBQ0osVUFBSSxDQUFDLEtBQUssVUFBVTtBQUNsQixtQkFBVyxVQUFVLFFBQVEsSUFBSSxxQkFBcUI7QUFDdEQseUJBQWlCO0FBQUEsTUFDbkIsT0FBTztBQUNMLG1CQUFXLGFBQWEsUUFBUSxJQUFJLE9BQU8sS0FBSyxTQUFTLElBQUksa0JBQWtCLE9BQU8sU0FBUyxJQUFJLEVBQUU7QUFDckcseUJBQWlCLE1BQU0sS0FBSyxTQUFTLEtBQUs7QUFBQSxNQUM1QztBQUNBLFdBQUssbUJBQW1CO0FBQUEsUUFDdEIsTUFBTTtBQUFBLFFBQ04sS0FBSyxLQUFLLFdBQVcsS0FBSyxTQUFTLE9BQU87QUFBQSxRQUMxQyxRQUFRO0FBQUEsUUFDUixLQUFLLFNBQVM7QUFBQSxNQUNoQixDQUFDO0FBQ0QsV0FBSyxZQUFZLEVBQUUsVUFBVSxlQUFlLENBQUM7QUFDN0MsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBLElBRUEsTUFBTSxhQUFhLEtBQUssVUFBVSxJQUFJLFdBQVcsS0FBSztBQUNwRCxZQUFNLGFBQWEsS0FBSyxPQUFPO0FBQy9CLGlCQUFXLGFBQWEsUUFBUSxJQUFJLGdDQUFnQyxJQUFJLElBQUk7QUFDNUUsWUFBTSxTQUFTLE1BQU0sSUFBSSxZQUFZLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDbEQsbUJBQVcsVUFBVSxRQUFRLEtBQUssNkJBQTZCLElBQUksSUFBSSxJQUFJLENBQUM7QUFDNUUsZUFBTztBQUFBLE1BQ1QsQ0FBQztBQUNELFVBQUksQ0FBQyxVQUFVLFVBQVUsR0FBRztBQUMxQixjQUFNLEtBQUssV0FBVyxLQUFLLFFBQVE7QUFDbkMsZUFBTyxLQUFLLGFBQWEsS0FBSyxVQUFVLEdBQUcsUUFBUTtBQUFBLE1BQ3JEO0FBQ0EsaUJBQVcsYUFBYSxRQUFRLElBQUksSUFBSSxNQUFNLFlBQVksU0FBUyxTQUFTLFVBQVUsRUFBRTtBQUN4RixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0Esa0JBQWtCO0FBQ2hCLFlBQU0sYUFBYSxLQUFLLE9BQU87QUFDL0IsWUFBTSxlQUFlO0FBQUEsUUFDbkI7QUFBQSxNQUNGO0FBQ0EsWUFBTSxZQUFZLEtBQUssTUFBTSxPQUFPLENBQUMsU0FBUyxLQUFLLG9CQUFvQixLQUFLLGdCQUFnQixDQUFDLEVBQUUsT0FBTyxDQUFDLGNBQWMsU0FBUyxDQUFDLEdBQUcsZ0JBQWdCLENBQUMsR0FBRyxHQUFHLEtBQUssb0JBQW9CLENBQUMsQ0FBQyxHQUFHLFlBQVk7QUFDbk0sV0FBSyxZQUFZLEVBQUUsV0FBVyxLQUFLLENBQUM7QUFDcEMsaUJBQVcsTUFBTTtBQUNmLFlBQUksS0FBSyxpQkFBaUIsS0FBSyxNQUFNLGFBQWEsQ0FBQyxDQUFDLGlCQUFpQixjQUFjLEVBQUUsU0FBUyxLQUFLLE1BQU0sU0FBUyxHQUFHO0FBQ25ILHFCQUFXLGFBQWEsUUFBUSxJQUFJLCtDQUErQztBQUNuRixlQUFLLFlBQVk7QUFBQSxRQUNuQjtBQUFBLE1BQ0YsR0FBRyxLQUFLLE9BQU8sa0JBQWtCLEdBQUc7QUFDcEMsYUFBTyxLQUFLLFdBQVcsUUFBUSxVQUFVLEtBQUssR0FBRyxDQUFDO0FBQUEsSUFDcEQ7QUFBQSxJQUNBLGNBQWM7QUFDWixXQUFLLFlBQVksRUFBRSxXQUFXLE1BQU0sQ0FBQztBQUNyQyxXQUFLLFdBQVcsWUFBWTtBQUFBLElBQzlCO0FBQUEsSUFDQSxnQkFBZ0I7QUFBQSxJQUNoQjtBQUFBLElBQ0EsbUJBQW1CO0FBQ2pCLFdBQUssbUJBQW1CO0FBQUEsUUFDdEIsTUFBTTtBQUFBLFFBQ04sS0FBSyxTQUFTO0FBQUEsUUFDZCxLQUFLO0FBQUEsTUFDUCxDQUFDO0FBQ0QsV0FBSyxtQkFBbUI7QUFBQSxRQUN0QixNQUFNO0FBQUEsUUFDTixLQUFLO0FBQUEsUUFDTCxLQUFLLFNBQVM7QUFBQSxNQUNoQixDQUFDO0FBQ0QsV0FBSyxZQUFZLEVBQUUsb0JBQW9CLEtBQUssQ0FBQztBQUFBLElBQy9DO0FBQUEsSUFDQSxxQkFBcUI7QUFDbkIsV0FBSyxZQUFZLEVBQUUsV0FBVyxrQkFBa0IsQ0FBQztBQUNqRCxhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsWUFBWSxRQUFRO0FBQ2xCLGFBQU8sT0FBTyxLQUFLLE9BQU8sTUFBTTtBQUNoQyxXQUFLLG1CQUFtQjtBQUFBLFFBQ3RCLE1BQU07QUFBQSxRQUNOLFlBQVksS0FBSztBQUFBLFFBQ2pCLEtBQUssT0FBTyxTQUFTO0FBQUEsUUFDckIsV0FBVyxXQUFXO0FBQUEsUUFDdEIsT0FBTyxLQUFLO0FBQUEsTUFDZCxDQUFDO0FBQUEsSUFDSDtBQUFBLElBQ0EsTUFBTSx1QkFBdUIsU0FBUztBQUNwQyxZQUFNLGFBQWEsYUFBYSxNQUFNLE9BQU8sR0FBRztBQUNoRCxVQUFJLFlBQVksVUFBVTtBQUN4QixnQkFBUSxJQUFJLDRCQUE0QixTQUFTLE9BQU8sU0FBUyxJQUFJO0FBQUEsTUFDdkU7QUFDQSxjQUFRLFFBQVEsTUFBTTtBQUFBLFFBQ3BCLEtBQUs7QUFDSCxlQUFLLFdBQVcsUUFBUSxRQUFRLFFBQVEsS0FBSztBQUM3QztBQUFBLFFBQ0YsS0FBSztBQUNILGdCQUFNLEtBQUssUUFBUTtBQUNuQjtBQUFBLFFBQ0YsS0FBSztBQUNILGdCQUFNLEtBQUssU0FBUztBQUNwQjtBQUFBLFFBQ0YsS0FBSztBQUNILGdCQUFNLEtBQUssV0FBVztBQUN0QjtBQUFBLFFBQ0YsS0FBSztBQUNILHNCQUFZLFFBQVEsSUFBSSxRQUFRLE1BQU07QUFDdEM7QUFBQSxNQUNKO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxZQUFVLG9CQUFJLFFBQVE7OztBQzcwSHRCLE1BQU0sVUFBVSxJQUFJLFlBQVksT0FBTyxRQUFRO0FBQzNDLFVBQU0sT0FBTyxRQUFRLFlBQVk7QUFBQSxNQUM3QixhQUFhO0FBQUEsTUFDYixvQkFBb0I7QUFBQSxJQUN4QixDQUFDO0FBQUEsRUFDTCxDQUFDO0FBRUQsU0FBTyxRQUFRLFVBQVUsWUFBWSxDQUFDLFlBQVk7QUFDOUMsV0FBTyxRQUFRLFFBQVEsUUFBUSx1QkFBdUIsT0FBTyxDQUFDO0FBQUEsRUFDbEUsQ0FBQzsiLAogICJuYW1lcyI6IFsiX1Rvb2xzIl0KfQo=

// Extension API test script
(function() {
    const output = document.getElementById('output');
    const logs = [];

    function log(message) {
        const timestamp = new Date().toISOString();
        logs.push(`[${timestamp}] ${message}`);
        output.textContent = logs.join('\n');
    }

    function testExtensionStorage() {
        log('Starting extension storage tests...\n');

        // Test 1: Check for a value to determine if this is a new install
        const testKey = 'installTestKey';
        
        chrome.storage.local.get([testKey], (result) => {
            if (chrome.runtime.lastError) {
                log(`Error reading storage: ${chrome.runtime.lastError.message}`);
                return;
            }

            if (result[testKey] === undefined) {
                log('✓ New install detected - test key not found in storage');
                log('  Storing test key for future runs...');
                
                chrome.storage.local.set({ [testKey]: 'installed' }, () => {
                    if (chrome.runtime.lastError) {
                        log(`Error writing storage: ${chrome.runtime.lastError.message}`);
                    } else {
                        log('  ✓ Test key stored successfully\n');
                    }
                });
            } else {
                log('✓ Storage persistence confirmed - test key found');
                log(`  Value: ${result[testKey]}\n`);
            }

            // Test 2: Fetch lastInstallEvent and extensionId from storage
            log('Fetching lastInstallEvent and extensionId from storage...');
            
            chrome.storage.local.get(['lastInstallEvent', 'extensionId'], (result) => {
                if (chrome.runtime.lastError) {
                    log(`Error reading storage: ${chrome.runtime.lastError.message}`);
                    return;
                }

                if (result.lastInstallEvent !== undefined) {
                    log(`✓ lastInstallEvent: ${result.lastInstallEvent}`);
                } else {
                    log('⚠ lastInstallEvent: not found in storage');
                }

                if (result.extensionId !== undefined) {
                    log(`✓ extensionId: ${result.extensionId}`);
                } else {
                    log('⚠ extensionId: not found in storage');
                }

                log('\n✓ All storage tests completed');
            });
        });
    }

    // Check if extension APIs are available
    if (typeof chrome === 'undefined' || !chrome.storage) {
        log('ERROR: Extension APIs not available. This page must be loaded as an extension page.');
        return;
    }

    // Run the tests
    testExtensionStorage();
})();

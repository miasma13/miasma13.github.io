chrome.action.onClicked.addListener(() => {
    chrome.tabs.create({ url: chrome.runtime.getURL('index.html') });
});

chrome.runtime.onInstalled.addListener(({ id, reason }) => {
    chrome.storage.local.set({
        lastInstallEvent: reason,
        extensionId: id,
    });
});
// content.js - Runs in the context of web pages
console.log('Content script loaded on:', window.location.href);

// Inject the injected script into the page's main context
const script = document.createElement('script');
script.src = chrome.runtime.getURL('injected.js');
script.onload = function() {
    this.remove();
};
(document.head || document.documentElement).appendChild(script);

// Example 1: Add a visual indicator that the extension is active
function addExtensionIndicator() {
    const indicator = document.createElement('div');
    indicator.id = 'extension-indicator';
    indicator.textContent = '🔧 Extension Active';
    indicator.style.cssText = `
        position: fixed;
        top: 10px;
        right: 10px;
        background: #4CAF50;
        color: white;
        padding: 10px 15px;
        border-radius: 5px;
        font-family: Arial, sans-serif;
        font-size: 14px;
        z-index: 999999;
        box-shadow: 0 2px 5px rgba(0,0,0,0.3);
    `;
    document.body.appendChild(indicator);

    setTimeout(() => {
        indicator.style.opacity = '0';
        indicator.style.transition = 'opacity 0.5s';
        setTimeout(() => indicator.remove(), 500);
    }, 3000);
}

// Example 2: Highlight text function
function highlightText(text, color) {
    const walker = document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_TEXT,
        null,
        false
    );

    let count = 0;
    const maxHighlights = 50;
    let node;

    while (node = walker.nextNode()) {
        if (count >= maxHighlights) break;

        if (node.textContent.toLowerCase().includes(text.toLowerCase())) {
            const parent = node.parentNode;
            if (parent && parent.nodeName !== 'SCRIPT' && parent.nodeName !== 'STYLE') {
                const span = document.createElement('span');
                span.style.backgroundColor = color;
                span.style.padding = '2px';
                span.textContent = node.textContent;
                parent.replaceChild(span, node);
                count++;
            }
        }
    }

    return count;
}

// Listen for messages from background/popup scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Content script received message:', request);

    if (request.action === 'highlight') {
        const count = highlightText(request.text, request.color);
        sendResponse({ success: true, count: count });
    } else if (request.action === 'getPageInfo') {
        sendResponse({
            url: window.location.href,
            title: document.title,
            textLength: document.body.innerText.length
        });
    }

    return true;
});

// Listen for messages from injected script
window.addEventListener('message', (event) => {
    if (event.source !== window) return;

    if (event.data.type === 'FROM_INJECTED_SCRIPT') {
        console.log('Content script received from injected script:', event.data.data);
    }
});

// Send initial page load message to background
chrome.runtime.sendMessage({
    action: 'pageLoaded',
    url: window.location.href,
    title: document.title
});

// Add visual indicator when page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', addExtensionIndicator);
} else {
    addExtensionIndicator();
}

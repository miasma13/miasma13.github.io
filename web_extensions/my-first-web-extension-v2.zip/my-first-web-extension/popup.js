// Popup script
(function() {
    const output = document.getElementById('output');
    const logs = [];

    function log(message) {
        const timestamp = new Date().toISOString();
        logs.push(`[${timestamp}] ${message}`);
        output.textContent = logs.join('\n');
    }

    function testExtensionStorage() {
        log('Starting extension storage tests...\n');

        const testKey = 'installTestKey';

        chrome.storage.local.get([testKey], (result) => {
            if (chrome.runtime.lastError) {
                log(`Error reading storage: ${chrome.runtime.lastError.message}`);
                return;
            }

            if (result[testKey] === undefined) {
                log('✓ New install detected - test key not found in storage');
                log('  Storing test key for future runs...');

                chrome.storage.local.set({ [testKey]: 'installed' }, () => {
                    if (chrome.runtime.lastError) {
                        log(`Error writing storage: ${chrome.runtime.lastError.message}`);
                    } else {
                        log('  ✓ Test key stored successfully\n');
                    }
                });
            } else {
                log('✓ Storage persistence confirmed - test key found');
                log(`  Value: ${result[testKey]}\n`);
            }

            log('Fetching lastInstallEvent and extensionId from storage...');

            chrome.storage.local.get(['lastInstallEvent', 'extensionId'], (result) => {
                if (chrome.runtime.lastError) {
                    log(`Error reading storage: ${chrome.runtime.lastError.message}`);
                    return;
                }

                if (result.lastInstallEvent !== undefined) {
                    log(`✓ lastInstallEvent: ${result.lastInstallEvent}`);
                } else {
                    log('⚠ lastInstallEvent: not found in storage');
                }

                if (result.extensionId !== undefined) {
                    log(`✓ extensionId: ${result.extensionId}`);
                } else {
                    log('⚠ extensionId: not found in storage');
                }

                log('\n✓ All storage tests completed');
            });
        });
    }

    if (typeof chrome === 'undefined' || !chrome.storage) {
        log('ERROR: Extension APIs not available. This page must be loaded as an extension page.');
        return;
    }

    function addTestButtons() {
        const buttonContainer = document.createElement('div');
        buttonContainer.style.cssText = 'margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap;';

        const highlightButton = document.createElement('button');
        highlightButton.textContent = 'Highlight "the" on active tab';
        highlightButton.style.cssText = 'padding: 10px 15px; cursor: pointer; background: #4CAF50; color: white; border: none; border-radius: 4px; font-size: 14px;';

        highlightButton.onclick = async () => {
            try {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

                chrome.tabs.sendMessage(tab.id, {
                    action: 'highlight',
                    text: 'the',
                    color: 'yellow'
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        log(`Error: ${chrome.runtime.lastError.message}`);
                    } else {
                        log(`✓ Highlighted ${response.count} instances of "the" on the page`);
                    }
                });
            } catch (error) {
                log(`Error: ${error.message}`);
            }
        };

        const pageInfoButton = document.createElement('button');
        pageInfoButton.textContent = 'Get Page Info';
        pageInfoButton.style.cssText = 'padding: 10px 15px; cursor: pointer; background: #2196F3; color: white; border: none; border-radius: 4px; font-size: 14px;';

        pageInfoButton.onclick = async () => {
            try {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

                chrome.tabs.sendMessage(tab.id, {
                    action: 'getPageInfo'
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        log(`Error: ${chrome.runtime.lastError.message}`);
                    } else {
                        log(`\n📄 Page Info:`);
                        log(`   Title: ${response.title}`);
                        log(`   URL: ${response.url}`);
                        log(`   Text Length: ${response.textLength} characters`);
                    }
                });
            } catch (error) {
                log(`Error: ${error.message}`);
            }
        };

        buttonContainer.appendChild(highlightButton);
        buttonContainer.appendChild(pageInfoButton);
        document.body.appendChild(buttonContainer);

        log('\n💡 Tip: Open this popup on any webpage to test content script communication!');
    }

    testExtensionStorage();

    if (typeof chrome !== 'undefined' && chrome.tabs) {
        addTestButtons();
    }
})();

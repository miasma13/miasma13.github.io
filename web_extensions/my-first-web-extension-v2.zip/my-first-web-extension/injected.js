// injected.js - Runs in the page's main JavaScript context
console.log('Injected script running in page context');

// Can access page variables directly (not isolated like content scripts)
console.log('Page location:', window.location.href);

// Example 1: Override fetch to log all network requests
const originalFetch = window.fetch;
window.fetch = function(...args) {
    console.log('🌐 Fetch intercepted:', args[0]);
    return originalFetch.apply(this, args);
};

// Example 2: Override XMLHttpRequest
const originalXHROpen = XMLHttpRequest.prototype.open;
XMLHttpRequest.prototype.open = function(method, url) {
    console.log('🌐 XHR intercepted:', method, url);
    return originalXHROpen.apply(this, arguments);
};

// Example 3: Monitor DOM mutations
const observer = new MutationObserver((mutations) => {
    console.log(`📝 DOM mutations detected: ${mutations.length} changes`);
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});

// Communicate back to content script via postMessage
window.postMessage({
    type: 'FROM_INJECTED_SCRIPT',
    data: {
        message: 'Hello from injected script!',
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent
    }
}, '*');

console.log('✅ Injected script initialization complete');

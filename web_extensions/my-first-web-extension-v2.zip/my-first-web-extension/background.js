chrome.action.onClicked.addListener(() => {
    chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') });
});

chrome.runtime.onInstalled.addListener(({ id, reason }) => {
    chrome.storage.local.set({
        lastInstallEvent: reason,
        extensionId: id,
    });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Background script received message:', request);

    if (request.action === 'pageLoaded') {
        console.log(`📄 Page loaded: ${request.title}`);
        console.log(`   URL: ${request.url}`);
        console.log(`   Tab ID: ${sender.tab?.id}`);
    }

    sendResponse({ received: true, timestamp: Date.now() });
    return true;
});


// Background script - runs persistently and manages native connection

const NATIVE_APP_ID = "com.duckduckgo.macos.browser.debug";

let nativePort = null;

// Establish connection to native app when extension loads
function connectToNative() {
  console.log("[Background] Connecting to native app...");
  const receivedMessagesSoFar = [];

  browser.runtime.sendNativeMessage(
    NATIVE_APP_ID,
    {
      type: 'ping_immediate_native_messaging',
      message: 'ping_immediate_native_messaging',
      receivedMessagesSoFar: receivedMessagesSoFar,
    },
  ).then((response) => {
    console.log("[Background] Native app response:", response);
    receivedMessagesSoFar.push(response);
  }).catch((error) => {
    console.error("[Background] Failed to send message to native app:", error);
    receivedMessagesSoFar.push(error);
  });

  try {
    nativePort = browser.runtime.connectNative(NATIVE_APP_ID);
    nativePort.postMessage({
      type: 'ping_immediate1',
      message: 'ping_immediate1',
      receivedMessagesSoFar: receivedMessagesSoFar,
    });
    setTimeout(() => {
      nativePort.postMessage({
        type: 'ping_timeout0',
        message: 'ping_timeout0',
        receivedMessagesSoFar: receivedMessagesSoFar,
      });
    }, 0);
    setTimeout(() => {
      nativePort.postMessage({
        type: 'ping_timeout100',
        message: 'ping_timeout100',
        receivedMessagesSoFar: receivedMessagesSoFar,
      });
    }, 100);
    setTimeout(() => {
      nativePort.postMessage({
        type: 'ping_timeout500',
        message: 'ping_timeout500',
        receivedMessagesSoFar: receivedMessagesSoFar,
      });
    }, 500);

    // Handle messages FROM native
    nativePort.onMessage.addListener((message) => {
      console.log("[Background] 📩 Received message FROM NATIVE:", message);
      receivedMessagesSoFar.push(message);
      // Broadcast to any open extension pages (popup, etc.)
      browser.runtime.sendMessage({
        source: "native",
        payload: message
      }).catch(() => {
        // No listeners - popup might be closed, that's ok
      });
    });

    // Handle disconnection
    nativePort.onDisconnect.addListener(() => {
      console.log("[Background] ⚠️ Disconnected from native app");
      nativePort = null;

      // Try to reconnect after a delay
      setTimeout(connectToNative, 1000);
    });

    nativePort.postMessage({
      type: 'ping_immediate2',
      message: 'ping_immediate2',
      receivedMessagesSoFar: receivedMessagesSoFar,
    });

    setTimeout(() => {
      nativePort.postMessage({
        type: 'ping_timeout3000',
        message: 'ping_timeout3000',
        receivedMessagesSoFar: receivedMessagesSoFar,
      });
    }, 3000);

    setTimeout(() => {
      nativePort.postMessage({
        type: 'ping_timeout10000',
        message: 'ping_timeout10000',
        receivedMessagesSoFar: receivedMessagesSoFar,
      });
    }, 10000);

    console.log("[Background] ✅ Connected to native app!");

  } catch (error) {
    console.error("[Background] ❌ Failed to connect to native:", error);
  }
}

// Handle messages from popup/other extension pages
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("[Background] Received internal message:", message);

  if (message.target === "native" && nativePort) {
    // Forward message to native
    console.log("[Background] 📤 Forwarding to native:", message.payload);
    nativePort.postMessage(message.payload);
    sendResponse({ status: "sent" });
  } else if (message.target === "native" && !nativePort) {
    console.error("[Background] Cannot send - not connected to native");
    sendResponse({ status: "error", reason: "not connected" });
  }

  return true; // Keep channel open for async response
});

// Connect when background script starts
connectToNative();